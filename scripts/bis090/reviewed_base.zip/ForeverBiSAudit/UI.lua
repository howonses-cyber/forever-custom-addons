local _,B=...
local frame,scroll,child,detail,selected,popup,search,counts
local classBtn,specBtn,slotBtn,limitBtn,lockedBtn,unknownBtn,sideBtn,tooltipBtn,modeBtn
local dscroll,dc,summary
local collapsed={}
local modeLabels={auto='자동 추천',guide='전문 가이드',setup='전체 추천 세팅',reference='스탯 참고 순위',documented='출처 명시 장비'}
local rows,headers={},{}
local function text(p,size,r,g,b)
 local f=p:CreateFontString(nil,'OVERLAY','GameFontNormal')
 if f.SetFont then pcall(f.SetFont,f,'Fonts\\2002.TTF',size or 12,'OUTLINE') end
 f:SetTextColor(r or .9,g or .93,b or .97);f:SetJustifyH('LEFT');f:SetJustifyV('MIDDLE');return f
end
local function tint(p,r,g,b,a)
 local t=p:CreateTexture(nil,'BACKGROUND');t:SetAllPoints();t:SetColorTexture(r,g,b,a or 1);return t
end
local function edge(p,r,g,b)
 for i=1,4 do local e=p:CreateTexture(nil,'BORDER');e:SetColorTexture(r,g,b,1)
  if i==1 then e:SetHeight(1);e:SetPoint('TOPLEFT');e:SetPoint('TOPRIGHT')
  elseif i==2 then e:SetHeight(1);e:SetPoint('BOTTOMLEFT');e:SetPoint('BOTTOMRIGHT')
  elseif i==3 then e:SetWidth(1);e:SetPoint('TOPLEFT');e:SetPoint('BOTTOMLEFT')
  else e:SetWidth(1);e:SetPoint('TOPRIGHT');e:SetPoint('BOTTOMRIGHT') end end
end
local function button(p,label,w,h,fn)
 local b=CreateFrame('Button',nil,p);b:SetSize(w,h);local bg=tint(b,.13,.18,.24,1)
 b.label=text(b,12,.91,.94,.98);b.label:SetAllPoints();b.label:SetJustifyH('CENTER');b.label:SetText(label)
 b:SetScript('OnClick',function(self) if fn then fn(self) end end)
 b:SetScript('OnEnter',function()bg:SetColorTexture(.20,.29,.38,1)end)
 b:SetScript('OnLeave',function()bg:SetColorTexture(.13,.18,.24,1)end);return b
end
local function closeMenu() if popup then popup:Hide() end end
local function menu(anchor,entries,current,choose)
 if popup and popup:IsShown() and popup.anchor==anchor then closeMenu();return end
 if popup then popup:Hide() else
  popup=CreateFrame('Frame',nil,frame);popup:SetFrameStrata('DIALOG');popup:SetFrameLevel(100);popup:EnableMouse(true);popup.buttons={}
  tint(popup,.075,.10,.15,1);edge(popup,.35,.44,.53)
 end
 popup.anchor=anchor;popup:ClearAllPoints();popup:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-3)
 local width=math.max(anchor:GetWidth(),182);local h=24
 popup:SetSize(width,#entries*h+8)
 for _,b in ipairs(popup.buttons) do b:Hide() end
 for i,e in ipairs(entries) do
  local b=popup.buttons[i]
  if not b then b=button(popup,'',width-8,h,function(self) local val=self.entry.value;closeMenu();self.choose(val) end);popup.buttons[i]=b end
  b:SetSize(width-8,h);b:ClearAllPoints();b:SetPoint('TOPLEFT',popup,'TOPLEFT',4,-4-(i-1)*h)
  b.entry=e;b.choose=choose;b.label:SetText((current==e.value and '✓  ' or '    ')..e.label);b:Show()
 end
 popup:Show()
end
local function specLabel()
 for _,s in ipairs(B.specs[B.db.class] or {}) do if s.key==B.db.spec then return s.label end end
 return B.db.spec or '-'
end
local function opts()
 local side=UnitFactionGroup and UnitFactionGroup('player') or nil
 return {mode=B.db.rankMode,slot=B.db.slot or 'all',search=B.db.search or '',top=B.db.top or 5,locked=B.db.showLocked,unknown=B.db.showUnknown,sideOnly=B.db.sideOnly,faction=side}
end
local function identity(row) return row and (row.class..':'..row.spec..':'..row.slot..':'..tostring(row.itemId or row.name)..':'..tostring(row.mode or '')..':'..tostring(row.variant and row.name or '')) end
local function rankText(r) return B:RankLabel(r,B:RankMode(B.db.class,B.db.spec,B.db.rankMode)) end
local function status(r)
 if r.status=='locked' then return '획득 제한',1,.48,.43 end
 if r.phaseUnknown then return '개방 미확인',1,.72,.36 end
 if r.status=='unknown' then return '출처 확인 필요',1,.72,.36 end
 if r.faction=='Alliance' then return '얼라이언스',.55,.78,1 end
 if r.faction=='Horde' then return '호드',1,.59,.46 end
 return '출처 명시',.55,.81,.71
end
local function setDetail(r)
 local changed=identity(selected)~=identity(r);selected=r;if not detail then return end
 if changed and dscroll then dscroll:SetVerticalScroll(0) end
 if not r then
  detail.title:SetText('선택할 장비 없음');detail.rank:SetText('');detail.desc:SetText('검색 조건이나 획득 제한 필터를 변경하세요. 확인되지 않은 순위는 임의로 채우지 않습니다.');detail.compare:SetText('');detail.url:SetText('');detail.source:SetText('');detail.icon:SetTexture('Interface\\Icons\\INV_Misc_QuestionMark');return
 end
 local v=B:RankInfo(r,true);detail.title:SetText(B:RankItemName(r,true));detail.icon:SetTexture(B:RankIcon(r));detail.rank:SetText(rankText(r)..'  ·  '..(B.slotNames[r.slot] or r.slot)..'  ·  '..status(r))
 local owned,worn=B:RankOwned(r)
 local lines={'획득 방법',B:RankAcquisition(r)}
 if r.mode=='guide' then lines[#lines+1]='평가: 전문 가이드 추천 등급 · 동순위 가능' else lines[#lines+1]='평가: 외부 사이트의 개별 스탯 참고 순위 (최종 비스 아님)' end
 if r.setOrder then lines[#lines+1]='전체 추천 세팅 포함 · 세트 효과 및 장비 조합에 유의' end
 if r.mode=='guide' and r.class=='ROGUE' and r.spec=='combat' then lines[#lines+1]='세팅 참고: 데빌사우루스 2세트 적중 2% / 검은장막 4세트 기력 회복 발동' elseif r.mode=='guide' and r.class=='SHAMAN' and r.spec=='enhancement' then lines[#lines+1]='세팅 참고: 우레의 다섯 6세트 주문력 23 / 전문 가이드 적중 목표 8% (무기 숙련·특성에 따라 달라짐)' end
 if r.weaponGroup then lines[#lines+1]='무기 유형: '..r.weaponGroup end
 if r.rankScore then lines[#lines+1]='원본 스탯 점수: '..r.rankScore..'%' end
 if r.unique then lines[#lines+1]='고유 착용: 중복 장착 불가' end
 if r.nameKind~='verified' and not (v and v.name and v.name:find('[\234-\237]')) then lines[#lines+1]='원문 식별명: '..r.name end
 if r.itemId then lines[#lines+1]='아이템 ID: '..r.itemId end
 if r.duplicateName then lines[#lines+1]='동일 이름의 다른 아이템과 ID가 다릅니다.' end
 if r.note then lines[#lines+1]=r.note end
 if r.phaseUnknown then lines[#lines+1]='콘텐츠 개방 여부 미확인' end
 if r.requiredLevel then lines[#lines+1]='요구 레벨: '..r.requiredLevel end
 if r.faction and r.faction~='Both' then local side=UnitFactionGroup and UnitFactionGroup('player');lines[#lines+1]='진영: '..(r.faction=='Alliance' and '얼라이언스' or '호드')..(side and side~=r.faction and ' · 현재 진영 획득 제한' or '') end
 if r.setName then lines[#lines+1]='세트: '..r.setName end
 if r.variant then lines[#lines+1]='무작위 옵션 아이템: 실제 옵션 별도 확인' end
 if r.sourceKo and r.sourceKo:find('[A-Za-z]') and r.source and r.source~=r.sourceKo then lines[#lines+1]='획득처 원문: '..r.source end
 if worn then lines[#lines+1]='현재 착용 중' elseif owned then lines[#lines+1]='가방 보유' end
 if not v then lines[#lines+1]='한글명·툴팁: 게임 데이터 로딩 중 또는 조회 불가' end
 detail.desc:SetText(table.concat(lines,'\n'));if dc and detail.desc.GetStringHeight then local h=detail.desc:GetStringHeight();if type(h)=='number' then dc:SetHeight(math.max(dscroll:GetHeight(),h+14)) end end
 detail.url:SetText(r.url or '');detail.url:SetCursorPosition(0)
 detail.source:SetText((r.mode=='guide' and '와우헤드 포에버 · 전문 추천' or '외부 자료 · 개별 스탯 참고')..' · '..(r.checked or '-')..'\n실제 서버 개방·획득 보증 아님')
 local link=B:RankLink(r)
 local player=UnitClass and select(2,UnitClass('player')) or B.db.class
 if B.db.class~=player then detail.compare:SetText('다른 직업을 열람 중: 현재 착용 비교 생략');return end
 if r.faction and r.faction~='Both' and UnitFactionGroup and UnitFactionGroup('player')~=r.faction then detail.compare:SetText('다른 진영의 장비: 착용 비교 보류');return end
 if not link then detail.compare:SetText('아이템 정보 로딩 중 · 툴팁에서 확인하거나 새로고침');return end
 if r.variant then detail.compare:SetText('무작위 옵션이 확정되지 않아 점수 비교 보류');return end
 if r.unique then local own,worn=B:RankOwned(r);if worn then detail.compare:SetText('고유 착용 아이템: 이미 착용 중 · 중복 장착 불가');return end end
 local ok,c,why=pcall(function() return B:VerifiedEquipPercent(link,B.db.class,B.db.spec,B:ResolveEquipLocation(link),r.slot) end)
 if not ok or not c then detail.compare:SetText('Pawn 비교 보류: '..tostring(ok and why or '조회 실패'));return end
 local s='착용: '..tostring(c.comparedName or '-')..'\n'
 if c.pct~=nil then s=s..string.format('Pawn 스탯 점수: %+.1f%%',c.pct) else s=s..'기준 점수 0 · % 비교 불가' end
 detail.compare:SetText(s..'\n세트·발동 효과 제외, 실제 DPS/HPS 아님')
end
function B:RefreshRankDetail() if selected then setDetail(selected) end end
local function makeRow()
 local r=CreateFrame('Button',nil,child);r:SetHeight(48);r.bg=tint(r,.095,.125,.17,.96)
 r.icon=r:CreateTexture(nil,'ARTWORK');r.icon:SetSize(34,34);r.icon:SetPoint('LEFT',r,'LEFT',68,0);r.icon:SetTexCoord(.07,.93,.07,.93)
 r.rank=text(r,12,1,.78,.34);r.rank:SetPoint('LEFT',r,'LEFT',5,0);r.rank:SetWidth(60);r.rank:SetJustifyH('CENTER')
 r.name=text(r,13,.91,.94,.99);r.name:SetPoint('TOPLEFT',r,'TOPLEFT',111,-5);r.name:SetPoint('TOPRIGHT',r,'TOPRIGHT',-147,-5);r.name:SetHeight(19)
 r.source=text(r,11,.66,.76,.84);r.source:SetPoint('TOPLEFT',r,'TOPLEFT',111,-25);r.source:SetPoint('TOPRIGHT',r,'TOPRIGHT',-9,-25);r.source:SetHeight(17)
 r.flag=text(r,10,.65,.8,.8);r.flag:SetWidth(140);r.flag:SetHeight(18);r.flag:SetJustifyH('RIGHT');r.flag:SetPoint('TOPRIGHT',r,'TOPRIGHT',-7,-5)
 r:SetScript('OnClick',function(self)if not self.item then return end;if IsShiftKeyDown and IsShiftKeyDown() then B:RankChatLink(self.item) else setDetail(self.item);B:RefreshRankVisuals() end end)
 r:SetScript('OnEnter',function(self) self.hover=true;B:RefreshRankRow(self);if self.item then B:RankTooltip(self,self.item) end end)
 r:SetScript('OnLeave',function(self) self.hover=false;B:RefreshRankRow(self);if GameTooltip then GameTooltip:Hide() end end)
 return r
end
function B:RefreshRankRow(row)
 local r=row.item;if not r then return end
 local v=self:RankInfo(r,true);local name=self:RankItemName(r,false)
 row.name:SetText(name..(r.duplicateName and (' ['..r.itemId..']') or ''));row.icon:SetTexture(self:RankIcon(r));row.rank:SetText(rankText(r));row.source:SetText(self:RankSourceLabel(r))
 local flag,red,g,b=status(r);local own,worn=self:RankOwned(r);if worn then flag='착용 · '..flag elseif own then flag='보유 · '..flag end
 row.flag:SetText(flag);row.flag:SetTextColor(red,g,b)
 if v and v.quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[v.quality] then local c=ITEM_QUALITY_COLORS[v.quality];row.name:SetTextColor(c.r,c.g,c.b) else row.name:SetTextColor(.9,.93,.98) end
 if r.rank==1 then row.rank:SetTextColor(1,.79,.36) elseif r.rank==2 then row.rank:SetTextColor(.80,.86,.94) else row.rank:SetTextColor(.65,.74,.83) end
 if identity(r)==identity(selected) then row.bg:SetColorTexture(.18,.30,.42,1) elseif row.hover then row.bg:SetColorTexture(.17,.23,.31,1) else row.bg:SetColorTexture(.095,.125,.17,.96) end
end
function B:RefreshRankVisuals()
 if not frame or not frame:IsShown() then return end
 for _,row in ipairs(rows) do if row:IsShown() then self:RefreshRankRow(row) end end
end
local function refreshList(preserve)
 if not child then return end
 local old=preserve and scroll:GetVerticalScroll() or 0;local key=identity(selected)
 for _,row in ipairs(rows) do row:Hide();row.item=nil end
 for _,h in ipairs(headers) do h:Hide() end
 local data=B:RankEntries(B.db.class,B.db.spec,opts());local y,n,hn=0,0,0;local last,found
 local width=math.max(300,scroll:GetWidth()-2);child:SetWidth(width)
 for _,r in ipairs(data) do
  if last~=r.slot then
   last=r.slot;hn=hn+1;local h=headers[hn]
   if not h then h=CreateFrame('Button',nil,child);h:SetHeight(27);tint(h,.16,.21,.29,1);h.label=text(h,12,.94,.81,.52);h.label:SetPoint('LEFT',h,'LEFT',9,0);h:SetScript('OnClick',function(self)collapsed[self.slot]=not collapsed[self.slot];refreshList(true) end);headers[hn]=h end
   h:SetWidth(width);h:ClearAllPoints();h:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);h.slot=r.slot;h.label:SetText((collapsed[r.slot] and '▶ ' or '▼ ')..(B.slotNames[r.slot] or r.slot));h:Show();y=y+30
  end
  if not collapsed[r.slot] then n=n+1;local row=rows[n];if not row then row=makeRow();rows[n]=row end
  row.item=r;row.hover=false;row:SetWidth(width);row:ClearAllPoints();row:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);row:Show();y=y+50
  if identity(r)==key then found=r end end
 end
 child:SetHeight(math.max(y+4,scroll:GetHeight()));local nextSelected=found or (n>0 and rows[1].item or nil)
 scroll:SetVerticalScroll(math.min(old,math.max(0,y-scroll:GetHeight())))
 local mode=B:RankMode(B.db.class,B.db.spec,B.db.rankMode)
 counts:SetText(string.format('표시 %d개 · %s · %s',n,modeLabels[mode] or '',B:RankHasGuide(B.db.class,B.db.spec) and '전문 가이드 확보' or '전문 가이드 미검증'))
 if summary then summary:SetText(mode=='setup' and '전체 세팅은 출처 추천 조합입니다. 진영·획득 조건 및 적중을 확인하세요.' or mode=='guide' and '동일 추천 등급은 공동 순위. 세트 조합은 전체 추천 세팅에서 확인.' or mode=='documented' and '출처 명시 장비만 표시. 실제 서버 획득을 보증하지 않습니다.' or '개별 스탯 참고 자료이며 최종 비스 순위가 아닙니다.') end
 setDetail(nextSelected);B:RefreshRankVisuals()
end
function B:RefreshUI(preserve)
 if not frame or not self.db then return end
 classBtn.label:SetText((self.classNames[self.db.class] or self.db.class)..'  ▼');specBtn.label:SetText(specLabel()..'  ▼')
 slotBtn.label:SetText((self.slotNames[self.db.slot] or '전체 부위')..'  ▼');limitBtn.label:SetText('상위 '..(self.db.top or 5)..'개  ▼')
 modeBtn.label:SetText((modeLabels[self.db.rankMode] or modeLabels.auto)..' ▼');lockedBtn.label:SetText(self.db.showLocked and '제한 포함' or '제한 제외');unknownBtn.label:SetText(self.db.showUnknown and '미확인 포함' or '미확인 제외');sideBtn.label:SetText(self.db.sideOnly and '내 진영' or '모든 진영');tooltipBtn.label:SetText(self.db.showTooltip and '가방 비교 켬' or '가방 비교 끔')
 refreshList(preserve)
end
function B:BuildUI()
 if frame or not CreateFrame or not UIParent then return end
 local db=self.db;db.rankMode=modeLabels[db.rankMode] and db.rankMode or 'auto';db.slot=type(db.slot)=='string' and db.slot or 'all';db.top=tonumber(db.top) or 5;db.search=type(db.search)=='string' and db.search or '';if db.sideOnly==nil then db.sideOnly=true end
 frame=CreateFrame('Frame','ForeverBiSAuditMainFrame',UIParent);frame:SetSize(1000,650);frame:SetFrameStrata('HIGH');frame:SetToplevel(true);frame:EnableMouse(true);frame:SetMovable(true);frame:RegisterForDrag('LeftButton');frame:SetClampedToScreen(true)
 frame:SetPoint('CENTER',UIParent,'CENTER',db.ui.x or 0,db.ui.y or 0);local pw,ph=UIParent:GetWidth(),UIParent:GetHeight();if pw and ph and pw>100 and ph>100 then frame:SetScale(math.max(.3,math.min(tonumber(db.ui.zoom) or 1,(pw-24)/1000,(ph-24)/650))) end;tint(frame,.055,.075,.105,.98);edge(frame,.30,.38,.48)
 frame:SetScript('OnDragStart',function(f)f:StartMoving()end);frame:SetScript('OnDragStop',function(f)f:StopMovingOrSizing();local _,_,_,x,y=f:GetPoint();db.ui.x=x or 0;db.ui.y=y or 0 end);frame:SetScript('OnHide',closeMenu);frame:SetScript('OnMouseDown',closeMenu)
 if UISpecialFrames then UISpecialFrames[#UISpecialFrames+1]='ForeverBiSAuditMainFrame' end
 local title=text(frame,20,.98,.83,.48);title:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-14);title:SetText('FOREVER BiS  |cffffffffV'..self.version..'|r')
 local subtitle=text(frame,11,.64,.75,.86);subtitle:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-42);subtitle:SetText('레이드 이전 장비 · 전문 가이드 / 참고 순위 / 착용 비교')
 local close=button(frame,'×',32,29,function()frame:Hide()end);close:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-14,-12)
 local refresh=button(frame,'아이템 재조회',115,29,function()self:RankRetry();self:RefreshUI(true)end);refresh:SetPoint('RIGHT',close,'LEFT',-8,0)
 local sizeBtn=button(frame,'화면 크기 ▼',100,29,function(a)menu(a,{{value=.80,label='80%'},{value=.9,label='90%'},{value=1,label='100%'},{value=1.1,label='110%'}},db.ui.zoom or 1,function(v)db.ui.zoom=v;local cap=math.min((UIParent:GetWidth()-24)/1000,(UIParent:GetHeight()-24)/650);frame:SetScale(math.min(v,math.max(.3,cap)))end)end);sizeBtn:SetPoint('RIGHT',refresh,'LEFT',-8,0)
 classBtn=button(frame,'직업',140,31,function(a)local list={};for _,c in ipairs(B.classOrder) do list[#list+1]={value=c,label=B.classNames[c]} end;menu(a,list,db.class,function(v)db.search='';search:SetText('');B:SetClass(v)end)end);classBtn:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-65)
 specBtn=button(frame,'특성',172,31,function(a)local list={};for _,s in ipairs(B.specs[db.class] or {}) do list[#list+1]={value=s.key,label=s.label} end;menu(a,list,db.spec,function(v)db.search='';search:SetText('');B:SetSpec(v)end)end);specBtn:SetPoint('LEFT',classBtn,'RIGHT',8,0)
 slotBtn=button(frame,'전체 부위',132,31,function(a)local list={{value='all',label='전체 부위'}};for _,s in ipairs(B.slotOrder) do list[#list+1]={value=s,label=B.slotNames[s]} end;menu(a,list,db.slot,function(v)db.slot=v;B:RefreshUI()end)end);slotBtn:SetPoint('LEFT',specBtn,'RIGHT',8,0)
 limitBtn=button(frame,'상위 5개',108,31,function(a)menu(a,{{value=3,label='상위 3개'},{value=5,label='상위 5개'},{value=10,label='상위 10개'}},db.top,function(v)db.top=v;B:RefreshUI()end)end);limitBtn:SetPoint('LEFT',slotBtn,'RIGHT',8,0)
 search=CreateFrame('EditBox',nil,frame,'InputBoxTemplate');search:SetAutoFocus(false);search:SetSize(340,31);search:SetPoint('LEFT',limitBtn,'RIGHT',17,0);search:SetText(db.search);search:SetScript('OnEscapePressed',function(e)e:ClearFocus()end);search:SetScript('OnEnterPressed',function(e)e:ClearFocus()end)
 search:SetScript('OnTextChanged',function(e)if db.search~=e:GetText() then db.search=e:GetText();B:RefreshUI() end end)
 local searchHint=text(frame,10,.60,.68,.77);searchHint:SetPoint('TOPLEFT',search,'BOTTOMLEFT',0,-3);searchHint:SetText('아이템명 / 획득처 / 번호 검색')
 lockedBtn=button(frame,'제한 제외',130,27,function()db.showLocked=not db.showLocked;B:RefreshUI()end);lockedBtn:SetPoint('TOPLEFT',classBtn,'BOTTOMLEFT',0,-12)
 unknownBtn=button(frame,'미확인 포함',130,27,function()db.showUnknown=not db.showUnknown;B:RefreshUI()end);unknownBtn:SetPoint('LEFT',lockedBtn,'RIGHT',8,0)
 sideBtn=button(frame,'내 진영',130,27,function()db.sideOnly=not db.sideOnly;B:RefreshUI()end);sideBtn:SetPoint('LEFT',unknownBtn,'RIGHT',8,0)
 tooltipBtn=button(frame,'가방 비교 켬',130,27,function()db.showTooltip=not db.showTooltip;B:RefreshUI(true)end);tooltipBtn:SetPoint('LEFT',sideBtn,'RIGHT',8,0)
 modeBtn=button(frame,'자동 추천',176,27,function(a)local list={};for _,v in ipairs({'auto','guide','setup','reference','documented'}) do list[#list+1]={value=v,label=modeLabels[v]} end;menu(a,list,db.rankMode,function(v)db.rankMode=v;B:RefreshUI()end)end);modeBtn:SetPoint('LEFT',tooltipBtn,'RIGHT',8,0)
 summary=text(frame,11,.7,.8,.9);summary:SetPoint('TOPLEFT',frame,'TOPLEFT',19,-135);summary:SetText('')
 local left=CreateFrame('Frame',nil,frame);left:SetSize(570,427);left:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-163);tint(left,.075,.10,.14,1);edge(left,.24,.32,.42)
 scroll=CreateFrame('ScrollFrame','ForeverBiSAuditItemScroll',left,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',left,'TOPLEFT',7,-7);scroll:SetPoint('BOTTOMRIGHT',left,'BOTTOMRIGHT',-26,7);child=CreateFrame('Frame',nil,scroll);child:SetSize(530,400);scroll:SetScrollChild(child)
 local right=CreateFrame('Frame',nil,frame);right:SetSize(386,427);right:SetPoint('TOPLEFT',left,'TOPRIGHT',8,0);tint(right,.08,.11,.15,1);edge(right,.24,.32,.42)
 detail={};detail.icon=right:CreateTexture(nil,'ARTWORK');detail.icon:SetSize(44,44);detail.icon:SetPoint('TOPLEFT',right,'TOPLEFT',13,-13)
 detail.title=text(right,16,1,.85,.5);detail.title:SetPoint('TOPLEFT',detail.icon,'TOPRIGHT',10,0);detail.title:SetSize(300,43);detail.title:SetJustifyV('TOP')
 detail.rank=text(right,12,.75,.87,.98);detail.rank:SetPoint('TOPLEFT',right,'TOPLEFT',13,-66);detail.rank:SetSize(360,22)
 local show=button(right,'아이템 툴팁',170,27,function(a)B:RankTooltip(a,selected)end);show:SetPoint('TOPLEFT',right,'TOPLEFT',13,-93);show:SetScript('OnEnter',function(a)B:RankTooltip(a,selected)end);show:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
 local chat=button(right,'채팅 링크',170,27,function()if selected then B:RankChatLink(selected) end end);chat:SetPoint('LEFT',show,'RIGHT',8,0)
 dscroll=CreateFrame('ScrollFrame','ForeverBiSAuditDetailScroll',right,'UIPanelScrollFrameTemplate');dscroll:SetPoint('TOPLEFT',right,'TOPLEFT',13,-130);dscroll:SetSize(343,153);dc=CreateFrame('Frame',nil,dscroll);dc:SetSize(337,360);dscroll:SetScrollChild(dc)
 detail.desc=text(dc,12,.87,.92,.96);detail.desc:SetPoint('TOPLEFT',dc,'TOPLEFT',0,0);detail.desc:SetWidth(331);detail.desc:SetJustifyV('TOP')
 detail.compare=text(right,12,.57,.91,.74);detail.compare:SetPoint('TOPLEFT',right,'TOPLEFT',13,-292);detail.compare:SetSize(355,66);detail.compare:SetJustifyV('TOP')
 detail.url=CreateFrame('EditBox',nil,right,'InputBoxTemplate');detail.url:SetSize(350,24);detail.url:SetAutoFocus(false);detail.url:SetPoint('TOPLEFT',right,'TOPLEFT',17,-368);detail.url:SetScript('OnEditFocusGained',function(e)e:HighlightText()end);detail.url:SetScript('OnEscapePressed',function(e)e:ClearFocus()end)
 detail.source=text(right,10,.62,.74,.85);detail.source:SetPoint('TOPLEFT',right,'TOPLEFT',13,-394);detail.source:SetSize(358,30);detail.source:SetJustifyV('TOP')
 counts=text(frame,11,.68,.84,.92);counts:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',18,32);local foot=text(frame,10,.75,.77,.80);foot:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',18,12);foot:SetText('쉬프트+클릭: 아이템 링크 · 공식 한글명은 게임 조회 우선 · 참고 순위와 착용 점수는 별개')
 B.frame=frame;B.detail=detail;B.rankRows=rows;B.rankSearch=search;B.rankClassButton=classBtn;B.rankSpecButton=specBtn;B.rankModeButton=modeBtn;frame:Hide();self:RefreshUI()
end

local root=ADDON_ROOT
local b={};local function load(n) assert(loadfile(root..n))('ForeverBiSAudit',b) end
load('Specs.lua');load('RankedData.lua');load('RankedRuntime.lua')
local n=0;local function ck(ok,msg)n=n+1;assert(ok,msg) end
local profiles,ref,guide,loc,unique={},{},{},{},{}
local rc,gc=0,0
for _,r in ipairs(b.catalog) do
 ck(type(r.itemId)=='number' and r.itemId>0 and r.slot and r.name,'valid record')
 if r.mode=='reference' then rc=rc+1;profiles[r.class..':'..r.spec]=true else gc=gc+1 end
 if r.nameKind=='verified' then loc[r.itemId]=true end
 if r.mode=='guide' then ck(r.tier>=1 and r.tier<=4 and r.url:find('wowhead.com/forever',1,true),'guide evidence') end
end
local pc,lc=0,0;for _ in pairs(profiles) do pc=pc+1 end;for _ in pairs(loc) do lc=lc+1 end
ck(pc==28 and rc==4283 and gc==125 and lc>=852,'production counts')
local function find(rows,id) for _,r in ipairs(rows) do if r.itemId==id then return r end end end
local sh=b:RankEntries('SHAMAN','enhancement',{mode='auto',unknown=true,locked=true});ck(find(sh,19323) and find(sh,22395),'enhancement weapon and relic');ck(not find(sh,19323).phaseUnknown or find(sh,19323).status~='reference','phase uncertainty')
local sr=b:RankEntries('SHAMAN','enhancement',{mode='setup'});ck(#sr==16,'shaman setup slots');ck(find(sr,19323).slot=='TwoHand','setup two-hand');ck(find(sr,22395).slot=='Relic','setup relic')
local rr=b:RankEntries('ROGUE','combat',{mode='setup'});ck(#rr==17,'rogue setup slots');ck(find(rr,15063) and find(rr,15062) and find(rr,260205),'rogue set synergy');ck(find(rr,1728).slot=='MainHand','main hand identity');ck(find(rr,260205).faction=='Alliance','faction identity')
local only=b:RankEntries('ROGUE','combat',{mode='guide',unknown=true,locked=true,sideOnly=true,faction='Horde'});ck(not find(only,260205),'faction filter');ck(b:RankMode('MAGE','frost','auto')=='reference','unreviewed profile is reference');ck(#b:RankEntries('MAGE','frost',{mode='guide',unknown=true})==0,'do not fabricate guide data')
local documented=b:RankEntries('ROGUE','combat',{mode='documented',unknown=true,locked=true});for _,r in ipairs(documented) do ck(r.status=='reference' and not r.phaseUnknown and not r.variant,'documented filter') end
local r=find(rr,260205);NpcDB={Get=function(id,key) if key=='name' then return '시험 NPC' elseif key=='spawns' then return {[12]={{25.5,42.2}}} end end};QuestDB={Get=function(id,key) if key=='name' then return '시험 퀘스트' elseif key=='startedBy' or key=='finishedBy' then return {{100}} elseif key=='requiredLevel' then return 47 end end};ck(b:RankAcquisition(r):find('25.5, 42.2',1,true),'quest coordinate enrichment');ck(b:RankAcquisition(r):find('89053',1,true),'quest ID')
local a={itemId=9999999,name='Original name',mode='reference'};ck(b:RankItemName(a,false):find('한글명 미확인',1,true),'no false Korean names');ItemDB={Get=function() return '실제 데이터 이름' end};b:RankRetry();ck(b:RankItemName(a,false)=='실제 데이터 이름','optional DB fallback');ck(b:RankLabel(sh[1]):find('순위',1,true) or b:RankLabel(sh[1])=='상황별','guide rank label');ck(b:RankLabel({rank=1,mode='reference'})=='1위(참고)','reference rank distinct')
print('PASS V0.9.0 production data / mode / acquisition assertions: '..n)

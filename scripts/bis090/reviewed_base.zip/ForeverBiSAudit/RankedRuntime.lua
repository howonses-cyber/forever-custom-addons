local _,B=...
-- All ranked records have a stable numeric item ID. The game, not a translation guess,
-- supplies localized names, quality, icon and tooltip when data is loaded.
local cache,requested,failed={},{},{}
local function now() return GetTime and GetTime() or 0 end
local function korean(s) return type(s)=='string' and s:find('[\234-\237]')~=nil end
local function dbget(db,id,key)
 if type(db)~='table' then return nil end
 local fn=db.Get
 if type(fn)~='function' then return nil end
 local ok,v=pcall(fn,id,key);if ok then return v end
end
local localized={}
B.rankCache=cache
local function infoAPI() return (C_Item and C_Item.GetItemInfo) or GetItemInfo end
function B:RankInfo(row,request)
 if not row or type(row.itemId)~='number' then return nil end
 local id=row.itemId
 local val=cache[id]
 if val then return val end
 local get=infoAPI()
 if type(get)=='function' then
  local ok,name,link,quality,ilevel,minlevel,itype,subtype,stack,loc,icon=pcall(get,id)
  if ok and type(name)=='string' and name~='' then
   val={name=name,link=link,quality=quality,ilevel=ilevel,level=minlevel,loc=loc,icon=icon}
   cache[id]=val;return val
  end
 end
 if request and ((not requested[id]) or (now()>requested[id]+15)) and (not failed[id] or now()>failed[id]+30) then
  requested[id]=now()
  if C_Item and type(C_Item.RequestLoadItemDataByID)=='function' then pcall(C_Item.RequestLoadItemDataByID,id) end
 end
end
function B:RankItemName(row,request)
 local v=self:RankInfo(row,request)
 if row.variant then return row.nameKo or ('무작위 옵션 장비 #'..row.itemId) end
 if v and korean(v.name) then return v.name end
 if row.nameKo then return row.nameKo..(row.nameKind=='provisional' and ' (번역 참고)' or '') end
 local n=localized[row.itemId];if n==nil then n=dbget(ItemDB,row.itemId,'name');if not korean(n) then n=false end;localized[row.itemId]=n end
 if n then return n end
 if not row.mode then return v and v.name or row.name end
 return '한글명 미확인 #'..row.itemId
end
function B:RankLink(row)
 local v=self:RankInfo(row,true)
 if v and type(v.link)=='string' then return v.link end
end
function B:RankIcon(row)
 local v=self:RankInfo(row,false)
 if v and v.icon then return v.icon end
 local fn=(C_Item and C_Item.GetItemIconByID) or GetItemIcon
 if row.itemId and type(fn)=='function' then local ok,icon=pcall(fn,row.itemId);if ok and icon then return icon end end
 return 'Interface\\Icons\\INV_Misc_QuestionMark'
end
function B:RankDataEvent(id,success)
 id=tonumber(id);if not id then return end
 cache[id]=nil;requested[id]=nil;localized[id]=nil
 if success==false then failed[id]=now() else failed[id]=nil end
 -- Coalesced in Events.lua; don't reset scroll or selection for every item.
end
function B:RankRetry()
 requested={};failed={};cache={};localized={};self.rankCache=cache
end
local function lower(s) return string.lower(tostring(s or '')) end
local function has(s,q) return lower(s):find(q,1,true)~=nil end
function B:RankHasGuide(cl,sp)
 for _,r in ipairs(self.catalog or {}) do if r.class==cl and r.spec==sp and r.mode=='guide' then return true end end
 return false
end
function B:RankMode(cl,sp,mode)
 if mode=='auto' or not mode then return self:RankHasGuide(cl,sp) and 'guide' or 'reference' end
 return mode
end
function B:RankLabel(r,mode)
 if mode=='setup' then return '세팅' end
 if r.mode=='guide' then return ({[1]='1순위',[2]='2순위',[3]='3순위',[4]='상황별'})[r.tier or r.rank] or '참고' end
 return r.rank and (r.rank..'위(참고)') or '미확인'
end
function B:RankEntries(cl,sp,opts)
 opts=opts or {};local result={};local q=lower(opts.search):gsub('^%s+',''):gsub('%s+$','')
 local side=opts.faction;local mode=self:RankMode(cl,sp,opts.mode);local keys={}
 for _,r in ipairs(self.catalog or {}) do
  if r.class==cl and r.spec==sp and ((mode=='setup' and r.mode=='guide' and r.setOrder) or (mode=='guide' and r.mode=='guide') or ((mode=='reference' or mode=='documented') and (r.mode=='reference' or not r.mode))) and (not opts.slot or opts.slot=='all' or r.slot==opts.slot) and
   (mode=='setup' or opts.locked or r.status~='locked') and (mode=='setup' or opts.unknown or (r.status~='unknown' and not r.phaseUnknown)) and
   (mode~='documented' or (r.status=='reference' and not r.phaseUnknown and not r.variant)) and
   (mode=='setup' or not opts.top or not r.rank or r.rank<=opts.top) and
   (mode=='setup' or not opts.sideOnly or not side or not r.faction or r.faction=='Both' or r.faction==side) then
   if q=='' or has(r.name,q) or has(self:RankItemName(r,false),q) or has(r.source,q) or has(r.sourceKo,q) or has(r.details,q) or has(r.acquisition,q) or has(r.itemId,q) then local key=r.slot..':'..tostring(r.itemId)..':'..(r.variant and r.name or '')..':'..(r.weaponGroup or '');if not keys[key] then result[#result+1]=r;keys[key]=true end end
  end
 end
 local slots={};for i,s in ipairs(self.slotOrder) do slots[s]=i end
 table.sort(result,function(a,b)
  if a.slot~=b.slot then return (slots[a.slot] or 999)<(slots[b.slot] or 999) end
  if mode=='setup' and a.setOrder~=b.setOrder then return (a.setOrder or 999)<(b.setOrder or 999) end
  if a.weaponGroup and b.weaponGroup and a.weaponGroup~=b.weaponGroup then return a.weaponGroup<b.weaponGroup end
  if (a.rank or 999)~=(b.rank or 999) then return (a.rank or 999)<(b.rank or 999) end
  if a.name~=b.name then return a.name<b.name end
  return (a.itemId or 0)<(b.itemId or 0)
 end)
 return result
end
function B:RankSourceLabel(row)
 local s=row.sourceKo or row.source or ""
 if (s=="" or s=="획득처 확인 필요" or s=="획득처 세부 미확인") and row.details and row.details~="" then return row.details:match("^[^\n]+") end
 return s~="" and s or "획득처 미확인"
end
function B:RankAcquisition(row)
 local out={};local seen={}
 local function add(s) if type(s)=='string' and s~='' and not seen[s] then out[#out+1]=s;seen[s]=true end end
 add(self:RankSourceLabel(row));add(row.details);add(row.acquisition)
 local function npc(id,prefix)
  local name=dbget(NpcDB,id,'name');local spawns=dbget(NpcDB,id,'spawns')
  if korean(name) then add(prefix..': '..name) else add(prefix..' 번호: '..id) end
  if type(spawns)=='table' then
   local n=0;local zones={};for zone in pairs(spawns) do if type(zone)=='number' then zones[#zones+1]=zone end end;table.sort(zones)
   for _,zone in ipairs(zones) do local points=spawns[zone];if type(points)=='table' then for _,point in ipairs(points) do if type(point)=='table' and type(point[1])=='number' and type(point[2])=='number' and point[1]>=0 and point[1]<=100 and point[2]>=0 and point[2]<=100 then
    add(string.format('  지역 번호 %d · 좌표 %.1f, %.1f (퀘스트 DB)',zone,point[1],point[2]));n=n+1;if n>=3 then return end
   end end end end
  end
 end
 for _,id in ipairs(row.questIds or {}) do
  local name=dbget(QuestDB,id,'name');add('퀘스트 번호 '..id..(korean(name) and ' · '..name or ''))
  local level=dbget(QuestDB,id,'requiredLevel');if type(level)=='number' and level>0 then add('퀘스트 요구 레벨 '..level) end
  for _,part in ipairs({{'startedBy','시작 NPC'},{'finishedBy','완료 NPC'}}) do
   local v=dbget(QuestDB,id,part[1]);if type(v)=='table' and type(v[1])=='table' then for i,n in ipairs(v[1]) do if i<=2 and type(n)=='number' then npc(n,part[2]) end end end
  end
 end
 for _,id in ipairs(row.npcIds or {}) do npc(id,'관련 NPC') end
 if not row.acquisition then add('가격·드롭률·선행 조건: 확인된 자료만 표시합니다.') end
 return table.concat(out,'\n')
end
function B:RankOwned(row)
 if row.variant then return false,false end
 local id=row.itemId;if not id then return false,false end
 if type(GetInventoryItemID)=='function' then
  for _,s in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
   local ok,n=pcall(GetInventoryItemID,'player',s);if ok and n==id then return true,true end
  end
 end
 local count=(C_Item and C_Item.GetItemCount) or GetItemCount
 if type(count)=='function' then local ok,n=pcall(count,id,false);if ok and type(n)=='number' then return n>0,false end end
 return false,false
end
function B:RankTooltip(owner,row)
 if not GameTooltip or not row then return end
 GameTooltip:SetOwner(owner,'ANCHOR_RIGHT')
 local link=self:RankLink(row)
 local ok=false
 if row.itemId and type(GameTooltip.SetHyperlink)=='function' then
  ok=pcall(GameTooltip.SetHyperlink,GameTooltip,link or ('item:'..row.itemId))
 end
 if not ok then GameTooltip:AddLine(self:RankItemName(row,true),.95,.9,.7) end
 if not link then GameTooltip:AddLine('게임 아이템 정보 로딩 중 / 미확인',1,.73,.35,true) end
 GameTooltip:AddLine(self:RankLabel(row)..(row.mode=='guide' and ' · 와우헤드 전문 가이드' or ' · 개별 스탯 참고')..' · 레이드 이전',.7,.85,1,true)
 GameTooltip:AddLine(self:RankSourceLabel(row),.76,.9,.8,true)
 if row.variant then GameTooltip:AddLine('기본 아이템 툴팁 · 무작위 옵션 미확정',1,.7,.3,true) end
 if row.details then GameTooltip:AddLine(row.details,.7,.8,.9,true) end
 GameTooltip:Show()
end
function B:RankChatLink(row)
 if row.variant then self.Print('무작위 옵션이 확정되지 않아 실제 장비 링크를 전송하지 않습니다.');return false end
 local link=self:RankLink(row)
 if not link then self.Print('아이템 링크 로딩 중입니다. 잠시 후 다시 선택하세요.');return false end
 if type(ChatEdit_InsertLink)=='function' then local ok,r=pcall(ChatEdit_InsertLink,link);if ok and r then return true end end
 if type(ChatFrame_OpenChat)=='function' then pcall(ChatFrame_OpenChat,link);return true end
 return false
end

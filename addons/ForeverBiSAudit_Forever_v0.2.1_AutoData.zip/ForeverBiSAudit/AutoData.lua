local _,B=...
-- Automatically generated from two independent public pre-raid rankings.
-- Availability, drop and DPS superiority remain UNVERIFIED.
B.autoMeta={version="0.2.1",count=9,reviewedAt="2026-11-24",policy='two-source provisional; no client HTTP'}
B.autoItemIds={}
local function upsert(class,spec,slot,name,id,source,checked,url1,url2)
 local current=nil
 for _,row in ipairs(B.catalog or {}) do
  if row.class==class and row.spec==spec and row.slot==slot then
   if row.name==name and row.status=='locked' then return end
   if row.name==name then current=row end
  end
 end
 if not current then
  current={class=class,spec=spec,slot=slot,name=name,status="unknown",kind="cross-source"}
  B.catalog[#B.catalog+1]=current
 end
 current.priority=current.priority or 2; current.status="unknown"; current.source=source; current.checked=checked
 current.url=url1; current.confirmingURL=url2; current.itemId=id; current.autoEvidence=true
 current.note="Two independent public rankings agree; actual WoW Forever drops, faction and phase still need confirmation."
 B.autoItemIds[string.lower(name)]=id
end
upsert("HUNTER","marksmanship","Back","Earthweave Cloak",21187,"Quest: Volunteer's Battlegear · lvl 60","2026-11-24","https://foreverwow.gg/hunter/marksmanship/pre-raid/","https://theforeverera.com/en/bis/hunter/marksmanship/pre-raid/")
upsert("MAGE","frost","Feet","Sorcerer's Boots",22064,"Quest: Anthion's Parting Words · lvl 58","2026-11-24","https://foreverwow.gg/mage/frost/pre-raid/","https://theforeverera.com/en/bis/mage/frost/pre-raid/")
upsert("MAGE","frost","Hands","Sorcerer's Gloves",22066,"Quest: Just Compensation · lvl 58","2026-11-24","https://foreverwow.gg/mage/frost/pre-raid/","https://theforeverera.com/en/bis/mage/frost/pre-raid/")
upsert("MAGE","frost","Legs","Sorcerer's Leggings",226933,"Vendor: Deliana","2026-11-24","https://foreverwow.gg/mage/frost/pre-raid/","https://theforeverera.com/en/bis/mage/frost/pre-raid/")
upsert("MAGE","frost","Shoulder","Mantle of the Timbermaw",19050,"Crafted: Tailoring","2026-11-24","https://foreverwow.gg/mage/frost/pre-raid/","https://theforeverera.com/en/bis/mage/frost/pre-raid/")
upsert("ROGUE","combat","Head","Darkmantle Cap",22005,"Quest: Saving the Best for Last · lvl 58","2026-11-24","https://foreverwow.gg/rogue/combat/pre-raid/","https://theforeverera.com/en/bis/rogue/combat/pre-raid/")
upsert("ROGUE","combat","Neck","Beads of Ogre Might",22150,"Quest: Falrin's Vendetta · lvl 58","2026-11-24","https://foreverwow.gg/rogue/combat/pre-raid/","https://theforeverera.com/en/bis/rogue/combat/pre-raid/")
upsert("SHAMAN","enhancement","Feet","Bloodmail Boots",14616,"Drop: Doctor Theolen Krastinov · lvl 60","2026-11-24","https://foreverwow.gg/shaman/enhancement/pre-raid/","https://theforeverera.com/en/bis/shaman/enhancement/pre-raid/")
upsert("WARRIOR","arms","Feet","Boots of Heroism",21995,"Quest: Anthion's Parting Words · lvl 58","2026-11-24","https://foreverwow.gg/warrior/arms/pre-raid/","https://theforeverera.com/en/bis/warrior/arms/pre-raid/")

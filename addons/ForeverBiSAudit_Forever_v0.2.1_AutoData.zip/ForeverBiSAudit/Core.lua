local name, B = ...
if type(B) ~= 'table' then B = {} end
_G.ForeverBiSAudit = B
B.name = name or 'ForeverBiSAudit'
B.version = '0.2.1'
B.buildDate = '2026-11-24'
B.dataVersion = '0.2.1'
B.db = nil
local function say(s)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage('|cffffcb48[Forever BiS]|r '..tostring(s)) end
end
B.Print = say
local function getClass()
 if UnitClass then local _, token = UnitClass('player'); if token then return token end end
 return 'SHAMAN'
end
function B:Initialize()
 if self.db then return end
 if type(_G.ForeverBiSAuditDB) ~= 'table' then _G.ForeverBiSAuditDB = {} end
 self.db = _G.ForeverBiSAuditDB
 local db = self.db
 db.class = db.class or getClass()
 if not self.specs[db.class] then db.class = getClass() end
 db.spec = db.spec or self.defaultSpec[db.class]
 if not self:ValidSpec(db.class, db.spec) then db.spec = self.defaultSpec[db.class] end
 if type(db.weights) ~= 'table' then db.weights = {} end
 if type(db.showLocked) ~= 'boolean' then db.showLocked = false end
 if type(db.showUnknown) ~= 'boolean' then db.showUnknown = true end
 if type(db.showTooltip) ~= 'boolean' then db.showTooltip = true end
 if type(db.minimapAngle) ~= 'number' then db.minimapAngle = 195 end
 if type(db.ui) ~= 'table' then db.ui={x=-60,y=30} end
 if self.BuildUI then self:BuildUI() end
 if self.CreateMinimapButton then self.minimapButtonFrame=self:CreateMinimapButton() end
 if self.SetupTooltips then self:SetupTooltips() end
end
function B:ValidSpec(class, key)
 for _,spec in ipairs(self.specs[class] or {}) do if spec.key==key then return true end end
 return false
end
function B:GetSpec()
 if not self.db then self:Initialize() end
 return self.db.class, self.db.spec
end
function B:SetClass(class)
 if not self.specs[class] then return false end
 self.db.class=class; self.db.spec=self.defaultSpec[class]
 if self.RefreshUI then self:RefreshUI() end
 return true
end
function B:SetSpec(spec)
 if not self:ValidSpec(self.db.class,spec) then return false end
 self.db.spec=spec
 if self.RefreshUI then self:RefreshUI() end
 return true
end
function B:GetWeights(class,spec)
 local key=class..':'..spec
 local fallback=self.scales[key] or self.scales.default or {}
 local override=(self.db and self.db.weights and self.db.weights[key]) or nil
 if not override then return fallback end
 local out={} for k,v in pairs(fallback) do out[k]=v end
 for k,v in pairs(override) do if type(v)=='number' then out[k]=v end end
 return out
end
function B:SetWeight(key,value)
 if not self.db then self:Initialize() end
 if not self.statNames[key] or type(value)~='number' or value < 0 or value > 100 then return false end
 local ck=self.db.class..':'..self.db.spec
 self.db.weights[ck]=self.db.weights[ck] or {}
 self.db.weights[ck][key]=value
 if self.RefreshUI then self:RefreshUI() end
 return true
end
function B:GetEntries(class,spec,slot)
 local result={}
 for _,entry in ipairs(self.catalog) do
  if entry.class==class and entry.spec==spec and (not slot or entry.slot==slot) then
   if (entry.status~='locked' or (self.db and self.db.showLocked)) and
      (entry.status~='unknown' or not self.db or self.db.showUnknown) then
   result[#result+1]=entry end
  end
 end
 table.sort(result,function(a,b)
  local av=(a.priority or 99);local bv=(b.priority or 99)
  if av==bv then return a.name < b.name end return av<bv
 end)
 return result
end
function B:Open()
 if not self.db then self:Initialize() end
 if self.StartItemIndex then self:StartItemIndex() end
 if self.frame then self.frame:Show();self:RefreshUI() end
end
function B:Toggle()
 if not self.db then self:Initialize() end
 if self.frame and self.frame:IsShown() then self.frame:Hide() else self:Open() end
end
SLASH_FOREVERBISAUDIT1='/fbis'
SLASH_FOREVERBISAUDIT2='/bisf'
SlashCmdList.FOREVERBISAUDIT=function(msg)
 if not B.db then B:Initialize() end
 msg=(msg or ''):lower():gsub('^%s+',''):gsub('%s+$','')
 local command,stat,val=msg:match('^(%S+)%s+(%S+)%s+(%S+)$')
 if command=='weight' then
  B.Print('장비 비교는 Pawn의 척도를 사용합니다. 가중치는 /pawn 에서 조정하세요. /fbis weight는 비교에 사용되지 않습니다.')
  return
 end
 if msg=='reset' then
  B.Print('Pawn 척도 초기화는 /pawn 메뉴에서 진행하세요. Forever BiS의 저장된 설정은 유지합니다.');return
 elseif msg=='tooltip on' then B.db.showTooltip=true; B.Print('툴팁 비교 켜짐');return
 elseif msg=='tooltip off' then B.db.showTooltip=false; B.Print('툴팁 비교 꺼짐');return
 elseif msg=='locked on' then B.db.showLocked=true;B:RefreshUI();return
 elseif msg=='locked off' then B.db.showLocked=false;B:RefreshUI();return
 elseif msg=='data' then
  B.Print('Version '..tostring(B.version)..' / Data '..tostring(B.dataVersion)..' / verified cross-source rows '..tostring(B.autoMeta and B.autoMeta.count or 0))
  B.Print('Updates require two independent matching pre-raid source rankings; unresolved changes stay pending.')
  B.Print('Check GitHub bis-sync/report.json for most recent daily source scan.')
  return
 elseif msg=='audit' then
  local a=B._lastAudit
  if not a then B.Print(B._lastAuditError or 'No validated comparison yet. Hover an item and retry.');return end
  B.Print('Scale: '..tostring(a.scale)..' / '..tostring(a.spec))
  B.Print(string.format('Candidate %.2f / equipped %.2f / EP delta %+.2f%%', a.incoming,a.baseline,a.pct))
  local names={'HitRating','Agility','Ap','Stamina','Intellect','Strength','MeleeDps'}
  for _,key in ipairs(names) do
   local raw=a.observed and a.observed[key]
   if raw then B.Print(key..': tooltip='..tostring(raw)..' / Pawn candidate='..tostring(a.pawnStats and a.pawnStats[key])..' / equipped='..tostring(a.equippedStats and a.equippedStats[key])) end
  end
  B.Print('Set excluded='..tostring(a.hasSet)..' / proc excluded='..tostring(a.proc))
  return
 elseif msg=='help' then
  B.Print('/fbis data, /fbis audit (last hovered), /fbis tooltip on/off, /fbis locked on/off')
  B.Print('툴팁 %는 Pawn/Pawn Forever 스탯 점수. 발동 효과와 실제 DPS/HPS는 포함하지 않습니다.')
  return
 end
 B:Toggle()
end

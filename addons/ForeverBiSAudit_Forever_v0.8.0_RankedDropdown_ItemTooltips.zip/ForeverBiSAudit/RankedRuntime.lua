local _,B=...
-- All ranked records have a stable numeric item ID. The game, not a translation guess,
-- supplies localized names, quality, icon and tooltip when data is loaded.
local cache,requested,failed={},{},{}
B.rankCache=cache
local function infoAPI() return (C_Item and C_Item.GetItemInfo) or GetItemInfo end
function B:RankInfo(row,request)
 if not row or type(row.itemId)~='number' then return nil end
 local id=row.itemId
 local val=cache[id]
 if val then return val end
 local get=infoAPI()
 if type(get)=='function' then
  local ok,name,link,quality,ilevel,minlevel,itype,subtype,stack,loc,icon=pcall(get,id)
  if ok and type(name)=='string' and name~='' then
   val={name=name,link=link,quality=quality,ilevel=ilevel,level=minlevel,loc=loc,icon=icon}
   cache[id]=val;return val
  end
 end
 if request and not requested[id] and not failed[id] then
  requested[id]=true
  if C_Item and type(C_Item.RequestLoadItemDataByID)=='function' then pcall(C_Item.RequestLoadItemDataByID,id) end
 end
end
function B:RankItemName(row,request)
 local v=self:RankInfo(row,request)
 return v and v.name or row.nameKo or row.name
end
function B:RankLink(row)
 local v=self:RankInfo(row,true)
 if v and type(v.link)=='string' then return v.link end
end
function B:RankIcon(row)
 local v=self:RankInfo(row,false)
 if v and v.icon then return v.icon end
 local fn=(C_Item and C_Item.GetItemIconByID) or GetItemIcon
 if row.itemId and type(fn)=='function' then local ok,icon=pcall(fn,row.itemId);if ok and icon then return icon end end
 return 'Interface\\Icons\\INV_Misc_QuestionMark'
end
function B:RankDataEvent(id,success)
 id=tonumber(id);if not id then return end
 cache[id]=nil
 if success==false then failed[id]=true else failed[id]=nil end
 -- Coalesced in Events.lua; don't reset scroll or selection for every item.
end
function B:RankRetry()
 requested={};failed={};cache={};self.rankCache=cache
end
local function lower(s) return string.lower(tostring(s or '')) end
local function has(s,q) return lower(s):find(q,1,true)~=nil end
function B:RankEntries(cl,sp,opts)
 opts=opts or {};local result={};local q=lower(opts.search):gsub('^%s+',''):gsub('%s+$','')
 local side=opts.faction
 for _,r in ipairs(self.catalog or {}) do
  if r.class==cl and r.spec==sp and (not opts.slot or opts.slot=='all' or r.slot==opts.slot) and
   (opts.locked or r.status~='locked') and (opts.unknown or r.status~='unknown') and
   (not opts.top or not r.rank or r.rank<=opts.top) and
   (not opts.sideOnly or not side or not r.faction or r.faction=='Both' or r.faction==side) then
   if q=='' or has(r.name,q) or has(self:RankItemName(r,false),q) or has(r.source,q) or has(r.sourceKo,q) or has(r.details,q) or has(r.itemId,q) then result[#result+1]=r end
  end
 end
 local slots={};for i,s in ipairs(self.slotOrder) do slots[s]=i end
 table.sort(result,function(a,b)
  if a.slot~=b.slot then return (slots[a.slot] or 999)<(slots[b.slot] or 999) end
  if (a.rank or 999)~=(b.rank or 999) then return (a.rank or 999)<(b.rank or 999) end
  if a.name~=b.name then return a.name<b.name end
  return (a.itemId or 0)<(b.itemId or 0)
 end)
 return result
end
function B:RankSourceLabel(row)
 local s=row.sourceKo or row.source or ""
 if (s=="" or s=="획득처 확인 필요" or s=="획득처 세부 미확인") and row.details and row.details~="" then return row.details:match("^[^\n]+") end
 return s~="" and s or "획득처 미확인"
end
function B:RankOwned(row)
 local id=row.itemId;if not id then return false,false end
 if type(GetInventoryItemID)=='function' then
  for _,s in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
   local ok,n=pcall(GetInventoryItemID,'player',s);if ok and n==id then return true,true end
  end
 end
 local count=(C_Item and C_Item.GetItemCount) or GetItemCount
 if type(count)=='function' then local ok,n=pcall(count,id,false);if ok and type(n)=='number' then return n>0,false end end
 return false,false
end
function B:RankTooltip(owner,row)
 if not GameTooltip or not row then return end
 GameTooltip:SetOwner(owner,'ANCHOR_RIGHT')
 local link=self:RankLink(row)
 local ok=false
 if row.itemId and type(GameTooltip.SetHyperlink)=='function' then
  ok=pcall(GameTooltip.SetHyperlink,GameTooltip,link or ('item:'..row.itemId))
 end
 if not ok then GameTooltip:AddLine(self:RankItemName(row,true),.95,.9,.7) end
 if not link then GameTooltip:AddLine('게임 아이템 정보 로딩 중 / 미확인',1,.73,.35,true) end
 GameTooltip:AddLine((row.rank and (row.rank..'순위 · ForeverWoW.gg') or '순위 미확인')..' · 레이드 이전',.7,.85,1,true)
 GameTooltip:AddLine(row.sourceKo or row.source or '획득처 미확인',.76,.9,.8,true)
 if row.details then GameTooltip:AddLine(row.details,.7,.8,.9,true) end
 GameTooltip:Show()
end
function B:RankChatLink(row)
 local link=self:RankLink(row)
 if not link then self.Print('아이템 링크 로딩 중입니다. 잠시 후 다시 선택하세요.');return false end
 if type(ChatEdit_InsertLink)=='function' then local ok,r=pcall(ChatEdit_InsertLink,link);if ok and r then return true end end
 if type(ChatFrame_OpenChat)=='function' then pcall(ChatFrame_OpenChat,link);return true end
 return false
end

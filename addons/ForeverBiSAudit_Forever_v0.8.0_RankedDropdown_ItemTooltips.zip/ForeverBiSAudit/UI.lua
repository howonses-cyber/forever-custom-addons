local _,B=...
local frame,scroll,child,detail,selected,popup,search,counts
local classBtn,specBtn,slotBtn,limitBtn,lockedBtn,unknownBtn,sideBtn,tooltipBtn
local rows,headers={},{}
local function text(p,size,r,g,b)
 local f=p:CreateFontString(nil,'OVERLAY','GameFontNormal')
 if f.SetFont then pcall(f.SetFont,f,'Fonts\\2002.TTF',size or 12,'OUTLINE') end
 f:SetTextColor(r or .9,g or .93,b or .97);f:SetJustifyH('LEFT');f:SetJustifyV('MIDDLE');return f
end
local function tint(p,r,g,b,a)
 local t=p:CreateTexture(nil,'BACKGROUND');t:SetAllPoints();t:SetColorTexture(r,g,b,a or 1);return t
end
local function edge(p,r,g,b)
 for i=1,4 do local e=p:CreateTexture(nil,'BORDER');e:SetColorTexture(r,g,b,1)
  if i==1 then e:SetHeight(1);e:SetPoint('TOPLEFT');e:SetPoint('TOPRIGHT')
  elseif i==2 then e:SetHeight(1);e:SetPoint('BOTTOMLEFT');e:SetPoint('BOTTOMRIGHT')
  elseif i==3 then e:SetWidth(1);e:SetPoint('TOPLEFT');e:SetPoint('BOTTOMLEFT')
  else e:SetWidth(1);e:SetPoint('TOPRIGHT');e:SetPoint('BOTTOMRIGHT') end end
end
local function button(p,label,w,h,fn)
 local b=CreateFrame('Button',nil,p);b:SetSize(w,h);local bg=tint(b,.13,.18,.24,1)
 b.label=text(b,12,.91,.94,.98);b.label:SetAllPoints();b.label:SetJustifyH('CENTER');b.label:SetText(label)
 b:SetScript('OnClick',function(self) if fn then fn(self) end end)
 b:SetScript('OnEnter',function()bg:SetColorTexture(.20,.29,.38,1)end)
 b:SetScript('OnLeave',function()bg:SetColorTexture(.13,.18,.24,1)end);return b
end
local function closeMenu() if popup then popup:Hide() end end
local function menu(anchor,entries,current,choose)
 if popup and popup:IsShown() and popup.anchor==anchor then closeMenu();return end
 if popup then popup:Hide() else
  popup=CreateFrame('Frame',nil,frame);popup:SetFrameStrata('DIALOG');popup:SetFrameLevel(100);popup:EnableMouse(true);popup.buttons={}
  tint(popup,.075,.10,.15,1);edge(popup,.35,.44,.53)
 end
 popup.anchor=anchor;popup:ClearAllPoints();popup:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-3)
 local width=math.max(anchor:GetWidth(),182);local h=24
 popup:SetSize(width,#entries*h+8)
 for _,b in ipairs(popup.buttons) do b:Hide() end
 for i,e in ipairs(entries) do
  local b=popup.buttons[i]
  if not b then b=button(popup,'',width-8,h,function(self) local val=self.entry.value;closeMenu();self.choose(val) end);popup.buttons[i]=b end
  b:SetSize(width-8,h);b:ClearAllPoints();b:SetPoint('TOPLEFT',popup,'TOPLEFT',4,-4-(i-1)*h)
  b.entry=e;b.choose=choose;b.label:SetText((current==e.value and '✓  ' or '    ')..e.label);b:Show()
 end
 popup:Show()
end
local function specLabel()
 for _,s in ipairs(B.specs[B.db.class] or {}) do if s.key==B.db.spec then return s.label end end
 return B.db.spec or '-'
end
local function opts()
 local side=UnitFactionGroup and UnitFactionGroup('player') or nil
 return {slot=B.db.slot or 'all',search=B.db.search or '',top=B.db.top or 5,locked=B.db.showLocked,unknown=B.db.showUnknown,sideOnly=B.db.sideOnly,faction=side}
end
local function identity(row) return row and (row.class..':'..row.spec..':'..row.slot..':'..tostring(row.itemId or row.name)) end
local function rankText(r) return r.rank and (r.rank..'순위') or '미확인' end
local function status(r)
 if r.status=='locked' then return '획득 제한',1,.48,.43 end
 if r.phaseUnknown then return '개방 미확인',1,.72,.36 end
 if r.status=='unknown' then return '출처 확인 필요',1,.72,.36 end
 if r.faction=='Alliance' then return '얼라이언스',.55,.78,1 end
 if r.faction=='Horde' then return '호드',1,.59,.46 end
 return '출처 순위',.55,.81,.71
end
local function setDetail(r)
 selected=r;if not detail then return end
 if not r then
  detail.title:SetText('선택할 장비 없음');detail.rank:SetText('');detail.desc:SetText('검색 조건이나 획득 제한 필터를 변경하세요. 확인되지 않은 순위는 임의로 채우지 않습니다.');detail.compare:SetText('');detail.url:SetText('');detail.source:SetText('');detail.icon:SetTexture('Interface\\Icons\\INV_Misc_QuestionMark');return
 end
 local v=B:RankInfo(r,true);detail.title:SetText(B:RankItemName(r,true));detail.icon:SetTexture(B:RankIcon(r));detail.rank:SetText(rankText(r)..'  ·  '..(B.slotNames[r.slot] or r.slot)..'  ·  '..status(r))
 local owned,worn=B:RankOwned(r)
 local lines={'획득처: '..B:RankSourceLabel(r)}
 if r.itemId then lines[#lines+1]='아이템 ID: '..r.itemId end
 if r.duplicateName then lines[#lines+1]='동일 이름의 다른 아이템과 ID가 다릅니다.' end
 if r.note then lines[#lines+1]=r.note end
 if r.details and r.details~='' then lines[#lines+1]=r.details end
 if r.requiredLevel then lines[#lines+1]='요구 레벨: '..r.requiredLevel end
 if r.faction and r.faction~='Both' then lines[#lines+1]='진영: '..(r.faction=='Alliance' and '얼라이언스' or '호드') end
 if r.setName then lines[#lines+1]='세트: '..r.setName end
 if r.variant then lines[#lines+1]='무작위 옵션 아이템: 실제 옵션 별도 확인' end
 if worn then lines[#lines+1]='현재 착용 중' elseif owned then lines[#lines+1]='가방 보유' end
 if not v then lines[#lines+1]='한글명·툴팁: 게임 데이터 로딩 중 또는 조회 불가' end
 detail.desc:SetText(table.concat(lines,'\n'))
 detail.url:SetText(r.url or '');detail.url:SetCursorPosition(0)
 detail.source:SetText('순위: '..(r.rank and 'ForeverWoW.gg 레이드 이전' or '미검증 참고 자료')..' · '..(r.checked or '-')..'\n출처는 서버의 실제 개방·드롭을 보증하지 않습니다.')
 local link=B:RankLink(r)
 local player=UnitClass and select(2,UnitClass('player')) or B.db.class
 if B.db.class~=player then detail.compare:SetText('다른 직업을 열람 중: 현재 착용 비교 생략');return end
 if not link then detail.compare:SetText('아이템 정보 로딩 중 · 툴팁에서 확인하거나 새로고침');return end
 if r.variant then detail.compare:SetText('무작위 옵션이 확정되지 않아 점수 비교 보류');return end
 local ok,c,why=pcall(B.VerifiedEquipPercent,B,link,B.db.class,B.db.spec,B:ResolveEquipLocation(link),r.slot)
 if not ok or not c then detail.compare:SetText('Pawn 비교 보류: '..tostring(ok and why or '조회 실패'));return end
 local s='착용: '..tostring(c.comparedName or '-')..'\n'
 if c.pct~=nil then s=s..string.format('Pawn 스탯 점수: %+.1f%%',c.pct) else s=s..'기준 점수 0 · % 비교 불가' end
 detail.compare:SetText(s..'\n세트·발동 효과 제외, 실제 DPS/HPS 아님')
end
local function makeRow()
 local r=CreateFrame('Button',nil,child);r:SetHeight(48);r.bg=tint(r,.095,.125,.17,.96)
 r.icon=r:CreateTexture(nil,'ARTWORK');r.icon:SetSize(34,34);r.icon:SetPoint('LEFT',r,'LEFT',56,0);r.icon:SetTexCoord(.07,.93,.07,.93)
 r.rank=text(r,12,1,.78,.34);r.rank:SetPoint('LEFT',r,'LEFT',5,0);r.rank:SetWidth(48);r.rank:SetJustifyH('CENTER')
 r.name=text(r,13,.91,.94,.99);r.name:SetPoint('TOPLEFT',r,'TOPLEFT',99,-5);r.name:SetPoint('TOPRIGHT',r,'TOPRIGHT',-108,-5);r.name:SetHeight(19)
 r.source=text(r,11,.66,.76,.84);r.source:SetPoint('TOPLEFT',r,'TOPLEFT',99,-25);r.source:SetPoint('TOPRIGHT',r,'TOPRIGHT',-9,-25);r.source:SetHeight(17)
 r.flag=text(r,10,.65,.8,.8);r.flag:SetWidth(101);r.flag:SetHeight(18);r.flag:SetJustifyH('RIGHT');r.flag:SetPoint('TOPRIGHT',r,'TOPRIGHT',-7,-5)
 r:SetScript('OnClick',function(self)if not self.item then return end;if IsShiftKeyDown and IsShiftKeyDown() then B:RankChatLink(self.item) else setDetail(self.item);B:RefreshRankVisuals() end end)
 r:SetScript('OnEnter',function(self) self.hover=true;B:RefreshRankRow(self);if self.item then B:RankTooltip(self,self.item) end end)
 r:SetScript('OnLeave',function(self) self.hover=false;B:RefreshRankRow(self);if GameTooltip then GameTooltip:Hide() end end)
 return r
end
function B:RefreshRankRow(row)
 local r=row.item;if not r then return end
 local v=self:RankInfo(r,true);local name=self:RankItemName(r,false)
 row.name:SetText(name..(r.duplicateName and (' ['..r.itemId..']') or ''));row.icon:SetTexture(self:RankIcon(r));row.rank:SetText(rankText(r));row.source:SetText(self:RankSourceLabel(r))
 local flag,red,g,b=status(r);local own,worn=self:RankOwned(r);if worn then flag='착용';red,g,b=.4,1,.65 elseif own then flag='보유';red,g,b=.5,.85,.7 elseif not v and not r.nameKo and r.status~='locked' and not r.phaseUnknown then flag='한글명 대기';red,g,b=.8,.76,.6 end
 row.flag:SetText(flag);row.flag:SetTextColor(red,g,b)
 if v and v.quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[v.quality] then local c=ITEM_QUALITY_COLORS[v.quality];row.name:SetTextColor(c.r,c.g,c.b) else row.name:SetTextColor(.9,.93,.98) end
 if r.rank==1 then row.rank:SetTextColor(1,.79,.36) elseif r.rank==2 then row.rank:SetTextColor(.80,.86,.94) else row.rank:SetTextColor(.65,.74,.83) end
 if identity(r)==identity(selected) then row.bg:SetColorTexture(.18,.30,.42,1) elseif row.hover then row.bg:SetColorTexture(.17,.23,.31,1) else row.bg:SetColorTexture(.095,.125,.17,.96) end
end
function B:RefreshRankVisuals()
 if not frame or not frame:IsShown() then return end
 for _,row in ipairs(rows) do if row:IsShown() then self:RefreshRankRow(row) end end
end
local function refreshList(preserve)
 if not child then return end
 local old=preserve and scroll:GetVerticalScroll() or 0;local key=identity(selected)
 for _,row in ipairs(rows) do row:Hide();row.item=nil end
 for _,h in ipairs(headers) do h:Hide() end
 local data=B:RankEntries(B.db.class,B.db.spec,opts());local y,n,hn=0,0,0;local last,found
 local width=math.max(300,scroll:GetWidth()-2);child:SetWidth(width)
 for _,r in ipairs(data) do
  if last~=r.slot then
   last=r.slot;hn=hn+1;local h=headers[hn]
   if not h then h=CreateFrame('Frame',nil,child);h:SetHeight(27);tint(h,.16,.21,.29,1);h.label=text(h,12,.94,.81,.52);h.label:SetPoint('LEFT',h,'LEFT',9,0);headers[hn]=h end
   h:SetWidth(width);h:ClearAllPoints();h:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);h.label:SetText(B.slotNames[r.slot] or r.slot);h:Show();y=y+30
  end
  n=n+1;local row=rows[n];if not row then row=makeRow();rows[n]=row end
  row.item=r;row.hover=false;row:SetWidth(width);row:ClearAllPoints();row:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);row:Show();y=y+50
  if identity(r)==key then found=r end
 end
 child:SetHeight(math.max(y+4,scroll:GetHeight()));selected=found or data[1]
 scroll:SetVerticalScroll(math.min(old,math.max(0,y-scroll:GetHeight())))
 counts:SetText(string.format('표시 %d개 · 전체 %d개 특성 / %d개 순위 행 · 출처: ForeverWoW.gg',n,B.rankedMeta and B.rankedMeta.profiles or 0,B.rankedMeta and B.rankedMeta.rows or 0))
 setDetail(selected);B:RefreshRankVisuals()
end
function B:RefreshUI(preserve)
 if not frame or not self.db then return end
 classBtn.label:SetText((self.classNames[self.db.class] or self.db.class)..'  ▼');specBtn.label:SetText(specLabel()..'  ▼')
 slotBtn.label:SetText((self.slotNames[self.db.slot] or '전체 부위')..'  ▼');limitBtn.label:SetText('상위 '..(self.db.top or 5)..'개  ▼')
 lockedBtn.label:SetText(self.db.showLocked and '제한 포함' or '제한 제외');unknownBtn.label:SetText(self.db.showUnknown and '미확인 포함' or '미확인 제외');sideBtn.label:SetText(self.db.sideOnly and '내 진영' or '모든 진영');tooltipBtn.label:SetText(self.db.showTooltip and '가방 비교 켬' or '가방 비교 끔')
 refreshList(preserve)
end
function B:BuildUI()
 if frame or not CreateFrame or not UIParent then return end
 local db=self.db;db.slot=type(db.slot)=='string' and db.slot or 'all';db.top=tonumber(db.top) or 5;db.search=type(db.search)=='string' and db.search or '';if db.sideOnly==nil then db.sideOnly=true end
 frame=CreateFrame('Frame','ForeverBiSAuditMainFrame',UIParent);frame:SetSize(1000,650);frame:SetFrameStrata('HIGH');frame:SetToplevel(true);frame:EnableMouse(true);frame:SetMovable(true);frame:RegisterForDrag('LeftButton');frame:SetClampedToScreen(true)
 frame:SetPoint('CENTER',UIParent,'CENTER',db.ui.x or 0,db.ui.y or 0);local pw,ph=UIParent:GetWidth(),UIParent:GetHeight();if pw and ph and pw>100 and ph>100 then frame:SetScale(math.min(1,(pw-24)/1000,(ph-24)/650)) end;tint(frame,.055,.075,.105,.98);edge(frame,.30,.38,.48)
 frame:SetScript('OnDragStart',function(f)f:StartMoving()end);frame:SetScript('OnDragStop',function(f)f:StopMovingOrSizing();local _,_,_,x,y=f:GetPoint();db.ui.x=x or 0;db.ui.y=y or 0 end);frame:SetScript('OnHide',closeMenu)
 if UISpecialFrames then UISpecialFrames[#UISpecialFrames+1]='ForeverBiSAuditMainFrame' end
 local title=text(frame,20,.98,.83,.48);title:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-14);title:SetText('FOREVER BiS  |cffffffffV'..self.version..'|r')
 local subtitle=text(frame,11,.64,.75,.86);subtitle:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-42);subtitle:SetText('레이드 이전 장비 · 출처별 추천 순위 / 착용 비교')
 local close=button(frame,'×',32,29,function()frame:Hide()end);close:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-14,-12)
 local refresh=button(frame,'아이템 재조회',115,29,function()self:RankRetry();self:RefreshUI(true)end);refresh:SetPoint('RIGHT',close,'LEFT',-8,0)
 classBtn=button(frame,'직업',140,31,function(a)local list={};for _,c in ipairs(B.classOrder) do list[#list+1]={value=c,label=B.classNames[c]} end;menu(a,list,db.class,function(v)db.search='';search:SetText('');B:SetClass(v)end)end);classBtn:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-65)
 specBtn=button(frame,'특성',172,31,function(a)local list={};for _,s in ipairs(B.specs[db.class] or {}) do list[#list+1]={value=s.key,label=s.label} end;menu(a,list,db.spec,function(v)db.search='';search:SetText('');B:SetSpec(v)end)end);specBtn:SetPoint('LEFT',classBtn,'RIGHT',8,0)
 slotBtn=button(frame,'전체 부위',132,31,function(a)local list={{value='all',label='전체 부위'}};for _,s in ipairs(B.slotOrder) do list[#list+1]={value=s,label=B.slotNames[s]} end;menu(a,list,db.slot,function(v)db.slot=v;B:RefreshUI()end)end);slotBtn:SetPoint('LEFT',specBtn,'RIGHT',8,0)
 limitBtn=button(frame,'상위 5개',108,31,function(a)menu(a,{{value=3,label='상위 3개'},{value=5,label='상위 5개'},{value=10,label='상위 10개'}},db.top,function(v)db.top=v;B:RefreshUI()end)end);limitBtn:SetPoint('LEFT',slotBtn,'RIGHT',8,0)
 search=CreateFrame('EditBox',nil,frame,'InputBoxTemplate');search:SetAutoFocus(false);search:SetSize(340,31);search:SetPoint('LEFT',limitBtn,'RIGHT',17,0);search:SetText(db.search);search:SetScript('OnEscapePressed',function(e)e:ClearFocus()end);search:SetScript('OnEnterPressed',function(e)e:ClearFocus()end)
 search:SetScript('OnTextChanged',function(e)if db.search~=e:GetText() then db.search=e:GetText();B:RefreshUI() end end)
 local searchHint=text(frame,10,.60,.68,.77);searchHint:SetPoint('TOPLEFT',search,'BOTTOMLEFT',0,-3);searchHint:SetText('아이템명 / 획득처 / ID 검색')
 lockedBtn=button(frame,'제한 제외',130,27,function()db.showLocked=not db.showLocked;B:RefreshUI()end);lockedBtn:SetPoint('TOPLEFT',classBtn,'BOTTOMLEFT',0,-12)
 unknownBtn=button(frame,'미확인 포함',130,27,function()db.showUnknown=not db.showUnknown;B:RefreshUI()end);unknownBtn:SetPoint('LEFT',lockedBtn,'RIGHT',8,0)
 sideBtn=button(frame,'내 진영',130,27,function()db.sideOnly=not db.sideOnly;B:RefreshUI()end);sideBtn:SetPoint('LEFT',unknownBtn,'RIGHT',8,0)
 tooltipBtn=button(frame,'가방 비교 켬',130,27,function()db.showTooltip=not db.showTooltip;B:RefreshUI(true)end);tooltipBtn:SetPoint('LEFT',sideBtn,'RIGHT',8,0)
 local left=CreateFrame('Frame',nil,frame);left:SetSize(570,449);left:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-145);tint(left,.075,.10,.14,1);edge(left,.24,.32,.42)
 scroll=CreateFrame('ScrollFrame','ForeverBiSAuditItemScroll',left,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',left,'TOPLEFT',7,-7);scroll:SetPoint('BOTTOMRIGHT',left,'BOTTOMRIGHT',-26,7);child=CreateFrame('Frame',nil,scroll);child:SetSize(530,400);scroll:SetScrollChild(child)
 local right=CreateFrame('Frame',nil,frame);right:SetSize(386,449);right:SetPoint('TOPLEFT',left,'TOPRIGHT',8,0);tint(right,.08,.11,.15,1);edge(right,.24,.32,.42)
 detail={};detail.icon=right:CreateTexture(nil,'ARTWORK');detail.icon:SetSize(44,44);detail.icon:SetPoint('TOPLEFT',right,'TOPLEFT',13,-13)
 detail.title=text(right,16,1,.85,.5);detail.title:SetPoint('TOPLEFT',detail.icon,'TOPRIGHT',10,0);detail.title:SetSize(300,43);detail.title:SetJustifyV('TOP')
 detail.rank=text(right,12,.75,.87,.98);detail.rank:SetPoint('TOPLEFT',right,'TOPLEFT',13,-66);detail.rank:SetSize(360,22)
 local show=button(right,'아이템 툴팁',170,27,function(a)B:RankTooltip(a,selected)end);show:SetPoint('TOPLEFT',right,'TOPLEFT',13,-93);show:SetScript('OnEnter',function(a)B:RankTooltip(a,selected)end);show:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
 local chat=button(right,'채팅 링크',170,27,function()if selected then B:RankChatLink(selected) end end);chat:SetPoint('LEFT',show,'RIGHT',8,0)
 local dscroll=CreateFrame('ScrollFrame','ForeverBiSAuditDetailScroll',right,'UIPanelScrollFrameTemplate');dscroll:SetPoint('TOPLEFT',right,'TOPLEFT',13,-130);dscroll:SetSize(343,153);local dc=CreateFrame('Frame',nil,dscroll);dc:SetSize(337,360);dscroll:SetScrollChild(dc)
 detail.desc=text(dc,12,.87,.92,.96);detail.desc:SetPoint('TOPLEFT',dc,'TOPLEFT',0,0);detail.desc:SetWidth(331);detail.desc:SetJustifyV('TOP')
 detail.compare=text(right,12,.57,.91,.74);detail.compare:SetPoint('TOPLEFT',right,'TOPLEFT',13,-292);detail.compare:SetSize(355,66);detail.compare:SetJustifyV('TOP')
 detail.url=CreateFrame('EditBox',nil,right,'InputBoxTemplate');detail.url:SetSize(350,24);detail.url:SetAutoFocus(false);detail.url:SetPoint('TOPLEFT',right,'TOPLEFT',17,-368);detail.url:SetScript('OnEditFocusGained',function(e)e:HighlightText()end);detail.url:SetScript('OnEscapePressed',function(e)e:ClearFocus()end)
 detail.source=text(right,10,.62,.74,.85);detail.source:SetPoint('TOPLEFT',right,'TOPLEFT',13,-402);detail.source:SetSize(358,40);detail.source:SetJustifyV('TOP')
 counts=text(frame,11,.68,.84,.92);counts:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',18,32);local foot=text(frame,10,.75,.77,.80);foot:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',18,12);foot:SetText('Shift+클릭: 아이템 링크  ·  실제 한글명은 서버 데이터 로딩 후 갱신  ·  순위와 Pawn 점수는 별개입니다.')
 B.frame=frame;B.detail=detail;B.rankRows=rows;B.rankSearch=search;B.rankClassButton=classBtn;B.rankSpecButton=specBtn;frame:Hide();self:RefreshUI()
end

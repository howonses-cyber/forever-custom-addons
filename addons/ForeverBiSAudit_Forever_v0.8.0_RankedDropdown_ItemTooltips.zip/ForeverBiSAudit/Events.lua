local _,B=...
if not CreateFrame then return end
local f=CreateFrame('Frame')
for _,event in ipairs({'PLAYER_LOGIN','PLAYER_ENTERING_WORLD','PLAYER_EQUIPMENT_CHANGED','PLAYER_TALENT_UPDATE','BAG_UPDATE_DELAYED','GET_ITEM_INFO_RECEIVED','ITEM_DATA_LOAD_RESULT'}) do pcall(f.RegisterEvent,f,event) end
local pending=false;local elapsed=0
f:SetScript('OnEvent',function(_,event,id,success)
 if event=='PLAYER_LOGIN' or event=='PLAYER_ENTERING_WORLD' then
  if not B.db then B:Initialize() end
  if B.CreateMinimapButton and not B.minimapButtonFrame then B.minimapButtonFrame=B:CreateMinimapButton() end
 elseif event=='GET_ITEM_INFO_RECEIVED' or event=='ITEM_DATA_LOAD_RESULT' then
  B:RankDataEvent(id,success);pending=true
 else pending=true end
end)
f:SetScript('OnUpdate',function(_,dt)
 if not pending then return end;elapsed=elapsed+(dt or 0)
 if elapsed<.35 then return end;elapsed=0;pending=false
 if B.db and B.frame and B.frame:IsShown() then B:RefreshUI(true) end
end)

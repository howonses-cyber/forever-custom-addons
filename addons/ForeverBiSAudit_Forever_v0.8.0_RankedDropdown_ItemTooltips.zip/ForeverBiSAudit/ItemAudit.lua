local _, B = ...
-- Strict read-only cross-check of Pawn's parsed stats against the item's OWN
-- tooltip (not the currently-equipped comparison tooltip). Set bonus lines
-- must never be interpreted as intrinsic item stats or as a weapon proc.
local K = {
 Agility = "\235\175\188\236\178\169\236\132\177", Strength = "\237\158\152", Stamina = "\236\178\180\235\160\165",
 Intellect = "\236\167\128\235\138\165", Hit = "\236\160\129\236\164\145\235\165\160", HitRating = "\236\160\129\236\164\145\235\143\132",
 Crit = "\236\185\152\235\170\133\237\131\128", Spell = "\236\163\188\235\172\184", Equip = "\236\176\169\236\154\169 \237\154\168\234\179\188",
 AP = "\236\160\132\237\136\172\235\160\165", Set = "\236\132\184\237\138\184 \237\154\168\234\179\188", SetTitle = "\236\132\184\237\138\184",
 OnHit = "\234\179\181\234\178\169 \236\139\156", Proc = "\235\176\156\235\143\153 \237\154\168\234\179\188",
 DPS = "\236\180\136\235\139\185 \234\179\181\234\178\169\235\160\165",
}
local function valid(v) return type(v)=='number' and v==v and v>=0 and v<1000000 end
local function clean(v)
 if type(v)~='string' then return '' end
 return (v:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r',''):gsub(',',''))
end
local function tooltipLines(link)
 local out={}
 if C_TooltipInfo and type(C_TooltipInfo.GetHyperlink)=='function' then
  local ok,info=pcall(C_TooltipInfo.GetHyperlink,link)
  if ok and type(info)=='table' and type(info.lines)=='table' then
   for _,line in ipairs(info.lines) do
    if type(line.leftText)=='string' then out[#out+1]=clean(line.leftText) end
    if type(line.rightText)=='string' then out[#out+1]=clean(line.rightText) end
   end
  end
 end
 if #out>0 then return out end
 if not CreateFrame or not UIParent then return nil end
 if not B._statScanner then
  local ok,tip=pcall(CreateFrame,'GameTooltip','ForeverBiSAuditStatScanner',UIParent,'GameTooltipTemplate')
  if not ok then return nil end
  B._statScanner=tip
 end
 local tip=B._statScanner
 if not tip then return nil end
 local ok=pcall(function()
  tip:SetOwner(UIParent,'ANCHOR_NONE'); tip:SetHyperlink(link)
  local name=tip:GetName()
  for i=1,math.min(tip:NumLines() or 0,48) do
   for _,side in ipairs({'TextLeft','TextRight'}) do
    local obj=_G[name..side..i]
    if obj and type(obj.GetText)=='function' then
     local txt=obj:GetText()
     if type(txt)=='string' then out[#out+1]=clean(txt) end
    end
   end
  end
  tip:Hide()
 end)
 if not ok or #out==0 then return nil end
 return out
end
local function observe(t,stat,label,seen)
 local n=t:match(label..'%s*%+%s*(%d+%.?%d*)') or
   t:match('%+%s*(%d+%.?%d*)%s*'..label)
 if n and tonumber(n) and tonumber(n)>0 then
  local v=tonumber(n)
  if not seen[stat] or seen[stat]<v then seen[stat]=v end
 end
end
local function analyze(lines)
 local observed,hasSet,hasProc={},false,false
 local inSet=false
 for _,original in ipairs(lines) do
  local t=clean(original)
  local low=t:lower()
  if t:find(K.SetTitle,1,true) or t:find(K.Set,1,true) or
   t:match('%(%d+/%d+%)') or low:find('set bonus',1,true) or
   low:match('^set:') then
   inSet=true
   hasSet=true
  end
  if not inSet then
   observe(t,'Agility',K.Agility,observed)
   observe(t,'Strength',K.Strength,observed)
   observe(t,'Stamina',K.Stamina,observed)
   observe(t,'Intellect',K.Intellect,observed)
   observe(low,'Agility','agility',observed)
   observe(low,'Strength','strength',observed)
   observe(low,'Stamina','stamina',observed)
   observe(low,'Intellect','intellect',observed)
   -- A melee hit line must not be confused with spell hit or critical hit.
   local isCrit=t:find(K.Crit,1,true) or low:find('critical',1,true)
   local isSpell=t:find(K.Spell,1,true) or low:find('spell',1,true)
   if not isCrit and not isSpell then
    local n
    if t:find(K.Hit,1,true) then
     n=t:match('([%d%.]+)%%')
    elseif low:find('chance to hit',1,true) then
     n=low:match('([%d%.]+)%%')
    end
    if n and tonumber(n) and tonumber(n)>0 then
     observed.HitRating=math.max(observed.HitRating or 0,tonumber(n))
    end
    if t:find(K.HitRating,1,true) then observe(t,'HitRating',K.HitRating,observed) end
   end
   if t:find(K.AP,1,true) then observe(t,'Ap',K.AP,observed) end
   if low:find('attack power',1,true) then observe(low,'Ap','attack power',observed) end
   local dps=t:match(K.DPS..'%s*(%d+%.?%d*)') or low:match('damage per second%s*(%d+%.?%d*)')
   if dps and tonumber(dps) and tonumber(dps)>0 then observed.MeleeDps=tonumber(dps) end
   if (t:find(K.OnHit,1,true) or t:find(K.Proc,1,true) or
       low:find('chance on hit',1,true)) then hasProc=true end
  end
 end
 return observed,hasSet,hasProc
end
local names={Agility='AGI',Strength='STR',Stamina='STA',Intellect='INT',HitRating='HIT',Ap='AP',MeleeDps='WDPS'}
function B:AuditPawnItem(link,item)
 if not link or type(item)~='table' or type(item.Stats)~='table' then
  return nil,'Pawn \236\149\132\236\157\180\237\133\156 \236\160\149\235\179\180 \236\151\134\236\157\140'
 end
 self._statAuditCache=self._statAuditCache or {}
 local cached=self._statAuditCache[link]
 if cached and cached.stats==item.Stats then return cached.audit end
 local lines=tooltipLines(link)
 if not lines then return nil,'\236\149\132\236\157\180\237\133\156 \237\136\180\237\140\129 \236\157\189\234\184\176 \236\139\164\237\140\168' end
 local observed,hasSet,hasProc=analyze(lines)
 local missing={}
 for key,expected in pairs(observed) do
  local actual=item.Stats[key]
  if not valid(actual) or actual + 0.051 < expected then
   missing[#missing+1]=string.format('%s %.2f (Pawn %s)',names[key] or key,expected,tostring(actual))
  end
 end
 table.sort(missing)
 if #missing>0 then
  return nil,'Pawn \236\164\145\236\154\148 \235\138\165\235\160\165\236\185\152 \235\136\132\235\157\189: '..table.concat(missing,', ')
 end
 local audit={observed=observed,hasSet=hasSet,hasProc=hasProc}
 self._statAuditCache[link]={stats=item.Stats,audit=audit}
 return audit
end
B.AnalyzeRawTooltipLines=analyze -- pure analyzer for deterministic tests

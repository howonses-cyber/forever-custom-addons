local root=ADDON_ROOT or '/mnt/data/bis080/work/ForeverBiSAudit/'
local B={};SlashCmdList={};local asserts=0
local function check(ok,msg) asserts=asserts+1;assert(ok,msg) end
local function load(name) assert(loadfile(root..name))('ForeverBiSAudit',B) end
local mockMethods={}
local function object(parent)
 local o={parent=parent,shown=true,scripts={},w=530,h=400,vscroll=0}
 return setmetatable(o,{__index=function(_,key) return mockMethods[key] or function() end end})
end
function mockMethods:SetScript(k,v) self.scripts[k]=v end
function mockMethods:GetScript(k) return self.scripts[k] end
function mockMethods:SetSize(w,h)self.w=w;self.h=h end
function mockMethods:SetWidth(w)self.w=w end
function mockMethods:SetHeight(h)self.h=h end
function mockMethods:GetWidth()return self.w end
function mockMethods:GetHeight()return self.h end
function mockMethods:GetVerticalScroll()return self.vscroll end
function mockMethods:SetVerticalScroll(n)self.vscroll=n end
function mockMethods:SetText(t)self.labelText=t end
function mockMethods:GetText()return self.labelText or '' end
function mockMethods:Show()self.shown=true end
function mockMethods:Hide()self.shown=false end
function mockMethods:IsShown()return self.shown end
function mockMethods:CreateTexture()return object(self) end
function mockMethods:CreateFontString()return object(self) end
function mockMethods:GetParent()return self.parent end
function mockMethods:GetPoint()return 'CENTER',UIParent,'CENTER',0,0 end
function CreateFrame(_,name,parent) local o=object(parent);if name then _G[name]=o end;return o end
UIParent=object();UISpecialFrames={};GameTooltip=object();local tooltipLink,chat,requests=nil,nil,0
function GameTooltip:SetHyperlink(v)tooltipLink=v end
function ChatEdit_InsertLink(v)chat=v;return true end
function UnitClass()return '도적','ROGUE' end
function UnitFactionGroup()return 'Alliance' end
local info={};C_Item={GetItemInfo=function(id)return (function() if not info[id] then return end;return info[id],'|Hitem:'..id..'|h['..info[id]..']|h',3,60,50,'Armor','Leather',1,'INVTYPE_HEAD',12345 end)() end,RequestLoadItemDataByID=function()requests=requests+1 end,GetItemIconByID=function()return 12345 end,GetItemCount=function(id)return id==1001 and 1 or 0 end}
function GetInventoryItemID(_,slot)if slot==1 then return 1001 end end
function GetInventoryItemLink()return nil end
load('Core.lua');load('Specs.lua');load('RankedRuntime.lua');load('UI.lua')
B.catalog={{class='ROGUE',spec='combat',slot='Head',name='Example A',itemId=1001,rank=2,sourceKo='전리품 · 검은바위 나락',status='reference',faction='Both'},{class='ROGUE',spec='combat',slot='Head',name='Example B',itemId=1002,rank=1,sourceKo='퀘스트',status='reference',faction='Alliance'},{class='ROGUE',spec='combat',slot='Head',name='Example C',itemId=1003,rank=3,status='locked',faction='Both'},{class='ROGUE',spec='combat',slot='Head',name='Example D',itemId=1004,rank=4,status='unknown',faction='Horde'},{class='SHAMAN',spec='enhancement',slot='Feet',name='Other Class',itemId=1005,rank=1,status='reference'}}
B.rankedMeta={rows=5,profiles=2};B.db={class='ROGUE',spec='combat',showLocked=false,showUnknown=true,showTooltip=true,ui={x=0,y=0}}
B.ResolveEquipLocation=function()return 'INVTYPE_HEAD' end;B.VerifiedEquipPercent=function()return {comparedName='현재 착용',pct=2.5} end
local rows=B:RankEntries('ROGUE','combat',{unknown=true,sideOnly=true,faction='Alliance'});check(#rows==2,'side and lock filter');check(rows[1].itemId==1002,'source order');check(#B:RankEntries('ROGUE','combat',{unknown=true,search='나락'})==1,'source search');check(#B:RankEntries('ROGUE','combat',{unknown=true,top=1})==1,'top filter')
local row=rows[1];check(B:RankItemName(row,true)=='Example B','safe missing name');local q=requests;B:RankInfo(row,true);check(requests==q,'no duplicate request');info[1002]='한국어 장비';B:RankDataEvent(1002,true);check(B:RankItemName(row,true)=='한국어 장비','localized name');check(B:RankIcon(row)==12345,'icon');check(B:RankChatLink(row) and chat:find('item:1002',1,true),'chat link');B:RankTooltip(UIParent,row);check(tooltipLink:find('item:1002',1,true),'native tooltip');B:RankTooltip(UIParent,rows[2]);check(tooltipLink=='item:1001','uncached tooltip by id');local owned,worn=B:RankOwned(rows[2]);check(owned and worn,'worn detection')
B:BuildUI();check(B.frame and not B.frame:IsShown(),'initial hidden');B:Open();check(B.frame:IsShown(),'open');check(B.rankRows[1].item.itemId==1002,'rank row visible');check(B.detail.title.labelText=='한국어 장비','detail localized');B.rankRows[2]:GetScript('OnClick')(B.rankRows[2]);check(B.detail.title.labelText=='Example A','row select');local b=B.rankClassButton;b:GetScript('OnClick')(b);check(B.db.class=='ROGUE','dropdown does not cycle');B.rankSpecButton:GetScript('OnClick')(B.rankSpecButton);check(B.db.spec=='combat','spec dropdown does not cycle');B:SetClass('SHAMAN');check(B.db.spec=='enhancement','class resets spec');check(B.rankRows[1].item.itemId==1005,'other class list');B:SetClass('ROGUE');check(B.rankRows[1].item.itemId==1002,'back to rogue');B.db.search='나락';B:RefreshUI();check(B.rankRows[1].item.itemId==1001 and not B.rankRows[2]:IsShown(),'filter refresh');check(B.detail.title.labelText=='Example A','selection follows filter')
print('PASS ranked runtime and UI assertions: '..asserts)

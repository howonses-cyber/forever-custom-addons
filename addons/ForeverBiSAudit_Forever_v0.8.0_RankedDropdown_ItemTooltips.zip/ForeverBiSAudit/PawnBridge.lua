local _, B = ...
-- Optional integration only. We DO NOT redistribute or modify Pawn/Pawn Forever.
-- All scores are obtained at runtime from Pawn's published functions and the
-- user's installed Pawn scales. This file contains no third-party addon code.
local equippedSlots = {
 INVTYPE_HEAD={1}, INVTYPE_NECK={2}, INVTYPE_SHOULDER={3},
 INVTYPE_CLOAK={15}, INVTYPE_CHEST={5}, INVTYPE_ROBE={5},
 INVTYPE_WRIST={9}, INVTYPE_HAND={10}, INVTYPE_WAIST={6},
 INVTYPE_LEGS={7}, INVTYPE_FEET={8}, INVTYPE_FINGER={11,12},
 INVTYPE_TRINKET={13,14}, INVTYPE_RELIC={18}, INVTYPE_RANGED={18},
 INVTYPE_RANGEDRIGHT={18}, INVTYPE_THROWN={18},
 INVTYPE_WEAPONMAINHAND={16}, INVTYPE_WEAPONOFFHAND={17},
 INVTYPE_HOLDABLE={17}, INVTYPE_SHIELD={17}, INVTYPE_WEAPON={16},
 INVTYPE_2HWEAPON={16,17},
}
local classIds={WARRIOR=1,PALADIN=2,HUNTER=3,ROGUE=4,PRIEST=5,
 SHAMAN=7,MAGE=8,WARLOCK=9,DRUID=11}
local specsForKey={
 DRUID={balance=1,['feral-cat']=2,['feral-bear']=2,restoration=3},
}
local function isNum(v) return type(v)=='number' and v==v and v<1e9 and v>-1e9 end
local function getLink(slot)
 if type(GetInventoryItemLink)~='function' then return nil end
 local ok,link=pcall(GetInventoryItemLink,'player',slot)
 return ok and type(link)=='string' and link or nil
end
local function itemId(link)
 return type(link)=='string' and link:match('item:(%d+)') or nil
end
local function token(link)
 if type(link)~='string' then return nil end
 return link:match('|H(item:[^|]+)|h') or link:match('^(item:[^|]+)')
end
local function sameItem(a,b)
 -- Base item ID alone is NOT identity: random suffixes and enchants differ.
 local ai,bi=token(a),token(b)
 return ai~=nil and ai==bi
end
local function itemName(link)
 if not link then return '미착용' end
 if type(B.GetEquippedName)=='function' then return B.GetEquippedName(link) end
 return link:match('|h%[(.-)%]|h') or '현재 장비'
end
local function scaleInfo(class,spec)
 local specs=B.specs[class]
 if not specs then return end
 local index=specsForKey[class] and specsForKey[class][spec] or nil
 if not index then
  for i,sp in ipairs(specs) do if sp.key==spec then index=i;break end end
 end
 return classIds[class],index
end
function B:PawnReady()
 return type(PawnGetItemData)=='function' and type(PawnGetItemValue)=='function' and
  type(PawnCommon)=='table' and type(PawnCommon.Scales)=='table'
end
function B:PawnScale(class,spec)
 if not self:PawnReady() then return nil,'Pawn addon not loaded' end
 local classID,index=scaleInfo(class,spec)
 if not classID or not index then return nil,'Unsupported spec' end
 local best=nil
 for name,scale in pairs(PawnCommon.Scales) do
  if type(name)=='string' and type(scale)=='table' and type(scale.Values)=='table' and
   scale.ClassID==classID and scale.SpecID==index and
   scale.Provider=='PawnForever' then
   if not best or name<best then best=name end
  end
 end
 -- Pawn's generic/Classic weights are NEVER silently substituted for
 -- a Forever scale; the results can invert upgrade rankings.
 if not best then return nil,'Pawn Forever \237\138\185\236\132\177\235\179\132 \236\178\153\235\143\132 \237\149\132\236\154\148 (\236\157\188\235\176\152 Pawn\236\156\188\235\161\156 \235\140\128\236\178\180 \236\149\136 \237\149\168)' end
 return best,'Pawn Forever'
end
local function pawnScore(link,scale)
 if not link then return nil,'\236\149\132\236\157\180\237\133\156 \235\167\129\237\129\172 \236\151\134\236\157\140' end
 local ok,item=pcall(PawnGetItemData,link)
 if not ok or type(item)~='table' or type(item.Stats)~='table' then
  return nil,'Pawn \236\149\132\236\157\180\237\133\156 \236\160\149\235\179\180 \235\161\156\235\148\169 \236\164\145'
 end
 local audit,why=B:AuditPawnItem(link,item)
 if not audit then return nil,why end
 local ok2,value=pcall(PawnGetItemValue,item.Stats,item.Level or 0,
   item.SocketBonusStats,scale,false,true,true)
 if not ok2 or not isNum(value) then return nil,'Pawn \236\160\144\236\136\152 \234\179\132\236\130\176 \236\139\164\237\140\168' end
 return value,nil,audit,item.Stats
end
function B:PawnScoreLink(link,scale) return pawnScore(link,scale) end
local function possibleProc(link)
 if not link then return false end
 local ok,item=pcall(PawnGetItemData,link)
 if not ok or type(item)~='table' then return false end
 local audit=B:AuditPawnItem(link,item)
 return audit and audit.hasProc or false
end
B.PawnHasUnscoredProc=possibleProc
local function isHandSlot(loc) return loc=='INVTYPE_2HWEAPON' or loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND' or loc=='INVTYPE_WEAPONOFFHAND' or loc=='INVTYPE_SHIELD' or loc=='INVTYPE_HOLDABLE' end
local function pickEquipped(self,link,loc,scale,slotHint)
 local ids=equippedSlots[loc]
 if not ids then return nil,'장착 부위 확인 불가' end
 if type(GetInventoryItemLink)~='function' then return nil,'현재 착용 장비 조회 불가' end
 if isHandSlot(loc) and loc~='INVTYPE_2HWEAPON' then
  local main=getLink(16)
  local mloc=main and self:ResolveEquipLocation(main)
  if mloc=='INVTYPE_2HWEAPON' then
   return nil,'양손 무기 착용 중: 한손 단독 비교 불가'
  end
 end
 local options={}
 if loc=='INVTYPE_2HWEAPON' then
  local main=getLink(16)
  if not main then return nil,'현재 주무기 미착용' end
  local off=getLink(17)
  local all={main}
  if off then all[#all+1]=off end
  return all,nil,itemName(main)..(off and ' + '..itemName(off) or '')
 end
 local idSlots=ids
 if loc=='INVTYPE_WEAPON' then idSlots=slotHint=='OffHand' and {17} or {16} end
 if loc=='INVTYPE_WEAPONOFFHAND' then idSlots={17} end
 local empty=false
 for _,slot in ipairs(idSlots) do
  local current=getLink(slot)
  if current and sameItem(link,current) then return {current},nil,itemName(current) end
  if not current then empty=true end
 end
 if empty then return {},nil,'미착용 슬롯' end
 for _,slot in ipairs(idSlots) do
  local current=getLink(slot)
  local sc,why=pawnScore(current,scale)
  if sc==nil then return nil,why end
  options[#options+1]={link=current,score=sc,slot=slot}
 end
 table.sort(options,function(a,b)
  if a.score==b.score then return a.slot<b.slot end
  return a.score<b.score
 end)
 local opt=options[1]
 if not opt then return nil,'현재 장비 미확인' end
 return {opt.link},nil,itemName(opt.link)
end
function B:VerifiedEquipPercent(link,class,spec,loc,slotHint)
 local isSelected=self.db and self.db.class==class and self.db.spec==spec
 if isSelected then self._lastAudit=nil; self._lastAuditError=nil end
 local function fail(why)
  if isSelected then self._lastAuditError=why end
  return nil,why
 end
 local scale,source=self:PawnScale(class,spec)
 if not scale then return fail(source) end
 local current,reason,currentName=pickEquipped(self,link,loc,scale,slotHint)
 if not current then return fail(reason) end
 local incoming,why,candidateAudit,candidateStats=pawnScore(link,scale)
 if incoming==nil then return fail(why) end
 local baseline=0
 local proc=candidateAudit.hasProc
 local hasSet=candidateAudit.hasSet
 local equippedStats=nil
 local identical=false
 for _,wear in ipairs(current) do
  local points,err,wornAudit,wornStats=pawnScore(wear,scale)
  if points==nil then return fail(err) end
  baseline=baseline+points
  proc=proc or wornAudit.hasProc
  hasSet=hasSet or wornAudit.hasSet
  if #current==1 then equippedStats=wornStats end
  if sameItem(wear,link) then identical=true end
 end
 if identical and #current==1 then
  return {pct=0,rawCandidate=incoming,rawEquipped=baseline,source=source,
   comparedName=currentName,proc=proc,hasSet=hasSet,mode='same',scale=scale}
 end
 if baseline==0 then
  if incoming==0 and (proc or hasSet) then
   return {pct=nil,reason='\236\132\184\237\138\184/\235\176\156\235\143\153 \237\154\168\234\179\188 \237\143\137\234\176\128 \236\160\156\236\153\184',source=source,comparedName=currentName,proc=proc,hasSet=hasSet,mode='unscored'}
  end
  if incoming==0 then
   return {pct=0,rawCandidate=0,rawEquipped=0,source=source,
    comparedName=currentName,proc=proc,mode='bothZero',scale=scale}
  end
  return {pct=nil,reason='착용템 점수가 0이라 % 계산 불가',delta=incoming,
   source=source,comparedName=currentName,proc=proc,hasSet=hasSet,mode='zeroBaseline',scale=scale}
 end
 local percent=(incoming-baseline)/baseline*100
 if class==(self.db and self.db.class) and spec==(self.db and self.db.spec) then
  self._lastAudit={spec=spec,scale=scale,source=source,link=link,comparedName=currentName,
   observed=candidateAudit.observed,pawnStats=candidateStats,equippedStats=equippedStats,
   incoming=incoming,baseline=baseline,pct=percent,hasSet=hasSet,proc=proc}
 end
 if not isNum(percent) or math.abs(percent)>10000 then return fail('점수 이상치') end
 return {pct=percent,rawCandidate=incoming,rawEquipped=baseline,
  source=source,comparedName=currentName,proc=proc,hasSet=hasSet,mode='statScore',scale=scale}
end

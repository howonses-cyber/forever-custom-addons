local addon,G = ...
-- Basic, source-grounded written directions. We never infer road, ship or portal
-- connections from point proximity; the existing live navigation stays separate.
local fallbackContinents = {}
for map=1411,1413 do fallbackContinents[map]=1414 end
for map=1416,1437 do fallbackContinents[map]=1415 end
for map=1438,1452 do fallbackContinents[map]=1414 end
fallbackContinents[1453]=1415
fallbackContinents[1454]=1414
fallbackContinents[1455]=1415
fallbackContinents[1456]=1414
fallbackContinents[1457]=1414
fallbackContinents[1458]=1415
local phases={accept="수락",objective="수행",turnin="보고",entrance="입구",inside="던전"}
local function goodPoint(p)
 return type(p)=="table" and type(p.map)=="number" and
  type(p.x)=="number" and type(p.y)=="number" and
  p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function mapInfo(id)
 return G.SafeCall(C_Map and C_Map.GetMapInfo,id)
end
function G.StepPlace(p)
 if not goodPoint(p) then return nil end
 local info=mapInfo(p.map)
 local zone=(info and type(info.name)=="string" and info.name~="" and info.name) or
  (G.MapDisplayName(p.map) or "지역명 미확인")
 local continent=nil
 local visited={}
 local id=p.map
 for _=1,12 do
  if not id or visited[id] then break end
  visited[id]=true
  local i=mapInfo(id)
  if not i then break end
  if i.mapType==2 or id==1414 or id==1415 then
   continent=i.name
   break
  end
  local parent=tonumber(i.parentMapID)
  if not parent or parent<=0 or parent==id then break end
  id=parent
 end
 if not continent then
  local continentId=fallbackContinents[p.map]
  if continentId==1414 then continent="칼림도어" end
  if continentId==1415 then continent="동부 왕국" end
 end
 if continent==zone then continent=nil end
 return {map=p.map,continent=continent,zone=zone,x=p.x,y=p.y,name=p.name}
end
local function stageTitle(step)
 local label=phases[step.kind] or "이동"
 local qname=step.questName
 if type(qname)~="string" or qname=="" then
  qname=step.title or "퀘스트명 미확인"
  local suffix=" - "..label
  if qname:sub(-#suffix)==suffix then qname=qname:sub(1,-#suffix-1) end
 end
 return "["..label.."] "..qname
end
local function actionMessage(step)
 if step.contactType=="object" then return step.kind=="turnin" and "오브젝트와 상호작용해 보고하세요." or "오브젝트와 상호작용해 수락하세요." end
 if step.contactType=="item" then return "시작 아이템을 가방에서 사용해 수락하세요." end
 if step.kind=="turnin" then return "보고 대상에게 퀘스트를 보고하고 보상을 받으세요." end
 if step.kind=="accept" then return "수락 대상과 상호작용해 퀘스트를 받으세요." end
 if step.kind=="objective" or step.kind=="inside" then
  if step.objectiveTitle then return step.objectiveTitle.." · "..(step.objectiveKind=="creature" and "처치" or step.objectiveKind=="object" and "상호작용" or "획득/사용").." 후 퀘스트 로그의 진행 수량을 확인하세요." end
  if step.goalText then return step.goalText end
  return "퀘스트 목표를 수행하고 실제 진행 상태를 확인하세요."
 end
 if step.kind=="entrance" then return "던전 입구에 도착한 뒤 내부 이동 경로를 확인하세요." end
 if step.kind=="inside" then return "던전 내부의 목표를 수행하세요. 내부 위치는 별도 확인이 필요합니다." end
 return step.note or "퀘스트 로그에서 단계 완료 여부를 확인하세요."
end
function G.BuildStepDirections(step,playerPosition,reviewStatus)
 if type(step)~="table" then return nil end
 local title=stageTitle(step)
 if reviewStatus then
  local loc=step.indoor and (step.indoor.dungeon.." · "..step.indoor.room.." · "..step.indoor.npcName) or step.landmark and (step.landmark.zone.." · "..step.landmark.site) or step.point and step.point.name or step.contactName
  local lines={reviewStatus,"기록 열람 전용입니다. 이전/동선표를 눌러도 현재 진행률과 실제 여정은 바뀌지 않습니다."}
  if loc then lines[#lines+1]="기록 장소: "..loc end
  lines[#lines+1]="[현재 단계]로 돌아가 진행하세요."
  return {title=title,lines=lines,hasCoordinates=false,review=true}
 end
 local p=step.point
 local area=G.StepPlace(p)
 local indoor=step.indoor or (step.quest and G.QuestInsideInfo and G.QuestInsideInfo(step.quest,step.kind))
 local lines={}
 if step.quest==4083 and step.kind=="accept" then
  local rank
  if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
   local ok,a,b=pcall(GetProfessions)
   if ok then for _,slot in pairs({a,b}) do local yes,name,_,level,_,_,_,skillId=pcall(GetProfessionInfo,slot);if yes and (skillId==186 or name=="Mining" or name=="채광") then rank=level end end end
  end
  lines[#lines+1]="필수 조건: 채광 230 이상. 별루비 2개·금괴 20개·진은 주괴 10개를 준비하세요."
  if type(rank)=="number" and rank<230 then lines[#lines+1]="현재 채광 "..rank.."/230 · 조건을 충족하기 전에는 [나중에]로 보류하세요." end
 end
 if indoor then
  local inside=G.IsInGuideDungeon and G.IsInGuideDungeon(indoor.dungeonId)
  if not inside then
   lines[#lines+1]="1. "..indoor.dungeon.."에 입장하세요. 지도/여정은 던전 입구 부근까지 안내합니다."
   if indoor.dungeonId=="brd" then lines[#lines+1]="검은바위 산 중앙 섬에서 아래쪽 쇠사슬로 내려가 채석장과 북쪽 통로를 지나 나락 차원문으로 들어가세요." end
  else lines[#lines+1]="1. 현재 던전 내부에서 진행하세요." end
  local who=indoor.contactType=="object" and "오브젝트" or indoor.contactType=="item" and "시작 아이템" or indoor.contactType=="objective" and "목표" or "NPC"
  lines[#lines+1]="2. "..indoor.room.." → "..who.." "..indoor.npcName
  lines[#lines+1]="3. "..(indoor.instruction or actionMessage(step))
  if not indoor.verified and not indoor.instruction then lines[#lines+1]="DB에서 확인된 던전/대상입니다. 세부 방은 아직 확인되지 않았습니다." end
  if indoor.followup then
   lines[#lines+1]="5. 완료 후 연계 퀘스트 "..G.GetQuestName(indoor.followup).."을(를) 확인하세요."
  end
 elseif area then
  if area.continent then
   lines[#lines+1]="2. "..area.continent.." → "..area.zone.." 지역으로 이동하세요."
  else
   lines[#lines+1]="2. "..area.zone.."으로 이동하세요."
  end
  local coord=string.format("%.1f, %.1f",area.x*100,area.y*100)
  local subject=type(p.name)=="string" and p.name~="" and p.name or nil
  if subject then
   local who=step.contactType=="object" and "오브젝트 " or ((step.kind=="accept" or step.kind=="turnin") and "NPC " or "목표 ")
   local suffix=(step.kind=="accept" or step.kind=="turnin") and
    "에게 이동하세요." or " 위치로 이동하세요."
   lines[#lines+1]="3. "..who..subject.." ("..coord..")"..suffix
  else
   lines[#lines+1]="3. "..coord.." 좌표 지점으로 이동하세요."
  end
 elseif step.landmark then
  local landmark=step.landmark
  local region=(landmark.continent and (landmark.continent.." → ") or "")..(landmark.zone or "확인된 장소")
  if region=="재료 준비" or region=="시작 아이템" then
   lines[#lines+1]="1. "..region.." · "..(landmark.site or "준비 사항")
  else
   lines[#lines+1]="1. "..region.." → "..(landmark.site or "목표 장소")
  end
  if landmark.approach and G.StepPlace(landmark.approach) then
   local a=G.StepPlace(landmark.approach)
   lines[#lines+1]=string.format("접근 지점: %s (%.1f, %.1f) · 실제 목표와 구분",a.zone,a.x*100,a.y*100)
  end
  lines[#lines+1]="2. "..(landmark.instruction or actionMessage(step))
  if landmark.approxArea then lines[#lines+1]="DB에서 확인된 활동 지역입니다. 세부 위치는 현장 기준으로 탐색하세요." end
  if landmark.note and landmark.note~="" then lines[#lines+1]="참고: "..landmark.note end
 elseif step.regionHint then
  lines[#lines+1]="관련 지역: "..step.regionHint.." (퀘스트 분류 기준, 방문 장소와 다를 수 있음)"
  local target=step.objectiveTitle or step.contactName or step.questName or "퀘스트 목표"
  lines[#lines+1]="대상: "..target
  if step.goalText then lines[#lines+1]="실제 목표: "..step.goalText end
  lines[#lines+1]="실제 방문 장소를 확인할 자료가 부족해 임의 경로는 표시하지 않습니다."
 else
  lines[#lines+1]="대상: "..(step.contactName or step.objectiveTitle or step.questName or "퀘스트 목표")
  if step.goalText then lines[#lines+1]="실제 목표: "..step.goalText end
  lines[#lines+1]="실제 방문 장소를 확인할 자료가 부족합니다. 임의 좌표로 이동시키지 않습니다."
 end
 if not indoor and not step.landmark then lines[#lines+1]="4. "..actionMessage(step) end
 if area and not indoor then
  if goodPoint(playerPosition) and playerPosition.map==area.map then
   local label,dir
   if G.RouteDistanceLabel then label,dir=G.RouteDistanceLabel(playerPosition,p) end
   lines[#lines+1]="같은 지도: "..(dir and dir~="" and dir.." 방향 | " or "")..(label or "현재 위치 정보 미확인")
  elseif goodPoint(playerPosition) and playerPosition.map~=area.map then
   lines[#lines+1]="다른 지역입니다. 이동 수단·지형은 오른쪽 실시간 길찾기를 확인하세요."
  end
 end
 if (G.GuideStepNavPoint and G.GuideStepNavPoint(step)) or area then
  lines[#lines+1]="오른쪽 여정은 확인된 지도 지점까지 안내합니다."
 elseif indoor then
  lines[#lines+1]="던전 내부 이동은 위 장소 설명과 던전 네비게이터를 참고하세요."
 end
 return {title=title,lines=lines,area=area,indoor=indoor,hasCoordinates=area~=nil}
end

local addon,G=...
-- Read-only contact preview: never invoke Navigate, mutate active guide, or touch world-map pins.
local function legal(p)
 return type(p)=="table" and type(p.map)=="number" and p.map>0 and type(p.x)=="number" and type(p.y)=="number" and p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
function G.ContactPreview(id,stage)
 id=tonumber(id);if not id or (stage~="accept" and stage~="turnin") then return nil end
 local indoor=G.QuestInsideInfo(id,stage)
 local landmark=G.QuestStageLandmark(id,stage)
 local point=not indoor and not landmark and G.QuestPoint(id,stage)
 if not indoor and not landmark and not point then landmark=G.QuestContactLandmark(id,stage) end
 local name,_,_,kind=G.QuestContactName(id,stage)
 local r={id=id,stage=stage,name=name,kind=kind}
 if indoor then
  r.name=indoor.npcName or name;r.kind=indoor.contactType or kind
  r.place=indoor.dungeon.." · "..indoor.room;r.note=indoor.instruction or "던전 내부의 대상 위치는 아래 장소 설명을 참고하세요."
  r.dungeonId=indoor.dungeonId
  if legal(indoor.entrance) then r.point=indoor.entrance;r.map=r.point.map;r.approach=true end
 elseif landmark then
  r.name=landmark.target or name or landmark.site;r.place=table.concat({landmark.zone or "",landmark.site or ""}," · ")
  r.note=landmark.instruction or landmark.note;r.dungeonId=landmark.dungeonId
  if legal(landmark.approach) then r.point=landmark.approach;r.map=r.point.map;r.approach=true
  else r.map=tonumber(landmark.map) end
 elseif legal(point) then
  r.name=point.name or name;r.map=point.map;r.point=point;r.approx=point.approx==true
  r.place=G.MapDisplayName(point.map) or ("지도 #"..point.map)
 end
 r.name=r.name or (stage=="accept" and "수락 대상 미확인" or "보고 대상 미확인")
 r.place=r.place or "실제 방문 지역 미확인"
 r.note=r.note or (r.point and (r.approach and "지도는 접근 지점입니다. 실제 목표가 아닙니다." or "DB에 등록된 방문 위치입니다.") or "확인된 위치 좌표가 없습니다. 퀘스트 설명을 참고하세요.")
 return r
end
-- Forever supports native quest hyperlinks even for quests not in the log.
-- Prefer native GetQuestLink; for known DB quests use the documented/tested Forever format.
local function cleanName(s)
 if type(s)~="string" then return nil end
 s=s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[|%c%[%]]", "")
 if s=="" then return nil end
 return s
end
function G.QuestChatLink(id)
 id=tonumber(id);if not id or id<=0 or id%1~=0 then return nil end
 local native=G.SafeCall(GetQuestLink,id) or G.SafeCall(C_QuestLog and C_QuestLog.GetQuestLink,id)
 if type(native)=="string" and tonumber(native:match("|Hquest:(%d+):"))==id then return native end
 local known=G.activeQuests and G.activeQuests[id]
 local dbname=G.DBGet(QuestDB,id,"name")
 if not known and not (type(dbname)=="string" and dbname~="") then return nil end
 local name=cleanName(G.GetQuestName(id)) or cleanName(dbname)
 if not name then return nil end
 -- The placeholder prefix is a display-only annotation, not part of the quest title.
 if name:find("한글 명칭 미확인",1,true)==1 then name=cleanName(dbname) or name end
 return "|cff40c040|Hquest:"..id..":0|h["..name.."]|h|r"
end
function G.TryQuestChatClick(id)
 if not id or not IsShiftKeyDown or not IsShiftKeyDown() then return false end
 local edit=G.SafeCall(ChatEdit_GetActiveWindow) or G.SafeCall(ChatFrameUtil and ChatFrameUtil.GetActiveWindow)
 if not edit or (edit.IsShown and not edit:IsShown()) then return false end
 local link=G.QuestChatLink(id)
 if not link then G.Print("이 퀘스트의 확인된 링크가 없습니다.");return true end
 local insert=ChatEdit_InsertLink or (ChatFrameUtil and ChatFrameUtil.InsertLink)
 if type(insert)=="function" then
  local before=type(edit.GetText)=="function" and G.SafeCall(edit.GetText,edit)
  local ok,result=pcall(insert,link)
  if ok and result then return true end
  local after=type(edit.GetText)=="function" and G.SafeCall(edit.GetText,edit)
  if before~=nil and after~=nil and before~=after then return true end
  -- If the client gives no result and no readable edit text, avoid doubling.
  if ok and result==nil and (before==nil or after==nil) then return true end
 end
 if type(edit.Insert)=="function" then
  local ok=pcall(edit.Insert,edit,link);if ok then return true end
 end
 G.Print("채팅창에 퀘스트 링크를 넣을 수 없습니다.")
 return true
end

-- The popup uses the native map's lowest art layer and crops edge tiles.
-- No new global map pin, navigation state or game CVar is created.
local popup,canvas,heading,subheading,notice,details,marker,mapButton,dungeonButton,startButton,endButton,current
local tiles={}
local function font(parent,template,x,y,w,h)
 local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h);f:SetJustifyH("LEFT");f:SetJustifyV("TOP")
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=G.UIButton(parent,text,w,h,fn);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);return b
end
function G.MapPreviewTiles(map)
 local layers=G.SafeCall(C_Map and C_Map.GetMapArtLayers,map)
 if type(layers)~="table" then return nil end
 -- Select the smallest complete native art layer, independent of list ordering.
 local chosen
 for i,l in ipairs(layers) do
  local w,h,tw,th=tonumber(l.layerWidth),tonumber(l.layerHeight),tonumber(l.tileWidth),tonumber(l.tileHeight)
  if w and h and tw and th and w>0 and h>0 and tw>0 and th>0 then
   local cols,rows=math.ceil(w/tw),math.ceil(h/th)
   if cols*rows<=256 and (not chosen or w*h<chosen.w*chosen.h) then
    local tex=G.SafeCall(C_Map.GetMapArtLayerTextures,map,i)
    if type(tex)=="table" and #tex==cols*rows then
     local valid=true;for _,v in ipairs(tex) do if type(v)~="number" or v<=0 then valid=false;break end end
     if valid then chosen={w=w,h=h,tw=tw,th=th,cols=cols,rows=rows,tex=tex} end
    end
   end
  end
 end
 return chosen
end
local function paintMap(r)
 for _,t in ipairs(tiles) do t:Hide() end
 marker:Hide();notice:Hide()
 local art=r.map and G.MapPreviewTiles(r.map)
 if not art then
  notice:SetText("지도 이미지 없음\n확인된 장소와 좌표는 아래에서 확인하세요.");notice:Show();return false
 end
 local scale=math.min(390/art.w,246/art.h)
 local w,h=art.w*scale,art.h*scale
 local left,top=(390-w)/2,(246-h)/2
 for j=0,art.rows-1 do
  for i=0,art.cols-1 do
   local ix=j*art.cols+i+1
   local t=tiles[ix]
   if not t then t=canvas:CreateTexture(nil,"ARTWORK");tiles[ix]=t end
   local a,b=math.min(art.tw,art.w-i*art.tw),math.min(art.th,art.h-j*art.th)
   t:ClearAllPoints();t:SetPoint("TOPLEFT",canvas,"TOPLEFT",left+i*art.tw*scale,-top-j*art.th*scale)
   t:SetSize(a*scale,b*scale);t:SetTexture(art.tex[ix]);t:SetTexCoord(0,a/art.tw,0,b/art.th);t:Show()
  end
 end
 if legal(r.point) and r.point.map==r.map then
  marker:ClearAllPoints();marker:SetPoint("CENTER",canvas,"TOPLEFT",left+r.point.x*w,-top-r.point.y*h)
  marker.text:SetText(r.approach and "↗" or r.stage=="accept" and "!" or "?")
  marker:Show()
 else notice:SetText("정확한 대상 좌표 없음");notice:Show() end
 return true
end
local function render(id,stage)
 local r=G.ContactPreview(id,stage);if not r then return end
 current=r
 heading:SetText(G.GetQuestName(id))
 subheading:SetText((stage=="accept" and "시작 · " or "완료 · ")..r.name)
 G.UIButtonState(startButton,stage=="accept");G.UIButtonState(endButton,stage=="turnin")
 paintMap(r)
 local where=r.place
 if legal(r.point) then
  where=where.."\n"..(r.approach and "입구/접근 지점: " or r.approx and "참고 좌표: " or "위치: ")..(G.MapDisplayName(r.point.map) or "지도")..string.format(" (%.1f, %.1f)",100*r.point.x,100*r.point.y)
 end
 details:SetText(where.."\n"..r.note)
 mapButton:SetText(r.map and "지역 지도 열기" or "지도 없음")
 if r.map then mapButton:Enable() else mapButton:Disable() end
 if r.dungeonId then dungeonButton:Enable() else dungeonButton:Disable() end
end
local function build(parent)
 if popup then return end
 popup=CreateFrame("Frame","ForeverQuestContactPreview",parent or UIParent)
 popup:SetSize(424,460);popup:SetPoint("CENTER",parent or UIParent,"CENTER",70,0)
 popup:SetFrameStrata("FULLSCREEN_DIALOG");popup:SetToplevel(true);popup:SetClampedToScreen(true);popup:EnableMouse(true)
 popup:SetMovable(true);popup:RegisterForDrag("LeftButton")
 popup:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown()) then self:StartMoving() end end)
 popup:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
 local bg=popup:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.055,.065,.082,.99)
 local border=popup:CreateTexture(nil,"BORDER");border:SetPoint("TOPLEFT");border:SetPoint("TOPRIGHT");border:SetHeight(2);border:SetColorTexture(.91,.72,.34,1)
 heading=font(popup,"GameFontNormal",14,-12,355,19)
 button(popup,"×",382,-7,30,25,function()popup:Hide()end)
 startButton=button(popup,"!  시작 NPC",14,-38,190,26,function()if current then render(current.id,"accept") end end)
 endButton=button(popup,"?  완료 NPC",210,-38,200,26,function()if current then render(current.id,"turnin") end end)
 subheading=font(popup,"GameFontHighlight",14,-74,395,32);subheading:SetTextColor(.48,.82,.94)
 canvas=CreateFrame("Frame",nil,popup);canvas:SetSize(390,246);canvas:SetPoint("TOPLEFT",popup,"TOPLEFT",17,-109)
 local mapbg=canvas:CreateTexture(nil,"BACKGROUND");mapbg:SetAllPoints();mapbg:SetColorTexture(.09,.12,.15,1)
 notice=font(canvas,"GameFontHighlightSmall",6,-6,378,52);notice:SetJustifyH("CENTER");notice:SetTextColor(1,.82,.43)
 marker=CreateFrame("Button",nil,canvas);marker:SetSize(24,24);marker:SetFrameLevel(canvas:GetFrameLevel()+5)
 local m=marker:CreateTexture(nil,"BACKGROUND");m:SetAllPoints();m:SetColorTexture(.03,.04,.05,.95)
 marker.text=marker:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");marker.text:SetPoint("CENTER");marker.text:SetTextColor(1,.83,.13)
 marker:SetScript("OnEnter",function(self)
  if current and GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_RIGHT");GameTooltip:SetText(current.approach and "입구/접근 지점" or current.name);GameTooltip:AddLine(current.place,1,1,1,true);GameTooltip:Show() end
 end)
 marker:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 -- Scroll text independently, so long interior instructions cannot hide buttons.
 local scroll=CreateFrame("ScrollFrame",nil,popup);scroll:SetPoint("TOPLEFT",popup,"TOPLEFT",14,-360);scroll:SetSize(396,59)
 local child=CreateFrame("Frame",nil,scroll);child:SetSize(396,1);scroll:SetScrollChild(child)
 details=font(child,"GameFontHighlightSmall",0,0,386,1);details:SetWordWrap(true)
 scroll:EnableMouseWheel(true);scroll:SetScript("OnMouseWheel",function(self,d)self:SetVerticalScroll(math.max(0,math.min(self:GetVerticalScroll()-d*20,math.max(0,child:GetHeight()-self:GetHeight()))))end)
 popup._fdqScroll=scroll;popup._fdqDetailChild=child
 mapButton=button(popup,"지역 지도",14,-429,128,24,function()
  if current and current.map then G.OpenRegionMap(current.map) end
 end)
 dungeonButton=button(popup,"던전 지도",148,-429,128,24,function()
  if current and current.dungeonId then G.OpenDungeonNavigator() end
 end)
 button(popup,"닫기",282,-429,128,24,function()popup:Hide()end)
 popup:Hide()
end
local rawRender=render
render=function(id,stage)
 rawRender(id,stage)
 if details and popup and popup._fdqDetailChild then
  details:SetHeight(0);local h=math.max(1,math.ceil(details:GetStringHeight() or 1)+4)
  details:SetHeight(h);popup._fdqDetailChild:SetHeight(h);popup._fdqScroll:SetVerticalScroll(0)
 end
end
function G.ShowContactPreview(id,stage,parent)
 if not tonumber(id) then return end
 build(parent);render(id,stage);popup:Show()
end
function G.CloseContactPreview() if popup then popup:Hide() end end
function G.ContactPreviewSelectionChanged(id)
 if popup and popup:IsShown() and current and current.id~=id then popup:Hide() end
end

local addon,G=...
-- EUI Forever source exposes _G.EllesmereUIQuestTracker.ShowQuestDetails(id).
-- Its detail window is EUI_QuestDetails. Post-hook the public function: never
-- infer IDs from the visible title, never patch the official EUI files.
local installed,button,window,currentId
local function combat() return InCombatLockdown and InCombatLockdown() end
local function currentQuest(id)
 id=tonumber(id)
 return id and id>0 and G.IsInLog(id) and id or nil
end
local function attach(win)
 if button and window==win then return true end
 if combat() or not win or not win.focus or not win.untrack or not win.share or not win.abandon or type(win.GetChildren)~="function" then return false end
 -- Recognize the actual EUI layout before resizing its content viewport.
 -- If the EUI layout changes, fail closed instead of covering native buttons.
 local scroll,anchor,relative,relativePoint,x,y
 for _,child in ipairs({win:GetChildren()}) do
  if child:GetObjectType()=="ScrollFrame" and child:GetNumPoints()==2 then
   for n=1,child:GetNumPoints() do
    local a,r,rp,px,py=child:GetPoint(n)
    if a=="BOTTOMRIGHT" and r==win and rp=="BOTTOMRIGHT" and type(py)=="number" and py>=54 and py<=64 then
     scroll,anchor,relative,relativePoint,x,y=child,a,r,rp,px,py;break
    end
   end
  end
  if scroll then break end
 end
 if not scroll then return false end
 local b=G.UIButton(win,"퀘스트 동선 가이드",math.max(120,win:GetWidth()-28),24,function()
  if combat() then G.Print("전투가 끝난 뒤 퀘스트 동선 가이드를 눌러주세요.");return end
  local id=window and window:IsShown() and currentQuest(currentId)
  if not id then G.Print("퀘스트 상세창을 다시 열어주세요.");return end
  if G.StartQuickGuide(id) then window:Hide() end
 end,"primary")
 b:SetPoint("BOTTOMLEFT",win,"BOTTOMLEFT",14,54)
 b:SetPoint("BOTTOMRIGHT",win,"BOTTOMRIGHT",-14,54)
 -- Reserve a separate row above the existing four-button footer.
 scroll:SetPoint(anchor,relative,relativePoint,x,y+30)
 b:SetScript("OnEnter",function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,"ANCHOR_TOP")
  GameTooltip:AddLine("퀘스트 동선 가이드",.9,.75,.4)
  GameTooltip:AddLine("선택한 퀘스트의 수행 또는 보고부터 시작합니다.",1,1,1,true)
  GameTooltip:AddLine("기존 통합 동선은 보관됩니다.",.8,.85,.9,true)
  GameTooltip:Show()
 end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 win:HookScript("OnHide",function()currentId=nil;b:Hide()end)
 button,window=b,win
 return true
end
function G.RefreshEUIQuestBridge()
 local win=_G.EUI_QuestDetails
 if not win or not win:IsShown() then currentId=nil;if button then button:Hide() end;return false end
 local id=currentQuest(currentId)
 if not id then if button then button:Hide() end;return false end
 if not attach(win) then return false end
 button:SetText(G.IsReadyToTurnIn(id) and "퀘스트 동선 가이드 · 보고" or "퀘스트 동선 가이드")
 button:Show()
 return true
end
function G.InstallEUIQuestBridge()
 local eqt=_G.EllesmereUIQuestTracker
 if type(eqt)~="table" or type(eqt.ShowQuestDetails)~="function" or type(hooksecurefunc)~="function" then return false end
 if installed==eqt then return true end
 local ok=pcall(hooksecurefunc,eqt,"ShowQuestDetails",function(id)
  local win=_G.EUI_QuestDetails
  currentId=win and win:IsShown() and currentQuest(id) or nil
  G.RefreshEUIQuestBridge()
 end)
 if ok then installed=eqt end
 return ok
end

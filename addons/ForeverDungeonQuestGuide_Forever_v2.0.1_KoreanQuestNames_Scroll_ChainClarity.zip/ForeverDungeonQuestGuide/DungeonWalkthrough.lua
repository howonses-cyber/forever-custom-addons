local addon,G=...
-- Original Korean instructions based on the installed Forever quest IDs and
-- publicly documented encounter mechanics. These are textual routes, not
-- coordinates or a guaranteed geometry/pathfinder. Never change game state.
local records=G.walkthroughRecords
local WH="https://www.wowhead.com/forever/quest="
local brd="https://www.wowhead.com/forever/guide/blackrock-depths-dungeon-overview-location-rewards"
local brd2="https://mobalytics.gg/wow-forever/dungeons/blackrock-depths-guide"
local st="https://mobalytics.gg/wow-forever/dungeons/sunken-temple-dungeon-guide"
local st2="https://wowbocho.com/forever/dungeon/sunken-temple/"
local strat="https://www.wowhead.com/forever/guide/stratholme-live-side-dungeon-overview-location-rewards"
local scholo="https://www.wowhead.com/forever/guide/scholomance-dungeon-overview-location-rewards"
local zf="https://www.wowhead.com/forever/guide/zulfarrak-dungeon-overview-location-rewards"
local mara="https://mobalytics.gg/wow-forever/dungeons/maraudon-guide"
local function add(id,src,accept,objective,turnin,bag,items)
 records[id]={source="Forever 퀘스트 원문/DB · 공개 던전 공략 (공략 절차는 실기기 미검증)",urls={WH..id,src},accept=accept,objective=objective,turnin=turnin,bag=bag,items=items}
end
local function indoor(id,phase,dungeon,room,target,contactType)
 local m=G.specialQuestMeta[id] or {};G.specialQuestMeta[id]=m
 m.insideStages=m.insideStages or {}
 local prev=m.insideStages[phase] or {}
 prev.dungeon=dungeon;prev.room=room;prev.npcName=target;prev.contactType=contactType or prev.contactType or "objective";prev.verified=true
 m.insideStages[phase]=prev
end
local function objective(id,dungeon,room,target) indoor(id,"objective",dungeon,room,target,"objective") end
local function finish(id,dungeon,room,target,kind) indoor(id,"turnin",dungeon,room,target,kind or "npc") end
local function acceptAt(id,dungeon,room,target,kind) indoor(id,"accept",dungeon,room,target,kind or "npc") end
local prison="입구의 감금 구역 (Detention Block)"
local tavern="험상궂은 주정뱅이 선술집 (Grim Guzzler)"
local tomb="일곱 현자의 무덤 (Summoners' Tomb)"
local forge="검은 모루 (Black Anvil)"
local lower="하층, 뱀 석상 회랑과 버려진 구덩이 (Pit of Refuse)"
local shrine="타락한 신의 성소 (Sanctum of the Fallen God)"
local lair="에라니쿠스의 은신처"
-- The original material override used 791 (not Star Ruby); correct ID 7910
-- matches Forever quest 4083's item objective. Do not alter completion flags.
for _,o in ipairs(G.verifiedObjectives[4083] or {}) do if o.id==791 then o.id=7910 end end
G.verifiedItemRequirements[4083]={[7910]=2,[3577]=20,[6037]=10}
add(4083,brd2,{"채광 숙련 230 이상인지 확인하세요. 던전 입장 전에 별루비 2개, 금괴 20개, 진은 주괴 10개를 준비하세요.","나락의 선술집을 지나 일곱 현자의 무덤으로 가세요. 일곱 현자 전투를 시작하기 전에 그늘의 문지기(Gloom'rel)에게 말을 거세요.","대화로 나타난 유령의 성배 오브젝트를 클릭해 수락하세요."},{"성배에 요구되는 재료는 전부 거래·제작으로 준비할 수 있습니다. 성배 앞에서 재료를 확인하세요. 전투를 먼저 시작하지 마세요."},{"성배와 상호작용해 재료를 바친 뒤 그늘의 문지기에게 다시 대화해 검은무쇠 제련을 배우세요."},nil,{{7910,2,"별루비"},{3577,20,"금괴"},{6037,10,"진은 주괴"}})
add(4201,brd,{"선술집의 나그마라에게 수락해 빈 약병을 받으세요.","던전 밖으로 나가 재료를 준비하는 연계입니다. 파티에 재입장이 필요한 것을 알려 주세요."},{"그롬의 피 4개는 채집 또는 거래로 준비하세요.","아즈샤라의 절벽거인에게서 일반 은광석이 아닌 퀘스트 전용 거대한 은 광석 10개를 모으세요.","운고로 골락카 간헐천의 물이 흐르는 곳에서 빈 약병을 사용해 가득 찬 약병을 확보하세요."},{"세 재료를 챙겨 나락 선술집의 나그마라에게 다시 보고하세요."},{{11412,"나그마라의 빈 약병"}},{{8846,4,"그롬의 피"},{11405,10,"거대한 은 광석"},{11413,1,"가득 찬 약병"}})
add(4024,brd2,{"불타는 평원의 사이러스에게 수락하고 지급된 변형된 검은용군단 허물을 확인하세요."},{"나락 입구에서 용암이 보이는 통로 쪽으로 이동해 거인 벨가르(Bael'Gar)를 처치하세요.","전투가 끝난 뒤 벨가르의 시체 가까이에서 지급된 허물을 사용하세요. 보스를 잡는 것만으로는 완료되지 않습니다.","생성된 불타는 정수(Encased Fiery Essence)를 가방과 퀘스트 로그에서 확인하세요."},{"정수를 가지고 불타는 평원의 사이러스에게 보고하세요."},{{11231,"변형된 검은용군단 허물"}},{{11230,1,"불타는 정수"}})
add(4123,"https://www.wowhead.com/forever/quest=4123/the-heart-of-the-mountain",{"불타는 평원의 맥스워트에게 수락하세요. 금고를 여는 데 필요한 유물 보관함 열쇠를 파티에서 확보할 계획을 세우세요."},{"검은바위 나락 안의 검은 금고(Black Vault)로 이동하세요.","금고에 있는 유물 보관함을 모두 열어 수호자 둠그립(Watchman Doomgrip)을 등장시키세요. 열쇠가 부족하면 먼저 검은무쇠 적에게서 확보하세요.","수호자를 처치하고 비밀 금고를 열어 산의 정수를 획득하세요. 단순 몬스터 전리품이 아닙니다."},{"산의 정수를 가지고 맥스워트에게 돌아가 보고하세요."},nil,{{11309,1,"산의 정수"}})
for _,id in ipairs({4126,4134}) do
 local giver=id==4126 and "던 모로 카라노스의 라그나르 썬더브루" or "황야의 땅 카르가스의 비비안 라그레이브"
 add(id,brd,{giver.."에게 양조법 회수 퀘스트를 받으세요."},{"나락 내부 선술집에 들어가 작은 술통 창고를 찾으세요.","창고에 있는 술통 3개를 파괴하면 헐레이와 경비병이 나타납니다. 파티가 전투 준비를 마친 뒤 시작하세요.","헐레이를 처치하고 시체에서 잃어버린 양조법을 획득하세요."},{giver.."에게 양조법을 보고하세요."},nil,{{11312,1,"잃어버린 썬더브루 양조법"}})
end
add(4136,brd,{"불타는 평원 화염 마루의 유카에게 수락하세요. 유카를 찾는 타나리스 선행은 이미 이 퀘스트를 보유했다면 다시 할 필요가 없습니다."},{"나락 내부 선술집의 손님들 사이에서 리블리 스크류스피곳을 찾으세요.","파티 준비 후 리블리를 처치해 머리를 회수하세요. 다른 중립 손님을 불필요하게 공격하지 마세요."},{"리블리의 머리를 유카에게 가져가세요."},nil,{{11313,1,"리블리의 머리"}})
add(4241,brd2,{"불타는 평원 모건의 망루의 맥스웰에게 수락하세요."},{"나락에 입장한 후 입구 근처 감금 구역을 돌아 윈저가 갇힌 감방을 찾으세요. 감옥 문을 여는 데 필요한 열쇠를 파티에서 확인하세요."},{"감방 안 윈저에게 직접 보고하고 [실망] 연계를 받으세요. 맥스웰에게 먼저 돌아갈 단계가 아닙니다."})
add(4264,brd2,{"[실망]을 맥스웰에게 보고한 상태에서 나락의 검은무쇠 적들을 처치해 꼬깃꼬깃한 쪽지를 얻으세요.","전리품에서 받은 쪽지를 가방에서 우클릭해 퀘스트를 시작하세요."},{"쪽지를 확보한 상태로 감금 구역의 윈저 감방에 가세요."},{"윈저에게 쪽지를 보여 주고 다음 정보 회수 퀘스트를 수락하세요."},{{11446,"꼬깃꼬깃한 쪽지"}})
add(4282,brd2,{"감금 구역의 윈저에게 수락하세요. 앵거포지와 아젤마크를 모두 처치할 파티 동선을 잡으세요."},{"동부 병영에서 사령관 앵거포지를 처치하고 정보 조각을 회수하세요.","제작 구역의 골렘 군주 아젤마크도 처치하고 다른 정보 조각을 회수하세요.","가방에 서로 다른 정보 조각 두 종류가 있는지 확인하세요. 한 보스만 잡아서는 완료되지 않습니다."},{"던전을 나가기 전에 윈저 감방에 돌아가 두 정보 조각을 제출하세요. 다음 호위 퀘스트를 받을 수 있습니다."},nil,{{11464,1,"윈저의 잃어버린 정보"},{11465,1,"윈저의 잃어버린 정보 (다른 조각)"}})
add(4322,brd2,{"윈저에게 호위를 수락하기 전 감금 구역의 적을 정리하고 파티가 모두 준비됐는지 확인하세요."},{"윈저가 감방을 나서면 멀리 앞서거나 뒤처지지 말고 따라가세요.","이동 중 윈저의 장비 회수와 다른 포로 구출이 진행됩니다. 나타나는 적을 처리하고 윈저를 살려 두세요.","입구까지 호위를 마쳐 실제 로그에서 탈옥 완료를 확인하세요."},{"던전 밖으로 나온 뒤 불타는 평원 모건의 망루의 맥스웰에게 보고하세요."})
add(4341,brd2,{"아이언포지의 국왕 마그니에게 수락한 뒤 나락 감금 구역으로 이동할 준비를 하세요."},{"입구 근처 감금 구역에서 카란 마이트해머의 감방을 찾으세요. 감방이 잠겨 있다면 감옥 열쇠를 확보한 파티원이 열어야 합니다."},{"감방 안 카란에게 직접 보고하고 후속 이야기를 들으세요. 보고하기 전에 던전에서 나가지 마세요."})
add(4342,brd2,{"나락 감금 구역의 카란에게 이야기를 듣는 연계를 받으세요."},{"카란의 대화를 끝까지 진행하세요. 적을 처치하거나 야외로 이동하는 단계가 아닙니다."},{"같은 감방의 카란에게 보고하고 아이언포지로 소식을 전하는 후속을 받으세요."})
add(4362,brd,{"국왕 마그니에게 수락한 뒤 제왕의 왕좌까지 진행할 파티를 구성하세요. 공주를 살려야 한다는 점을 미리 알리세요."},{"나락 마지막 구역인 제왕의 왕좌로 가세요.","제왕 다그란 타우릿산만 처치하고 공주 모이라를 죽이지 마세요. 광역 공격이나 자동 공격 대상에 주의하세요."},{"제왕 처치 뒤 살아 있는 모이라에게 바로 보고하고 후속 퀘스트를 수락하세요."})
add(3802,brd,{"검은바위 산 중앙 구조물에서 유령 상태의 프랑클론에게 열쇠 연계를 수락하세요. 살아 있는 상태에서는 그를 볼 수 없습니다."},{"나락에 입장해 검은 모루에서 빛의 전당 방향으로 진행해 파이너스 다크바이어(Fineous Darkvire)를 찾으세요.","파이너스를 처치해 망치 무쇠지옥(Ironfel)을 회수하세요."},{"타우릿산의 제단에 있는 프랑클론 기념비와 상호작용하여 무쇠지옥을 제출하세요. 보상으로 어둠괴철로단 열쇠를 얻습니다."},nil,{{10999,1,"무쇠지옥 (Ironfel)"}})
-- 7848 is the active Forever ID from QuestieDB, not the duplicate historical 7487.
objective(7848,"brd","일곱 현자의 무덤 이후, 화산 심장부 차원문으로 연결되는 다리","핵 조각 (Core Fragment)")
add(7848,"https://www.wowhead.com/forever/quest=7848/attunement-to-the-core",{"검은바위 산의 나락 입구로 내려가는 통로에서 로소스 리프트웨이커에게 수락하세요.","깊은 던전까지 들어가므로 파티와 열쇠 및 진행 경로를 확인하세요."},{"나락에서 선술집 → 화염술사 구역 → 일곱 현자의 무덤을 지나 화산 심장부 차원문으로 이어지는 돌다리를 찾으세요. 일반 공략 경로이며 지형 단축은 파티 상황에 따라 달라집니다.","차원문 바로 옆 왼쪽의 핵 조각 오브젝트를 찾아 상호작용해 1개를 획득하세요.","조각을 얻기 전에 화산 심장부 차원문을 통과하지 마세요."},{"나락 밖의 로소스 리프트웨이커에게 핵 조각을 보고하세요."},nil,{{18412,1,"핵 조각"}})
-- Sunken Temple: lower event and upper encounters are separate routes.
objective(3528,"sunken",shrine,"학카르의 화신")
add(3528,"https://www.wowhead.com/forever/quest=3528/the-god-hakkar",{"타나리스 스팀휘들 항구의 예킨야에게 수락하고 학카르의 알을 받으세요. 알이 가방에 있는지 확인하세요."},{"아탈학카르 신전에 입장한 뒤 상층의 타락한 신의 성소로 가세요. 하층 석상 퍼즐과 다른 방입니다.","파티가 준비되면 가방의 학카르의 알을 사용해 소환 이벤트를 시작하세요.","나타나는 피를 지닌 학카리 적을 처치해 학카리의 피를 얻고, 그 피로 성소의 불꽃을 하나씩 끄세요.","모든 불꽃이 꺼지면 나타나는 학카르의 화신을 처치하세요. 학카르의 정수를 확보해 알에 담으세요.","가득 찬 학카르의 알을 가방과 퀘스트 로그에서 확인하세요."},{"가득 찬 알을 타나리스의 예킨야에게 가져가 보고하세요."},{{10465,"학카르의 알"}},{{10662,1,"가득 찬 학카르의 알"}})
objective(3446,"sunken",lower,"학카르의 제단")
finish(3446,"sunken",lower,"학카르의 제단","object")
add(3446,st2,{"타나리스 남쪽의 마본 리벳시커에게 수락하고 아탈라이 돌무리를 확인하세요."},{"신전 입구 층에서 아래로 내려가 뱀 석상 회랑 중앙 구덩이의 학카르 제단을 찾으세요. 상층 보스 방으로 갈 필요는 없습니다."},{"구덩이 아래 물가에 있는 학카르 제단을 클릭해 보고하세요. 아래층 석상 퍼즐도 함께 진행할 수 있습니다."},{{10466,"아탈라이 돌무리"}})
-- No explicit kill/objective in the DB; the hand-in itself is the puzzle result.
G.specialQuestMeta[3446].directTurnin=true
objective(3447,"sunken",lower,"아탈알라리온과 학카르 우상")
finish(3447,"sunken",lower,"학카르의 우상","object")
local circle={"입구 층에서 하층 뱀 석상 회랑으로 내려가 중앙 구덩이를 둘러싼 여섯 석상을 찾으세요.","미니맵 북쪽을 위로 맞추고 남 → 북 → 남서 → 남동 → 북서 → 북동 순서로 한 사람이 석상을 클릭하세요.","순서가 맞으면 석상이 활성화되고 중앙 구덩이에 아탈알라리온이 등장합니다. 파티와 함께 처치하세요.","구덩이 물가의 학카르 우상과 상호작용하세요. 석상 클릭만으로 완료되는 것이 아닙니다."}
add(3447,st2,{"타나리스의 마본 리벳시커에게 수락하세요. [심연의 늪]과 같이 진행하면 좋습니다."},circle,{circle[1],circle[2],circle[3],"보스 처치 뒤 중앙 물가의 학카르 우상(Idol of Hakkar)을 클릭하여 보고하고 보상 단지를 획득하세요."})
G.specialQuestMeta[3447].directTurnin=true
acceptAt(3373,"sunken",lair,"에라니쿠스의 정수","item")
finish(3373,"sunken",lair,"정수의 샘 (Essence Font)","object")
G.specialQuestMeta[3373].directTurnin=true
add(3373,st,{"상층 끝의 에라니쿠스의 망령을 처치하세요. 전리품으로 얻은 에라니쿠스의 정수를 가방에서 사용해 퀘스트를 시작하세요."},{"보스가 있던 은신처를 벗어나지 말고 뒤쪽의 정수의 샘을 찾으세요."},{"보스 뒤의 정수의 샘에 정수를 바쳐 퀘스트를 완료하세요. 던전을 나온 뒤 야외 NPC를 찾는 퀘스트가 아닙니다."},{{10454,"에라니쿠스의 정수"}})
objective(1446,"sunken","상층, 아탈라이 수호자 이후 예언자의 방","예언자 잠말란")
add(1446,"https://questing.wiki/wow-forever/dungeons/sunken-temple/quests/",{"동부 내륙지의 추방된 아탈라이트롤에게 수락하세요."},{"상층 회랑의 아탈라이 수호자들을 처치해 예언자 구역으로 가는 길을 여세요.","예언자 잠말란과 함께 있는 적을 처치한 뒤 잠말란의 머리를 회수하세요."},{"머리를 동부 내륙지의 추방된 아탈라이트롤에게 전달하세요."},nil,{{6212,1,"잠말란의 머리"}})
-- Stratholme: do not redirect an internal objective to the exterior chapel.
objective(5214,"strat","정문 쪽 시가지의 담배 가게","에즈라 그림 / 담배 상자")
add(5214,strat,{"동부 역병지대 희망의 빛 예배당의 스모키 라루에게 수락하세요."},{"스트라솔름 정문 쪽 시가지에서 담배 가게를 찾으세요.","가게의 퀘스트 오브젝트와 상호작용하면 에즈라 그림(구 프라스 샤비)과 적이 등장할 수 있습니다. 파티 전투 준비 후 진행하세요.","담배 상자에서 그림의 최고급 담배 1개를 확보하세요."},{"담배를 스모키 라루에게 보고하세요."},nil,{{13172,1,"그림의 최고급 담배"}})
objective(5251,"strat","붉은십자군 요새 내부 기록보관실","기록관 갈포드 / 기록물")
add(5251,strat,{"희망의 빛 예배당의 공작 니콜라스에게 수락하세요. 붉은십자군 요새 접근에 필요한 열쇠를 파티에서 확인하세요."},{"정문 쪽 시가지를 지나 붉은십자군 요새의 기록보관실로 가세요.","[가족과 사랑]도 진행한다면 그림을 먼저 회수한 뒤 기록물을 불태우는 편이 안전합니다.","기록관 갈포드를 처치하고 기록물 오브젝트와 상호작용해 불태우세요. 두 목표가 모두 완료되었는지 확인하세요."},{"희망의 빛 예배당의 공작 니콜라스에게 돌아가 보고하세요."})
objective(5848,"strat","붉은십자군 요새 기록보관실","두 달 그림 뒤에 숨은 그림")
add(5848,strat,{"티리온의 연계를 수락한 뒤 스트라솔름 정문 쪽 경로를 준비하세요."},{"붉은십자군 요새 안 기록보관실에서 두 개의 달이 그려진 그림을 찾으세요.","그림 뒤의 [가족과 사랑]을 회수하세요. 기록관 퀘스트의 기록물 방화보다 먼저 그림을 챙기는 것이 안전합니다."},{"그림을 티리온 폴드링에게 전달하세요."},nil,{{14679,1,"가족과 사랑"}})
objective(5282,"strat","시가지의 유령·망령 시민 활동 구역","잠 못드는 영혼")
add(5282,"https://www.wowhead.com/forever/quest=5282/the-restless-souls",{"에간에게 수락하고 가방에 지급된 에간의 제령포를 확인하세요."},{"스트라솔름 내부에서 유령 시민 또는 망령 시민을 찾으세요.","시민을 대상으로 지정해 에간의 제령포를 사용하세요. 시민에게서 영혼이 분리되어 나타납니다.","나타난 잠 못드는 영혼을 대상으로 다시 제령포를 사용하세요. 두 번째 사용으로 해방 수량이 증가하는지 확인하세요.","같은 방법으로 영혼 15명을 해방하세요."},{"에간에게 돌아가 보고하세요."},{{13289,"에간의 제령포"}})
-- Scholomance.
objective(5382,"scholo","후반부, 바닥에 유해가 있는 도살자 방","테올렌 크라스티노브와 두 유해")
add(5382,scholo,{"서부 역병지대 카엘 다로우의 에바 사크호프에게 수락하세요."},{"스칼로맨스 후반의 도살자 테올렌 크라스티노브를 찾아 처치하세요.","그 방에 있는 에바 사크호프의 유해와 루시엔 사크호프의 유해를 각각 클릭해 불태우세요.","처치 및 유해 두 개가 모두 완료되었는지 퀘스트 로그를 확인하세요."},{"던전 밖 카엘 다로우의 에바에게 보고하세요."})
objective(5515,"scholo","잔다이스 바로브가 있는 방","잔다이스 바로브")
add(5515,scholo,{"에바의 도살자 연계를 마치고 가방 회수 퀘스트를 받으세요."},{"스칼로맨스의 잔다이스 바로브가 있는 방으로 이동하세요.","분신 전투를 마치고 실제 보스 시체에서 크라스티노브의 가방을 회수하세요."},{"가방을 에바에게 가져가고 소환 연계를 확인하세요."},nil,{{13725,1,"크라스티노브의 가방"}})
objective(5466,"scholo","라스 프로스트위스퍼의 방","라스 프로스트위스퍼")
add(5466,scholo,{"카엘 다로우의 집정관 마르듀크에게 수락하고 영혼이 깃든 추억의 유품(Soulbound Keepsake)을 확인하세요."},{"스칼로맨스 내부의 라스 프로스트위스퍼를 찾으세요. 바로 처치하지 말고 파티에 아이템 사용이 필요하다고 알리세요.","라스를 대상으로 지정해 지급된 유품을 사용해 인간 모습으로 되돌리세요.","변신 후 처치하고 인간 모습 라스의 머리를 획득하세요."},{"머리를 집정관 마르듀크에게 전달하세요."},{{13752,"영혼이 깃든 추억의 유품"}},{{13626,1,"라스 프로스트위스퍼의 인간 머리"}})
-- Zul'Farrak and Maraudon.
objective(2770,"zf","물웅덩이 쪽 큰 징","가즈릴라")
add(2770,zf,{"소금 평원의 위즐 브라스볼츠에게 수락하세요. 파티원 중 한 명이 줄파락의 망치를 준비해야 합니다.","망치가 없다면 동부 내륙지 줄의 제단에서 키아가의 신성한 망치를 획득하고 진타알로 정상 제단에서 사용해 줄파락의 망치로 만드세요."},{"줄파락 안의 물웅덩이 앞 큰 징으로 이동하세요.","파티가 준비되면 망치를 가진 플레이어가 징과 상호작용하여 가즈릴라를 소환하세요.","가즈릴라를 처치하고 전기를 띤 비늘을 확보하세요."},{"소금 평원의 위즐에게 비늘을 보고하세요."},nil,{{8707,1,"가즈릴라의 전기 비늘"}})
objective(2768,"zf","피라미드 위 포로 구역","하사관 블라이")
add(2768,"https://www.wowhead.com/classic/quest=2768/divino-matic-rod",{"가젯잔의 수석기술자 빌지위즐에게 수락하세요."},{"줄파락 피라미드 위의 포로 구역으로 가서 구조 이벤트를 시작하세요.","내려오는 적들의 공격을 막아 포로 구출 이벤트를 완료하세요.","블라이와 대화하면 전투가 시작될 수 있으므로 먼저 파티 체력·마나를 회복하세요. 블라이를 처치하고 자동 탐지 막대를 회수하세요."},{"가젯잔의 빌지위즐에게 막대를 전달하세요."},nil,{{8548,1,"자동 탐지 막대 (Divino-matic Rod)"}})
objective(7044,"mara","주황색·보라색 갈래와 셀레브라스 구역","셀레브리안 막대 및 다이아몬드")
finish(7044,"mara","셀레브라스의 동굴","구원받은 셀레브라스")
add(7044,mara,{"마라우돈 바깥 동굴의 카빈드라에게 수락하세요. 주황색·보라색 두 갈래 모두 진행할 필요가 있습니다."},{"주황색 갈래에서 녹시온(Noxxion)을 처치하여 셀레브리안 막대를 얻으세요.","보라색 갈래에서 군주 바일텅(Lord Vyletongue)을 처치해 셀레브리안 다이아몬드를 얻으세요.","두 재료를 가지고 셀레브라스의 구역으로 가서 저주받은 셀레브라스를 처치하세요."},{"전투 후 등장하는 구원받은 셀레브라스에게 두 재료를 제출하고 홀 제작 연계를 받으세요. 던전을 먼저 나가지 마세요."},nil,{{17703,1,"셀레브리안 막대"},{17702,1,"셀레브리안 다이아몬드"}})
-- The 7067 chain starts partly OUTSIDE the instance, so do not mark the
-- whole objective as an indoor step. Use a named entrance approach only.
local m=G.specialQuestMeta[7067] or {};G.specialQuestMeta[7067]=m;m.stageLandmarks=m.stageLandmarks or {}
m.stageLandmarks.objective={zone="마라우돈",site="외부 동굴 및 주황·보라 갈래 내부",target="이름 없는 예언자와 다섯 칸",instruction="입장 차원문 바깥에서부터 진행되는 퀘스트입니다. 외부 동굴의 예언자부터 찾으세요.",approach=G.GetDungeon("mara").entrance,verified=true}
add(7067,mara,{"잊혀진 땅의 추방된 켄타우로스에게 수락한 뒤 가방에 들어온 지침서를 읽으세요."},{"마라우돈 외부 동굴의 이름 없는 예언자를 처치해 영혼의 아뮬렛을 획득하세요.","콜크, 겔크, 마그라, 마라우도스, 벵의 영혼을 찾으세요. 일부는 입장 차원문 밖 동굴에 있고 일부는 던전 내부 갈래에 있습니다.","우호적인 영혼을 대상으로 아뮬렛을 사용하면 전투가 가능해집니다. 각각 처치해 보석을 회수하세요.","다섯 보석을 모은 뒤 영혼의 아뮬렛을 사용하여 결합의 아뮬렛을 만드세요."},{"결합의 아뮬렛을 잊혀진 땅의 추방된 켄타우로스에게 전달하세요."},{{17781,"추방자의 지침서"},{17757,"영혼의 아뮬렛"}},{{17758,1,"결합의 아뮬렛"}})

-- For mixed outdoor/material stages, keep the current target procedure first.
records[4201].byObjective={
 [8846]={"그롬의 피 4개를 경매장·거래 또는 직접 약초채집으로 준비하세요."},
 [11405]={"아즈샤라의 절벽거인에게서 퀘스트 전용 거대한 은 광석 10개를 획득하세요. 일반 은광석이 아닙니다."},
 [11413]={"운고로 골락카 간헐천으로 가세요. 간헐천 물이 흐르는 곳에서 빈 약병을 사용해 가득 찬 약병을 얻으세요."},
}
records[4083].byObjective={ [7910]={"별루비 2개를 준비하세요."},[3577]={"금괴 20개를 준비하세요."},[6037]={"진은 주괴 10개를 준비하세요."}}

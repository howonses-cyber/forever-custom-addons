local addon,G=...
-- A browsing-only grouping. This never changes checked IDs, the actual
-- prerequisite resolver, quest completion flags, or route ordering.
-- OR alternatives remain alternatives in the details pane, not extra required quests.
local function parents(id)
 local result,seen={},{}
 for _,p in ipairs(G.MandatoryRoutePrereqs(id) or {}) do
  if type(p)=="number" and p>0 and p~=id and not seen[p] then seen[p]=true;result[#result+1]=p end
 end
 table.sort(result);return result
end
local function process(entries,scope,addContext,out)
 if #entries==0 then return end
 local nodes,links,dsu,visited,positions={}, {}, {}, {}, {}
 local branchNodes={}
 local original={};local nContext=0
 local function root(q)
  local p=dsu[q]
  if not p then dsu[q]=q;return q end
  while p~=dsu[p] do dsu[p]=dsu[dsu[p]];p=dsu[p] end
  dsu[q]=p;return p
 end
 local function union(a,b)
  a,b=root(a),root(b);if a==b then return end
  if a<b then dsu[b]=a else dsu[a]=b end
 end
 for i,e in ipairs(entries) do nodes[e.id]=e;positions[e.id]=i;original[e.id]=true;root(e.id) end
 local function walk(q,depth)
  if visited[q] or depth>32 then return end
  visited[q]=true
  links[q]=parents(q)
  -- If the route resolver chose a viable alternative, show that route branch
  -- as context. The other alternatives remain in the OR detail, not required rows.
  local alternative=false
  if G.QuestPrerequisite then
   local all,one=G.QuestPrerequisite(q)
   alternative=#one>1
   if not alternative then
    for _,pre in ipairs(all) do
     local ex=pre>0 and G.DBGet(QuestDB,pre,"exclusiveTo")
     if type(ex)=="table" and next(ex) then alternative=true;break end
    end
   end
  end
  if alternative and G.ResolveRouteRequirements and G.IsRouteSatisfied and not G.IsRouteSatisfied(q) then
   local graph=G.ResolveRouteRequirements(q,{})
   if graph and graph[q] then
    local have={};for _,p in ipairs(links[q]) do have[p]=true end
    for p in pairs(graph[q]) do
     if p~=q and not have[p] then links[q][#links[q]+1]=p;have[p]=true;branchNodes[q]=true end
    end
    table.sort(links[q])
   end
  end
  for _,p in ipairs(links[q]) do
   union(q,p)
   if addContext and not nodes[p] and nContext<180 and G.IsQuestBrowseVisible(p) and type(G.DBGet(QuestDB,p,"name"))=="string" then
    nContext=nContext+1;nodes[p]={kind="quest",id=p,meta=G.QuestListMeta(p),chainContext=true};positions[p]=#entries+nContext
   end
   walk(p,depth+1)
  end
 end
 for _,e in ipairs(entries) do walk(e.id,0) end
 local groups,ordered={},{}
 for q,e in pairs(nodes) do
  local k=root(q);local g=groups[k]
  if not g then g={members={},pos=math.huge,key=k};groups[k]=g;ordered[#ordered+1]=g end
  g.members[#g.members+1]=q;g.pos=math.min(g.pos,positions[q] or math.huge)
  if branchNodes[q] or #(links[q] or {})>1 then g.branch=true end
 end
 table.sort(ordered,function(a,b)if a.pos~=b.pos then return a.pos<b.pos end return a.key<b.key end)
 for _,g in ipairs(ordered) do
  local members=g.members
  table.sort(members,function(a,b)if positions[a]~=positions[b] then return positions[a]<positions[b] end return a<b end)
  local present={};for _,q in ipairs(members) do present[q]=true end
  -- Topological DFS on mandatory edges (including hidden ancestors). Cycles
  -- cannot recurse indefinitely; they are not interpreted as completion.
  local emitted,visiting,orderedIds,cycle={}, {}, {}, false
  local function order(q,depth)
   if emitted[q] or depth>64 then return end
   if visiting[q] then cycle=true;return end
   visiting[q]=true
   for _,p in ipairs(links[q] or {}) do order(p,depth+1) end
   visiting[q]=nil;emitted[q]=true
   if present[q] then orderedIds[#orderedIds+1]=q end
  end
  for _,q in ipairs(members) do order(q,0) end
  -- A hidden prerequisite may connect two visible quests, but is not added
  -- outside the dungeon scope and must not be silently checked.
  if #members>1 then
   local first=orderedIds[1] or members[1]
   local key=tostring(scope or "list")..":"..g.key
   local collapsed=G.db.chainCollapsed and G.db.chainCollapsed[key]==true
   local checked,done,extra=0,0,0
   for _,q in ipairs(members) do
    if G.db.selectedQuests[q] then checked=checked+1 end
    if G.IsRouteSatisfied(q) then done=done+1 end
    if not original[q] then extra=extra+1 end
   end
   out[#out+1]={kind="chain",key=key,label=G.GetQuestName(first),count=#members,checked=checked,done=done,extra=extra,collapsed=collapsed,cycle=cycle,branch=g.branch}
   if not collapsed then
    local names={}
    for _,q in ipairs(orderedIds) do local name=G.GetQuestName(q);names[name]=(names[name] or 0)+1 end
    for i,q in ipairs(orderedIds) do
     local e=nodes[q];e.chainIndex=i;e.chainCount=#members
     e.sameTitle=(names[G.GetQuestName(q)] or 0)>1
     e.chainBranch=g.branch==true
     out[#out+1]=e
    end
   end
  else
   local e=nodes[members[1]];out[#out+1]=e
  end
 end
end
function G.QuestChainRows(rows,scope,addContext)
 if not G.db or G.db.groupChains==false or not G.Ready() then return rows end
 local result,section={},{}
 local sectionKey=scope or "list"
 local function flush()process(section,sectionKey,addContext,result);section={} end
 for _,e in ipairs(rows) do
  if e.kind=="header" then
   flush();result[#result+1]=e;sectionKey=(scope or "list")..":"..e.label
  elseif e.kind=="quest" then section[#section+1]=e end
 end
 flush();return result
end
function G.ToggleChainGroup(key)
 if not key or not G.db then return end
 G.db.chainCollapsed=G.db.chainCollapsed or {}
 if G.db.chainCollapsed[key] then G.db.chainCollapsed[key]=nil else G.db.chainCollapsed[key]=true end
end

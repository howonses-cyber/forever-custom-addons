local addon,G=...
-- Exact source-title correspondence, not an assertion of current Forever availability.
-- Wowhead Classic (English/Korean) Nightmare Incursions Overview.
-- https://www.wowhead.com/classic/guide/season-of-discovery/nightmare-incursions-overview
-- https://www.wowhead.com/classic-ptr/ko/guide/season-of-discovery/nightmare-incursions-overview
local aliases={
 ["Hinterlands Mission I: Defeat Moonkin"]="동부 내륙지 임무 I: 달빛야수 처치",
 ["Hinterlands Mission II: Defeat Giant Turtles"]="동부 내륙지 임무 II: 거대 거북이 처치",
 ["Hinterlands Mission III: Defeat Dragonkin"]="동부 내륙지 임무 III: 용족 처치",
 ["Hinterlands Mission IV: Dragon Intelligence"]="동부 내륙지 임무 IV: 용 첩보",
 ["Hinterlands Mission V: Turtle Intelligence"]="동부 내륙지 임무 V: 거북이 첩보",
 ["Hinterlands Mission VI: Moonkin Intelligence"]="동부 내륙지 임무 VI: 달빛야수 첩보",
 ["Hinterlands Mission VII: Recover Star-Touched Dragonegg"]="동부 내륙지 임무 VII: 별에 물든 용의 알 회수",
 ["Hinterlands Mission VIII: Recover Elunar Relic"]="동부 내륙지 임무 VIII: 엘루나르 유물 회수",
 ["Hinterlands Mission IX: Recover Dreampearl"]="동부 내륙지 임무 IX: 꿈진주 회수",
 ["Hinterlands Mission X: Star Lotus"]="동부 내륙지 임무 X: 별빛연꽃",
 ["Hinterlands Mission XI: Starsilver Ore"]="동부 내륙지 임무 XI: 별빛은 광석",
 ["Hinterlands Mission XII: Starshells"]="동부 내륙지 임무 XII: 별빛껍질",
 ["Hinterlands Mission XIII: Defeat Florius"]="동부 내륙지 임무 XIII: 플로리우스 처치",
 ["Hinterlands Mission XIV: Defeat Doomkin"]="동부 내륙지 임무 XIV: 파멸의 자손 처치",
 ["Hinterlands Mission XV: Defeat Ghamoo-Raja"]="동부 내륙지 임무 XV: 가무라자 처치",
 ["Hinterlands Mission XVI: Rescue Elianar Shadowdrinker"]="동부 내륙지 임무 XVI: 엘리아나르 섀도드링커 구출",
 ["Hinterlands Mission XVII: Rescue Serlina Starbright"]="동부 내륙지 임무 XVII: 세를리나 스타브라이트 구출",
 ["Hinterlands Mission XVIII: Rescue Veanna Cloudsleeper"]="동부 내륙지 임무 XVIII: 베아나 클라우드슬리퍼 구출",
 ["Feralas Mission I: Defeat Children of Cenarius"]="페랄라스 임무 I: 세나리우스의 자손 처치",
 ["Feralas Mission II: Defeat Harpies"]="페랄라스 임무 II: 하피 처치",
 ["Feralas Mission III: Defeat Dragonkin"]="페랄라스 임무 III: 용족 처치",
 ["Feralas Mission IV: Dragon Intelligence"]="페랄라스 임무 IV: 용 첩보",
 ["Feralas Mission V: Cenarion Intelligence"]="페랄라스 임무 V: 세나리온 첩보",
 ["Feralas Mission VI: Harpy Intelligence"]="페랄라스 임무 VI: 하피 첩보",
 ["Feralas Mission VII: Recover Moonglow Dragonegg"]="페랄라스 임무 VII: 달빛너울 용의 알 회수",
 ["Feralas Mission VIII: Recover Keeper's Notes"]="페랄라스 임무 VIII: 수호자의 기록 회수",
 ["Feralas Mission IX: Recover Harpy Screed"]="페랄라스 임무 IX: 하피의 장광설 회수",
 ["Feralas Mission X: Moonroot"]="페랄라스 임무 X: 달뿌리",
 ["Feralas Mission XI: Greater Moonstone"]="페랄라스 임무 XI: 상급 월장석",
 ["Feralas Mission XII: Greater Moondragon Scales"]="페랄라스 임무 XII: 상급 달의 용비늘",
 ["Feralas Mission XIII: Defeat Tyrannikus"]="페랄라스 임무 XIII: 티라니쿠스 처치",
 ["Feralas Mission XIV: Defeat Alondrius"]="페랄라스 임무 XIV: 알론드리우스 처치",
 ["Feralas Mission XV: Defeat Slirena"]="페랄라스 임무 XV: 슬리레나 처치",
 ["Feralas Mission XVI: Rescue Mellias Earthtender"]="페랄라스 임무 XVI: 멜리아스 어스텐더 구출",
 ["Feralas Mission XVII: Rescue Nerene Brooksinger"]="페랄라스 임무 XVII: 네렌 브룩싱어 구출",
 ["Feralas Mission XVIII: Rescue Jamniss Treemender"]="페랄라스 임무 XVIII: 잼니스 트리멘더 구출",
}
function G.ExternalKoreanQuestName(raw)
 return aliases[raw]
end
function G.ExternalQuestNameNote(id,raw)
 if not aliases[raw] then return nil end
 if tonumber(id)==81833 and raw=="Hinterlands Mission X: Star Lotus" then
  return "클래식 한국어 명칭 대조 · 포에버 공개 DB에 현재 수락 불가로 표시됨. 게임에서 수락 여부 확인 필요."
 end
 return "클래식 한국어 명칭 대조 · 포에버 실제 수락 가능 여부는 별도 확인 필요."
end

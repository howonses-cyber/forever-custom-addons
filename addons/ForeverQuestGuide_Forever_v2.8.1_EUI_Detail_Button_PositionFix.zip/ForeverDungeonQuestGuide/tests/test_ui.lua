-- Run both client-compatible runtimes: python3 tests/run_compatibility.py
-- Pure fixture data: names mirror the reported UX problem; quest IDs outside
-- 3801/3802 are synthetic and do not assert game prerequisites or locations.
local Mock=assert(loadfile("tests/mock_wow.lua"))().install()
local base=arg[1] or "./"
local G={}
local function loadAddon(file) assert(loadfile(base..file))("ForeverDungeonQuestGuide",G) end
local function eq(a,b,message) assert(a==b,(message or "mismatch")..": expected "..tostring(b)..", got "..tostring(a)) end
local function has(s,part,message) assert(type(s)=="string" and s:find(part,1,true),message or (tostring(s).." lacks "..part)) end
local checked=0
local function test(name,fn) fn();checked=checked+1;print("PASS "..name) end
loadAddon("Core.lua")
loadAddon("Data.lua");loadAddon("VerifiedRoutes.lua");loadAddon("KoreanGameData.lua");loadAddon("KoreanPlaces.lua");loadAddon("QuestLocalization.lua")
G.StartSaved();G.PlayerRefresh()
local names={[3801]="검은무쇠 유물",[3802]="검은무쇠 유물",[90101]="산의 정수",[90102]="헐레이 블랙브레스",[90103]="리블리 스크류스피곳",[90104]="준비할 퀘스트",[90105]="보고할 퀘스트",[90106]="선행이 필요한 퀘스트",[90107]="접근 불가 퀘스트",[90108]=string.rep("긴 퀘스트 이름 ",10)}
local states={[3801]="done",[3802]="active",[90101]="active",[90102]="active",[90103]="active",[90104]="ready",[90105]="turnin",[90106]="locked",[90107]="blocked",[90108]="active"}
local completionFlags,objectiveRows={},{}
C_QuestLog={
 IsQuestFlaggedCompleted=function(id)if completionFlags[id]~=nil then return completionFlags[id] end;return states[id]=="done"end,
 GetQuestObjectives=function(id)return objectiveRows[id] end,
}
local parents={[3802]={3801},[90106]={90104}}
local levels={[3801]=52,[3802]=52,[90101]=55,[90102]=55,[90103]=53}
local stateLabels={done="보고 완료",superseded="후속 진행 확인",active="진행 중",ready="아직 안 받음",turnin="보고 대기",locked="선행 필요",blocked="조건 확인",low="레벨 부족",unknown="정보 미확인",deferred="보류",dependentDeferred="선행 보류"}
local fixtureIds={3801,3802,90101,90102,90103}
local logIds={3802,90101,90102,90103,90105,90108}
local searchIds=fixtureIds
local dbReady=true
QuestDB={Get=function(id,key)if key=="name" then return names[id] end end}
G.DBGet=function(db,id,key)if db and dbReady then if key=="name" then return names[id] elseif key=="zoneOrSort" then return 230 elseif key=="questLevel" then return levels[id] or 55 end end end
G.DBRawGet=G.DBGet
G.Ready=function()return dbReady end
G.GetQuestName=function(id)return names[id] or ("테스트 퀘스트 "..tostring(id))end
G.GetQuestLevel=function(id)return levels[id] or 55 end
G.GetQuestMinLevel=function()return 50 end
G.GetQuestZone=function()return 230,"검은바위 나락","dungeon"end
G.RouteAssessment=function(id)local code=G.db.deferredQuests[id] and "deferred" or states[id] or "ready";return stateLabels[code],code,code=="blocked" and "다른 진영 조건" or nil end
G.QuestState=G.RouteAssessment
G.IsCompleted=function(id)if completionFlags[id]~=nil then return completionFlags[id] end;return states[id]=="done"end
G.IsInLog=function(id)return states[id]=="active" or states[id]=="turnin"end
G.IsReadyToTurnIn=function(id)return states[id]=="turnin"end
G.IsRouteSatisfied=function(id)return states[id]=="done" or states[id]=="superseded"end
G.RoutePrereqEvidence=function(id)return states[id]=="superseded"end
G.MandatoryRoutePrereqs=function(id)return parents[id] or {}end
G.QuestPrerequisite=function(id)return parents[id] or {},{}end
G.ResolveRouteRequirements=function(id)
 local result={};local function walk(q)if result[q] then return end;result[q]={};for _,p in ipairs(parents[q] or {}) do if not G.IsRouteSatisfied(p) then result[q][p]=true;walk(p) end end end
 walk(id);return result
end
G.GetMissingPrereqs=function(id)local out={};for _,p in ipairs(parents[id] or {})do if not G.IsRouteSatisfied(p) then out[#out+1]=p end end;return out end
G.RouteNextPrereqs=G.GetMissingPrereqs
G.IsQuestBrowseVisible=function()return true end
G.QuestFactionTag=function()return ""end
G.DungeonMatchesFactionFilter=function()return true end
G.QuestMatchesFactionFilter=function()return true end
G.QuestIndexStatus=function()return "테스트 DB"end
local dungeon={id="brd",name="검은바위 나락",level="50–60",ids=fixtureIds,area=230}
G.dungeons={dungeon};G.dungeonById={brd=dungeon};G.db.selectedDungeon="brd";G.selection.dungeon="brd"
G.questIndex={zones={[230]={key=230,name="검은바위 나락",kind="dungeon",count=5}}}
G.SearchQuestZones=function()return {G.questIndex.zones[230]}end
G.ZoneFactionCount=function()return #searchIds end
G.SearchQuestIds=function(mode,search)
 local source=searchIds
 if mode=="active" then source=logIds elseif mode=="turnin" then source={90105} elseif mode=="deferred" then source={};for id in pairs(G.db.deferredQuests)do source[#source+1]=id end elseif mode=="selected" then source={};for id,yes in pairs(G.db.selectedQuests)do if yes then source[#source+1]=id end end end
 local result={};for _,id in ipairs(source)do if search=="" or G.GetQuestName(id):find(search,1,true) or tostring(id)==search then result[#result+1]=id end end
 return result,#result,false
end
G.QuestDetails=function(id)local status,code,reason=G.RouteAssessment(id);return{id=id,name=G.GetQuestName(id),level=G.GetQuestMinLevel(id),status=status,code=code,reason=reason,all=parents[id] or {},one={},category="검은바위 나락",startDescription="테스트 지역 · 수락 NPC",finishDescription="테스트 지역 · 보고 NPC",goal="목표 물건 3개 수집"}end
G.QuestInsideInfo=function(id,stage)if id==90101 and stage=="objective" then return{dungeon="검은바위 나락",dungeonId="brd",room="테스트 구역",instruction="퀘스트 물건을 찾으세요.",entrance={map=1427,x=.2,y=.3}} end end
G.QuestStageLandmark=function()return nil end
G.QuestContactLandmark=function()return nil end
G.QuestContactName=function(_,stage)return stage=="accept" and "수락 NPC" or "보고 NPC",1,nil,"npc"end
G.QuestGiverName=function(_,stage)return stage=="accept" and "수락 NPC" or "보고 NPC"end
G.QuestPoint=function(id,stage)return{questId=id,map=1427,x=stage=="accept" and .2 or .4,y=.3,name=stage=="accept" and "수락 NPC" or "보고 NPC"}end
G.QuestObjectivePoints=function()return{{point={map=1427,x=.3,y=.4},text="목표 물건"}}end
G.QuestObjectiveText=function()return "목표 물건 3개 수집"end
G.LiveQuestNarrative=function()return nil end
G.MapDisplayName=function()return "테스트 지역"end
G.WalkthroughDetails=function(id)return id==90108 and string.rep("아주 긴 안내 문장입니다.\n",60) or nil end
G.DeferredBlocker=function(id)return id and G.db.deferredQuests[id] and id or nil end
G.DeferredCount=function()local n=0;for _ in pairs(G.db.deferredQuests)do n=n+1 end;return n end
G.SelectedCount=function()local n=0;for _,v in pairs(G.db.selectedQuests)do if v then n=n+1 end end;return n end
G.ToggleQuestChecked=function(id,value)G.db.selectedQuests[id]=value or nil;G.UIRefresh()end
G.ClearCheckedQuests=function()G.db.selectedQuests={};G.UIRefresh()end
G.ResumeSelectedBlocker=function(id)G.db.deferredQuests[id]=nil;G.UIRefresh()end
G.ResumeDeferredQuests=function()G.db.deferredQuests={};G.UIRefresh()end
G.GuideProgress=function()return 0,0 end
G.GuideViewingHistory=function()return false end
G.GuideViewIndex=function()return 1 end
G.CurrentStep=function()return nil end
G.RouteScopeLabel=function()return "테스트 동선"end
local calls={}
for _,method in ipairs({"StartQuickGuide","StartSelectedGuide","StartTurninGuide","StartActiveGuide","StartGuide","OpenPointMap","OpenRegionMap","OpenGuideStepMap","OpenDungeonNavigator","NextGuide","ToggleHUD","StopGuide","ReturnToActiveGuide","SelectGuideStep"})do local key=method;G[key]=function(...)calls[#calls+1]={key,...};return true end end
G.ResetRoutePlanning=function()calls[#calls+1]={"ResetRoutePlanning"}end
G.EnrichStepLocation=function()end
G.activeQuests={};for _,id in ipairs(logIds)do G.activeQuests[id]={title=G.GetQuestName(id),level=G.GetQuestLevel(id),complete=states[id]=="turnin"}end
G.db.guide={sentinel="saved route"};G.db.manualProgress={sentinel=true};G.db.selectedQuests={[90101]=true};G.db.deferredQuests={[90107]={reason="user"}}
local guideBefore,manualBefore,selectedBefore,deferredBefore=G.db.guide,G.db.manualProgress,G.db.selectedQuests,G.db.deferredQuests
loadAddon("QuestList.lua");loadAddon("QuestChains.lua");loadAddon("UITheme.lua");loadAddon("QuestContacts.lua")
if io.open(base.."QuestJourney.lua","r") then loadAddon("QuestJourney.lua") end
loadAddon("QuestStatus.lua")
loadAddon("QuestRouteSafety.lua")
loadAddon("UI.lua")
local function rows()return Mock.all(function(o)return o.kind=="Button" and o.checkbox~=nil end)end
local function visibleRows()local a={};for _,r in ipairs(rows())do if r:IsVisible()then a[#a+1]=r end end;return a end
local function rowFor(id)for _,r in ipairs(rows())do if r:IsVisible() and r.quest==id then return r end end end
local function parentBar(parent)return Mock.find(function(o)return o.kind=="Slider" and o.parent==parent end)end
local function checkPreserved()
 eq(G.db.guide,guideBefore,"browse replaced route");eq(G.db.manualProgress,manualBefore,"browse replaced progress");eq(G.db.selectedQuests,selectedBefore,"browse replaced checks");eq(G.db.deferredQuests,deferredBefore,"browse replaced deferrals");eq(G.db.selectedQuests[90101],true,"existing check changed")
end
test("Build and refresh with completed same-title chain and independent quests",function()
 G.selection.mode="dungeon";G.db.viewMode="dungeon";G.ShowUI(true)
 assert(G.IsUIShown());assert(rowFor(3801));assert(rowFor(3802));assert(rowFor(90101));checkPreserved()
 has(rowFor(3801).text:GetText(),"3801","duplicate quest identity is distinguishable")
end)
test("Select independent quest without route/checkbox mutation",function()
 rowFor(90101):Click();eq(G.selection.quest,90101);checkPreserved()
 local text=Mock.visibleText();has(text,"산의 정수")
end)
test("Real contact preview opens, closes on new selection, preserves route",function()
 G.ShowContactPreview(90101,"accept",ForeverDungeonQuestGuideFrame)
 assert(ForeverQuestContactPreview:IsShown());has(Mock.visibleText(ForeverQuestContactPreview),"수락 NPC")
 G.SetQuest(90102);eq(ForeverQuestContactPreview:IsShown(),false);checkPreserved()
end)
test("Shift+click quest inserts native fallback link without selecting",function()
 local inserted;local edit={IsShown=function()return true end,Insert=function(_,s)inserted=s end}
 ChatEdit_GetActiveWindow=function()return edit end;IsShiftKeyDown=function()return true end
 local before=G.selection.quest;local r=assert(rowFor(90101));r:Click();eq(G.selection.quest,before);has(inserted,"|Hquest:90101:")
 r.checkbox:Click();eq(G.db.selectedQuests[90101],true);eq(r.checkbox:GetChecked(),true)
 IsShiftKeyDown=function()return false end;ChatEdit_GetActiveWindow=nil;checkPreserved()
end)
test("Chain collapse does not hide independent rows or change state",function()
 local header=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible() end);assert(header,"chain header missing")
 header:Click();assert(not rowFor(3801));assert(rowFor(90101));checkPreserved()
 local header2=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible() end);header2:Click();assert(rowFor(3801));assert(rowFor(3802));checkPreserved()
end)
test("Selection detail handles long text and resets scroll when quest changes",function()
 dungeon.ids={3801,3802,90101,90102,90103,90108};G.UIRefresh()
 G.SetQuest(90108)
 local scroll=Mock.find(function(o)return o.kind=="ScrollFrame" and o.scrollChild and o.parent~=ForeverQuestContactPreview and o.parent.parent==ForeverDungeonQuestGuideFrame end)
 assert(scroll,"detail scroll missing")
 local button=Mock.button("상세 보기")
 assert(button,"detail expansion control missing");button:Click();assert(scroll:IsShown(),"expanded details not shown")
 scroll:Wheel(-5);assert(scroll:GetVerticalScroll()>0,"long detail did not scroll")
 G.SetQuest(90102);eq(scroll:GetVerticalScroll(),0)
 Mock.button("요약 보기"):Click();assert(not scroll:IsShown(),"collapsed details remained visible")
 checkPreserved();dungeon.ids=fixtureIds;G.UIRefresh()
end)
test("Native slider reaches top/bottom, wheel is consistent, shrinking clamps",function()
 local many={};for i=1,40 do local id=91000+i;many[i]=id;names[id]="독립 퀘스트 "..i;states[id]="ready" end
 G.db.groupChains=false;dungeon.ids=many;G.UIRefresh()
 local rs=visibleRows();local parent=rs[1].parent;local bar=assert(parentBar(parent));local _,hi=bar:GetMinMaxValues()
 eq(rs[1].quest,91001);assert(hi>0);bar:SetValue(hi);eq(visibleRows()[#visibleRows()].quest,91040)
 bar:SetValue(0);eq(visibleRows()[1].quest,91001);parent:Wheel(-1);eq(visibleRows()[1].quest,91004);eq(bar:GetValue(),3)
 parent:Wheel(1);eq(visibleRows()[1].quest,91001);bar:SetValue(hi)
 dungeon.ids={91001,91002};G.UIRefresh();eq(bar:GetValue(),0);eq(bar:IsShown(),false);eq(visibleRows()[1].quest,91001);eq(#visibleRows(),2)
 dungeon.ids=fixtureIds;G.db.groupChains=true;G.UIRefresh();checkPreserved()
end)
test("Mode and faction switches preserve route/checks and update catalogs",function()
 for _,mode in ipairs({"active","turnin","selected","deferred","all","zone","dungeon"})do G.SetViewMode(mode);eq(G.selection.mode,mode);checkPreserved()end
 local actual=G.player.faction;G.SetFactionFilter("Horde");eq(G.player.faction,actual);checkPreserved();G.SetFactionFilter("auto")
end)
test("Database missing still renders accepted quests and honest status",function()
 dbReady=false;QuestDB=nil;G.SetViewMode("active");G.SetQuest(90101);G.UIRefresh()
 assert(rowFor(90101));has(Mock.visibleText(),"퀘스트 자료");checkPreserved();dbReady=true;QuestDB={Get=function()end};G.UIRefresh()
end)
test("Active/turnin/dungeon bulk actions retain their correct scopes",function()
 for _,case in ipairs({{"active","현재 수락 퀘스트 전체 동선","StartActiveGuide",false},{"turnin","보고 대기 전체 동선","StartActiveGuide",true},{"dungeon","던전 전체 통합 동선","StartGuide","brd"}})do
  G.SetViewMode(case[1]);local b=(G.UIJourneyWidgets and G.UIJourneyWidgets.scopeStartButton) or Mock.button(case[2]);assert(b,"scope button missing: "..case[2]);assert(b:IsEnabled());b:Click();local c=calls[#calls];eq(c[1],case[3]);eq(c[2],case[4])
 end
 checkPreserved()
end)
if G.UIJourneyWidgets then
 local w=G.UIJourneyWidgets
 test("Status filtering keeps full prerequisite context and excludes unrelated quests",function()
  dungeon.ids={3801,3802,90101,90102,90103,90104,90105,90106,90107};G.SetViewMode("dungeon");w.phaseButtons.unaccepted:Click()
  assert(rowFor(90104),"accept target absent");assert(rowFor(90106),"related locked followup was stripped out");assert(not rowFor(90101),"unrelated objective appears under accept filter")
  assert(not rowFor(90105),"report target appears under accept filter");checkPreserved()
  w.phaseButtons.blocked:Click();assert(rowFor(90104),"required predecessor stripped by blocked filter");assert(rowFor(90106),"blocked target missing");checkPreserved()
  w.phaseButtons.all:Click()
 end)
 test("Report stage is actionable but never writes completion",function()
  w.phaseButtons.turnin:Click();assert(rowFor(90105));rowFor(90105):Click()
  assert(w.quickStartButton:IsEnabled());has(w.nowAction:GetText(),"보고");eq(states[90105],"turnin")
  local n=#calls;w.quickStartButton:Click();eq(#calls,n+1);eq(calls[#calls][1],"StartQuickGuide");eq(calls[#calls][2],90105)
  eq(states[90105],"turnin");checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Locked target map uses actionable predecessor, guide keeps desired target",function()
  w.phaseButtons.blocked:Click();G.SetQuest(90106);assert(w.quickStartButton:IsEnabled());has(w.nowAction:GetText(),"먼저")
  local n=#calls;w.locationButton:Click();eq(#calls,n+1);eq(calls[#calls][1],"OpenPointMap");eq(calls[#calls][2].questId,90104)
  w.quickStartButton:Click();eq(calls[#calls][1],"StartQuickGuide");eq(calls[#calls][2],90106)
  checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Done or blocked selections cannot start a new guide",function()
  G.SetQuest(3801);eq(w.quickStartButton:IsEnabled(),false);local n=#calls;w.quickStartButton:Click();eq(#calls,n)
  w.phaseButtons.blocked:Click();G.SetQuest(90107);eq(w.quickStartButton:IsEnabled(),false);eq(w.locationButton:IsEnabled(),false)
  w.quickStartButton:Click();eq(#calls,n);checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Suggested action only selects/reveals a quest and does not navigate",function()
  G.SetQuest(90101);local n=#calls;w.findNextButton:Click();eq(G.selection.quest,90105);eq(#calls,n);assert(rowFor(90105),"chosen target not brought into view")
  checkPreserved()
 end)
 test("Empty phase shows explanation and disables absent action",function()
  dungeon.ids={3801};G.SetQuest(3801);w.phaseButtons.active:Click()
  eq(#visibleRows(),0);assert(w.emptyList:IsShown());assert(#w.emptyList:GetText()>0);eq(w.quickStartButton:IsEnabled(),false);eq(w.findNextButton:IsEnabled(),false)
  checkPreserved();w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Explicit API.Open outside current filter preserves selected quest",function()
  w.search:SetText("산의 정수");G.API.Open(nil,90108)
  eq(G.selection.quest,90108);eq(G.db.selectedQuest,90108);has(w.nowTitle:GetText(),"목록 밖")
  has(w.detailHead:GetText(),G.GetQuestName(90108));assert(not rowFor(90108));checkPreserved()
  w.search:SetText("");G.SetQuest(90101)
 end)
 test("Changing search preserves explicit selection and marks outside result",function()
  G.SetQuest(90101);w.search:SetText("헐레이");eq(G.selection.quest,90101);has(w.nowTitle:GetText(),"목록 밖");assert(rowFor(90102));assert(not rowFor(90101))
  w.search:SetText("");eq(G.selection.quest,90101);has(w.nowTitle:GetText(),"지금 할 일");checkPreserved()
 end)
 test("Grouping off filters individual quests and clears reused chain visuals",function()
  dungeon.ids={3801,3802,90101,90104,90106};G.db.groupChains=false;G.UIRefresh();w.phaseButtons.unaccepted:Click()
  assert(rowFor(90104));assert(rowFor(90106),"locked but unaccepted quest must retain its primary state");assert(not rowFor(3802))
  for _,r in ipairs(visibleRows())do eq(r.chainKey,nil);assert(not r.rail:IsShown());assert(not r.edge:IsShown());eq(r.entry.kind,"quest")end
  G.SetQuest(90104);has(w.relationshipInfo:GetText(),"끔");checkPreserved()
  G.db.groupChains=true;w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Priority selection expands a collapsed chain and reveals target",function()
  states[3802]="turnin";G.UIRefresh()
  local chain=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible()end);assert(chain);chain:Click();assert(not rowFor(3802))
  G.SetQuest(90101);local n=#calls;w.findNextButton:Click()
  eq(G.selection.quest,3802);assert(rowFor(3802),"collapsed target not revealed");eq(#calls,n);eq(states[3802],"turnin");checkPreserved()
  states[3802]="active";G.UIRefresh()
 end)
 test("External predecessor context does not inflate a zero-count status",function()
  states[90104]="active";dungeon.ids={90106};G.UIRefresh();w.phaseButtons.active:Click()
  eq(w.statusSummary.active,0);eq(#visibleRows(),0);eq(w.findNextButton:IsEnabled(),false)
  w.phaseButtons.blocked:Click();assert(rowFor(90104));assert(rowFor(90106));eq(w.summary.nextQuestId,90106)
  w.findNextButton:Click();eq(G.selection.quest,90106);checkPreserved();states[90104]="ready";w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Suggested target matches selected phase while preserving other chain context",function()
  dungeon.ids={90104,90106};G.UIRefresh();w.phaseButtons.blocked:Click()
  assert(rowFor(90104));assert(rowFor(90106));w.findNextButton:Click();eq(G.selection.quest,90106)
  w.phaseButtons.unaccepted:Click();assert(rowFor(90104));assert(rowFor(90106));w.findNextButton:Click();eq(G.selection.quest,90104)
  checkPreserved();w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Branch rows do not imply a single numbered progression",function()
  parents[90106]={90104,90101};dungeon.ids={90104,90101,90106};G.UIRefresh()
  for _,r in ipairs(visibleRows())do if r.quest then assert(not r.text:GetText():find("%d+/%d+"),"branch row misleadingly numbered") end end
  checkPreserved();parents[90106]={90104};dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Every quest has four visible card edges and five-pixel air gaps",function()
  dungeon.ids=fixtureIds;G.SetViewMode("dungeon");w.phaseButtons.all:Click();G.SetQuest(3802);w.questScrollbar:SetValue(0)
  eq(#w.questRows,5);eq(w.rowStride-w.rowHeight,5)
  for _,r in ipairs(visibleRows())do if r.quest then
   for _,side in ipairs({"top","right","bottom","left"})do assert(r.cardBorder[side]:IsShown(),"missing "..side.." border on quest "..r.quest)end
   eq(r.cardInset,r.entry.chainKey and 12 or 0);eq(r.marker:IsShown(),false)
  end end
  local selected=assert(rowFor(3802));eq(selected.cardBorder.top.color[1],1);eq(selected.cardBorder.top.color[2],.80)
  local standalone=assert(rowFor(90101));assert(standalone.cardBorder.top.color[1]~=1 or standalone.cardBorder.top.color[2]~=.80,"unselected card has the selected gold outline");checkPreserved()
 end)
 test("Chain group frame encloses its end and excludes next standalone card",function()
  local group=Mock.find(function(o)return o.chainKey and o.border and o:IsVisible()end);assert(group)
  for _,side in ipairs({"top","right","bottom","left"})do assert(group.border[side]:IsShown())end
  eq(w.questRows[group.firstRow].entry.kind,"chain");eq(w.questRows[group.lastRow].entry.kind,"chainEnd")
  local nextRow=w.questRows[group.lastRow+1];assert(nextRow and nextRow.entry.kind=="quest"and not nextRow.entry.chainKey)
  eq(group:GetHeight(),(group.lastRow-group.firstRow)*w.rowStride+w.rowHeight)
  eq(group.continuesAfter,false);eq(group.continuesBefore,false);checkPreserved()
 end)
 test("Scrolling through a long chain closes visible boundary without bleeding",function()
  local long={};for i=1,12 do local id=92000+i;long[i]=id;names[id]="긴 연계 "..i;states[id]="active";parents[id]=i>1 and{92000+i-1}or{}end
  names[93001]="연계 뒤 개별 퀘스트";states[93001]="active";long[#long+1]=93001;dungeon.ids=long;G.UIRefresh();w.questScrollbar:SetValue(0)
  local function currentGroup()return Mock.find(function(o)return o.chainKey and o.border and o:IsVisible()end)end
  local group=assert(currentGroup());eq(group.continuesBefore,false);eq(group.continuesAfter,true);eq(group.firstRow,1);eq(group.lastRow,#w.questRows)
  w.questScrollbar:SetValue(3);group=assert(currentGroup());eq(group.continuesBefore,true);eq(group.continuesAfter,true)
  local _,high=w.questScrollbar:GetMinMaxValues();w.questScrollbar:SetValue(high);group=assert(currentGroup())
  eq(group.continuesBefore,true);eq(group.continuesAfter,false);eq(group.lastRow,#w.questRows-1);eq(w.questRows[#w.questRows].quest,93001)
  checkPreserved();dungeon.ids=fixtureIds;G.UIRefresh();w.questScrollbar:SetValue(0)
 end)
 test("Recycled rows and collapsed chains do not leave phantom card borders",function()
  local header=Mock.find(function(o)return o.chainKey and o.checkbox and o:IsVisible()end);assert(header);header:Click()
  for _,r in ipairs(visibleRows())do if not r.quest then for _,edge in pairs(r.cardBorder)do assert(not edge:IsShown())end end end
  local group=Mock.find(function(o)return o.chainKey and o.border and o:IsVisible()end);assert(group);eq(group:GetHeight(),w.rowHeight)
  local h=Mock.find(function(o)return o.chainKey and o.checkbox and o:IsVisible()end);h:Click();checkPreserved()
 end)
 test("Primary status badges distinguish active, report-ready, completed and unaccepted",function()
  dungeon.ids={3801,90101,90104,90105,90107};G.db.groupChains=false;w.statusButtons.all:Click();G.UIRefresh()
  local expected={[3801]="done",[90101]="active",[90104]="unaccepted",[90105]="turnin",[90107]="unaccepted"}
  local colors={}
  for id,key in pairs(expected)do
   local r=assert(rowFor(id),"status fixture missing "..id)
   eq(r.statusKey,key);assert(r.statusBadge:IsShown() and r.statusBadge:GetText()~="","primary status badge missing")
   assert(r.badgeFill:IsShown() and r.statusStripe:IsShown(),"status visual must be persistent")
   colors[key]=table.concat(r.statusStripe.color,",")
  end
  for a,ca in pairs(colors)do for b,cb in pairs(colors)do if a~=b then assert(ca~=cb,"primary states have identical stripe colors")end end end
  has(rowFor(3801).statusBadge:GetText(),"완료");has(rowFor(90101).statusBadge:GetText(),"수행")
  has(rowFor(90105).statusBadge:GetText(),"보고");has(rowFor(90104).statusBadge:GetText(),"미수락")
  eq(w.statusSummary.all,5);eq(w.statusSummary.done,1);eq(w.statusSummary.active,1);eq(w.statusSummary.turnin,1);eq(w.statusSummary.unaccepted,2)
  eq(w.statusSummary.blocked,1,"condition count is an overlapping secondary state")
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Selecting a card changes its outline without replacing its status color",function()
  dungeon.ids={3801,90101,90104,90105};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90104)
  local before=table.concat(assert(rowFor(90101)).statusStripe.color,",")
  G.SetQuest(90101);local selected=assert(rowFor(90101))
  eq(table.concat(selected.statusStripe.color,","),before);eq(selected.statusKey,"active")
  eq(selected.cardBorder.top.color[1],1);eq(selected.cardBorder.top.color[2],.80)
  local other=assert(rowFor(90104));assert(other.cardBorder.top.color[1]~=1 or other.cardBorder.top.color[2]~=.80,"two cards look selected")
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Checkboxes select a route without completing or reclassifying the quest",function()
  dungeon.ids={90104};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90104)
  local r=assert(rowFor(90104));eq(r.statusKey,"unaccepted");eq(G.IsCompleted(90104),false)
  r.checkbox:Click();eq(G.db.selectedQuests[90104],true);eq(rowFor(90104).statusKey,"unaccepted");eq(w.statusSummary.done,0);eq(G.IsCompleted(90104),false)
  rowFor(90104).checkbox:Click();eq(G.db.selectedQuests[90104],nil);eq(states[90104],"ready")
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("An accepted repeatable keeps its active badge despite an older completed flag",function()
  names[95001]="반복 퀘스트 검사";states[95001]="active";completionFlags[95001]=true
  dungeon.ids={95001};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(95001)
  eq(assert(rowFor(95001)).statusKey,"active");eq(w.statusSummary.active,1);eq(w.statusSummary.done,0)
  w.statusButtons.done:Click();eq(#visibleRows(),0)
  completionFlags[95001]=nil;checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Superseded history is identified without fabricating a completed badge",function()
  names[95002]="지난 단계 검사";states[95002]="superseded";dungeon.ids={95002};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(95002)
  local r=assert(rowFor(95002));eq(r.statusKey,"unknown");has(r.statusBadge:GetText(),"기록")
  eq(w.statusSummary.done,0);eq(w.statusSummary.unknown,1);assert(not G.IsCompleted(95002))
  w.statusButtons.done:Click();eq(#visibleRows(),0)
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Status filters keep context but count only the original scope once",function()
  dungeon.ids={3801,3802};G.db.groupChains=true;w.statusButtons.done:Click()
  eq(w.statusSummary.all,2);eq(w.statusSummary.done,1);eq(w.statusSummary.active,1)
  eq(assert(rowFor(3801)).statusKey,"done");eq(assert(rowFor(3802)).statusKey,"active")
  assert(rowFor(3802).filterContext,"nonmatching chain member must be marked as context")
  has(rowFor(3802).statusText:GetText(),"연계 참고")
  eq(w.findNextButton:IsEnabled(),false,"completed filter cannot recommend active contextual member")
  checkPreserved();dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Completed filter reveals default-collapsed cards while respecting saved user collapse choices",function()
  local savedCollapsed=G.db.chainCollapsed;G.db.chainCollapsed={};states[3802]="done"
  dungeon.ids={3801,3802};G.db.groupChains=true;w.statusButtons.all:Click()
  local header=Mock.find(function(o)return o.checkbox and o.chainKey and o:IsVisible()end);assert(header)
  local key=header.chainKey;assert(not rowFor(3801) and not rowFor(3802),"all view no longer auto-collapses a fully rewarded group")
  eq(G.db.chainCollapsed[key],nil)
  w.statusButtons.done:Click();assert(rowFor(3801) and rowFor(3802),"completed cards are hidden behind default collapse")
  eq(rowFor(3801).statusKey,"done");eq(rowFor(3802).statusKey,"done");eq(G.db.chainCollapsed[key],nil,"status filter saved an unsolicited collapse preference")
  G.db.chainCollapsed[key]=true;G.UIRefresh();assert(not rowFor(3801) and not rowFor(3802));eq(G.db.chainCollapsed[key],true)
  G.db.chainCollapsed[key]=false;G.UIRefresh();assert(rowFor(3801) and rowFor(3802));eq(G.db.chainCollapsed[key],false)
  states[3802]="active";G.db.chainCollapsed=savedCollapsed;checkPreserved();dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Explicit completed and condition filters override hide preferences without changing them",function()
  local browse=G.IsQuestBrowseVisible;local incomplete,hidden=G.db.onlyIncomplete,G.db.hideUnavailable
  G.IsQuestBrowseVisible=function(id,options)
   if options and options.ignoreStateFilters then return true end
   return not ((G.db.onlyIncomplete and states[id]=="done") or (G.db.hideUnavailable and id==90107))
  end
  dungeon.ids={3801,90101,90107};G.db.groupChains=false;G.db.onlyIncomplete=true;G.db.hideUnavailable=true;w.statusButtons.all:Click()
  assert(not rowFor(3801));assert(not rowFor(90107));assert(rowFor(90101))
  eq(w.statusSummary.done,1);eq(w.statusSummary.blocked,1)
  w.statusButtons.done:Click();assert(rowFor(3801));assert(not rowFor(90101));eq(G.db.onlyIncomplete,true);eq(G.db.hideUnavailable,true)
  w.statusButtons.blocked:Click();assert(rowFor(90107));eq(G.db.onlyIncomplete,true);eq(G.db.hideUnavailable,true)
  G.IsQuestBrowseVisible=browse;G.db.onlyIncomplete=incomplete;G.db.hideUnavailable=hidden
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Live objective quantity and objective completion remain separate and missing data stays unknown",function()
  objectiveRows[90101]={{text="검사 물건 2/3",numFulfilled=2,numRequired=3,finished=false,type="item"},{text="검사 대상 대화",finished=true,type="event"}}
  dungeon.ids={90101};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90101)
  local r=assert(rowFor(90101));local p=assert(r.objectiveProgress)
  eq(r.statusKey,"active");eq(p.done,1);eq(p.total,2);eq(p.ratio,.5)
  has(r.progressText:GetText(),"2/3");has(w.detailText:GetText(),"2/3");assert(r.progressBar:IsShown())
  eq(w.selectedProgress.ratio,.5);assert(not G.IsCompleted(90101))
  objectiveRows[90101]=nil;G.UIRefresh();r=assert(rowFor(90101))
  eq(r.objectiveProgress.available,false);eq(r.objectiveProgress.ratio,nil);eq(r.progressBar:IsShown(),false)
  assert(not r.progressText:GetText():find("0%%") and not r.progressText:GetText():find("0/0",1,true),"missing progress was presented as zero")
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Large result sets reuse five cards and read progress only for visible or selected quests",function()
  local many={};for i=1,80 do local id=96000+i;many[i]=id;names[id]="상태 스크롤 검사 "..i;states[id]="active"end
  local oldObjectives=C_QuestLog.GetQuestObjectives;local reads={}
  C_QuestLog.GetQuestObjectives=function(id)reads[id]=(reads[id]or 0)+1;return oldObjectives(id)end
  local allocated=#Mock.objects
  dungeon.ids=many;G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90101);reads={};G.UIRefresh()
  eq(#w.questRows,5);eq(#Mock.objects,allocated,"growing results allocated additional widgets")
  local unique=0;for _,n in pairs(reads)do unique=unique+1;eq(n,1,"same quest progress read twice in one refresh")end
  assert(unique<=6,"progress scanned the whole result set");eq(reads[96080],nil,"offscreen progress was eagerly read")
  local _,high=w.questScrollbar:GetMinMaxValues();w.questScrollbar:SetValue(high);eq(w.questRows[#w.questRows].quest,96080);assert(reads[96080])
  w.statusButtons.done:Click();eq(#visibleRows(),0);eq(w.questScrollbar:GetValue(),0);eq(#Mock.objects,allocated)
  for _,r in ipairs(w.questRows)do assert(not r:IsShown(),"filtered row remained visible")end
  C_QuestLog.GetQuestObjectives=oldObjectives;checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;w.statusButtons.all:Click();G.UIRefresh()
 end)
 test("Lua 5.1 upvalue budget remains under 60",function()
  local function count(fn)
   local n=0
   while debug.getupvalue(fn,n+1) do n=n+1 end
   return n
  end
  local refresh=count(G.UIRefresh)
  assert(refresh<=60,"UIRefresh over Lua 5.1 upvalue budget: "..refresh)
  local build
  for i=1,count(G.ShowUI) do
   local name,value=debug.getupvalue(G.ShowUI,i)
   if name=="buildUI" and type(value)=="function" then build=value end
  end
  assert(build,"buildUI local closure missing")
  local upvalues=count(build)
  assert(upvalues<=60,"buildUI over Lua 5.1 upvalue budget: "..upvalues)
  print("UI closure upvalues (Lua5.4 observed): buildUI="..upvalues..", UIRefresh="..refresh)
 end)
 test("Readable cards show action, location or condition and compact metadata",function()
  dungeon.ids={90101,90104,90106};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90101)
  local active=assert(rowFor(90101));has(active.progressText:GetText(),"지금 수행")
  has(active.blockerText:GetText(),"이동:");has(active.statusText:GetText(),"레벨")
  local blocked=assert(rowFor(90106));has(blocked.blockerText:GetText(),"조건 확인")
  assert(active.text:GetText()~=active.progressText:GetText(),"name/action should be separate")
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Dungeon preflight is visible in details without marking quests complete",function()
  G.selection.mode="dungeon";G.selection.dungeon="brd";G.SetQuest(90101)
  local guideBefore=G.db.guide
  local before=G.db.selectedQuests
  if not w.detailScroll:IsShown() then w.detailToggle:Click() end
  has(w.detailText:GetText(),"던전 출발 전 점검")
  has(w.detailText:GetText(),"실제 수락")
  has(w.detailText:GetText(),"입장 자체에 모든 열쇠")
  eq(G.db.guide,guideBefore);eq(G.db.selectedQuests,before)
  w.detailToggle:Click();checkPreserved()
 end)
 test("Five-step overview switches to full scroll without changing the route",function()
  G.SetQuest(90101)
  assert(w.overview:IsShown(),"summary should be default")
  assert(not w.detailScroll:IsShown(),"details should start folded")
  eq(#w.overviewRows,5)
  for i=1,5 do assert(w.overviewRows[i].text:GetText()~="","missing overview step "..i) end
  has(w.overviewRows[2].text:GetText(),"검은바위 나락")
  w.detailToggle:Click();assert(w.detailScroll:IsShown());assert(not w.overview:IsShown())
  has(w.detailText:GetText(),"선행");has(w.detailToggle:GetText(),"요약")
  w.detailToggle:Click();assert(w.overview:IsShown());assert(not w.detailScroll:IsShown())
  checkPreserved()
 end)
 test("Character-only readable font toggle preserves all quest and route records",function()
  local before=G.db.uiLargeText
  w.fontToggle:Click();eq(G.db.uiLargeText,not before)
  local r=assert(rowFor(90101));eq(r.text.fontSize,13)
  eq(w.overviewRows[1].text.fontSize,13)
  w.fontToggle:Click();eq(G.db.uiLargeText,before);eq(rowFor(90101).text.fontSize,12)
  checkPreserved()
 end)
 test("Long Korean quest names do not bleed into state badges",function()
  dungeon.ids={90108};G.db.groupChains=false;w.statusButtons.all:Click();G.SetQuest(90108)
  local r=assert(rowFor(90108));has(r.text:GetText(),"…")
  assert(#r.text:GetText()<#names[90108],"the long name should be safely shortened")
  assert(r.statusBadge:IsShown());eq(r.text.maxLines,1);eq(r.progressText.maxLines,1)
  checkPreserved();G.db.groupChains=true;dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Version button reports loaded version and fixed labels are Korean",function()
  eq(G.uiVersion,G.version);has(Mock.visibleText(),G.version)
  local printed;local old=G.Print;G.Print=function(s)printed=s end;w.versionButton:Click();G.Print=old
  has(printed,G.version);has(printed,G.uiVersion)
  for _,b in ipairs(Mock.all(function(o)return o.kind=="Button"and o._fdqStyle and o:IsVisible()end))do
   assert(not b:GetText():find("[A-Za-z]"),"untranslated fixed button: "..b:GetText())
  end
  checkPreserved()
 end)
 test("Mixed runtime and screen versions are visibly identified",function()
  local old=G.uiVersion;G.uiVersion="2.0.1";G.UIRefresh();has(w.titleInfo:GetText(),"파일 버전 다름")
  G.uiVersion=old;G.UIRefresh();assert(not w.titleInfo:GetText():find("파일 버전 다름",1,true));checkPreserved()
 end)
 test("Dungeon search retains original English database-name lookup",function()
  local raw=G.DBRawGet;G.DBRawGet=function(db,id,key)if id==90101 and key=="name"then return "Fixture Raw Mountain"end;return raw(db,id,key)end
  w.search:SetText("Fixture Raw Mountain");assert(rowFor(90101),"raw-name search lost after localization");has(rowFor(90101).text:GetText(),"산의 정수")
  w.search:SetText("");G.DBRawGet=raw;checkPreserved()
 end)
 test("Saved English route labels localize only at display boundaries",function()
  local step={quest=3802,kind="objective",questName="Dark Iron Legacy",title="Dark Iron Legacy",note="Grim Guzzler"}
  local savedGuide=G.db.guide;local saved={steps={step},index=1,mode="selected"}
  local progress,current,scope,status,done=G.GuideProgress,G.CurrentStep,G.RouteScopeLabel,G.GuideViewStatus,G.StepIsDone
  G.db.guide=saved;G.GuideProgress=function()return 0,1 end;G.CurrentStep=function()return step end
  G.RouteScopeLabel=function()return "Black Vault"end;G.GuideViewStatus=function()return "진행"end;G.StepIsDone=function()return false end
  G.UIRefresh();local text=Mock.visibleText(w.frame);assert(not text:find("Dark Iron Legacy",1,true));assert(not text:find("Grim Guzzler",1,true));assert(not text:find("Black Vault",1,true))
  has(text,"험상궂은 주정뱅이 선술집");G.TogglePlanWindow()
  local routeRow=Mock.find(function(o)return o.guideIndex==1 and o:IsVisible()end);assert(routeRow);has(routeRow.text:GetText(),"검은무쇠 유물");assert(not routeRow.text:GetText():find("Dark Iron Legacy",1,true))
  eq(step.title,"Dark Iron Legacy");eq(step.questName,"Dark Iron Legacy");eq(step.note,"Grim Guzzler");eq(G.db.guide,saved)
  G.TogglePlanWindow();G.db.guide=savedGuide;G.GuideProgress=progress;G.CurrentStep=current;G.RouteScopeLabel=scope;G.GuideViewStatus=status;G.StepIsDone=done
  G.UIRefresh();checkPreserved()
 end)
end
test("Closing browser also closes contact preview",function()
 G.ShowContactPreview(90101,"accept",ForeverDungeonQuestGuideFrame);G.ShowUI(false);eq(ForeverQuestContactPreview:IsShown(),false);eq(G.IsUIShown(),false);checkPreserved()
end)
print("UI tests: "..checked.." passed (mock only; not in-game rendering/input validation)")
if arg[2]=="preview" then
 assert(loadfile("tests/export_ui.lua"))()(Mock,G,base,names,states,levels,dungeon)
end

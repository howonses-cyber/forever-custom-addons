local addon,G=...
G.chainVersion="2.8.1"
-- Presentation only: grouping must not check quests, infer rewards, change
-- deferred/history state, or replace the route resolver's actual prerequisites.
local effectiveCollapsed={}
local function copy(entry)
 local out={};for k,v in pairs(entry) do out[k]=v end;return out
end
local function parents(id)
 local result,seen={},{}
 for _,p in ipairs((G.NarrativeParents and G.NarrativeParents(id)) or G.MandatoryRoutePrereqs(id) or {}) do
  if type(p)=="number" and p>0 and p~=id and not seen[p] then seen[p]=true;result[#result+1]=p end
 end
 table.sort(result);return result
end
local actionPriority={turnin=1,active=2,ready=3}
local actionLabels={turnin="보상 받기",active="목표 수행",ready="퀘스트 받기"}
local function process(entries,scope,addContext,out,assessments,options)
 if #entries==0 then return end
 local nodes,links,dsu,visited,positions={}, {}, {}, {}, {}
 local branchNodes={}
 local original={};local nContext=0
 local function root(q)
  local p=dsu[q]
  if not p then dsu[q]=q;return q end
  while p~=dsu[p] do dsu[p]=dsu[dsu[p]];p=dsu[p] end
  dsu[q]=p;return p
 end
 local function union(a,b)
  a,b=root(a),root(b);if a==b then return end
  if a<b then dsu[b]=a else dsu[a]=b end
 end
 for i,e in ipairs(entries) do nodes[e.id]=copy(e);positions[e.id]=i;original[e.id]=true;root(e.id) end
 local function walk(q,depth)
  if visited[q] or depth>32 then return end
  visited[q]=true
  links[q]=parents(q)
  -- Show only an alternative chosen by the existing viable route resolver.
  -- Other OR choices are never all appended as required steps.
  local alternative=false
  if G.QuestPrerequisite then
   local all,one=G.QuestPrerequisite(q)
   alternative=#(one or {})>1
   if not alternative then
    for _,pre in ipairs(all or {}) do
     local ex=pre>0 and G.DBGet(QuestDB,pre,"exclusiveTo")
     if type(ex)=="table" and next(ex) then alternative=true;break end
    end
   end
  end
  if alternative and G.ResolveRouteRequirements and G.IsRouteSatisfied and not G.IsRouteSatisfied(q) then
   local graph=G.ResolveRouteRequirements(q,{})
   if graph and graph[q] then
    local have={};for _,p in ipairs(links[q]) do have[p]=true end
    for p in pairs(graph[q]) do
     if type(p)=="number" and p>0 and p~=q and not have[p] then
      links[q][#links[q]+1]=p;have[p]=true;branchNodes[q]=true
     end
    end
    table.sort(links[q])
   end
  end
  for _,p in ipairs(links[q]) do
   union(q,p)
   if addContext and not nodes[p] and nContext<180 and G.IsQuestBrowseVisible(p) and type(G.DBGet(QuestDB,p,"name"))=="string" then
    nContext=nContext+1;nodes[p]={kind="quest",id=p,meta=G.QuestListMeta(p),chainContext=true};positions[p]=#entries+nContext
   end
   walk(p,depth+1)
  end
  -- Future story chapters are part of the same visible family even when
  -- not yet in the dungeon category. Keep them contextual, never selected.
  if G.NarrativeChildren then
   for _,future in ipairs(G.NarrativeChildren(q)) do
    union(q,future)
    if addContext and not nodes[future] and nContext<60 and G.IsQuestBrowseVisible(future)
       and type(G.DBGet(QuestDB,future,"name"))=="string" then
     nContext=nContext+1
     nodes[future]={kind="quest",id=future,meta=G.QuestListMeta(future),chainContext=true}
     positions[future]=#entries+nContext
    end
    if nodes[future] then walk(future,depth+1) end
   end
  end
 end
 for _,e in ipairs(entries) do walk(e.id,0) end
 local groups,ordered={},{}
 for q in pairs(nodes) do
  local k=root(q);local g=groups[k]
  if not g then g={members={},pos=math.huge,key=k};groups[k]=g;ordered[#ordered+1]=g end
  g.members[#g.members+1]=q;g.pos=math.min(g.pos,positions[q] or math.huge)
  if branchNodes[q] or #(links[q] or {})>1 then g.branch=true end
 end
 table.sort(ordered,function(a,b)if a.pos~=b.pos then return a.pos<b.pos end return a.key<b.key end)
 local function assess(q)
  if not assessments[q] then
   local label,code,reason
   if G.RouteAssessment then label,code,reason=G.RouteAssessment(q)
   elseif G.QuestState then label,code=G.QuestState(q) end
   assessments[q]={label=label,code=code,reason=reason}
  end
  return assessments[q]
 end
 for _,g in ipairs(ordered) do
  local members=g.members
  table.sort(members,function(a,b)if positions[a]~=positions[b] then return positions[a]<positions[b] end return a<b end)
  local present={};for _,q in ipairs(members) do present[q]=true end
  local emitted,visiting,orderedIds,depths={}, {}, {}, {}
  local cycle,incomplete=false,false
  local children={}
  -- A topological order can contain parallel branches. Count both fan-in and
  -- fan-out, including hidden ancestors, before calling a chain linear.
  local function order(q,depth)
   if emitted[q] then return end
   if depth>64 then incomplete=true;return end
   if visiting[q] then cycle=true;return end
   visiting[q]=true
   local level=0
   if not present[q] then incomplete=true end
   local pre=links[q]
   if not pre then incomplete=true;pre={} end
   if #pre>1 or branchNodes[q] then g.branch=true end
   for _,p in ipairs(pre) do
    children[p]=children[p] or {};children[p][q]=true
    order(p,depth+1);level=math.max(level,(depths[p] or 0)+1)
   end
   visiting[q]=nil;emitted[q]=true;depths[q]=level
   if present[q] then orderedIds[#orderedIds+1]=q end
  end
  for _,q in ipairs(members) do order(q,0) end
  for _,ids in pairs(children) do
   local count=0;for _ in pairs(ids) do count=count+1 end
   if count>1 then g.branch=true;break end
  end
  if #members>1 then
   local first=orderedIds[1] or members[1]
   local key=tostring(scope or "list")..":"..g.key
   local checked,done,superseded,extra,blocked=0,0,0,0,0
   local candidates={}
   for i,q in ipairs(orderedIds) do
    if G.db.selectedQuests and G.db.selectedQuests[q] then checked=checked+1 end
    local status=assess(q)
    if (G.IsCompleted and G.IsCompleted(q)) or status.code=="done" then
     done=done+1
    elseif status.code=="superseded" or (G.IsRouteSatisfied and G.IsRouteSatisfied(q)) then
     superseded=superseded+1
    elseif actionPriority[status.code] then
     candidates[#candidates+1]={id=q,code=status.code,order=i}
    else blocked=blocked+1 end
    if not original[q] then extra=extra+1 end
   end
   table.sort(candidates,function(a,b)
    local ap,bp=actionPriority[a.code],actionPriority[b.code]
    if ap~=bp then return ap<bp end;return a.order<b.order
   end)
   local nextAction=candidates[1]
   local actionableIds={};for _,candidate in ipairs(candidates) do actionableIds[#actionableIds+1]=candidate.id end
   local label=(G.NarrativeTitle and G.NarrativeTitle(first)) or G.GetQuestName(first)
   local optional=false
   if G.NarrativeEdgeKind then
    for _,q in ipairs(orderedIds) do
     for _,p in ipairs(links[q] or {}) do
      local kind=G.NarrativeEdgeKind(p,q)
      if kind and kind~="required" then optional=true end
     end
    end
   end
   local linear=not g.branch and not cycle and not incomplete and not optional
   local saved=G.db.chainCollapsed and G.db.chainCollapsed[key]
   -- Auto-collapse only confirmed rewards; an excluded stage is not a reward.
   -- Explicit false is a user expansion and survives later refreshes.
   -- An explicit state filter must expose its matching cards by default.
   -- Preserve a deliberate user collapse/expansion without writing saved state.
   local collapsed=saved==true or (saved==nil and done==#members and not (options and options.expandCompleted))
   effectiveCollapsed[key]=collapsed
   local header={kind="chain",key=key,label=label,count=#members,checked=checked,done=done,
    completed=done,superseded=superseded,resolved=done+superseded,extra=extra,blockedCount=blocked,
    collapsed=collapsed,cycle=cycle,branch=g.branch==true,linear=linear,incomplete=incomplete,optional=optional,
    memberIds=orderedIds,actionableIds=actionableIds,nextQuestId=nextAction and nextAction.id,
    nextCode=nextAction and nextAction.code,nextLabel=nextAction and actionLabels[nextAction.code]}
   out[#out+1]=header
   if not collapsed then
    local names={}
    for _,q in ipairs(orderedIds) do local name=G.GetQuestName(q);names[name]=(names[name] or 0)+1 end
    for i,q in ipairs(orderedIds) do
     local e=nodes[q];e.chainIndex=i;e.chainCount=#members
     e.sameTitle=(names[G.GetQuestName(q)] or 0)>1
     e.chainBranch=g.branch==true;e.chainLinear=linear;e.chainDepth=depths[q] or 0
     e.chainKey=key;e.chainLabel=label;e.chainMembers=orderedIds;e.chainSummary=header
     e.chainRelation=(G.NarrativeParents and G.NarrativeEdgeKind and (function()
      for _,p in ipairs(G.NarrativeParents(q)) do local kind=G.NarrativeEdgeKind(p,q)
       if kind and kind~="required" then return kind end end
     end)()) or nil
     e.chainFirst=i==1;e.chainLast=i==#orderedIds;e.standalone=false;e.relationship="chain"
     out[#out+1]=e
    end
    -- A real closing row keeps the next independent quest outside this block,
    -- even when the header has scrolled away from the visible window.
    out[#out+1]={kind="chainEnd",key=key,label=label,count=#members,
     nextQuestId=header.nextQuestId,nextCode=header.nextCode,nextLabel=header.nextLabel,
     memberIds=orderedIds,completed=done,superseded=superseded}
   end
  else
   local e=nodes[members[1]]
   -- "single" means an individual card in this view, not proof that the game
   -- has no hidden prerequisite or future follow-up for this quest.
   e.standalone=true;e.relationship="single";e.hasPrerequisites=#(links[e.id] or {})>0
   out[#out+1]=e
  end
 end
end
function G.QuestChainRows(rows,scope,addContext,options)
 if not G.db or G.db.groupChains==false or not G.Ready() then
  local plain={}
  for _,entry in ipairs(rows) do
   if entry.kind=="header" then plain[#plain+1]=entry
   elseif entry.kind=="quest" then
    local e=copy(entry);e.standalone=true;e.relationship="ungrouped";plain[#plain+1]=e
   end
  end
  return plain
 end
 local result,section,assessments={}, {}, {}
 local sectionKey=scope or "list"
 local function flush()process(section,sectionKey,addContext,result,assessments,options);section={} end
 for _,e in ipairs(rows) do
  if e.kind=="header" then
   flush();result[#result+1]=e;sectionKey=(scope or "list")..":"..e.label
  elseif e.kind=="quest" then section[#section+1]=e end
 end
 flush();return result
end
function G.ToggleChainGroup(key)
 if not key or not G.db then return end
 G.db.chainCollapsed=G.db.chainCollapsed or {}
 local collapsed=G.db.chainCollapsed[key]
 if collapsed==nil then collapsed=effectiveCollapsed[key] or false end
 G.db.chainCollapsed[key]=not collapsed
end

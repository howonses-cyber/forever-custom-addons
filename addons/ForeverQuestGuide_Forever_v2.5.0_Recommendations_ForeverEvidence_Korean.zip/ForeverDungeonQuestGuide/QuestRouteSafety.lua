local addon,G=...
-- Phase 2: read-only, provenance-aware location and readiness explanations.
-- Candidate spawns are NOT paths or guaranteed NPC positions.  No guessed links,
-- quests, items, or coordinates, and no changes to the quest log or SavedVariables.
G.routeSafetyVersion="2.5.0"
local function valid(id)
 id=tonumber(id)
 return id and id>0 and id%1==0 and id or nil
end
local function db(dbObject,id,field)
 if type(G.DBGet)=="function" then return G.DBGet(dbObject,id,field) end
end
local function point(p)
 return type(p)=="table" and type(p.map)=="number" and p.map>0
  and type(p.x)=="number" and type(p.y)=="number" and p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function addCandidate(rows,unique,p,name,source)
 if not point(p) then return end
 local key=string.format("%d:%.4f:%.4f",p.map,p.x,p.y)
 if unique[key] then return end
 unique[key]=true
 rows[#rows+1]={map=p.map,x=p.x,y=p.y,name=name or p.name or "대상",source=source or "QuestieDB",approx=p.approx==true}
end
local function collectSpawns(rows,unique,entityDb,entityId,name)
 local spawns=db(entityDb,entityId,"spawns")
 if type(spawns)~="table" then return end
 local zones={}
 for area,pts in pairs(spawns) do zones[#zones+1]={id=tonumber(area),positions=pts} end
 table.sort(zones,function(a,b)return (a.id or 0)<(b.id or 0) end)
 for _,zone in ipairs(zones) do
  local area=zone.id
  local isInstance=type(G.IsInstanceArea)=="function" and G.IsInstanceArea(area)
  local map=area and not isInstance and type(G.AreaToUiMap)=="function" and G.AreaToUiMap(area)
  if type(map)=="number" and map>0 and type(zone.positions)=="table" then
   for i=1,math.min(#zone.positions,80) do
    local coords=zone.positions[i]
    if type(coords)=="table" and type(coords[1])=="number" and type(coords[2])=="number"
       and coords[1]>=0 and coords[1]<=100 and coords[2]>=0 and coords[2]<=100 then
     addCandidate(rows,unique,{map=map,x=coords[1]/100,y=coords[2]/100},name,"QuestieDB 출현 후보")
     if #rows>=60 then return end
    end
   end
  end
 end
end
local function providers(id,stage)
 local row=db(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return {} end
 return {{db=NpcDB,ids=row.npc or row.NPC or row[1]},
         {db=ObjectDB,ids=row.object or row.Object or row[2]}}
end
local function objectiveSources(id)
 local objects=db(QuestDB,id,"objectives")
 if type(objects)~="table" then return {} end
 return {{db=NpcDB,ids=objects[1]}, {db=ObjectDB,ids=objects[2]}}
end
-- Returns up to maxItems explicitly sourced candidate locations and the total
-- unique sample count.  Never use these points to change a navigation target.
function G.QuestVisitCandidates(id,stage,maxItems)
 id=valid(id)
 if not id or (stage~="accept" and stage~="turnin" and stage~="objective") then return {},0 end
 if G.QuestInsideInfo and G.QuestInsideInfo(id,stage) then return {},0 end
 if G.QuestStageLandmark and G.QuestStageLandmark(id,stage) then return {},0 end
 local rows,unique={},{}
 local overrides=stage=="accept" and G.pickupOverrides or stage=="turnin" and G.turninOverrides
 local override=overrides and overrides[id]
 if override then
  addCandidate(rows,unique,override,override.name,"검증된 가이드 보정")
 else
  for _,provider in ipairs(stage=="objective" and objectiveSources(id) or providers(id,stage)) do
   local list=provider.ids
   if type(list)=="table" then
    -- Bound work on anomalous plugin DB rows; do not scan arbitrary entities.
    for i=1,math.min(#list,24) do
     local entry=list[i]
     local entityId=valid(type(entry)=="table" and entry[1] or entry)
     if entityId then
      local name=db(provider.db,entityId,"name") or ("대상 #"..entityId)
      collectSpawns(rows,unique,provider.db,entityId,name)
      if #rows>=60 then break end
     end
    end
   end
  end
 end
 table.sort(rows,function(a,b)
  if a.map~=b.map then return a.map<b.map end
  if a.x~=b.x then return a.x<b.x end
  if a.y~=b.y then return a.y<b.y end
  return a.name<b.name
 end)
 local total=#rows
 local max=math.max(1,math.min(tonumber(maxItems) or 3,6))
 while #rows>max do rows[#rows]=nil end
 return rows,total
end
local function questName(id)
 return G.GetQuestName and G.GetQuestName(id) or ("퀘스트 #"..tostring(id))
end
-- A successor relation NEVER proves the predecessor has been handed in, or
-- that the successor can already be picked up. Check game reward state first.
function G.QuestFollowupHint(id)
 id=valid(id);if not id then return nil end
 local hint=G.specialQuestMeta and G.specialQuestMeta[id]
 local stages=hint and hint.insideStages
 local turnin=stages and stages.turnin
 local nextId=valid(turnin and turnin.followup)
 local source=nextId and "검증된 내부 연계" or nil
 if not nextId then
  nextId=valid(db(QuestDB,id,"nextQuestInChain"))
  source=nextId and "QuestieDB 후속 관계" or nil
 end
 if not nextId or nextId==id then return nil end
 local nextMeta=G.specialQuestMeta and G.specialQuestMeta[nextId]
 local start=nextMeta and nextMeta.insideStages and nextMeta.insideStages.accept
 local sameContact=turnin and start and start.dungeon==turnin.dungeon
  and start.npcName and turnin.npcName and start.npcName==turnin.npcName
 local state
 if G.IsCompleted and G.IsCompleted(nextId) then state="후속 퀘스트 보고 완료"
 elseif G.IsInLog and G.IsInLog(nextId) then state="후속 퀘스트 이미 수락"
 elseif G.IsCompleted and G.IsCompleted(id) then state="이전 단계 보고 완료 · 후속 수락 가능 여부 현장 확인"
 elseif G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) then state="현재 퀘스트를 먼저 보고하고 보상을 받으세요"
 elseif G.IsInLog and G.IsInLog(id) then state="현재 퀘스트 목표를 마친 뒤 보고가 먼저입니다"
 else state="이전 단계 보고 완료 기록 및 후속 수락 조건 확인 필요" end
 return {id=nextId,name=questName(nextId),source=source,state=state,sameContact=sameContact==true}
end
local function rowStatus(id)
 if G.IsCompleted and G.IsCompleted(id) then return "done","보고 완료" end
 if G.IsInLog and G.IsInLog(id) then
  if G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) then return "turnin","보고 가능" end
  return "active","수행 중"
 end
 if not G.Ready or not G.Ready() or not db(QuestDB,id,"name") then return "unknown","퀘스트 DB 확인 필요" end
 local state,code,reason=G.RouteAssessment(id)
 if code=="ready" then return "unaccepted","미수락 · 받을 수 있는지 NPC 확인" end
 if code=="locked" then return "locked",reason or state or "선행 필요" end
 if code=="low" then return "blocked",reason or state or "레벨 부족" end
 return "blocked",reason or state or "제한/확인 필요"
end
-- Quest catalog rows include optional/breadcrumb/alternate quests. Do not
-- mistake the catalog for the player's actual log or mark entry as prepared.
function G.DungeonPreflight(dungeonKey)
 local dungeon=G.GetDungeon and G.GetDungeon(dungeonKey)
 if not dungeon then return nil end
 local data={dungeon=dungeon.name,id=dungeon.id,counts={done=0,active=0,turnin=0,unaccepted=0,locked=0,blocked=0,unknown=0},
  rows={},notes={},confirmedReady=false}
 if not dungeon.ids or #dungeon.ids==0 then
  data.notes[#data.notes+1]="서버 전용 던전의 퀘스트 목록이 검증되지 않았습니다. 준비 완료로 판단할 수 없습니다."
  return data
 end
 for _,id in ipairs(dungeon.ids) do
  local key,reason=rowStatus(id)
  data.counts[key]=data.counts[key]+1
  data.rows[#data.rows+1]={id=id,name=questName(id),status=key,note=reason}
 end
 data.notes[#data.notes+1]="던전 목록은 관련 퀘스트 참고 목록입니다. 모두 필수 수락 대상이라는 뜻이 아닙니다."
 if data.counts.unknown>0 then data.notes[#data.notes+1]="퀘스트 DB 미확인 "..data.counts.unknown.."건 · 출발 준비가 전부 끝났다고 판정할 수 없습니다." end
 if dungeon.id=="brd" then
  data.notes[#data.notes+1]="나락: 감금 구역의 내부 보고/후속 수락, 열쇠가 필요한 일부 구역, 호위 시작 조건은 파티와 확인하세요. 입장 자체에 모든 열쇠가 필요한 것은 아닙니다."
 end
 return data
end
function G.DungeonPreflightLines(dungeonKey,maxRows)
 local report=G.DungeonPreflight(dungeonKey)
 if not report then return {} end
 local c=report.counts
 local lines={"던전 출발 전 점검 · "..report.dungeon,
  "실제 수락 "..c.active.." · 보고 가능 "..c.turnin.." · 아직 미수락 "..c.unaccepted.." · 선행 필요 "..c.locked.." · 기타 제한 "..c.blocked.." · DB 미확인 "..c.unknown}
 for _,note in ipairs(report.notes) do lines[#lines+1]="주의: "..note end
 local shown,max=0,math.max(1,math.min(tonumber(maxRows) or 6,20))
 for _,row in ipairs(report.rows) do
  if row.status=="turnin" or row.status=="active" or row.status=="locked" or row.status=="unknown" then
   shown=shown+1
   if shown<=max then lines[#lines+1]="· "..row.name.." (#"..row.id..") : "..row.note end
  end
 end
 if shown>max then lines[#lines+1]="위 목록 이외 점검 필요 "..(shown-max).."건 · 전체 퀘스트 목록에서 확인" end
 lines[#lines+1]="표시는 읽기 전용입니다. 완료·수락·아이템 보유를 임의 판정하거나 변경하지 않습니다."
 return lines
end
local specialInstructions={
 [4083]="특수: 채광 230 이상과 재료를 준비한 뒤 던전 내부 성배와 상호작용하세요. 칠현자 이벤트 진행 전에 확인하세요.",
 [4264]="특수: 적에게서 얻은 시작 아이템을 가방에서 사용해야 퀘스트가 생성됩니다. 일반 NPC 수락과 다릅니다.",
 [4322]="호위: 시작 전 파티 준비와 경로를 확인하세요. 호위 NPC가 이동 중이면 현장 진행 상황을 우선합니다.",
 [3801]="유령 상태: 살아 있는 상태에서는 수락 대상이 보이지 않을 수 있습니다.",
 [3802]="열쇠 연계: 재료를 얻어 던전 내부 기념비에 사용해야 하는 단계입니다. 일반 NPC 보고와 다릅니다.",
 [4024]="아이템 사용: 대상 처치 뒤 시체에 퀘스트 아이템을 사용해야 합니다. 처치만으로 완료되지 않습니다.",
 [4362]="전투 주의: 제왕을 처치하되 공주 모이라가 살아 있어야 한다는 퀘스트 조건을 확인하세요.",
}
function G.QuestSpecialInstruction(id)
 id=valid(id)
 if not id then return nil end
 local note=specialInstructions[id]
 if note then return note end
 local metadata=G.specialQuestMeta and G.specialQuestMeta[id]
 if metadata and metadata.specialInstruction then return metadata.specialInstruction end
 local _,_,_,typeName=G.QuestContactName and G.QuestContactName(id,"accept")
 if typeName=="item" then return "시작 아이템: 가방에서 해당 아이템을 사용해 수락하세요. 보유/드롭 여부는 직접 확인해야 합니다." end
 return nil
end
function G.RouteTravelCaveat(step,playerPosition)
 if type(step)~="table" then return nil end
 if step.indoor then
  if G.IsInGuideDungeon and G.IsInGuideDungeon(step.indoor.dungeonId) then
   return "던전 안에서는 입구 좌표를 목표로 표시하지 않습니다. 내부 방·층/통로는 던전 네비게이터와 현장 지형을 확인하세요."
  end
  return "외부 화살표는 던전 입구 접근용입니다. 내부 목표까지 계산한 길이 아니며 층수·문·지름길은 별도 확인하세요."
 end
 if step.landmark and step.landmark.approach then
  return "이 위치는 접근 지점입니다. 실제 목표 좌표가 아닙니다."
 end
 if point(step.point) and step.point.approx then
  return "등록된 좌표는 탐색 후보입니다. 대상 위치가 달라질 수 있습니다."
 end
 if point(playerPosition) and point(step.point) and playerPosition.map~=step.point.map then
  return "지도 간 직선거리는 이동 경로가 아닙니다. 배·비행·포탈·산길 연결 여부는 외부 길찾기와 실제 게임 지도로 확인하세요."
 end
 return nil
end

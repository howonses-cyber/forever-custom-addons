-- Game-state presentation tests against the actual Core completion/log helpers.
-- C APIs are controlled fixtures; no live-client rendering is claimed.
local base=arg[1] or './'
local G={}
assert(loadfile(base..'Core.lua'))('ForeverDungeonQuestGuide',G)
assert(loadfile(base..'QuestStatus.lua'))('ForeverDungeonQuestGuide',G)
local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,(label or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b))end
local function ok(value,label)checks=checks+1;assert(value,label)end
local function contains(value,part,label)ok(type(value)=='string' and value:find(part,1,true)~=nil,label)end
local function snapshot(t)
 local keys={};for k in pairs(t)do keys[#keys+1]=k end
 table.sort(keys,function(a,b)return tostring(a)<tostring(b)end)
 local out={};for _,k in ipairs(keys)do local v=t[k];out[#out+1]=tostring(k)..'='..(type(v)=='table' and snapshot(v)or tostring(v))end
 return table.concat(out,'|')
end
local log={[2]={index=17},[3]={index=18,ready=true},[8]={index=19},[9]={index=20,ready=true},[15]={index=21},[16]={index=22},[17]={index=23,ready=true}}
local rewards={[4]=true,[15]=true,[17]=true}
local noRecord={[13]=true}
local route={
 [5]={'선행 필요 · 2개 자동 추가','locked'},
 [6]={'레벨 부족 (40 / 최소 50)','low'},
 [7]={'사용자 보류','deferred','사용자가 가이드에서 보류했습니다.'},
 [8]={'사용자 보류','deferred'},
 [9]={'사용자 보류','deferred'},
 [10]={'연계 진행 · 동선 제외','superseded'},
 [11]={'선행 보류: 이전 퀘스트','dependentDeferred'},
 [12]={'퀘스트 자료 연결 필요','unknown'},
 [19]={'현재 진영/종족/직업 제한','blocked'},
}
local objectiveReads,routeReads=0,0
local objectives={
 [2]={{text='시험 대상 처치',type='monster',numFulfilled=3,numRequired=10,finished=false},
      {text='시험 수집물: 2/2',type='item',numFulfilled=2,numRequired=2,finished=true},
      {text='대상과 대화',type='event',numFulfilled=0,numRequired=0,finished=false}},
}
C_QuestLog={
 IsOnQuest=function(id)return log[id]~=nil end,
 GetLogIndexForQuestID=function(id)return log[id] and log[id].index or 0 end,
 IsComplete=function(id)return log[id] and log[id].ready==true or false end,
 IsQuestFlaggedCompleted=function(id)if noRecord[id]then return nil end;return rewards[id]==true end,
 GetInfo=function(index)for id,row in pairs(log)do if row.index==index then return{questID=id}end end end,
 GetQuestObjectives=function(id)objectiveReads=objectiveReads+1;return objectives[id]end,
}
G.RouteAssessment=function(id)
 routeReads=routeReads+1
 if route[id]then return route[id][1],route[id][2],route[id][3]end
 if G.IsInLog(id)then return G.IsReadyToTurnIn(id) and '보고 대기'or'진행 중',G.IsReadyToTurnIn(id) and'turnin'or'active'end
 if G.IsCompleted(id)then return'완료','done'end
 return'미수락','ready'
end
G.db={selectedQuests={[1]=true,[10]=true},deferredQuests={[7]=true,[8]=true,[9]=true},manualProgress={[10]=true},guide={steps={{quest=10,kind='turnin',done=true}},index=1}}
G.sessionTurnins[16]=true
local savedBefore=snapshot(G.db)
local selectionBefore=snapshot(G.selection)
local sessionBefore=snapshot(G.sessionTurnins)

eq(G.statusVersion,'2.5.0','status module version')
for _,spec in ipairs({{1,'unaccepted','미수락',false},{2,'active','수행 중',false},{3,'turnin','보고 가능',false},{4,'done','완료',false},
 {5,'unaccepted','미수락',true},{6,'unaccepted','미수락',true},{7,'unaccepted','미수락',true},{8,'active','수행 중',true},{9,'turnin','보고 가능',true},
 {10,'unknown','기록 확인',true},{11,'unaccepted','미수락',true},{12,'unaccepted','미수락',true},{13,'unknown','기록 확인',false},{15,'active','수행 중',false},
 {16,'active','수행 중',false},{17,'turnin','보고 가능',false},{19,'unaccepted','미수락',true}})do
 local s=G.QuestListStatus(spec[1]);eq(s.key,spec[2],'primary game state '..spec[1]);eq(s.label,spec[3],'state label '..spec[1]);eq(s.blocked,spec[4],'secondary condition '..spec[1])
end
eq(G.QuestListStatus(10).reason,'지난 단계 · 완료 기록 미확인','superseded is not completed')
contains(G.QuestListStatus(10).detail,'자체를 보고한 완료 기록은 확인하지 못했습니다','superseded explanation is honest')
eq(G.QuestListStatus(5).reason,'선행 필요','locked secondary label')
eq(G.QuestListStatus(6).reason,'레벨 부족','level secondary label');contains(G.QuestListStatus(6).detail,'40 / 최소 50','level detail retains actual gap')
eq(G.QuestListStatus(19).reason,'진영·종족·직업 제한','faction condition is secondary')
contains(G.QuestListStatus(8).detail,'퀘스트 자체의 수락·완료 상태는 바뀌지 않습니다','deferred active quest stays active')
eq(objectiveReads,0,'row statuses never query objectives')
eq(G.QuestListStatus(0),nil,'invalid zero quest');eq(G.QuestListStatus(-1),nil,'invalid negative quest');eq(G.QuestListStatus(1.5),nil,'invalid fractional quest')

local cache={};local a=G.QuestListStatus(1,cache);local reads=routeReads
eq(G.QuestListStatus(1,cache),a,'per-refresh status result is reused');eq(routeReads,reads,'cache avoids duplicate route assessment')
local counts=G.QuestStatusSummary({1,'1',2,3,4,5,8,9,10,13,0,-1,2.5},cache)
eq(counts.all,9,'summary deduplicates IDs');eq(counts.unaccepted,2,'unaccepted count');eq(counts.active,2,'active count');eq(counts.turnin,2,'turnin count');eq(counts.done,1,'done count');eq(counts.unknown,2,'unknown count');eq(counts.blocked,4,'blocked count overlaps primary states')
eq(counts.unaccepted+counts.active+counts.turnin+counts.done+counts.unknown,counts.all,'primary counts partition list')
eq(objectiveReads,0,'summary never queries objectives')
eq(G.QuestStatusMatches(G.QuestListStatus(8),'active'),true,'deferred accepted quest remains in active filter')
eq(G.QuestStatusMatches(G.QuestListStatus(8),'blocked'),true,'deferred accepted quest also has secondary condition')
eq(G.QuestStatusMatches(G.QuestListStatus(10),'done'),false,'superseded excluded from done filter')
eq(G.QuestStatusMatches(G.QuestListStatus(10),'all'),true,'unknown remains visible in all filter')
eq(G.QuestStatusMatches(G.QuestListStatus(13),'blocked'),false,'unknown reward history alone is not an acceptance blocker')
eq(G.QuestStatusMatches(G.QuestListStatus(1),'bogus'),false,'unknown filter does not match')

local rewardAPI=C_QuestLog.IsQuestFlaggedCompleted
C_QuestLog.IsQuestFlaggedCompleted=nil
eq(G.QuestListStatus(1).key,'unknown','missing completion API does not manufacture unaccepted state')
Questie={db={char={complete={[14]=true}}}}
eq(G.QuestListStatus(14).key,'done','positive completion cache passes actual Core helper')
eq(G.QuestListStatus(1).key,'unknown','absence from completion cache is not proof')
G.MarkQuestTurnedIn(18)
eq(G.QuestListStatus(18).key,'done','confirmed same-session turnin remains completed without API')
IsQuestFlaggedCompleted=function()return false end
eq(G.QuestListStatus(1).key,'unaccepted','working legacy completion API provides negative record')
IsQuestFlaggedCompleted=nil
C_QuestLog.IsQuestFlaggedCompleted=function()error('record unavailable')end
eq(G.QuestListStatus(1).key,'unknown','throwing completion API is not false completion evidence')
C_QuestLog.IsQuestFlaggedCompleted=rewardAPI
G.sessionTurnins[18]=nil;Questie=nil

eq(G.QuestListStatus(20).key,'unaccepted','transition starts unaccepted')
log[20]={index=24};G.MarkQuestAccepted(20)
eq(G.QuestListStatus(20).key,'active','accept transition')
log[20].ready=true;eq(G.QuestListStatus(20).key,'turnin','objective completion is report-ready')
log[20]=nil;G.MarkQuestTurnedIn(20);eq(G.QuestListStatus(20).key,'done','rewarded turnin transition')
rewards[20]=true;log[20]={index=24};G.MarkQuestAccepted(20)
eq(G.QuestListStatus(20).key,'active','repeat acceptance wins over old rewarded flag')
log[20]=nil;rewards[20]=nil
eq(G.QuestListStatus(20).key,'unaccepted','abandoning an unrewarded quest does not complete it')

local sourceBefore=snapshot(objectives)
local progressCache={};local p=G.QuestObjectiveProgress(2,progressCache)
eq(p.available,true,'live objective data available');eq(p.done,1,'completed objective rows');eq(p.total,3,'total objective rows');eq(p.ratio,1/3,'ratio counts objectives, not mixed item/kill quantities')
eq(p.summary,'완료 목표 1/3','ratio label states its definition')
eq(p.objectives[1].current,3,'exact kill current');eq(p.objectives[1].required,10,'exact kill required');eq(p.objectives[1].display,'시험 대상 처치 (3/10)','missing textual counter appended')
eq(p.objectives[2].display,'시험 수집물: 2/2','existing live counter is not duplicated')
eq(p.objectives[3].quantity,nil,'non-count objective has no invented counter')
eq(p.partialText,'시험 대상 처치 (3/10)','partial objective highlights exact quantity')
contains(p.detail,'보상까지 받은 완료 상태를 뜻하지 않습니다','goal completion is separate from reward completion')
local progressReads=objectiveReads;eq(G.QuestObjectiveProgress(2,progressCache),p,'per-refresh progress cache reused');eq(objectiveReads,progressReads,'progress cache avoids duplicate APIs')
eq(snapshot(objectives),sourceBefore,'progress never rewrites live objective array')
local inactive=G.QuestObjectiveProgress(1)
eq(inactive.available,false,'unaccepted quest has no current progress');eq(inactive.ratio,nil,'unaccepted quest has no invented zero percent');eq(objectiveReads,progressReads,'unaccepted progress does not query API')

local sig=G.QuestProgressSignature(2)
eq(G.QuestProgressSignature(2),sig,'unchanged raw live data has stable signature')
objectives[2][1].numFulfilled=4
ok(G.QuestProgressSignature(2)~=sig,'quantity-only change updates signature')
local quantitySig=G.QuestProgressSignature(2)
eq(G.QuestObjectiveProgress(2).ratio,1/3,'partial quantity change does not fake a completed objective')
contains(G.QuestObjectiveProgress(2).partialText,'4/10','partial quantity text updates')
objectives[2][1].finished=true
ok(G.QuestProgressSignature(2)~=quantitySig,'finished-only change updates signature')
eq(G.QuestObjectiveProgress(2).done,2,'updated finished goal count')
local finishedSig=G.QuestProgressSignature(2);objectives[2][1].text='새 목표 설명'
ok(G.QuestProgressSignature(2)~=finishedSig,'text-only change updates signature')
local textSig=G.QuestProgressSignature(2);objectives[2][1].numRequired=12
ok(G.QuestProgressSignature(2)~=textSig,'required quantity changes signature')
eq(G.QuestProgressSignature(1),'not-in-log','signature ignores unaccepted quests')

local modern=C_QuestLog.GetQuestObjectives
C_QuestLog.GetQuestObjectives=function()return{}end
local emptySig=G.QuestProgressSignature(2);local empty=G.QuestObjectiveProgress(2)
eq(empty.available,false,'empty live objectives do not claim progress');eq(empty.ratio,nil,'empty objectives have no invented ratio')
C_QuestLog.GetQuestObjectives=nil
local missing=G.QuestObjectiveProgress(2)
eq(missing.available,false,'missing live objective API is unavailable');eq(missing.ratio,nil,'missing API has no invented zero percent')
ok(G.QuestProgressSignature(2)~=emptySig,'signature distinguishes empty objective table from missing API')
eq(G.QuestObjectiveProgress(3).ratio,nil,'report-ready status alone does not fabricate objective totals')

local legacyReads=0
C_QuestLog.GetLogIndexForQuestID=nil
G.activeQuests[2]={logIndex=17}
GetNumQuestLeaderBoards=function(index)eq(index,17,'legacy objective count uses exact cached log index');return 2 end
GetQuestLogLeaderBoard=function(i,index)
 legacyReads=legacyReads+1;eq(index,17,'legacy row uses exact cached log index')
 if i==1 then return '처치: 2/8','monster',0 end
 return '수집: 1/1','item',1
end
SelectQuestLogEntry=function()error('progress reads must not select a quest')end
local legacy=G.QuestObjectiveProgress(2)
eq(legacy.source,'legacy','legacy source marked');eq(legacy.done,1,'numeric zero finished flag is false');eq(legacy.total,2,'legacy objective rows');eq(legacy.ratio,.5,'legacy ratio counts finished goals')
eq(legacy.objectives[1].current,2,'legacy counter read from exact live text');eq(legacy.objectives[1].required,8,'legacy required counter read from exact live text')
eq(legacyReads,2,'legacy reads only requested objective rows')
GetNumQuestLeaderBoards=function(index)eq(index,17,'legacy unknown row log index');return 1 end
GetQuestLogLeaderBoard=function()return'대상과 대화','event',nil end
local unknownGoal=G.QuestObjectiveProgress(2)
eq(unknownGoal.ratio,nil,'missing legacy finished flag/counts do not invent zero completion');contains(unknownGoal.summary,'기록 확인 필요','unknown goal completion is explained')
GetQuestLogLeaderBoard=function()return'처치: 2/8','monster',nil end
eq(G.QuestObjectiveProgress(2).ratio,0,'explicit live numeric quantities establish unfinished goal without flag')

C_QuestLog.GetInfo=function()return{questID=999}end
GetNumQuestLeaderBoards=function()error('must not read another quest log entry')end
eq(G.QuestObjectiveProgress(2).available,false,'mismatched log identity blocks legacy read')
C_QuestLog.GetInfo=function(index)return{questID=2}end
GetNumQuestLeaderBoards=function(index)eq(index,31,'signature honors explicit current log index');return 1 end
GetQuestLogLeaderBoard=function(_,index)eq(index,31,'signature row honors explicit log index');return'테스트: 1/5','monster',false end
contains(G.QuestProgressSignature(2,31),'legacy','signature supports exact explicit legacy index')

C_QuestLog.GetQuestObjectives=modern
GetNumQuestLeaderBoards=nil;GetQuestLogLeaderBoard=nil
objectives[2]={{text='대화',finished=false},{text='시험 수집물',numFulfilled=1,numRequired=3,finished=false}}
eq(G.QuestObjectiveProgress(2).partialText,'시험 수집물 (1/3)','numeric partial goal is preferred over a non-count goal')
local finalSource=snapshot(objectives)
G.QuestProgressSignature(2);G.QuestObjectiveProgress(2)
eq(snapshot(objectives),finalSource,'signature/progress reads do not mutate source records')
eq(snapshot(G.db),savedBefore,'status/progress never change routes, checks, deferred state or manual progress')
eq(snapshot(G.selection),selectionBefore,'status/progress never change selected quest')
eq(snapshot(G.sessionTurnins),sessionBefore,'presentation functions do not create rewarded records')
print('PASS QuestStatus: '..checks..' checks; actual log/reward precedence, repeatables, independent route conditions, deduplicated filters/counts, live objective quantities/signatures, missing-data honesty, exact legacy indices and read-only behavior')

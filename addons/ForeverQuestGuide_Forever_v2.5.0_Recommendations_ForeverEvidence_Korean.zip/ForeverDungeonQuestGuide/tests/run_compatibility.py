#!/usr/bin/env python3
"""Compile and test the shipped addon with Lua 5.1 and LuaJIT 2.1.

Requires Python 3 and lupa 2.8 (install in a separate development environment).
No WoW installation, saved variables, native chat implementation, or production
source is modified. Every suite receives a fresh Lua state. This is a language
compatibility and mock regression gate, not an in-game compatibility claim.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import traceback


ENGINES = ("lua51", "luajit21")
REQUIRED_SUITES = {
    "test_authored_korean.lua",
    "test_chains.lua",
    "test_chat_dispatch.lua",
    "test_journey.lua",
    "test_korean_data.lua",
    "test_load.lua",
    "test_localization.lua",
    "test_route_safety.lua",
    "test_recommendation.lua",
    "test_forever_evidence.lua",
    "test_strict_commands.lua",
    "test_status.lua",
    "test_ui.lua",
}
CHAT_FILES = (
    "SlashCommandsRegistry.lua",
    "ChatFrameUtil.lua",
    "ChatFrameEditBox.lua",
    "ChatFrameSetup.lua",
)


def options() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--addon-root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument(
        "--lupa-path", type=Path,
        help="Optional directory containing a separately installed lupa package.",
    )
    parser.add_argument(
        "--chat-fixtures", type=Path,
        help="Directory containing the four pinned native chat source fixtures.",
    )
    parser.add_argument(
        "--baseline", type=Path,
        help="Optional old addon directory. Its known failure is evidence, not a release gate.",
    )
    parser.add_argument("--report", type=Path, help="Optional JSON regression report.")
    return parser.parse_args()


def lua_arg_table(runtime, script: str, values: list[str]):
    return runtime.table_from({0: script, **dict(enumerate(values, 1))})


def new_runtime(module):
    runtime = module.LuaRuntime(unpack_returned_tuples=True)
    # Do not inject modern-language compatibility globals. The production
    # modules must compile and execute using the real Lua 5.1 language/runtime.
    version = runtime.eval("_VERSION")
    jit_version = runtime.eval("jit and jit.version or nil")
    if version != "Lua 5.1":
        raise RuntimeError(f"Expected Lua 5.1 language runtime, got {version!r}")
    return runtime, {"language": version, "jit": jit_version}


def compile_files(runtime, base: Path, files: list[str]) -> list[dict]:
    compile_one = runtime.eval(
        "function(path) local chunk, err = loadfile(path); "
        "return chunk ~= nil, err end"
    )
    results = []
    for filename in files:
        success, error = compile_one(str(base / filename))
        results.append({"file": filename, "passed": bool(success), "error": error})
    return results


def run_suite(module, base: Path, filename: str, fixtures: Path, baseline: Path | None) -> dict:
    runtime, _ = new_runtime(module)
    script = "tests/" + filename
    values = [base.as_posix() + "/"]
    if filename == "test_chains.lua":
        values = [(base / "QuestChains.lua").as_posix()]
    elif filename == "test_chat_dispatch.lua":
        values.append(fixtures.as_posix() + "/")
        if baseline:
            values.append(baseline.as_posix() + "/")
    runtime.globals().arg = lua_arg_table(runtime, script, values)
    output = []

    def capture(*parts):
        line = "\t".join("nil" if part is None else str(part) for part in parts)
        output.append(line)
        print("  " + line, flush=True)

    runtime.globals().print = capture
    try:
        runtime.execute("assert(loadfile(...))()", script)
    except Exception as error:
        return {"suite": filename, "passed": False, "error": str(error), "output": output}
    return {"suite": filename, "passed": True, "output": output}


def main() -> int:
    args = options()
    base = args.addon_root.resolve()
    report_path = args.report.resolve() if args.report else None
    if args.lupa_path:
        sys.path.insert(0, str(args.lupa_path.resolve()))
    elif os.environ.get("FDQG_LUPA_PATH"):
        sys.path.insert(0, str(Path(os.environ["FDQG_LUPA_PATH"]).resolve()))
    try:
        import lupa
        modules = {engine: importlib.import_module("lupa." + engine) for engine in ENGINES}
    except ImportError as error:
        print(
            "ERROR: Both lupa.lua51 and lupa.luajit21 are required. "
            "Install lupa==2.8 in the development Python environment, "
            "or provide --lupa-path /path/to/package-directory.\n" + str(error),
            file=sys.stderr,
        )
        return 2

    toc = base / "ForeverDungeonQuestGuide.toc"
    if not toc.is_file():
        print("ERROR: addon TOC not found: " + str(toc), file=sys.stderr)
        return 2
    source_files = [
        line.strip() for line in toc.read_text(encoding="utf-8-sig").splitlines()
        if line.strip().endswith(".lua") and not line.lstrip().startswith("#")
    ]
    suites = sorted(path.name for path in (base / "tests").glob("test_*.lua"))
    missing_suites = REQUIRED_SUITES - set(suites)
    if missing_suites:
        print("ERROR: regression suites missing: " + ", ".join(sorted(missing_suites)), file=sys.stderr)
        return 2
    fixtures = args.chat_fixtures.resolve() if args.chat_fixtures else Path(
        os.environ.get("FDQG_CHAT_FIXTURES", str(Path(tempfile.gettempdir()) / "forever-quest-guide-native-chat"))
    ).resolve()
    if not all((fixtures / name).is_file() for name in CHAT_FILES):
        print(
            "ERROR: pinned native chat fixtures are missing. Fetch them with "
            "tests/fetch_native_chat_fixture.py --destination DIR, then pass --chat-fixtures DIR. "
            "The native chat regression is never silently skipped.", file=sys.stderr,
        )
        return 2
    helper_path = base / "tests" / "fetch_native_chat_fixture.py"
    helper_spec = importlib.util.spec_from_file_location("fdqg_native_fixture_sources", helper_path)
    if not helper_spec or not helper_spec.loader:
        raise RuntimeError("Native fixture source manifest is unavailable")
    helper = importlib.util.module_from_spec(helper_spec)
    previous_bytecode_setting = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        helper_spec.loader.exec_module(helper)
    finally:
        sys.dont_write_bytecode = previous_bytecode_setting
    if set(helper.FILES) != set(CHAT_FILES):
        raise RuntimeError("Unexpected native chat fixture manifest")
    for name, expected in helper.FILES.items():
        data = (fixtures / name).read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
        if actual != expected:
            print(f"ERROR: unverified native fixture {name}: expected {expected}, got {actual}", file=sys.stderr)
            return 2
    baseline = args.baseline.resolve() if args.baseline else base.parents[1] / "v212" / "ForeverDungeonQuestGuide"
    if not (baseline / "UI.lua").is_file():
        baseline = None
    report = {
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "addon_root": str(base),
        "lupa_version": lupa.__version__,
        "toc_modules": source_files,
        "chat_fixtures": str(fixtures),
        "chat_source_commit": helper.COMMIT,
        "chat_git_blobs": helper.FILES,
        "scope": "Native Lua 5.1/LuaJIT compiler and mock/API/native-chat-source regressions; no live game test.",
        "engines": {},
    }
    old_cwd = Path.cwd()
    try:
        os.chdir(base)
        for engine, module in modules.items():
            runtime, identity = new_runtime(module)
            print(f"\n=== {engine}: {identity['language']} / {identity['jit'] or 'standard VM'} ===", flush=True)
            result = {"runtime": identity}
            if baseline:
                baseline_result = compile_files(runtime, baseline, ["UI.lua"])[0]
                result["optional_baseline"] = {"path": str(baseline), **baseline_result}
                if not baseline_result["passed"]:
                    print("BASELINE REPRODUCED (not release gate): " + str(baseline_result["error"]), flush=True)
                else:
                    print("BASELINE INFO: supplied UI source compiled; no historical failure reproduced.", flush=True)
            result["syntax"] = compile_files(runtime, base, source_files)
            syntax_passed = all(item["passed"] for item in result["syntax"])
            result["suites"] = []
            if syntax_passed:
                print(f"PASS actual TOC syntax: {len(source_files)} production modules", flush=True)
                for suite in suites:
                    print("RUN " + suite, flush=True)
                    suite_result = run_suite(module, base, suite, fixtures, baseline)
                    result["suites"].append(suite_result)
                    if not suite_result["passed"]:
                        print("FAIL " + suite + ": " + suite_result["error"], flush=True)
            else:
                for item in result["syntax"]:
                    if not item["passed"]:
                        print("FAIL SYNTAX " + item["file"] + ": " + str(item["error"]), flush=True)
                print("Runtime suites skipped because production source did not compile.", flush=True)
            result["passed"] = syntax_passed and len(result["suites"]) == len(suites) and all(
                item["passed"] for item in result["suites"]
            )
            report["engines"][engine] = result
    finally:
        os.chdir(old_cwd)
    report["passed"] = all(result["passed"] for result in report["engines"].values())
    if report_path:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(
        "\n" + ("PASS" if report["passed"] else "FAIL")
        + f" compatibility gate: {len(ENGINES)} runtimes, {len(source_files)} TOC modules, {len(suites)} suites per runtime.",
        flush=True,
    )
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise SystemExit(2)

local root=arg[1] or './'
local G={}
G.GetDungeon=function(id)return G.dungeonById[id]end
G.SafeCall=function(fn,...)if type(fn)=='function'then return fn(...)end end
G.IsInLog=function()return false end
G.DBGet=function()return nil end
for _,file in ipairs({'Data.lua','VerifiedRoutes.lua','Walkthrough.lua','DungeonWalkthrough.lua'}) do
 assert(loadfile(root..file))('ForeverDungeonQuestGuide',G)
end
local earlier=G.walkthroughRecords[4290]
assert(loadfile(root..'ForeverQuestEvidence.lua'))('ForeverDungeonQuestGuide',G)
assert(G.walkthroughRecords[4290]==earlier,'existing curated route mutated')
assert(G.foreverQuestEvidenceVersion=='2.5.0')
local expected={96391,96393,96394,96395,96403,98423,92462}
for _,id in ipairs(expected)do
 local r=assert(G.walkthroughRecords[id],'missing new Forever record '..id)
 assert(#r.urls==1 and r.urls[1]=='https://questing.wiki/wow-forever/quests/'..id..'/','source provenance')
 assert(#r.accept>0 and #r.objective>0 and #r.turnin>0,'missing steps')
 assert(r.evidence:find('직접 확인하지 않음',1,true),'evidence disclaimer missing')
 local text=table.concat(r.accept,'\n')..table.concat(r.objective,'\n')..table.concat(r.turnin,'\n')
 assert(not text:find('[A-Za-z]'),'new guide contains untranslated English '..id)
end
assert(G.walkthroughRecords[96391].turnin[1]:find('구 아이언포지 침입',1,true),'confirmed predecessor link')
assert(G.walkthroughRecords[98423].turnin[2]:find('강제 후속',1,true),'no invented chain edge')
assert(G.walkthroughRecords[96395].accept[2]:find('확정되지',1,true),'unverified indoor coordinates must be flagged')
assert(G.walkthroughRecords[96403].objective[1]:find('8개',1,true),'required item quantity')
assert(G.walkthroughRecords[96394].objective[1]:find('15명',1,true),'mob count 1')
assert(G.walkthroughRecords[96394].objective[1]:find('10명',1,true),'mob count 2')
assert(not G.pickupOverrides[96393] and not G.turninOverrides[96403],'must not invent fixed map pins')
assert(not G.verifiedObjectives[96403],'must not invent item/object IDs')
print('PASS Phase3 Forever evidence: seven verified public quest IDs, steps, sources, uncertainties, no route state or invented pins')

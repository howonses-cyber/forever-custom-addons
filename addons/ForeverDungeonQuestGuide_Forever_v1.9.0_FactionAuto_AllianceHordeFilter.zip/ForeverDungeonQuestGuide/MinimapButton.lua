local addon,G=...
-- The EllesmereUI button collection discovers named direct Minimap children.
-- Match the already-working ForeverWatchRadar integration; do not patch EUI.
local button
local function collected()
 local cache=_G._EBS_CachedAddonButtons
 if type(cache)~="table" or not button then return false end
 for _,candidate in ipairs(cache) do if candidate==button then return true end end
 return false
end
local function place()
 if not button or collected() then return end
 local minimap=_G.Minimap
 if not minimap or button:GetParent()~=minimap then return end
 local radius=(minimap.GetWidth and minimap:GetWidth() or 140)/2+12
 button:ClearAllPoints()
 button:SetPoint("CENTER",minimap,"CENTER",math.cos(math.rad(218))*radius,math.sin(math.rad(218))*radius)
end
function G.CreateMinimapButton()
 if button then
  if not collected() then place() end
  button:Show()
  return button
 end
 if not UIParent or not CreateFrame then return nil end
 button=CreateFrame("Button","ForeverDungeonQuestGuideMinimapButton",_G.Minimap or UIParent)
 button:SetSize(32,32)
 button:SetFrameStrata("HIGH");button:SetFrameLevel(8)
 button:EnableMouse(true)
 button:RegisterForClicks("LeftButtonUp","RightButtonUp")
 local bg=button:CreateTexture(nil,"BACKGROUND")
 bg:SetAllPoints();bg:SetColorTexture(.045,.055,.07,.94)
 local icon=button:CreateTexture(nil,"ARTWORK")
 icon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")
 icon:SetTexCoord(.08,.92,.08,.92)
 icon:SetPoint("TOPLEFT",button,"TOPLEFT",3,-3)
 icon:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-3,3)
 button.icon=icon
 for side=1,4 do
  local rim=button:CreateTexture(nil,"OVERLAY")
  rim:SetColorTexture(.9,.68,.28,.95)
  if side==1 then
   rim:SetHeight(2);rim:SetPoint("TOPLEFT",button,"TOPLEFT",0,0);rim:SetPoint("TOPRIGHT",button,"TOPRIGHT",0,0)
  elseif side==2 then
   rim:SetHeight(2);rim:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",0,0);rim:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
  elseif side==3 then
   rim:SetWidth(2);rim:SetPoint("TOPLEFT",button,"TOPLEFT",0,0);rim:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",0,0)
  else
   rim:SetWidth(2);rim:SetPoint("TOPRIGHT",button,"TOPRIGHT",0,0);rim:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
  end
 end
 local hl=button:CreateTexture(nil,"HIGHLIGHT")
 hl:SetAllPoints(icon);hl:SetColorTexture(.9,.76,.38,.18)
 button:SetScript("OnClick",function(self,mouse)
  if mouse=="RightButton" then
   if G.ToggleHUD then G.ToggleHUD() end
  elseif G.ToggleUI then G.ToggleUI() end
 end)
 button:SetScript("OnEnter",function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,"ANCHOR_LEFT")
  GameTooltip:AddLine("포에버 퀘스트 동선 가이드",1,.79,.35)
  GameTooltip:AddLine("좌클릭: 전체 퀘스트 검색·체크·길찾기",.87,.92,1)
  GameTooltip:AddLine("우클릭: 동선 HUD 켜기/끄기",.87,.92,1)
  if collected() then GameTooltip:AddLine("엘스미어UI 애드온 모음집",.65,.82,1) end
  GameTooltip:Show()
 end)
 button:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 if _G.Minimap then place()
 else button:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-150,-90) end
 button:Show()
 return button
end

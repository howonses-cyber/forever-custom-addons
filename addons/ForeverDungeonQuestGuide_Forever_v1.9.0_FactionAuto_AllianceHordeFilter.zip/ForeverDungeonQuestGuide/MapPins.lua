local addon,G=...
-- Only draw OUR guide markers. Do not touch Questie, Blizzard, or ShortestPath
-- pins. The older guide drew 35 icons and straight lines; these implied a
-- walkable route even across mountains and crowded out the map.
local pins={}
local palette={
 accept={.25,.82,.96}, objective={.98,.77,.30},
 turnin={.42,.90,.50}, entrance={1,.56,.25}, inside={.69,.70,.75},
}
local function canvas()
 local frame=_G.WorldMapFrame
 if not frame or not frame.IsShown or not frame:IsShown() then return nil,nil end
 local id=frame.GetMapID and frame:GetMapID()
 local scroll=frame.ScrollContainer
 local child=scroll and (scroll.Child or (scroll.GetCanvas and scroll:GetCanvas()))
 if not child or type(child.GetWidth)~="function" then return nil,nil end
 return child,id
end
local function makePin(i,parent)
 local b=pins[i]
 if b then
  if b:GetParent()~=parent then b:SetParent(parent) end
  return b
 end
 b=CreateFrame("Button",nil,parent)
 b:SetSize(17,17)
 if b.SetFrameStrata then b:SetFrameStrata("HIGH") end
 local border=b:CreateTexture(nil,"BORDER")
 border:SetAllPoints();border:SetColorTexture(0.03,0.05,0.08,.92)
 b.border=border
 local fill=b:CreateTexture(nil,"ARTWORK")
 fill:SetPoint("TOPLEFT",b,"TOPLEFT",2,-2)
 fill:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-2,2)
 b.fill=fill
 local txt=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
 txt:SetPoint("CENTER",0,0)
 b.text=txt
 b:SetScript("OnEnter",function(self)
  if GameTooltip then
   GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
   GameTooltip:SetText(self.title or "선택한 퀘스트 경유지")
   GameTooltip:AddLine(self.desc or "",.86,.86,.90,true)
   GameTooltip:AddLine("통합 동선 순서 · 길찾기는 여정에서 표시",.65,.70,.75)
   GameTooltip:Show()
  end
 end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 -- A map pin is an informative marker, not a hidden step-skip control.
 b:SetScript("OnClick",function(self)
  if self.point and G.OpenPointMap then G.OpenPointMap(self.point) end
 end)
 pins[i]=b
 return b
end
function G.RefreshMapPins()
 for _,b in ipairs(pins) do b:Hide() end
 local mode=G.db and G.db.mapPinMode or "auto"
 if mode=="off" then return end
 -- ShortestPath already marks its own 1-3 ordered stops: don't duplicate them.
 if mode=="auto" and G.IsGuideJourneyActive and G.IsGuideJourneyActive() then return end
 local guide=G.db and G.db.guide
 if not guide or type(guide.steps)~="table" then return end
 local ix=guide.index or 1
 local parent,mapId=canvas()
 if not parent or not mapId then return end
 local w,h=parent:GetWidth(),parent:GetHeight()
 if not w or not h or w<=0 or h<=0 then return end
 local maxVisible=mode=="next" and 2 or 1 -- auto/current: current only
 local rendered=0
 for i=ix,math.min(#guide.steps,ix+maxVisible-1) do
  local step=guide.steps[i]
  local p=step and step.point
  if p and p.map==mapId and type(p.x)=="number" and type(p.y)=="number" and
     p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1 then
   rendered=rendered+1
   local b=makePin(rendered,parent)
   local now=i==ix
   b:SetSize(now and 19 or 14,now and 19 or 14)
   b:ClearAllPoints()
   b:SetPoint("CENTER",parent,"TOPLEFT",w*p.x,-h*p.y)
   local c=palette[step.kind] or palette.objective
   b.fill:SetColorTexture(c[1],c[2],c[3],now and .95 or .68)
   b.text:SetText(now and "1" or "2")
   b.title=step.title or p.name
   b.desc=(now and "현재 방문" or "다음 방문").." · "..string.format("%.1f, %.1f",100*p.x,100*p.y)
   b.point=p
   b:Show()
  end
 end
end

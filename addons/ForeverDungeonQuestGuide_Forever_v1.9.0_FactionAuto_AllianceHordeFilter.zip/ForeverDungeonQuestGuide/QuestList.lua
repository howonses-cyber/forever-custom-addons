local addon,G=...
-- Rows are lightweight render data; the game UI renders only the visible window.
-- Level = quest level (not required/minimum player level); unknown is '?'.
local dungeonIds={}
local dungeonAreas={}
for _,d in ipairs(G.dungeons or {}) do
 if d.area then dungeonAreas[d.area]=dungeonAreas[d.area] or d end
 for _,qid in ipairs(d.ids or {}) do
  -- Explicit dungeon quest associations take precedence over the pickup zone.
  -- Some prerequisite chains lead through outdoor areas; those remain labelled
  -- as dungeon-related rather than pretending the pickup NPC is inside.
  if not dungeonIds[qid] then dungeonIds[qid]=d end
 end
end
local function questLevel(id)
 local active=G.activeQuests and G.activeQuests[id]
 local lv=active and tonumber(active.level)
 if not lv or lv<=0 then lv=tonumber(G.GetQuestLevel and G.GetQuestLevel(id)) end
 if lv and lv>0 then return tostring(math.floor(lv)) end
 return "?"
end
function G.QuestListMeta(id)
 id=tonumber(id)
 local area=tonumber(G.DBGet and G.DBGet(QuestDB,id,"zoneOrSort"))
 local dungeon=dungeonIds[id] or (area and dungeonAreas[area])
 if dungeon then
  return {key="dungeon:"..dungeon.id,label=dungeon.name,isDungeon=true,level=questLevel(id)}
 end
 local map,zone=G.GetQuestZone(id)
 if zone and zone~="" then
  return {key="zone:"..tostring(map),label=zone,isDungeon=false,level=questLevel(id)}
 end
 local log=G.activeQuests and G.activeQuests[id]
 local fallback=log and log.header
 if type(fallback)~="string" or fallback=="" then fallback="기타 · 지역 확인 필요" end
 return {key="unknown:"..fallback,label=fallback,isDungeon=false,level=questLevel(id)}
end
function G.QuestListRows(ids,grouped)
 ids=ids or {}
 local out={}
 if not grouped then
  for _,id in ipairs(ids) do
   local m=G.QuestListMeta(id)
   out[#out+1]={kind="quest",id=id,meta=m}
  end
  return out
 end
 local groups,sorted={},{}
 for _,id in ipairs(ids) do
  local m=G.QuestListMeta(id)
  local group=groups[m.key]
  if not group then
   group={meta=m,quests={}}
   groups[m.key]=group
   sorted[#sorted+1]=group
  end
  group.quests[#group.quests+1]={kind="quest",id=id,meta=m}
 end
 table.sort(sorted,function(a,b)
  local aUnknown=string.sub(a.meta.key,1,8)=="unknown:"
  local bUnknown=string.sub(b.meta.key,1,8)=="unknown:"
  if aUnknown~=bUnknown then return not aUnknown end
  if a.meta.isDungeon~=b.meta.isDungeon then return not a.meta.isDungeon end
  if a.meta.label~=b.meta.label then return a.meta.label<b.meta.label end
  return a.meta.key<b.meta.key
 end)
 for _,group in ipairs(sorted) do
  table.sort(group.quests,function(a,b)
   local al,bl=tonumber(a.meta.level) or 999,tonumber(b.meta.level) or 999
   if al~=bl then return al<bl end
   return a.id<b.id
  end)
  out[#out+1]={kind="header",label=group.meta.label,count=#group.quests,isDungeon=group.meta.isDungeon}
  for _,entry in ipairs(group.quests) do out[#out+1]=entry end
 end
 return out
end

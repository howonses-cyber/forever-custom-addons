local addon,G=...
G.navStatus="경로 대기"
local tomtomUid,usedNative,previousNative,pending
local OWNER="ForeverDungeonQuestGuide"
local lastGuideSignature=nil
local recoveryWait=nil
local recoveryWindow=0
local recoveryBudget=0
local unsubscribeJourney=nil
local MAX_SP_STOPS=3 -- show only current + 2 upcoming, rather than flooding the world map
local function shortPathAPI()
 local s=_G.ShortestPathForever
 local api=s and s.API
 if type(api)=="table" and (api.version==1 or api.version==2) then return api end
 return nil
end
local function ownsJourney()
 local api=shortPathAPI()
 if not api then return false end
 if type(api.Journey)=="function" then
  local ok,journey=pcall(api.Journey)
  if ok and type(journey)=="table" then return journey.owner==OWNER end
 end
 if type(api.CurrentStop)=="function" then
  local ok,idx=pcall(api.CurrentStop,OWNER)
  if ok and type(idx)=="number" and idx>0 then return true end
 end
 return false
end
G.IsGuideJourneyActive=ownsJourney
local function legalPoint(point)
 return type(point)=="table" and type(point.map)=="number" and type(point.x)=="number"
    and type(point.y)=="number" and point.x>=0 and point.x<=1 and point.y>=0 and point.y<=1
end
function G.OpenPointMap(p)
 if not legalPoint(p) then return false end
 if InCombatLockdown and InCombatLockdown() then G.Print("전투 종료 후 지도를 엽니다.");return false end
 local opened=false
 if C_Map and type(C_Map.OpenWorldMap)=="function" then
  local ok=pcall(C_Map.OpenWorldMap,p.map);opened=ok or opened
 end
 local frame=_G.WorldMapFrame
 if type(ToggleWorldMap)=="function" and (not frame or (type(frame.IsShown)=="function" and not frame:IsShown())) then
  local ok=pcall(ToggleWorldMap);opened=ok or opened
  frame=_G.WorldMapFrame
 end
 if frame and type(frame.SetMapID)=="function" then
  local ok=pcall(frame.SetMapID,frame,p.map);opened=ok or opened
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
 return opened
end
local function clearLocalWaypoints()
 if tomtomUid and TomTom and type(TomTom.RemoveWaypoint)=="function" then
  pcall(TomTom.RemoveWaypoint,TomTom,tomtomUid)
 end
 tomtomUid=nil
 if usedNative and C_Map and type(C_Map.ClearUserWaypoint)=="function" then
  -- Do not clear another addon's waypoint or one the user moved to.
  local current=G.SafeCall(C_Map.GetUserWaypoint)
  if not current or (previousNative and current==previousNative) then
   pcall(C_Map.ClearUserWaypoint)
  end
 end
 usedNative=false;previousNative=nil
end
function G.ClearWaypoint()
 -- Clearing our guide must never cancel the player's own journey, or one
 -- started by Questie, Adventure Guide, RestedXP, or other external addons.
 local api=shortPathAPI()
 if api and type(api.Cancel)=="function" then pcall(api.Cancel,OWNER) end
 clearLocalWaypoints()
 lastGuideSignature=nil;recoveryWait=nil;recoveryWindow=0;recoveryBudget=0
end
function G.Navigate(p,openMap)
 if not legalPoint(p) then
  G.navStatus="이 단계의 위치 정보가 없습니다. Questie 지도를 확인하세요."
  return false
 end
 if InCombatLockdown and InCombatLockdown() then
  pending={p=p,open=openMap}
  G.navStatus="전투 종료 후 길찾기를 적용합니다."
  return false
 end
 clearLocalWaypoints()
 local engine=shortPathAPI()
 if engine and type(engine.Navigate)=="function" and (engine.version==1 or engine.version==2) then
  local ok,result=pcall(engine.Navigate,OWNER,p.map,p.x,p.y,p.name or "퀘스트 목적지")
  if ok and result then
   G.navStatus="실제 이동 경로: Shortest Path Forever 연결됨"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if TomTom and type(TomTom.AddWaypoint)=="function" then
  local ok,uid=pcall(TomTom.AddWaypoint,TomTom,p.map,p.x,p.y,{title=p.name or "던전 퀘스트 목적지",persistent=false})
  if ok and uid then
   tomtomUid=uid
   if type(TomTom.SetCrazyArrow)=="function" then pcall(TomTom.SetCrazyArrow,TomTom,uid,0,p.name or "목적지") end
   G.navStatus="TomTom 화살표/지도 지점 표시 (지형 경로 계산 아님)"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if C_Map and type(C_Map.SetUserWaypoint)=="function" and UiMapPoint and type(UiMapPoint.Create)=="function" then
  local point=G.SafeCall(UiMapPoint.Create,p.map,p.x,p.y)
  if point then
   local ok,result=pcall(C_Map.SetUserWaypoint,point)
   if ok and result~=false then
    usedNative=true;previousNative=point
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
     pcall(C_SuperTrack.SetSuperTrackedUserWaypoint,true)
    end
    G.navStatus="기본 지도 목적지 표시 (지형 경로 계산 아님)"
    if openMap then G.OpenPointMap(p) end
    return true
   end
  end
 end
 G.navStatus="지도 위치 표시 실패: TomTom 또는 Shortest Path Forever를 확인하세요."
 if openMap then G.OpenPointMap(p) end
 return false
end
function G.OnLeaveCombat()
 if pending then
  local p=pending;pending=nil
  if p.guide then G.NavigateGuideRoute(G.db and G.db.guide,p.open,true)
  else G.Navigate(p.p,p.open) end
  if G.UIRefresh then G.UIRefresh() end
 end
end
function G.OpenDungeonNavigator()
 local nav=_G.ForeverDungeonNavigator
 if nav and type(nav.ShowLeader)=="function" then
  local ok=pcall(nav.ShowLeader,true)
  if ok then return true end
 end
 G.Print("Forever Dungeon Navigator가 없거나 준비되지 않았습니다. /dnav 로 직접 열 수 있습니다.")
 return false
end

-- The guide is the authority for visit order. Shortest Path supplies terrain
-- legs between those stops, but must not pick a different quest order.
-- Hold each stop until the quest status/manual advance actually changes.
local function inDungeon(dungeonId)
 local inside,kind
 if type(IsInInstance)=="function" then inside,kind=IsInInstance() end
 if not inside or kind~="party" then return false end
 local name,instanceID
 if type(GetInstanceInfo)=="function" then
  local _instanceType,_difficulty,_difficultyName,_maxPlayers,_dynamic,_isDynamic
  name,_instanceType,_difficulty,_difficultyName,_maxPlayers,_dynamic,_isDynamic,instanceID=GetInstanceInfo()
 end
 if dungeonId=="brd" then
  return instanceID==230 or name=="Blackrock Depths" or name=="검은바위 나락"
 end
 return false
end
function G.GuideStepNavPoint(step)
 if not step then return nil end
 if legalPoint(step.point) then return step.point end
 local indoor=step.indoor
 if indoor and not inDungeon(indoor.dungeonId) and legalPoint(indoor.entrance) then
  return indoor.entrance -- outside approach only, not the prisoner's indoor coordinate
 end
 return nil
end
local function routeStops(guide)
 local out,keys={},{}
 local ix=guide.index or 1
 for i=ix,#(guide.steps or {}) do
  local step=guide.steps[i]
  local p=G.GuideStepNavPoint(step)
  if not legalPoint(p) then break end -- don't skip an unknown required stop
  local title=(step.indoor and (step.indoor.dungeon.." 입구 → 내부 "..step.indoor.room)) or step.title or p.name or "퀘스트 목적지"
  out[#out+1]={map=p.map,x=p.x,y=p.y,title=title,
                 tooltip=(step.indoor and (step.indoor.npcName.."에게 던전 안에서 "..(step.kind=="turnin" and "보고" or "대화"))) or
                         (step.questName or title),hold=true,
                 questID=tonumber(step.quest)}
  keys[#keys+1]=(step.key or (tostring(i)..":"..title))..":"..p.map..":"..string.format("%.5f,%.5f",p.x,p.y)
  if #out>=MAX_SP_STOPS then break end
 end
 return out,table.concat(keys,"|")
end
function G.NavigateGuideRoute(guide,openMap,force)
 if not guide or type(guide.steps)~="table" then return false end
 local step=guide.steps[guide.index or 1]
 if not step then
  G.ClearWaypoint();G.navStatus="통합 동선 완료";return false
 end
 local navPoint=G.GuideStepNavPoint(step)
 if not legalPoint(navPoint) then
  -- No guessed points, no skipping that mandatory quest task.
  G.ClearWaypoint()
  if step.indoor and inDungeon(step.indoor.dungeonId) then
   G.navStatus=step.indoor.dungeon.." 내부: "..step.indoor.room.."의 "..step.indoor.npcName.."에게 이동 · 실내 좌표 미제공"
  else
   G.navStatus="다음 단계의 NPC/목표 좌표 미확인 · 지도와 QuestieDB 확인 필요"
  end
  return false
 end
 if InCombatLockdown and InCombatLockdown() then
  pending={guide=true,open=openMap}
  G.navStatus="전투 종료 후 현재 통합 동선을 여정에 반영합니다."
  return false
 end
 local api=shortPathAPI()
 local stops,signature=routeStops(guide)
 if #stops==0 then return false end
 if api and type(api.NavigateRoute)=="function" then
  -- Avoid sending the same itinerary again on every map refresh, or movement.
  if not force and lastGuideSignature==signature and ownsJourney() then
   if openMap then G.OpenPointMap(navPoint) end
   return true
  end
  local ok,started=pcall(api.NavigateRoute,OWNER,stops)
  if ok and started then
   lastGuideSignature=signature
   clearLocalWaypoints()
   G.navStatus="여정에 통합 동선 적용: 현재 + 다음 "..tostring(#stops-1).."경유지 (수행/보고 전 대기)"
   if openMap then G.OpenPointMap(navPoint) end
   if G.RefreshMapPins then G.RefreshMapPins() end
   return true
  end
 end
 -- Older releases may only expose the single-stop API. Be explicit.
 local success=G.Navigate(navPoint,openMap)
 if success then
  lastGuideSignature=signature
  G.navStatus="외부 길찾기 구버전: 현재 경유지 1개만 안내 · 차례대로 갱신"
 end
 return success
end
-- One delayed repair per quest accept/turn-in, not a perpetual tug-of-war.
-- Other addons and manual waypoints keep control outside these quest events.
function G.ScheduleQuestJourneyRepair()
 if not G.db or not G.db.guide or not G.db.guide.steps or
    not G.db.guide.steps[G.db.guide.index or 1] then return end
 recoveryWait=1.6
 recoveryWindow=5
 recoveryBudget=2
end
function G.InitializeNavigationSubscription()
 if unsubscribeJourney then return end
 local api=shortPathAPI()
 if not api or type(api.Subscribe)~="function" then return end
 local ok,unsubscribe=pcall(api.Subscribe,function(changes)
  if recoveryWindow<=0 or recoveryBudget<=0 or type(changes)~="table" then return end
  if not (changes.changed or changes.started or changes.stop) then return end
  if ownsJourney() then return end
  local guide=G.db and G.db.guide
  if guide and guide.steps and guide.steps[guide.index or 1] then
   -- Defer instead of navigating synchronously inside ShortestPath's callback.
   recoveryWait=math.min(recoveryWait or .2,.2)
  end
 end)
 if ok and type(unsubscribe)=="function" then unsubscribeJourney=unsubscribe end
end
function G.TickQuestJourneyRepair(dt)
 dt=tonumber(dt) or 0
 if recoveryWindow>0 then recoveryWindow=math.max(0,recoveryWindow-dt) end
 if not recoveryWait then return end
 recoveryWait=recoveryWait-dt
 if recoveryWait>0 then return end
 recoveryWait=nil
 if recoveryWindow<=0 or recoveryBudget<=0 then return end
 local guide=G.db and G.db.guide
 if not guide or not guide.steps or not guide.steps[guide.index or 1] then return end
 local api=shortPathAPI()
 if not api or type(api.NavigateRoute)~="function" or ownsJourney() then return end
 recoveryBudget=recoveryBudget-1
 if G.NavigateGuideRoute(guide,false,true) then
  G.navStatus="퀘스트 변경 후 선택한 통합 동선을 여정에 다시 적용했습니다."
  if G.UIRefresh then G.UIRefresh() end
 end
end
function G.GuideNavigationInfo()
 local api=shortPathAPI()
 if not api then return "외부 여정 미설치" end
 if ownsJourney() then return "여정 동기화 · 통합 동선" end
 local j=type(api.Journey)=="function" and G.SafeCall(api.Journey)
 if j and j.owner and j.owner~=OWNER then
  return "여정이 다른 애드온에서 변경됨: "..tostring(j.owner).." · /fdq sync"
 end
 return "여정 연결 대기 · /fdq sync"
end

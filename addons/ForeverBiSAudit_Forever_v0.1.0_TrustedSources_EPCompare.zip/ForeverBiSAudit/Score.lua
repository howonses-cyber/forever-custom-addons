local _,B=...
-- This is a transparent partial-stat EP proxy, NOT a combat simulation.
-- WoW Forever ratings, dynamic enemy/zone procs, weapon DPS, enchants and sets
-- can change the actual outcome. No actual DPS+% is ever claimed.
local statByAPI={
 ITEM_MOD_STRENGTH_SHORT='str',ITEM_MOD_AGILITY_SHORT='agi',ITEM_MOD_STAMINA_SHORT='sta',
 ITEM_MOD_INTELLECT_SHORT='int',ITEM_MOD_SPIRIT_SHORT='spi',
 ITEM_MOD_ATTACK_POWER_SHORT='ap',ITEM_MOD_RANGED_ATTACK_POWER_SHORT='rap',
 ITEM_MOD_SPELL_POWER_SHORT='sp',ITEM_MOD_SPELL_DAMAGE_DONE_SHORT='sp',
 ITEM_MOD_SPELL_HEALING_DONE_SHORT='heal',ITEM_MOD_HEALING_DONE_SHORT='heal',
 ITEM_MOD_HIT_RATING_SHORT='hit',ITEM_MOD_HIT_PERCENT_SHORT='hit',
 ITEM_MOD_CRIT_RATING_SHORT='crit',ITEM_MOD_CRIT_PERCENT_SHORT='crit',
 ITEM_MOD_SPELL_HIT_RATING_SHORT='spellhit',ITEM_MOD_SPELL_HIT_PERCENT_SHORT='spellhit',
 ITEM_MOD_SPELL_CRIT_RATING_SHORT='spellcrit',ITEM_MOD_SPELL_CRIT_PERCENT_SHORT='spellcrit',
 ITEM_MOD_HASTE_RATING_SHORT='haste',ITEM_MOD_SPELL_HASTE_RATING_SHORT='haste',
 ITEM_MOD_EXPERTISE_RATING_SHORT='expertise',ITEM_MOD_DEFENSE_SKILL_RATING_SHORT='def',
 ITEM_MOD_DODGE_RATING_SHORT='dodge',ITEM_MOD_PARRY_RATING_SHORT='parry',
 ITEM_MOD_BLOCK_RATING_SHORT='block',ITEM_MOD_ARMOR_SHORT='armor',
 ITEM_MOD_MANA_REGENERATION_SHORT='mp5',ITEM_MOD_MANA_REGENERATION='mp5',
 ITEM_MOD_FROST_DAMAGE_SHORT='frost',ITEM_MOD_FIRE_DAMAGE_SHORT='fire',
 ITEM_MOD_SHADOW_DAMAGE_SHORT='shadow',ITEM_MOD_NATURE_DAMAGE_SHORT='nature',
}
B.statByAPI=statByAPI
function B:WeightedStats(stats,class,spec)
 if type(stats)~='table' then return nil,'스탯 로드 대기' end
 local weights=self:GetWeights(class,spec)
 local points,scored,count=0,0,0
 for raw,val in pairs(stats) do
  local key=statByAPI[raw]
  if key and type(val)=='number' then
   count=count+1
   local weight=weights[key]
   if weight and weight~=0 then points=points+val*weight;scored=scored+1 end
  end
 end
 if scored<1 then return nil,'가중치로 측정 가능한 스탯 없음' end
 return points,nil,{seen=count,scored=scored}
end
function B:ScoreItem(link,class,spec)
 if not link or not GetItemStats then return nil,'게임 아이템 스탯 미로드' end
 local ok,stats=pcall(GetItemStats,link)
 if not ok or type(stats)~='table' then return nil,'아이템 스탯 캐시 미로드' end
 return self:WeightedStats(stats,class,spec)
end
local staticSlot={INVTYPE_HEAD=1,INVTYPE_NECK=2,INVTYPE_SHOULDER=3,
 INVTYPE_CLOAK=15,INVTYPE_CHEST=5,INVTYPE_ROBE=5,INVTYPE_WRIST=9,
 INVTYPE_HAND=10,INVTYPE_WAIST=6,INVTYPE_LEGS=7,INVTYPE_FEET=8,
 INVTYPE_RANGED=18,INVTYPE_RANGEDRIGHT=18,INVTYPE_THROWN=18,INVTYPE_RELIC=18,
 INVTYPE_WEAPONMAINHAND=16,INVTYPE_WEAPONOFFHAND=17,INVTYPE_SHIELD=17,
 INVTYPE_HOLDABLE=17,INVTYPE_2HWEAPON=16,INVTYPE_WEAPON=16}
local slotToEquip={Head=1,Neck=2,Shoulder=3,Back=15,Chest=5,Wrist=9,
 Hands=10,Waist=6,Legs=7,Feet=8,Finger=11,Trinket=13,
 MainHand=16,OffHand=17,TwoHand=16,Ranged=18,Relic=18}
B.slotToEquip=slotToEquip
function B:ResolveEquipLocation(link)
 if not link or not GetItemInfo then return nil end
 local ok,a,b,c,d,e,f,g,h,loc=pcall(GetItemInfo,link)
 if ok and type(loc)=='string' and loc~='' then return loc end
 if GetItemInfoInstant then
  local success,_,_,_,il=pcall(GetItemInfoInstant,link)
  if success and type(il)=='string' then return il end
 end
 return nil
end
function B:ChooseEquipped(slot,link,class,spec)
 if not GetInventoryItemLink then return nil,'장착 장비 조회 불가' end
 local loc=self:ResolveEquipLocation(link)
 local ids={}
 if loc=='INVTYPE_FINGER' or slot=='Finger' then ids={11,12}
 elseif loc=='INVTYPE_TRINKET' or slot=='Trinket' then ids={13,14}
 elseif loc=='INVTYPE_2HWEAPON' or slot=='TwoHand' then ids={16,17}
 elseif loc=='INVTYPE_WEAPON' then ids={16} -- do NOT blindly compare a one-hander with offhand
 else ids={staticSlot[loc] or slotToEquip[slot]} end
 if not ids[1] then return nil,'장비 슬롯 식별 불가' end
 local selected,selectedScore,anyScore,anyItem=nil,nil,false,false
 for _,id in ipairs(ids) do
  local equipped=GetInventoryItemLink('player',id)
  if equipped then
   anyItem=true
   local score=self:ScoreItem(equipped,class,spec)
   if score~=nil then
    anyScore=true
    -- replace the worse ring or trinket; 2H uses sum (handled below)
    if not selected or score<selectedScore then selected,selectedScore=equipped,score end
   end
  end
 end
 if loc=='INVTYPE_2HWEAPON' or slot=='TwoHand' then
  local primary=GetInventoryItemLink('player',16)
  local second=GetInventoryItemLink('player',17)
  if not primary then return nil,'현재 무기 없음' end
  local total,err=self:ScoreItem(primary,class,spec)
  if not total then return nil,err end
  if second then
   local add,e=self:ScoreItem(second,class,spec)
   if not add then return nil,'보조장비 스탯 확인 불가' end
   total=total+add
  end
  return primary,nil,total
 end
 if selected then return selected,nil,selectedScore end
 return nil,anyItem and '현재 장비 스탯 미로드' or '해당 슬롯 미착용'
end
function B:Compare(link,class,spec,slot)
 local points,errorText=self:ScoreItem(link,class,spec)
 if points==nil then return nil,errorText end
 local eq,why,base=self:ChooseEquipped(slot,link,class,spec)
 if not eq or type(base)~='number' then return {candidate=points},why end
 if base<=0 then return {candidate=points,equipped=base},'기존 장비 점수가 0 이하; % 표기 보류' end
 local change=(points-base)/base*100
 if change>9999 or change < -1000 then return {candidate=points,equipped=base},'점수 이상치; % 표기 보류' end
 local loc=self:ResolveEquipLocation(link)
 local limited=(loc=='INVTYPE_2HWEAPON' or loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND' or loc=='INVTYPE_WEAPONOFFHAND' or loc=='INVTYPE_RANGED' or loc=='INVTYPE_RANGEDRIGHT' or loc=='INVTYPE_TRINKET' or slot=='Trinket' or slot=='TwoHand' or slot=='MainHand' or slot=='OffHand')
 return {candidate=points,equipped=base,change=change,limited=limited,compared=eq},nil
end
function B:FindLocalItem(name)
 if type(name)~='string' or not GetItemInfo then return nil end
 local ok,n,link=pcall(GetItemInfo,name)
 if ok and n and type(link)=='string' and link:find('item:',1,true) then return link end
 local id=self.ResolveItemID and self:ResolveItemID(name) or nil
 if id and id>0 then
  local itemString='item:'..tostring(id)
  local good,_,itemLink=pcall(GetItemInfo,itemString)
  if good and type(itemLink)=='string' and itemLink:find('item:',1,true) then return itemLink end
  if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID,id) end
 end
 return nil
end

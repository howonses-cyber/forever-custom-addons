local _,B=...
local initialized=false
local function AddInfo(tooltip)
 if not B.db or not B.db.showTooltip or not tooltip or not tooltip.GetItem then return end
 local ok,_,link=pcall(tooltip.GetItem,tooltip)
 if not ok or type(link)~='string' or not link:find('item:',1,true) then return end
 if tooltip._fbisLink==link then return end
 tooltip._fbisLink=link
 local class=UnitClass and select(2,UnitClass('player')) or B.db.class
 if not B.specs[class] then return end
 local loc=B:ResolveEquipLocation(link)
 local slot=({INVTYPE_FINGER='Finger',INVTYPE_TRINKET='Trinket',INVTYPE_2HWEAPON='TwoHand',INVTYPE_WEAPON='MainHand',INVTYPE_WEAPONMAINHAND='MainHand',INVTYPE_WEAPONOFFHAND='OffHand',INVTYPE_HOLDABLE='OffHand',INVTYPE_SHIELD='OffHand',INVTYPE_RANGED='Ranged',INVTYPE_RANGEDRIGHT='Ranged',INVTYPE_RELIC='Relic'})[loc]
 tooltip:AddLine('Forever BiS |cffb9e4ff가중 스탯점수 비교|r',1,.77,.28)
 local printed=0
 for _,sp in ipairs(B.specs[class]) do
  local c,reason=B:Compare(link,class,sp.key,slot)
  if c and c.change then
   local prefix=c.change>=0 and '+' or ''
   local suffix=c.limited and ' (무기/효과 제외)' or ''
   tooltip:AddDoubleLine(sp.label,prefix..string.format('%.1f',c.change)..'% EP'..suffix,1,1,1,c.change>=0 and .5 or 1,c.change>=0 and 1 or .5,.55)
   printed=printed+1
  elseif c and c.candidate then
   tooltip:AddDoubleLine(sp.label,string.format('%.1f EP',c.candidate)..' (비교 불가)',.8,.8,.9,.7,.7,.7)
   printed=printed+1
  end
 end
 if printed==0 then tooltip:AddLine('스탯 미캐시 또는 비교 가능한 장비가 없습니다.',.7,.7,.7) end
 tooltip:AddLine('※ 이 %는 DPS/힐량 증가율이 아닙니다.',1,.55,.43)
 tooltip:AddLine('세트·발동·적중캡·무기피해·전투 상황 제외.',.68,.75,.80)
 if tooltip.Show then tooltip:Show() end
end
function B:SetupTooltips()
 if initialized then return end
 initialized=true
 for _,tip in ipairs({GameTooltip,ItemRefTooltip,ShoppingTooltip1,ShoppingTooltip2}) do
  if tip and tip.HookScript then
   pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisLink=nil end)
   pcall(tip.HookScript,tip,'OnTooltipSetItem',function(self)AddInfo(self)end)
  end
 end
 if hooksecurefunc and GameTooltip then
  for _,method in ipairs({'SetBagItem','SetInventoryItem','SetHyperlink','SetLootItem','SetQuestItem','SetQuestLogItem','SetMerchantItem'}) do
   if type(GameTooltip[method])=='function' then
    pcall(hooksecurefunc,GameTooltip,method,function(self) AddInfo(self) end)
   end
  end
 end
end

local _,B=...
-- Optional, read-only QuestieDB ItemDB name -> itemID resolution.
-- Data is scanned incrementally, never editing QuestieDB or touching the game files.
local wanted,ids,cursor,frame={},nil,1,nil
local elapsed=0
B.itemIdByName={}
local function clean(s) return type(s)=='string' and string.lower((s:gsub('^%s+',''):gsub('%s+$',''))) or nil end
function B:StartItemIndex()
 if frame or not CreateFrame or type(ItemDB)~='table' or type(ItemDB.GetAllIds)~='function' then return end
 for _,entry in ipairs(self.catalog) do wanted[clean(entry.name)]=true end
 local ok,list=pcall(ItemDB.GetAllIds)
 if not ok or type(list)~='table' then return end
 ids=list;cursor=1
 frame=CreateFrame('Frame')
 frame:SetScript('OnUpdate',function(self,dt)
  elapsed=elapsed+(dt or .03)
  if elapsed<.06 then return end
  elapsed=0
  local batch=0
  while cursor<=#ids and batch<180 do
   local id=ids[cursor];cursor=cursor+1;batch=batch+1
   if type(id)=='number' and type(ItemDB.Get)=='function' then
    local valid,itemName=pcall(ItemDB.Get,id,'name')
    local key=valid and clean(itemName) or nil
    if key and wanted[key] and not B.itemIdByName[key] then B.itemIdByName[key]=id end
   end
  end
  if cursor>#ids then
   self:SetScript('OnUpdate',nil)
   if B.frame and B.frame:IsShown() and B.RefreshUI then B:RefreshUI() end
  end
 end)
end
function B:ResolveItemID(name)
 local key=clean(name)
 return key and B.itemIdByName[key] or nil
end

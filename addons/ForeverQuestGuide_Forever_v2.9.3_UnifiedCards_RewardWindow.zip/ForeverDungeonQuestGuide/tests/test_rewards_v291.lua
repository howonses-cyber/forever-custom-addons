-- Rewards use quest-ID game APIs when available. Unsupported/unknown rewards
-- stay unknown; never use the currently selected quest as a silent fallback.
local base=(arg and arg[1]) or './'
local G={selection={quest=91},uiRefreshes=0}
function G.IsInLog(id)return id==91 end
function G.KoreanName(_,id,name)return name end
local fromGame={}
GetNumQuestLogChoices=function(id)if id==91 then return 2 end end
GetQuestLogChoiceInfo=function(i,id)
 if id~=91 then return end
 return i==1 and '보상 방패' or '보상 반지','tex'..i,1,4,true,601+i
end
GetNumQuestLogRewards=function(id)if id==91 then return 1 end end
GetQuestLogRewardInfo=function(i,id)if id==91 then return '고정 약초','tex',4,2,true,666 end end
GetQuestLogRewardMoney=function(id)if id==91 then return 12345 end end
GetQuestLogRewardXP=function(id)if id==91 then return 6790 end end
HaveQuestRewardData=function(id)return id==91 end
local requested={}
C_QuestLog={RequestLoadQuestByID=function(id)requested[id]=(requested[id] or 0)+1 end}
local frame
CreateFrame=function()
 frame={events={}}
 function frame:RegisterEvent(e)self.events[e]=true end
 function frame:SetScript(which,fn)self[which]=fn end
 return frame
end
local checks=0
local function check(v,m)assert(v,m);checks=checks+1 end
assert(loadfile(base..'QuestRewards.lua'))('ForeverDungeonQuestGuide',G)
local info=G.QuestRewardInfo(91)
check(info.available and not info.reference,'actual game data is authoritative')
check(#info.choices==2 and info.choices[1].name=='보상 방패','two alternative rewards')
check(#info.fixed==1 and info.fixed[1].count==4,'fixed item quantity')
check(info.money==12345 and info.xp==6790,'money and xp supplied by the game')
check(G.QuestRewardBrief(info):find('선택 2종 중 1개',1,true)~=nil,'choice not falsely labeled all rewards')
local detail=table.concat(G.QuestRewardLines(info),'\n')
check(detail:find('보상 방패',1,true) and detail:find('보상 반지',1,true),'choice item names displayed')
check(detail:find('고정 약초',1,true) and detail:find('경험치: 6790',1,true),'fixed reward and XP displayed')
check(frame and frame.events.QUEST_DATA_LOAD_RESULT,'late reward data refresh listener installed')
local flame=G.QuestRewardInfo(4024)
check(flame.available and flame.reference,'4024 uses explicit source-labeled reference if client data unavailable')
check(#flame.choices==3 and flame.choices[1].id==12066 and flame.choices[3].id==12083,'reference carries three choice items')
check(flame.money==26500 and flame.xp==6200 and flame.referenceXP,'reference base XP and money labeled')
check(G.QuestRewardBrief(flame):find('자료 참고',1,true)~=nil,'external reference explicitly flagged')
local chain={3441,3442,3443,3452,3453,3454,3462,3463,3481,4022,4023,4024}
for _,id in ipairs(chain)do local r=G.QuestRewardInfo(id);check(r.available and r.reference and r.xp>0,'chain reward reference '..id) end
check(#G.QuestRewardInfo(3463).choices==4,'four source-listed choice rewards including Forever item')
check(G.QuestRewardInfo(3454).fixed[1].id==10515 and G.QuestRewardInfo(3481).fixed[1].id==10569,'chain fixed reward ids')
check(table.concat(G.QuestRewardLines(flame),'\n'):find('기준 경험치(자료)',1,true),'reference XP is not promised live XP')
HaveQuestRewardData=function(id)return id==91 or id==4024 end
check(G.QuestRewardInfo(4024).reference,'empty ready flag must not suppress sourced reference')
GetQuestLogRewardMoney=function(id)if id==91 then return 12345 elseif id==4024 then return 123 end end
local partial=G.QuestRewardInfo(4024)
check(partial.money==123 and not partial.reference and partial.referenceDetail and #partial.referenceDetail.choices==3,'partial live currency and distinct reference item choices')
GetQuestLogRewardMoney=function(id)if id==91 then return 12345 end end
G.db={}
local observed=G.QuestRewardInfo(91)
check(G.db.questRewardHistory[91] and #G.db.questRewardHistory[91].choices==2,'positive live rewards stored per character')

HaveQuestRewardData=function(id)return id==91 end
local absent=G.QuestRewardInfo(77777)
check(not absent.available and absent.pending and absent.reason:find('요청',1,true)~=nil,'unknown rewards stay unknown')
check(#absent.choices==0 and #absent.fixed==0 and not absent.money,'no invented rewards')
check(requested[77777]==1,'non-log quest loaded by explicit ID')
local again=G.QuestRewardInfo(77777)
check(requested[77777]==1,'repeat request suppressed while pending')
G.UIRefresh=function() G.uiRefreshes=G.uiRefreshes+1 end
frame.OnEvent(frame,'QUEST_DATA_LOAD_RESULT',77777,true)
check(G.uiRefreshes==0,'data event does not redraw unrelated selected quest')
G.QuestRewardInfo(77777)
check(requested[77777]==1,'successful quest load without rewards must not request forever')
G.selection.quest=77778
G.QuestRewardInfo(77778)
frame.OnEvent(frame,'QUEST_DATA_LOAD_RESULT',77778,false)
check(G.uiRefreshes==1,'failed relevant request clears loading and redraws')
G.RetryQuestReward(77778);G.QuestRewardInfo(77778)
check(requested[77778]==2,'explicit retry permitted after failure')
frame.OnEvent(frame,'QUEST_DATA_LOAD_RESULT',77778,true)
check(G.uiRefreshes==2,'successful relevant request refreshes')
GetNumQuestLogChoices=function(id)if id==77778 then return 1 end end
GetQuestLogChoiceInfo=function(i,id)if id==77778 then return 'loaded reward','tex',1,4,true,987 end end
check(G.QuestRewardInfo(77778).choices[1].id==987,'loaded non-log quest rewards by explicit ID even when HaveQuestRewardData false')
GetNumQuestLogChoices=function(id)if id==88888 then return 1 end end
GetQuestLogChoiceInfo=function(i,id)if id==88888 then return nil,nil,1,2,true,1234 end end
check(G.QuestRewardInfo(88888).choices[1].id==1234,'quest-ID data used even before readiness, unresolved item name retained')


check(G.QuestRewardBrief({available=false})=='보상 · 자료 확인 필요','no unsupported reward claim')
print('PASS V2.9.1 client rewards/choice/fixed/money/xp, reference provenance and unknown-state: '..checks..' assertions')

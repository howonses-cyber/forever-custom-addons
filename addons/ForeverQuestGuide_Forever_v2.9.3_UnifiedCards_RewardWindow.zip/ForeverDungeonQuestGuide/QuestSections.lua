local addon,G=...
-- View-only differentiation of single quests from verified chain containers.
-- A visible standalone card is not proof that it has no prerequisites elsewhere.
G.questSectionsVersion="2.9.3"
local function copy(e)
 local c={};for k,v in pairs(e) do c[k]=v end;return c
end
local function relationElsewhere(entry)
 if entry.hasPrerequisites then return true end
 local q=entry.id
 if G.NarrativeParents then
  local p=G.NarrativeParents(q)
  if type(p)=="table" and #p>0 then return true end
 end
 if G.NarrativeChildren then
  local p=G.NarrativeChildren(q)
  if type(p)=="table" and #p>0 then return true end
 end
 return false
end
function G.QuestListSeparateBlocks(rows,scope)
 if not G.db or G.db.groupChains==false then return rows end
 local out={};local pos=1;local section=0
 while pos<=#rows do
  local e=rows[pos]
  if e.kind=="quest" and not e.chainKey then
   local last=pos;local external=false
   while last<=#rows and rows[last].kind=="quest" and not rows[last].chainKey do
    if relationElsewhere(rows[last]) then external=true end
    last=last+1
   end
   section=section+1
   local key="individual:"..tostring(scope or "list")..":"..tostring(rows[pos].id)..":"..tostring(rows[last-1].id)
   out[#out+1]={kind="standaloneHeader",key=key,count=last-pos,external=external,label="개별 표시 퀘스트"}
   for i=pos,last-1 do
    local c=copy(rows[i]);c.singleSectionKey=key;c.singleSectionIndex=i-pos+1
    c.singleSectionCount=last-pos;c.relatedOutside=relationElsewhere(c)
    out[#out+1]=c
   end
   pos=last
  else
   out[#out+1]=e;pos=pos+1
  end
 end
 return out
end
function G.QuestVisibleAnchor(display,offset)
 local entry=display and display[(offset or 0)+1]
 if not entry then return nil end
 if entry.kind=="quest" then return {kind="quest",id=entry.id} end
 if entry.kind=="chain" then return {kind="chain",key=entry.key} end
 if entry.kind=="subchapter" then return {kind="subchapter",key=entry.key} end
 if entry.kind=="standaloneHeader" then return {kind="standaloneHeader",key=entry.key} end
 if entry.kind=="chainEnd" then return {kind="chainEnd",key=entry.key} end
 return nil
end
function G.QuestFindAnchor(display,anchor)
 if not anchor then return nil end
 for i,e in ipairs(display or {}) do
  if e.kind==anchor.kind and ((anchor.id and e.id==anchor.id) or (anchor.key and e.key==anchor.key)) then return i end
 end
 -- If a quest is now inside a collapsed chain, the visible header is its anchor.
 if anchor.kind=="quest" then
  for i,e in ipairs(display or {}) do
   if (e.kind=="chain" or e.kind=="subchapter") and e.collapsed then
    for _,id in ipairs(e.memberIds or {}) do if id==anchor.id then return i end end
   end
  end
 end
 return nil
end

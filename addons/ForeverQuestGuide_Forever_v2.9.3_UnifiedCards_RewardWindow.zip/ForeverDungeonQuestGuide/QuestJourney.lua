local addon,G=...
G.journeyVersion="2.9.3"
-- A read-only explanation of the existing quest/route state. This module never
-- marks a quest, a route step or a checkbox complete and never starts navigation.
local actionable={ready="accept",active="objective",turnin="turnin"}
local priority={turnin=1,active=2,ready=3,locked=4}
local function questId(first,second)
 local id=tonumber(first==G and second or first)
 if not id or id<=0 or id%1~=0 then return nil end
 return id
end
local function read(name,...)
 local fn=G[name]
 if type(fn)=="function" then return fn(...) end
end
local function label(id) return read("GetQuestName",id) or ("퀘스트 #"..tostring(id)) end
local function text(value)
 if type(value)~="string" then return nil end
 value=value:gsub("^%s+",""):gsub("%s+$","")
 if G.KoreanText then value=G.KoreanText(value) end
 return value~="" and value or nil
end
local function join(parts,separator)
 local out={}
 for _,v in ipairs(parts) do local localized=text(v);if localized then out[#out+1]=localized end end
 return table.concat(out,separator or " · ")
end
local function assessment(id)
 local state,code,reason,blocker=read("RouteAssessment",id)
 return state or "자료 확인 필요",code or "unknown",reason,blocker
end
local function stateFor(id,cache)
 if type(cache)=="table" and cache[id] then return cache[id] end
 local state,code,reason,blocker=assessment(id)
 local r={questId=id,state=state,code=code,reason=reason,blocker=blocker,
  phase=actionable[code] or (code=="done" and "done") or (code=="superseded" and "superseded") or "blocked"}
 if type(cache)=="table" then cache[id]=r end
 return r
end
-- Lightweight phase/count information for a fresh per-refresh cache. Avoid
-- looking up every NPC spawn and every objective when only a badge is needed.
function G.JourneyState(first,second,third)
 local id=questId(first,second);if not id then return nil end
 return stateFor(id,first==G and third or second)
end
local function validPoint(p)
 return type(p)=="table" and type(p.map)=="number" and p.map>0
  and type(p.x)=="number" and type(p.y)=="number"
  and p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function pointPlace(p)
 if not validPoint(p) then return nil end
 return (read("MapDisplayName",p.map) or ("지도 #"..p.map))
  ..string.format(" (%.1f, %.1f)",p.x*100,p.y*100)..(p.approx and " · 참고 위치" or "")
end
local function landmarkPlace(lm)
 if type(lm)~="table" then return nil end
 local where=join({lm.zone or "장소 미확인",lm.site or lm.target or ""})
 return where~="" and where or nil
end
local function contact(id,stage)
 -- For item-start quests the FIRST action is obtaining the item, not just
 -- clicking an item the player might not possess. Unknown bag state stays unknown.
 local item=stage=="accept" and read("QuestStartItemGuide",id)
 if item then
  return {name=item.name,kind="item",place=item.place,note=item.note,startItem=item,
   known=item.known,inside=item.inside}
 end
 local name,_,_,kind=read("QuestContactName",id,stage)
 local indoor=read("QuestInsideInfo",id,stage)
 local lm=read("QuestStageLandmark",id,stage)
 if indoor then
  return {name=indoor.npcName or name,kind=indoor.contactType or kind,
   place=join({indoor.dungeon or "던전",indoor.room or "던전 내부"}),
   note=indoor.instruction,inside=true,dungeonId=indoor.dungeonId,known=true}
 end
 local p=not lm and read("QuestPoint",id,stage)
 if not lm and not validPoint(p) then lm=read("QuestContactLandmark",id,stage) end
 if lm then
  return {name=name or lm.target or lm.site,kind=kind,place=landmarkPlace(lm),
   note=lm.instruction or lm.note,inside=lm.dungeonId~=nil,dungeonId=lm.dungeonId,
   known=text(lm.zone)~=nil and lm.zone~="시작 아이템"}
 end
 if validPoint(p) then return {name=p.name or name,kind=kind,place=pointPlace(p),point=p,known=true} end
 return {name=name,kind=kind,place="실제 방문 위치 미확인",known=false}
end
local function objectiveGoal(id)
 local journal=read("LiveQuestNarrative",id)
 local goal=journal and text(journal.objective) or nil
 goal=goal or text(read("QuestObjectiveText",id))
 if not goal then
  local record=G.walkthroughRecords and G.walkthroughRecords[id]
  local steps={}
  for _,line in ipairs(record and record.objective or {}) do if text(line) then steps[#steps+1]=line end end
  if #steps>0 then goal=table.concat(steps,"\n") end
 end
 return goal or "퀘스트 창의 목표와 필요한 수량을 확인하세요. 수행 방법 자료가 아직 없습니다."
end
local function objectivePlace(id)
 local indoor=read("QuestInsideInfo",id,"objective")
 if indoor then return {place=join({indoor.dungeon or "던전",indoor.room or "던전 내부"}),note=indoor.instruction,inside=true,dungeonId=indoor.dungeonId,known=true} end
 local lm=read("QuestStageLandmark",id,"objective")
 if lm then return {place=landmarkPlace(lm),note=lm.instruction or lm.note,inside=lm.dungeonId~=nil,dungeonId=lm.dungeonId,known=text(lm.zone)~=nil} end
 local points=read("QuestObjectivePoints",id) or {}
 local places,seen={},{}
 local first,hasUnknown
 for _,obj in ipairs(points) do
  local place=pointPlace(obj.point) or landmarkPlace(obj.landmark)
  if place then
   if not seen[place] then seen[place]=true;places[#places+1]=place end
   first=first or {place=place,point=validPoint(obj.point) and obj.point or nil,
    note=obj.landmark and (obj.landmark.instruction or obj.landmark.note),
    dungeonId=obj.landmark and obj.landmark.dungeonId,
    inside=obj.landmark and obj.landmark.dungeonId~=nil,known=true}
  else hasUnknown=true end
 end
 if #places>0 then
  first.place=table.concat(places," / ")..(hasUnknown and " / 일부 목표 위치 미확인" or "")
  -- Several objectives cannot be presented as one single precise destination.
  if #places>1 or hasUnknown then first.point=nil;first.note=nil;first.multiple=true end
  return first
 end
 lm=read("QuestEventLandmark",id)
 if lm then return {place=landmarkPlace(lm),note=lm.instruction or lm.note,inside=lm.dungeonId~=nil,dungeonId=lm.dungeonId,known=text(lm.zone)~=nil} end
 local p=read("QuestPoint",id,"objective")
 if validPoint(p) then return {place=pointPlace(p),point=p,known=true} end
 -- The quest's list category is not evidence of where its objective is located.
 return {place="목표 위치 미확인 · 퀘스트 설명 확인",known=false}
end
local function contactAction(info,stage)
 local name=info.name
 if stage=="accept" then
  if info.kind=="item" then
   if info.startItem then return info.startItem.verb,info.startItem.action end
   return "시작 아이템 사용",name and ("가방에서 ‘"..name.."’을 사용해 퀘스트를 받으세요.") or "가방의 시작 아이템을 확인하고 사용하세요."
  end
  if info.kind=="object" then return "퀘스트 받기",name and ("‘"..name.."’와 상호작용해 퀘스트를 받으세요.") or "시작 대상을 확인해 퀘스트를 받으세요." end
  return "퀘스트 받기",name and (name.."에게 말을 걸어 퀘스트를 받으세요.") or "수락 대상 자료를 확인한 뒤 퀘스트를 받으세요."
 end
 if info.kind=="object" then return "완료 보고",name and ("‘"..name.."’와 상호작용해 퀘스트를 보고하세요.") or "보고 대상을 확인해 퀘스트를 보고하세요." end
 return "완료 보고",name and (name.."에게 말을 걸어 퀘스트를 보고하고 보상을 받으세요.") or "보고 대상 자료를 확인하고 퀘스트를 보고하세요."
end
local function effectiveAction(id,code)
 local phase=actionable[code]
 local info=phase=="objective" and objectivePlace(id) or contact(id,phase)
 local verb,detail
 if phase=="objective" then verb="목표 수행";detail=objectiveGoal(id)
 else verb,detail=contactAction(info,phase) end
 local nextText=phase=="accept" and "퀘스트를 받으면 ‘목표 수행’ 단계로 바뀝니다."
  or phase=="objective" and "목표를 채우면 ‘완료 보고’로 바뀝니다. 보고해야 퀘스트가 끝납니다."
  or "실제로 보고하고 보상을 받으면 ‘보고 완료’로 바뀝니다."
 if phase=="accept" and G.specialQuestMeta and G.specialQuestMeta[id] and G.specialQuestMeta[id].directTurnin then
  nextText="퀘스트를 받은 뒤 보고할 대상으로 이동하세요. 실제 퀘스트 창의 보고 가능 표시를 확인합니다."
 end
 if info.note and not detail:find(info.note,1,true) then detail=detail.."\n"..info.note end
 if info.startItem and info.startItem.sourceText and not detail:find(info.startItem.sourceText,1,true) then
  detail=detail.."\n획득처: "..info.startItem.sourceText
 end
 if G.KoreanText then detail=G.KoreanText(detail) end
 if info.inside then nextText=nextText.." 대상은 던전 안에 있습니다. 지도 입구 표시와 구분하세요." end
 if phase=="turnin" and G.QuestFollowupHint then
  local following=G.QuestFollowupHint(id)
  if following then
   nextText=nextText.." 후속: "..following.name.." · 현재 퀘스트를 실제로 보고한 다음 "
    ..(following.sameContact and "같은 NPC에게서 수락 가능한지 확인하세요." or "시작 대상과 수락 조건을 확인하세요.")
  end
 end
 if G.QuestSpecialInstruction then
  local special=G.QuestSpecialInstruction(id)
  if special and not detail:find(special,1,true) then detail=detail.."\n"..special end
 end
 return {actionQuestId=id,actionCode=code,actionPhase=phase,phase=phase,verb=verb,title=verb.." · "..label(id),
  location=info.place or "위치 미확인",detail=detail,nextText=nextText,canGuide=true,
  contactStage=phase~="objective" and phase or nil,locationKnown=info.known==true,
  inside=info.inside==true,dungeonId=info.dungeonId,point=info.point}
end
local function nextPrerequisite(id,states)
 local graph=read("ResolveRouteRequirements",id,{})
 if type(graph)~="table" or type(graph[id])~="table" then return nil end
 local best,bestCode
 -- Use only the route solver's chosen branch. Never choose an arbitrary entry
 -- from preQuestSingle, and never treat the display order as a dependency.
 for candidate,parents in pairs(graph) do
  candidate=tonumber(candidate)
  if candidate and candidate~=id and type(parents)=="table" and next(parents)==nil then
   local code=stateFor(candidate,states).code
   if actionable[code] and (not best or priority[code]<priority[bestCode]
      or (priority[code]==priority[bestCode] and candidate<best)) then best=candidate;bestCode=code end
  end
 end
 return best,bestCode
end
function G.QuestJourney(first,second,third)
 local id=questId(first,second)
 if not id then return nil end
 local states=first==G and third or second
 local current=stateFor(id,states)
 local state,code,reason,blocker=current.state,current.code,current.reason,current.blocker
 local r={questId=id,actionQuestId=id,code=code,actionCode=code,state=state,
  phase="blocked",verb="조건 확인",title="진행 조건 확인",location="진행 장소 확인 전",
  detail=reason or state,nextText="아래 진행 조건을 먼저 확인하세요.",canGuide=false,blocker=blocker}
 if actionable[code] then
  local action=effectiveAction(id,code);for key,value in pairs(action) do r[key]=value end
 elseif code=="locked" then
  local pre,preCode=nextPrerequisite(id,states)
  if pre then
   local action=effectiveAction(pre,preCode);for key,value in pairs(action) do r[key]=value end
   r.phase="blocked";r.prerequisite=true;r.verb="선행 · "..action.verb
   r.title="먼저: "..label(pre).." · "..action.verb
   r.detail=action.detail.."\n‘"..label(id).."’보다 먼저 필요한 퀘스트입니다."
   r.nextText="선행 퀘스트를 보고한 뒤 남은 조건을 이어서 확인합니다. ‘이 퀘스트 안내’는 필요한 선행을 함께 안내합니다."
  else
   r.verb="선행 확인";r.title="먼저 필요한 퀘스트 확인"
   r.detail=reason or "진행 가능한 선행 경로를 확인하지 못했습니다. 아래 선행 조건을 확인하세요."
  end
 elseif code=="done" then
  r.phase="done";r.verb="보고 완료";r.title="보고와 보상 수령 완료"
  r.location="다음 퀘스트를 선택하세요.";r.detail="게임에서 이 퀘스트의 보고 완료가 확인됐습니다."
  r.nextText="연계에 남은 퀘스트가 있으면 다음 진행 대상을 확인하세요."
 elseif code=="superseded" then
  r.phase="superseded";r.verb="지나간 단계";r.title="현재 진행에서 다시 받지 않는 단계"
  r.location="후속 퀘스트를 확인하세요."
  r.detail=read("RouteExclusionReason",id) or "후속 퀘스트 진행으로 이 단계가 현재 동선에서 제외됐습니다."
  r.nextText="실제 보고 완료 기록과 구분하여 표시합니다. 후속 퀘스트를 계속 진행하세요."
 elseif code=="low" then
  r.verb="레벨 필요";r.title="레벨 조건부터 충족하세요."
  local minimum=tonumber(read("GetQuestMinLevel",id));local level=G.player and tonumber(G.player.level)
  if minimum and minimum>0 and level then
   r.detail="수락 최소 "..minimum.."레벨 · 현재 "..level.."레벨"..(minimum>level and (" · "..(minimum-level).."레벨 더 필요") or "")
   if reason and reason~="" then r.detail=r.detail.."\n"..reason end
  end
  r.nextText="현재 진행할 수 있는 다른 퀘스트로 레벨을 올린 뒤 다시 확인하세요."
 elseif code=="deferred" then
  r.verb="보류 중";r.title="보류한 퀘스트"
  r.detail="사용자가 잠시 미룬 퀘스트입니다. 게임에서 완료한 것으로 처리하지 않습니다."
  r.nextText="다시 진행하려면 ‘보류 해제’를 누르세요."
 elseif code=="dependentDeferred" then
  r.verb="선행 보류";r.title="먼저 필요한 퀘스트가 보류 중"
  r.detail=reason or state;r.nextText="선행 퀘스트의 보류를 해제한 뒤 안내를 시작하세요."
 elseif code=="unknown" then
  r.verb="자료 확인";r.title="진행 자료 확인 필요"
  r.detail=reason or "이 퀘스트의 진행 조건을 확인할 자료가 부족합니다."
  r.nextText="퀘스트 자료 애드온의 로드 상태와 실제 퀘스트 창을 확인하세요."
 else
  r.verb="조건 확인";r.title="진행을 막는 조건 확인"
  r.detail=reason or state;r.nextText="아래 조건을 확인한 뒤 진행 가능한 퀘스트를 선택하세요."
 end
 return r
end
function G.JourneySummary(first,second,third,fourth)
 local ids=first==G and second or first
 local cache=first==G and third or second
 if type(cache)~="table" then cache={} end
 local states=first==G and fourth or third
 if type(states)~="table" then states={} end
 local counts={accept=0,objective=0,turnin=0,blocked=0,done=0,superseded=0,deferred=0,prerequisite=0}
 local result={total=0,counts=counts,nextQuestId=nil,nextAction=nil,allDone=false}
 local seen,candidates={},{}
 for _,raw in ipairs(type(ids)=="table" and ids or {}) do
  local id=questId(raw)
  if id and not seen[id] then
   seen[id]=true;result.total=result.total+1
   local current=cache[id] or stateFor(id,states)
   local code=current.code
   local phase=actionable[code] or (code=="done" and "done") or (code=="superseded" and "superseded") or "blocked"
   counts[phase]=counts[phase]+1
   if code=="deferred" or code=="dependentDeferred" then counts.deferred=counts.deferred+1 end
   if code=="locked" then counts.prerequisite=counts.prerequisite+1 end
   if priority[code] then candidates[#candidates+1]={id=id,rank=priority[code]} end
  end
 end
 table.sort(candidates,function(a,b)if a.rank~=b.rank then return a.rank<b.rank end;return a.id<b.id end)
 for _,candidate in ipairs(candidates) do
  local id=candidate.id
  local journey=cache[id] or G.QuestJourney(id,states);cache[id]=journey
  if journey.canGuide then result.nextQuestId=id;result.nextAction=journey;break end
 end
 result.allDone=result.total>0 and counts.done==result.total
 result.orderNote="표시 우선순위: 완료 보고 → 진행 중 → 새로 받기 → 선행 준비"
 return result
end
function G.JourneyDetailLines(first,second)
 local id=questId(first,second)
 if not id then return {} end
 local r=G.QuestJourney(id)
 local start,finish=contact(id,"accept"),contact(id,"turnin")
 local _,startText=contactAction(start,"accept");local _,finishText=contactAction(finish,"turnin")
 local goal=objectivePlace(id)
 local lines={"지금 할 일: "..r.title,"장소: "..r.location,r.detail,"다음: "..r.nextText,"",
  "이 퀘스트를 진행하는 순서",
  "1. 받기 · "..startText,"   장소: "..(start.place or "미확인"),
  "2. 목표 수행 · "..objectiveGoal(id),"   장소: "..(goal.place or "미확인"),
  "3. 보고 · "..finishText,"   장소: "..(finish.place or "미확인"),
  "목표를 채운 상태와 보고를 마친 상태는 다릅니다. 보상을 받아야 끝납니다."}
 -- Evidence-aware spawn candidates: do not send navigation to any of these.
 if G.QuestVisitCandidates then
  for _,stage in ipairs({"accept","objective","turnin"}) do
   local points,total=G.QuestVisitCandidates(id,stage,3)
   if total>1 then
    local stageName=stage=="accept" and "받는 곳" or stage=="turnin" and "보고하는 곳" or "목표"
    lines[#lines+1]=""
    lines[#lines+1]=stageName.." · 출현 후보 "..total.."곳 (자료 기반, 실제 위치·길찾기 확정 아님)"
    for _,p in ipairs(points) do
     lines[#lines+1]="   · "..(G.MapDisplayName and G.MapDisplayName(p.map) or ("지도 #"..p.map))
      ..string.format(" (%.1f, %.1f)",p.x*100,p.y*100).." · "..p.name
    end
    if total>#points then lines[#lines+1]="   · 그 밖의 후보 "..(total-#points).."곳은 생략" end
   end
  end
 end
 if G.QuestFollowupHint then
  local f=G.QuestFollowupHint(id)
  if f then
   lines[#lines+1]=""
   lines[#lines+1]="4. 이어서 · "..f.name.." (#"..f.id..")"
   lines[#lines+1]="   "..f.state
   if f.sameContact then lines[#lines+1]="   이전 퀘스트를 보고한 뒤, 던전을 떠나기 전에 같은 NPC에게 다시 말을 걸어 보세요." end
   lines[#lines+1]="   연계 근거: "..f.source.." · 수락 가능 여부는 실제 게임에서 확인"
  end
 end
 if G.QuestSpecialInstruction then
  local special=G.QuestSpecialInstruction(id)
  if special then lines[#lines+1]="";lines[#lines+1]="특수 진행: "..special end
 end
 if r.prerequisite then
  lines[#lines+1]=""
  lines[#lines+1]="선행 퀘스트: 먼저 해야 이 퀘스트를 받을 수 있는 일입니다."
  lines[#lines+1]="지금 진행할 선행: "..label(r.actionQuestId).." · "..r.location
 end
 return lines
end

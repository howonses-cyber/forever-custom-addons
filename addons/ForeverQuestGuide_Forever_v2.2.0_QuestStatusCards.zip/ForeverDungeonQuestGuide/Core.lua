local addon, G = ...
_G.ForeverDungeonQuestGuide = G
G.addon=addon
G.version="2.2.0"
G.displayName="포에버 퀘스트 가이드"
G.db={}
G.selection={dungeon=nil,quest=nil,mode="all"}
G.player={faction=nil,classId=0,level=1}
G.activeQuests={}
G.sessionTurnins={}
G.nameCache={}
G.pendingRefresh=false
G.API={}
function G.Print(msg)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffd9b565["..G.displayName.."]|r "..tostring(msg)) end
end
function G.Clean(s)
 return string.lower(tostring(s or "")):gsub("[%s%p%c]","")
end
function G.SafeCall(fn,...)
 if type(fn)~="function" then return nil end
 local ok,result=pcall(fn,...)
 if ok then return result end
 return nil
end
function G.VersionReport()
 local metadata=G.SafeCall(C_AddOns and C_AddOns.GetAddOnMetadata,G.addon,"Version") or G.SafeCall(GetAddOnMetadata,G.addon,"Version")
 local lines={G.displayName.." 버전 확인", "실행 코드: "..G.version,
  "목록 화면: "..tostring(G.uiVersion or "확인 필요"),
  "연계 표시: "..tostring(G.chainVersion or "확인 필요"),
  "행동 안내: "..tostring(G.journeyVersion or "확인 필요"),
  "상태 표시: "..tostring(G.statusVersion or "확인 필요"),
  "설치 정보: "..tostring(metadata or "클라이언트에서 확인 불가")}
 local mismatch=(metadata and metadata~=G.version) or G.uiVersion~=G.version or G.chainVersion~=G.version or G.journeyVersion~=G.version or G.statusVersion~=G.version
 if mismatch then lines[#lines+1]="일부 파일 버전이 일치하지 않습니다. 관리툴에서 이 애드온을 적용한 뒤 게임을 완전히 종료하고 다시 실행하세요."
 else lines[#lines+1]="실행 중인 가이드 파일의 버전이 일치합니다." end
 lines[#lines+1]="이전 화면이 보이면 실제 실행한 게임 폴더에 설치했는지도 확인하세요."
 return table.concat(lines,"\n"),mismatch==true
end
function G.GetDungeon(id) return G.dungeonById and G.dungeonById[id] end
function G.PlayerRefresh()
 local value=UnitFactionGroup and UnitFactionGroup("player")
 -- Never silently assign Alliance when the client has not supplied a faction.
 if value=="Alliance" or value=="Horde" then G.player.faction=value else G.player.faction=nil end
 local classToken,classID
 if type(UnitClass)=="function" then
  local _,token,numericId=UnitClass("player")
  classToken,classID=token,numericId
 end
 if not classID then
  local classes={WARRIOR=1,PALADIN=2,HUNTER=3,ROGUE=4,PRIEST=5,DEATHKNIGHT=6,SHAMAN=7,MAGE=8,WARLOCK=9,MONK=10,DRUID=11}
  classID=classes[classToken] or 0
 end
 G.player.classId=classID or 0
 G.player.level=UnitLevel and (UnitLevel("player") or 1) or 1
end
function G.Ready() return type(QuestDB)=="table" and type(QuestDB.Get)=="function" end
function G.StartSaved()
 if type(ForeverDungeonQuestGuideDB)~="table" then ForeverDungeonQuestGuideDB={} end
 G.db=ForeverDungeonQuestGuideDB
 if G.db.hideUnavailable==nil then G.db.hideUnavailable=true end
 if G.db.onlyIncomplete==nil then G.db.onlyIncomplete=false end
 if G.db.openOnLogin==nil then G.db.openOnLogin=false end
 -- Only our route overlay. Questie, the game, and Shortest Path own their pins.
 if not ({auto=true,current=true,next=true,off=true})[G.db.mapPinMode] then G.db.mapPinMode="auto" end
 G.db.manualProgress=G.db.manualProgress or {}
 -- Postponement is not game completion: keep checked quests and their real flags.
 if type(G.db.deferredQuests)~="table" then G.db.deferredQuests={} end
 if G.db.hudCollapsed==nil then G.db.hudCollapsed=false end
 -- Keep the in-world guide's own visual preferences separate from other addons.
 if type(G.db.hudSize)~="table" then G.db.hudSize={width=460,height=455} end
 local size=G.db.hudSize
 size.width=math.min(760,math.max(420,tonumber(size.width) or 460))
 size.height=math.min(700,math.max(360,tonumber(size.height) or 455))
 G.db.hudTextSize=math.min(17,math.max(10,math.floor(tonumber(G.db.hudTextSize) or 12)))
 G.db.hudOpacity=math.min(1,math.max(.15,tonumber(G.db.hudOpacity) or .95))
 G.db.selectedQuests=G.db.selectedQuests or {}
 if G.db.groupChains==nil then G.db.groupChains=true end
 if type(G.db.chainCollapsed)~="table" then G.db.chainCollapsed={} end
 -- Separate browsing preferences from the actual playable faction used by routes.
 if not ({auto=true,Alliance=true,Horde=true,all=true})[G.db.factionFilter] then
  G.db.factionFilter="auto"
 end
 G.db.viewMode=G.db.viewMode or "active"
 if G.db.viewMode=="region" then G.db.viewMode="zone" end
 G.db.selectedZone=tonumber(G.db.selectedZone)
 G.db.position=G.db.position or {}
 G.db.selectedDungeon=G.db.selectedDungeon or "sunken"
 G.db.guide=G.db.guide or {}
 -- SavedVariablesPerCharacter: never import another character's active route.
 local saved=G.db.suspendedGuide
 if saved~=nil and (type(saved)~="table" or type(saved.guide)~="table" or type(saved.guide.steps)~="table" or type(saved.manualProgress)~="table") then G.db.suspendedGuide=nil end
 G.selection.zone=G.db.selectedZone
 G.selection.dungeon=G.db.selectedDungeon
 G.selection.quest=G.db.selectedQuest
 G.selection.mode=G.db.viewMode
end
-- Quest objective completion (ready to report) and rewarded completion are
-- different states. QuestieDB/Questie and the Blizzard client can update on
-- separate events, so consult the questID API instead of trusting one raw
-- GetQuestLogTitle return. Never interpret a quest rewarded in the past as a
-- currently reportable quest.
local function truth(value) return value==true or value==1 end
local function questIsReady(id,logIndex,titleFlag)
 if truth(titleFlag) then return true,"quest-log" end
 local function query(fn)
  if type(fn)~="function" then return nil end
  local ok,v=pcall(fn,id)
  if ok and v~=nil then return truth(v) end
  return nil
 end
 local apiReady=query(C_QuestLog and C_QuestLog.IsComplete)
 if apiReady==true then return true,"client" end
 local legacyReady=query(IsQuestComplete)
 if legacyReady==true then return true,"client" end
 -- Some Forever builds use the Questie cache to drive the objective tracker.
 -- QuestieDB.IsComplete returns 1 for a finished quest in the ACTIVE log.
 if QuestieDB and type(QuestieDB.IsComplete)=="function" then
  local ok,value=pcall(QuestieDB.IsComplete,id)
  if ok and truth(value) then return true,"questie" end
 end
 -- Read objectives as a conservative fallback only if no authoritative API
 -- explicitly reports incomplete. A quest with no objectives is NOT deemed
 -- complete merely because an empty list was returned.
 if apiReady==nil and legacyReady==nil then
  if C_QuestLog and type(C_QuestLog.GetQuestObjectives)=="function" then
   local ok,objectives=pcall(C_QuestLog.GetQuestObjectives,id)
   if ok and type(objectives)=="table" and #objectives>0 then
    local all=true
    for _,objective in ipairs(objectives) do
     if type(objective)~="table" or not truth(objective.finished) then all=false;break end
    end
    if all then return true,"objectives" end
   end
  end
  if type(GetNumQuestLeaderBoards)=="function" and type(GetQuestLogLeaderBoard)=="function" then
   local ok,n=pcall(GetNumQuestLeaderBoards,logIndex)
   if ok and type(n)=="number" and n>0 then
    local all=true
    for i=1,n do
     local worked,_,_,finished=pcall(GetQuestLogLeaderBoard,i,logIndex)
     if not worked or not truth(finished) then all=false;break end
    end
    if all then return true,"objectives" end
   end
  end
 end
 return false,"log"
end
function G.RefreshQuestLog()
 local previous=G.activeQuests
 local updated={}
 local num=G.SafeCall(GetNumQuestLogEntries) or (C_QuestLog and G.SafeCall(C_QuestLog.GetNumQuestLogEntries)) or 0
 local currentHeader=nil
 for i=1,num do
  local title,level,suggested,isHeader,isCollapsed,isComplete,frequency,questID
  if type(GetQuestLogTitle)=="function" then
   title,level,suggested,isHeader,isCollapsed,isComplete,frequency,questID=GetQuestLogTitle(i)
  end
  if C_QuestLog and type(C_QuestLog.GetInfo)=="function" then
   local info=G.SafeCall(C_QuestLog.GetInfo,i)
   if type(info)=="table" then
    questID=info.questID or questID
    title=info.title or title
    level=info.level or level
    if info.isHeader~=nil then isHeader=info.isHeader end
    -- A false/lagging GetInfo field must not erase a positive title flag.
    if info.isComplete~=nil and not truth(isComplete) then isComplete=info.isComplete end
   end
  end
  if isHeader then currentHeader=title end
  if not isHeader then
   local id=tonumber(questID)
   if (not id or id<=0) and C_QuestLog and C_QuestLog.GetQuestIDForLogIndex then
    id=tonumber(G.SafeCall(C_QuestLog.GetQuestIDForLogIndex,i))
   end
   if id and id>0 then
    local ready,source=questIsReady(id,i,isComplete)
    updated[id]={title=title,complete=ready,source=source,logIndex=i,level=tonumber(level),header=currentHeader}
   end
  end
 end
 local changed=false
 for id,value in pairs(updated) do
  local old=previous[id]
  if not old or old.complete~=value.complete or old.title~=value.title then changed=true;break end
 end
 if not changed then for id in pairs(previous) do if not updated[id] then changed=true;break end end end
 G.activeQuests=updated
 -- Partial objective changes must repaint the list even before a quest becomes
 -- ready to report. Keep this separate from route changes: collecting 2/10
 -- instead of 1/10 should not restart navigation or rebuild a selected route.
 local progressChanged=false
 if G.QuestProgressSignature then
  for id,value in pairs(updated) do
   value.progressSignature=G.QuestProgressSignature(id,value.logIndex)
   local old=previous[id]
   if not old or old.progressSignature~=value.progressSignature then progressChanged=true end
  end
 end
 if G.RefreshRouteEvidence and G.RefreshRouteEvidence() then changed=true end
 -- Previous selected quests are not the current quest log. Preserve their
 -- completion status in the full regional/dungeon catalogs, but never keep
 -- rewarded quests in a live route selection.
 if G.db and type(G.db.selectedQuests)=="table" then
  for id,chosen in pairs(G.db.selectedQuests) do
   if chosen and G.IsCompleted(tonumber(id)) then
    G.db.selectedQuests[id]=nil
    changed=true
   end
  end
 end
 -- Clean only actual rewarded postponements; never mistake a skipped or
 -- deferred guide step for a completed quest.
 if G.db and type(G.db.deferredQuests)=="table" then
  for id,yes in pairs(G.db.deferredQuests) do
   if yes and G.IsCompleted(tonumber(id)) then G.db.deferredQuests[id]=nil;changed=true end
  end
 end
 return changed,progressChanged
end
-- A successful QUEST_TURNED_IN event is a same-session bridge until the
-- rewarded flag is refreshed by the server. It does not modify WTF/Questie.
function G.MarkQuestTurnedIn(id)
 id=tonumber(id)
 if id and id>0 then G.sessionTurnins[id]=true end
end
function G.MarkQuestAccepted(id)
 id=tonumber(id)
 if id and id>0 then G.sessionTurnins[id]=nil end
end
function G.IsCompleted(id)
 id=tonumber(id)
 if not id or id<=0 then return false end
 if G.IsInLog(id) then return false end
 if G.sessionTurnins[id] then return true end
 if C_QuestLog and type(C_QuestLog.IsQuestFlaggedCompleted)=="function" then
  local ok,done=pcall(C_QuestLog.IsQuestFlaggedCompleted,id)
  if ok and done~=nil then return truth(done) end
 end
 if type(IsQuestFlaggedCompleted)=="function" then
  local ok,done=pcall(IsQuestFlaggedCompleted,id)
  if ok and done~=nil then return truth(done) end
 end
 local q=Questie and Questie.db and Questie.db.char
 return q and q.complete and q.complete[id]==true or false
end
-- Only actively accepted quests belong to the live quest-log tab.
function G.IsInLog(id)
 id=tonumber(id)
 if not id or id<=0 then return false end
 if G.activeQuests[id] then return true end
 -- Direct quest-ID lookup also covers a temporarily incomplete/collapsed log.
 if truth(G.SafeCall(C_QuestLog and C_QuestLog.IsOnQuest,id)) then return true end
 local index=tonumber(G.SafeCall(C_QuestLog and C_QuestLog.GetLogIndexForQuestID,id))
 return index~=nil and index>0
end
function G.IsReadyToTurnIn(id)
 id=tonumber(id)
 if not id or not G.IsInLog(id) then return false end
 if G.activeQuests[id] and G.activeQuests[id].complete then return true end
 return truth(G.SafeCall(C_QuestLog and C_QuestLog.IsComplete,id)) or
        truth(G.SafeCall(IsQuestComplete,id)) or truth(G.SafeCall(QuestieDB and QuestieDB.IsComplete,id))
end
function G.QuestState(id)
 if G.IsInLog(id) then
  if G.IsReadyToTurnIn(id) then return "보고 대기","turnin" end
  return "진행 중","active"
 end
 if G.IsCompleted(id) then return "완료","done" end
 if not G.Ready() then return "퀘스트 자료 연결 필요","unknown" end
 if G.RouteExclusionReason and G.RouteExclusionReason(id) then return "연계 진행 · 동선 제외","superseded" end
 local reason,code
 if G.RouteHardBlock then reason,code=G.RouteHardBlock(id) end
 if reason then return reason,code or "blocked" end
 local prereq=G.GetMissingPrereqs and G.GetMissingPrereqs(id) or {}
 if #prereq>0 then return "선행 필요","locked" end
 return "미수락","ready"
end
function G.SearchDungeons(text)
 local needle=G.Clean(text); local list={}
 local function hasVisibleQuests(d)
  if not G.DungeonMatchesFactionFilter(d) then return false end
  for _,id in ipairs(d.ids or {}) do
   if G.QuestMatchesFactionFilter(id) then return true end
  end
  return #d.ids==0 -- Preserve unindexed instance categories for discovery.
 end
 for _,d in ipairs(G.dungeons) do
  local hit=(needle=="" or string.find(G.Clean(d.name),needle,1,true) or string.find(G.Clean(d.aliases),needle,1,true))
  local questHit
  if not hit and needle~="" then
   for _,id in ipairs(d.ids) do
    if G.QuestMatchesFactionFilter(id) and
       (string.find(G.Clean(G.GetQuestName(id)),needle,1,true) or string.find(G.Clean((G.DBRawGet or G.DBGet)(QuestDB,id,"name")),needle,1,true) or tostring(id)==needle) then
     questHit=id;break
    end
   end
  end
  if (hit or questHit) and hasVisibleQuests(d) then list[#list+1]={dungeon=d,matchedQuest=questHit} end
 end
 return list
end
function G.SetZone(id)
 id=tonumber(id)
 if not id or not G.questIndex or not G.questIndex.zones or not G.questIndex.zones[id] then return false end
 G.selection.zone=id
 G.selection.quest=nil
 G.selection.mode="zone"
 G.db.selectedZone=id
 G.db.selectedQuest=nil
 G.db.viewMode="zone"
 if G.UIRefresh then G.UIRefresh() end
 return true
end
function G.SetDungeon(id)
 local d=G.GetDungeon(id);if not d then return end
 G.selection.dungeon=id;G.selection.quest=nil
 G.selection.mode="dungeon";G.db.viewMode="dungeon"
 G.db.selectedDungeon=id;G.db.selectedQuest=nil
 if G.UIRefresh then G.UIRefresh() end
end
function G.SetQuest(id)
 G.selection.quest=id
 G.db.selectedQuest=id
 if G.UIRefresh then G.UIRefresh() end
end
function G.StatusLabel()
 local guide=G.db and G.db.guide
 if guide and guide.steps and #guide.steps>0 then
  return tostring(math.min(guide.index or 1,#guide.steps)).."/"..#guide.steps
 end
 return "대기 중"
end
function G.NotifyDataChange()
 if G.UIRefresh then G.UIRefresh() end
 if G.RefreshMapPins then G.RefreshMapPins() end
 if G.PlanRefresh then G.PlanRefresh() end
 if G.HUDRefresh then G.HUDRefresh() end
end
G.API.Open=function(dungeonId,questId)
 if dungeonId and G.GetDungeon(dungeonId) then G.SetDungeon(dungeonId) end
 if questId then G.SetQuest(questId) end
 if G.ShowUI then G.ShowUI(true) end
end
G.API.StartDungeon=function(dungeonId)
 if G.StartGuide then return G.StartGuide(dungeonId,nil) end
 return false
end

function G.SetFactionFilter(value)
 if not ({auto=true,Alliance=true,Horde=true,all=true})[value] then return false end
 G.db.factionFilter=value
 -- Browse-only switch: never rewrite the actual character faction or hijack
 -- a running guide when the player explores another faction's catalog.
 if G.UIRefresh then G.UIRefresh() end
 return true
end
G.API.SetFactionFilter=function(value) return G.SetFactionFilter(value) end
function G.SetViewMode(mode)
 if mode~="all" and mode~="active" and mode~="turnin" and mode~="zone" and mode~="dungeon" and mode~="selected" and mode~="deferred" then return end
 G.selection.mode=mode;G.db.viewMode=mode
 if G.UIRefresh then G.UIRefresh() end
end
G.API.StartChecked=function() if G.StartSelectedGuide then return G.StartSelectedGuide() end return false end
G.API.StartTurnins=function() if G.StartTurninGuide then return G.StartTurninGuide() end return false end
G.API.CheckQuest=function(id,enabled) if G.ToggleQuestChecked then return G.ToggleQuestChecked(id,enabled) end return false end

local addon,G=...
G.navStatus="경로 대기"
local tomtomUid,usedNative,previousNative,pending
local function legalPoint(point)
 return type(point)=="table" and type(point.map)=="number" and type(point.x)=="number"
    and type(point.y)=="number" and point.x>=0 and point.x<=1 and point.y>=0 and point.y<=1
end
function G.OpenPointMap(p)
 if not legalPoint(p) then return false end
 if InCombatLockdown and InCombatLockdown() then G.Print("전투 종료 후 지도를 엽니다.");return false end
 local opened=false
 if C_Map and type(C_Map.OpenWorldMap)=="function" then
  local ok=pcall(C_Map.OpenWorldMap,p.map);opened=ok or opened
 end
 local frame=_G.WorldMapFrame
 if type(ToggleWorldMap)=="function" and (not frame or (type(frame.IsShown)=="function" and not frame:IsShown())) then
  local ok=pcall(ToggleWorldMap);opened=ok or opened
  frame=_G.WorldMapFrame
 end
 if frame and type(frame.SetMapID)=="function" then
  local ok=pcall(frame.SetMapID,frame,p.map);opened=ok or opened
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
 return opened
end
function G.ClearWaypoint()
 if tomtomUid and TomTom and type(TomTom.RemoveWaypoint)=="function" then
  pcall(TomTom.RemoveWaypoint,TomTom,tomtomUid)
 end
 tomtomUid=nil
 if usedNative and C_Map and type(C_Map.ClearUserWaypoint)=="function" then
  -- Do not clear another addon's waypoint or one the user moved to.
  local current=G.SafeCall(C_Map.GetUserWaypoint)
  if not current or (previousNative and current==previousNative) then
   pcall(C_Map.ClearUserWaypoint)
  end
 end
 usedNative=false;previousNative=nil
end
function G.Navigate(p,openMap)
 if not legalPoint(p) then
  G.navStatus="이 단계의 위치 정보가 없습니다. Questie 지도를 확인하세요."
  return false
 end
 if InCombatLockdown and InCombatLockdown() then
  pending={p=p,open=openMap}
  G.navStatus="전투 종료 후 길찾기를 적용합니다."
  return false
 end
 if tomtomUid and TomTom and type(TomTom.RemoveWaypoint)=="function" then
  pcall(TomTom.RemoveWaypoint,TomTom,tomtomUid);tomtomUid=nil
 end
 local engine=ShortestPathForever and ShortestPathForever.API
 if engine and type(engine.Navigate)=="function" and (engine.version==1 or engine.version==2) then
  local ok,result=pcall(engine.Navigate,"ForeverDungeonQuestGuide",p.map,p.x,p.y,p.name or "퀘스트 목적지")
  if ok and result then
   G.navStatus="실제 이동 경로: Shortest Path Forever 연결됨"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if TomTom and type(TomTom.AddWaypoint)=="function" then
  local ok,uid=pcall(TomTom.AddWaypoint,TomTom,p.map,p.x,p.y,{title=p.name or "던전 퀘스트 목적지",persistent=false})
  if ok and uid then
   tomtomUid=uid
   if type(TomTom.SetCrazyArrow)=="function" then pcall(TomTom.SetCrazyArrow,TomTom,uid,0,p.name or "목적지") end
   G.navStatus="TomTom 화살표/지도 지점 표시 (지형 경로 계산 아님)"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if C_Map and type(C_Map.SetUserWaypoint)=="function" and UiMapPoint and type(UiMapPoint.Create)=="function" then
  local point=G.SafeCall(UiMapPoint.Create,p.map,p.x,p.y)
  if point then
   local ok,result=pcall(C_Map.SetUserWaypoint,point)
   if ok and result~=false then
    usedNative=true;previousNative=point
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
     pcall(C_SuperTrack.SetSuperTrackedUserWaypoint,true)
    end
    G.navStatus="기본 지도 목적지 표시 (지형 경로 계산 아님)"
    if openMap then G.OpenPointMap(p) end
    return true
   end
  end
 end
 G.navStatus="지도 위치 표시 실패: TomTom 또는 Shortest Path Forever를 확인하세요."
 if openMap then G.OpenPointMap(p) end
 return false
end
function G.OnLeaveCombat()
 if pending then
  local p=pending;pending=nil
  G.Navigate(p.p,p.open)
  if G.UIRefresh then G.UIRefresh() end
 end
end
function G.OpenDungeonNavigator()
 local nav=_G.ForeverDungeonNavigator
 if nav and type(nav.ShowLeader)=="function" then
  local ok=pcall(nav.ShowLeader,true)
  if ok then return true end
 end
 G.Print("Forever Dungeon Navigator가 없거나 준비되지 않았습니다. /dnav 로 직접 열 수 있습니다.")
 return false
end

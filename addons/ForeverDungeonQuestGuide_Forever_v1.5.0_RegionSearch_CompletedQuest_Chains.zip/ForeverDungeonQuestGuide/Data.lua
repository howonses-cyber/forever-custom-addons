local addon, G = ...
-- Dungeon -> quest ID indices are lightweight references, not a bundled copy of QuestieDB.
-- Quest titles, starter/finisher locations, prerequisite graphs are read from the user's
-- installed Forever QuestieDB at runtime. New Forever instances are shown honestly as
-- unverified until authoritative quest mappings are available.
local defs = {
 -- id, Korean display name, English search, UIMap ID, entrance X/Y (percent), zoneOrSort ID, quest IDs, level range
 {"rfc", "성난불길 협곡", "Ragefire Chasm RFC", 1454, 52.8, 49.0, 2437, "5722 5723 5724 5725 5728 5761", "13-18", "호드"},
 {"wailing", "통곡의 동굴", "Wailing Caverns WC", 1413, 46.0, 36.5, 718, "914 959 962 1486 1487 1489 1490 1491 6981", "17-25"},
 {"deadmines", "죽음의 폐광", "Deadmines DM", 1436, 42.5, 71.7, 1581, "166 167 168 214 2040", "17-26", "얼라이언스"},
 {"sfk", "그림자송곳니 성채", "Shadowfang Keep SFK", 1421, 44.8, 67.8, 209, "1013 1014 1098", "20-30"},
 {"bfd", "검은심연의 나락", "Blackfathom Deeps BFD", 1440, 14.5, 14.2, 719, "971 1198 1199 1200 1275 6561 6562 6563 6564 6565 6921", "22-32"},
 {"stockades", "스톰윈드 지하감옥", "The Stockade Stockades", 1453, 52.4, 70.0, 717, "377 378 386 387 388 391", "23-29", "얼라이언스"},
 {"gnomer", "놈리건", "Gnomeregan", 1426, 24.3, 39.8, 133, "2841 2842 2843 2904 2922 2923 2924 2925 2926 2927 2928 2929 2930 2931 2945 2947 2949 2951 2952 2953 2962 4601 4602 4603 4604 4605 4606", "25-38"},
 {"rfk", "가시덩굴 우리", "Razorfen Kraul RFK", 1413, 42.9, 90.2, 1717, "1101 1102 1109 1142 1144 1221", "24-40"},
 {"sm", "붉은십자군 수도원", "Scarlet Monastery SM", 1420, 82.6, 33.8, 796, "1048 1049 1050 1051 1053 1113 1160", "30-45"},
 {"rfd", "가시덩굴 구릉", "Razorfen Downs RFD", 1413, 49.0, 93.9, 722, "3341 3523 3525 3636 6521 6522 6626", "37-46"},
 {"uldaman", "울다만", "Uldaman", 1418, 44.6, 12.1, 1517, "17 704 709 721 722 1139 1360 2198 2199 2200 2201 2202 2204 2240 2278 2279 2280 2283 2284 2318 2338 2339 2340 2341 2342 2361 2398 2418 3375", "41-51"},
 {"zf", "줄파락", "Zul'Farrak ZF", 1446, 38.7, 20.1, 978, "2768 2770 2846 2861 2864 2865 2936 2991 3042 3527", "44-54"},
 {"mara", "마라우돈", "Maraudon", 1443, 29.1, 62.5, 2100, "7028 7029 7041 7044 7046 7064 7065 7066 7067 7068 7070", "46-55"},
 {"sunken", "아탈학카르 신전", "Sunken Temple Temple of Atal'Hakkar 가라앉은 사원 학카르 아탈", 1435, 69.9, 53.5, 1417,
   "1445 1446 1475 3373 3380 3446 3447 3528 4143 4146 8733 8413", "50-56"},
 {"brd", "검은바위 나락", "Blackrock Depths BRD", 1428, 29.4, 38.3, 1584,
  "3801 3802 3907 3981 3982 4001 4002 4003 4004 4024 4063 4081 4082 4083 4121 4122 4123 4126 4128 4132 4133 4134 4136 4201 4241 4242 4263 4264 4282 4286 4295 4322 4324 4341 4342 4361 4362 4363 7201 7604 9015", "52-60"},
 {"brs", "검은바위 첨탑", "Blackrock Spire LBRS UBRS", 1428, 29.4, 38.3, 1583,
  "4701 4724 4729 4734 4735 4742 4743 4764 4765 4766 4768 4769 4788 4862 4866 4867 4903 4907 4974 4981 4982 4983 5001 5002 5047 5081 5089 5102 5127 5160 6502 6569 6602 7761 8966 8989 8995", "55-60"},
 {"dm", "혈투의 전장", "Dire Maul", 1444, 59.2, 45.1, 2557,
  "1193 1318 5518 5519 5525 5528 7429 7441 7461 7462 7463 7481 7482 7483 7484 7485 7488 7489 7492 7494 7498 7499 7500 7501 7502 7503 7504 7505 7506 7507 7508 7703 7877 8948 8949 8950 8967 8990", "54-60"},
 {"strat", "스트라솔름", "Stratholme", 1423, 26.5, 10.4, 2017,
  "5122 5125 5212 5213 5214 5243 5251 5262 5263 5282 5463 5848 6163 8945 8968 8991", "55-60"},
 {"scholo", "스칼로맨스", "Scholomance", 1422, 69.7, 73.2, 2057,
  "4771 5341 5343 5382 5384 5466 5515 5529 5531 5582 8969 8992", "57-60"},
 -- Forever-original dungeons are discoverable but not falsely populated from Classic.
 {"thanes", "Hall of Thanes (한글 명칭 미확인)", "Ironforge Hall of Thanes", nil,nil,nil,nil,"","13-18",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"lordaeron", "Ruins of Lordaeron (한글 명칭 미확인)", "Ruins of Lordaeron", nil,nil,nil,nil,"","15-22",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"wetlands", "Excavation Site: Wetlands (한글 명칭 미확인)", "Wetlands Excavation Site", nil,nil,nil,nil,"","24-31",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"dalaran", "City of Dalaran (한글 명칭 미확인)", "City of Dalaran", nil,nil,nil,nil,"","28-35",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
}
G.dungeons={}
G.dungeonById={}
for _,v in ipairs(defs) do
 local row={id=v[1],name=v[2],aliases=v[3],entrance=(v[4] and {map=v[4],x=v[5]/100,y=v[6]/100,name=v[2].." 던전 부근"} or nil),area=v[7],ids={},level=v[9],onlyFaction=v[10],warning=v[11]}
 for q in string.gmatch(v[8],"%d+") do row.ids[#row.ids+1]=tonumber(q) end
 G.dungeons[#G.dungeons+1]=row; G.dungeonById[row.id]=row
end
-- Authoritative Korean spellings sourced from localized Forever quest records.
G.koQuestNames={
 [1448]="신전을 찾아서",[1449]="동부 내륙지로",[1450]="그리핀 조련사 탈론액스",[1451]="랩소디 신디거",[1452]="랩소디의 칼림도어 칵테일",[1469]="랩소디의 이야기",[1475]="아탈학카르 신전으로",
 [1445]="아탈학카르 신전",[1446]="예언자 잠말란",[3373]="에라니쿠스의 정수",[3380]="가라앉은 사원",[3446]="심연의 늪",[3447]="돌무리의 비밀",[3528]="학카르의 화신",[4143]="악의 아지랑이",[4146]="구제장치 연료",
}
-- Exact outdoor locations only when grounded. Other quests use the live DB spawn positions.
G.pickupOverrides={
 [1448]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},[1449]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},[1475]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},
 [1446]={map=1425,x=.338,y=.752,name="추방된 아탈라이트롤"},[1445]={map=1435,x=.479,y=.548,name="펠제룰"},
 [3446]={map=1446,x=.526,y=.458,name="마본 리벳시커"},[3447]={map=1446,x=.526,y=.458,name="마본 리벳시커"},
 [3520]={map=1446,x=.670,y=.220,name="예킨야"},[3528]={map=1446,x=.670,y=.220,name="예킨야"},
 [4143]={map=1444,x=.450,y=.250,name="그레간 브루스퓨"},[4146]={map=1413,x=.620,y=.380,name="리브 리즐픽스"},
 [8413]={map=1416,x=.805,y=.669,name="바스라 윈드워처"},
}
-- This supplement is necessary because some class quests use a class sort rather
-- than the dungeon zone and thus are absent from simple instance-area lookups.
G.specialQuestMeta={
 [8413]={onlyFaction="Horde",classMask=64,note="주술사 50레벨 직업 연계(현재 공식 가이드: 호드 전용)."},
 [3373]={inside=true,note="던전 내부의 에라니쿠스가 떨어뜨리는 물건에서 시작."},
 [8733]={inside=true,note="추가 고레벨 연계, 레벨·진행 조건 확인 필요."},
}

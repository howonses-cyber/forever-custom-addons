local addon,G=...
local controller=CreateFrame("Frame")
local dirty=false
local elapsed=0
local movementElapsed=0
local indexElapsed=0
local statusElapsed=0
local hudElapsed=0
local lastPosition=nil
local function sync()
 G.PlayerRefresh()
 G.RefreshQuestLog()
 if G.db and G.db.guide and G.db.guide.mode=="selected" and G.ReplanSelectedGuide then
  G.ReplanSelectedGuide("퀘스트 상태 변경")
 elseif G.ReconcileGuide then G.ReconcileGuide() end
 G.NotifyDataChange()
end
controller:SetScript("OnEvent",function(self,event,arg1,...)
 if event=="ADDON_LOADED" then
  if arg1==addon then
   G.StartSaved()
   G.PlayerRefresh()
   G.RefreshQuestLog()
  elseif arg1=="QuestieDB" then
   G.nameCache={}
   if G.RestartQuestIndex then G.RestartQuestIndex() end
   dirty=true
  elseif arg1=="Blizzard_WorldMap" then
   dirty=true
  end
 elseif event=="PLAYER_LOGIN" then
  G.StartSaved()
  sync()
  if G.RestartQuestIndex then G.RestartQuestIndex() end
  if G.CreateMinimapButton then G.CreateMinimapButton() end
  local gd=G.db.guide
  if gd and gd.steps and #gd.steps>0 then G.ReconcileGuide() end
  if G.db.openOnLogin then G.ShowUI(true) end
  if not G.Ready() then G.Print("QuestieDB가 없으면 퀘스트/선행 정보가 표시되지 않습니다. QuestieDB 설치 후 /reload 하세요.") end
 elseif event=="QUEST_LOG_UPDATE" or event=="QUEST_ACCEPTED" or event=="QUEST_TURNED_IN" or event=="QUEST_REMOVED" or event=="PLAYER_LEVEL_UP" then
  if event=="QUEST_TURNED_IN" and G.MarkQuestTurnedIn then G.MarkQuestTurnedIn(arg1) end
  if event=="QUEST_ACCEPTED" and G.MarkQuestAccepted then
   local questID=select(1,...)
   if tonumber(questID) then G.MarkQuestAccepted(questID) end
  end
  dirty=true
 elseif event=="ZONE_CHANGED_NEW_AREA" or event=="WORLD_MAP_UPDATE" then
  if G.RefreshMapPins then G.RefreshMapPins() end
  if event=="ZONE_CHANGED_NEW_AREA" and G.db and G.db.guide and G.db.guide.mode=="selected" then
   if G.ReplanSelectedGuide then G.ReplanSelectedGuide("지역 변경") end
  end
 elseif event=="PLAYER_ENTERING_WORLD" then
  if G.CreateMinimapButton then G.CreateMinimapButton() end
 elseif event=="PLAYER_REGEN_ENABLED" then
  if G.OnLeaveCombat then G.OnLeaveCombat() end
 end
end)
controller:SetScript("OnUpdate",function(_,dt)
 elapsed=elapsed+dt
 hudElapsed=hudElapsed+dt
 if hudElapsed>=.65 then
  hudElapsed=0
  if G.HUDUpdateDistance then G.HUDUpdateDistance() end
 end
 indexElapsed=indexElapsed+dt
 if indexElapsed>=.12 then
  indexElapsed=0
  if G.TickQuestIndex then G.TickQuestIndex(170) end
 end
 -- Questie can finish loading its objective cache after QUEST_LOG_UPDATE.
 -- Poll only while the guide or UI is active; replan only on state changes.
 statusElapsed=statusElapsed+dt
 if statusElapsed>=2 then
  statusElapsed=0
  if not dirty and G.db and ((G.db.guide and G.db.guide.mode=="selected") or (G.IsUIShown and G.IsUIShown())) then
   if G.RefreshQuestLog and G.RefreshQuestLog() then
    if G.db.guide and G.db.guide.mode=="selected" and G.ReplanSelectedGuide then G.ReplanSelectedGuide("퀘스트 완료 상태 갱신") end
    G.NotifyDataChange()
   end
  end
 end
 movementElapsed=movementElapsed+dt
 if movementElapsed>=4 then
  movementElapsed=0
  if G.db and G.db.guide and G.db.guide.mode=="selected" and G.PlayerLocation then
   local loc=G.PlayerLocation()
   if loc and (not lastPosition or lastPosition.map~=loc.map or
      (not loc.approx and (lastPosition.approx or type(lastPosition.x)~="number" or type(lastPosition.y)~="number" or
       ((loc.x-lastPosition.x)^2+(loc.y-lastPosition.y)^2)>.0004))) then
    lastPosition=loc
    if G.ReplanSelectedGuide then G.ReplanSelectedGuide("플레이어 위치 변경") end
   end
  else lastPosition=nil end
 end
 if elapsed<.5 then return end
 elapsed=0
 if dirty then dirty=false;sync() end
 if G.RefreshMapPins then G.RefreshMapPins() end
end)
for _,ev in ipairs({"ADDON_LOADED","PLAYER_LOGIN","QUEST_LOG_UPDATE","QUEST_ACCEPTED","QUEST_TURNED_IN","QUEST_REMOVED","PLAYER_LEVEL_UP","ZONE_CHANGED_NEW_AREA","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED"}) do
 controller:RegisterEvent(ev)
end
-- WORLD_MAP_UPDATE is not available on all Forever-era clients.
if C_EventUtils and C_EventUtils.IsEventValid and C_EventUtils.IsEventValid("WORLD_MAP_UPDATE") then
 controller:RegisterEvent("WORLD_MAP_UPDATE")
end
SLASH_FOREVERDUNGEONQUESTGUIDE1="/fdq"
SLASH_FOREVERDUNGEONQUESTGUIDE2="/던전퀘"
SlashCmdList.FOREVERDUNGEONQUESTGUIDE=function(msg)
 msg=tostring(msg or ""):gsub("^%s+",""):gsub("%s+$","")
 local cmd,rest=msg:match("^(%S+)%s*(.-)$")
 cmd=cmd or ""
 if cmd=="" then G.ToggleUI();return end
 if cmd=="stop" or cmd=="중지" then G.StopGuide();return end
 if cmd=="hud" or cmd=="표시" then if G.ToggleHUD then G.ToggleHUD() end;return end
 if cmd=="steps" or cmd=="동선" then if G.TogglePlanWindow then G.TogglePlanWindow() end;return end
 if cmd=="hudcfg" or cmd=="config" then
  if G.HUDRefresh then G.HUDRefresh() end
  if G.ToggleHUDSettings then G.ToggleHUDSettings() end
  return
 end
 if cmd=="opacity" or cmd=="alpha" then
  local n=tonumber(rest)
  if n and G.HUDSetOpacity then G.HUDSetOpacity(n)
  else G.Print("Usage: /fdq opacity 0-85") end
  return
 end
 if cmd=="size" then
  local a,b=rest:match("^(%d+)%s+(%d+)$")
  if a and b and G.HUDSetSize then
   if G.HUDRefresh then G.HUDRefresh() end
   G.HUDSetSize(tonumber(a),tonumber(b))
  else G.Print("Usage: /fdq size 520 430") end
  return
 end

 if cmd=="next" or cmd=="다음" then G.NextGuide(1,true);return end
 if cmd=="map" or cmd=="지도" then
  local step=G.CurrentStep()
  if step and step.point then G.Navigate(step.point,true)
  else G.Print("선택한 단계에는 지도 좌표가 없습니다.") end
  return
 end
 if cmd=="all" or cmd=="전체" then G.SetViewMode("all");G.ShowUI(true);return end
 if cmd=="dungeon" or cmd=="던전" then G.SetViewMode("dungeon");G.ShowUI(true);return end
 if cmd=="zone" or cmd=="지역" then G.SetViewMode("zone");G.ShowUI(true);return end
 if cmd=="active" or cmd=="진행" then G.SetViewMode("active");G.ShowUI(true);return end
 if cmd=="turnin" or cmd=="보고" then G.SetViewMode("turnin");G.ShowUI(true);return end
 if cmd=="turnins" or cmd=="보고동선" then G.StartTurninGuide();G.ShowUI(true);return end
 if cmd=="checked" or cmd=="체크" then G.SetViewMode("selected");G.ShowUI(true);return end
 if cmd=="route" or cmd=="경로" then G.StartSelectedGuide();G.ShowUI(true);return end
 if cmd=="guide" or cmd=="시작" then
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil);G.ShowUI(true)
  else G.Print("먼저 던전을 선택하세요.") end
  return
 end
 if cmd=="quest" or cmd=="퀘스트" then
  local qid=tonumber(rest)
  if qid and G.DBGet(QuestDB,qid,"name") then
   G.SetViewMode("all");G.SetQuest(qid);G.ShowUI(true)
  else G.Print("QuestieDB에서 퀘스트 ID를 찾을 수 없습니다: "..tostring(rest)) end
  return
 end
 if cmd=="check" or cmd=="추가" then
  local qid=tonumber(rest)
  if qid and G.DBGet(QuestDB,qid,"name") then G.ToggleQuestChecked(qid,true);G.SetQuest(qid);G.ShowUI(true)
  else G.Print("퀘스트 ID를 확인하세요.") end
  return
 end
 local found=G.SearchDungeons(msg)
 if found and #found>0 then
  G.SetDungeon(found[1].dungeon.id)
  if found[1].matchedQuest then G.SetQuest(found[1].matchedQuest) end
  G.ShowUI(true)
 else G.SetViewMode("all");G.ShowUI(true);G.Print("전체 퀘스트 검색창에 검색어를 입력하세요: "..msg) end
end

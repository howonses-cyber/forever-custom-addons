local addon,G = ...
-- In-world guide: grounded written directions live in this window, while the
-- independent real-time navigation addon continues to own its arrow/path.
local hud,back,heading,progress,current,distance,nextOne,nextTwo,source
local scroll,scrollChild,directions,collapseButton,configButton,resizeGrip
local settings,opacityLabel,opacitySlider,widthBox,heightBox
local buttons={}
local resizing=false
local lastStepKey=nil
local MINW,MAXW,MINH,MAXH=420,760,360,700
local function clamp(v,min,max)
 v=tonumber(v) or min
 if v<min then return min end
 if v>max then return max end
 return v
end
local function button(parent,text,width,height,action)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(width,height);b:SetText(text);b:SetScript("OnClick",action)
 return b
end
local function font(parent,template)
 local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlightSmall")
 f:SetJustifyH("LEFT");f:SetJustifyV("TOP")
 return f
end
local function savePosition()
 if not hud or not G.db then return end
 local x,y=hud:GetLeft(),hud:GetTop()
 local px,py=UIParent:GetLeft() or 0,UIParent:GetTop() or 0
 if x and y then G.db.hudPosition={anchor="TOPLEFT",x=x-px,y=y-py} end
end
local function applyOpacity()
 if not hud or not G.db then return end
 local alpha=clamp(G.db.hudOpacity,.15,1)
 back:SetColorTexture(.055,.068,.08,alpha)
 if hud.goldBar then hud.goldBar:SetColorTexture(.93,.71,.27,math.max(.50,alpha)) end
 if hud.divider then hud.divider:SetColorTexture(.33,.31,.22,math.max(.45,alpha)) end
 if opacityLabel then opacityLabel:SetText("배경 투명도: "..tostring(math.floor((1-alpha)*100+.5)).."%") end
end
local function saveSize()
 if not hud or not G.db or G.db.hudCollapsed then return end
 G.db.hudSize={width=math.floor(clamp(hud:GetWidth(),MINW,MAXW)+.5),
  height=math.floor(clamp(hud:GetHeight(),MINH,MAXH)+.5)}
end
local function layout()
 if not hud then return end
 local w=math.max(MINW,hud:GetWidth() or MINW)
 heading:SetWidth(w-131)
 progress:SetWidth(w-28)
 current:SetWidth(w-29)
 distance:SetWidth(w-29)
 nextOne:SetWidth(w-29)
 nextTwo:SetWidth(w-29)
 source:SetWidth(w-29)
 if scroll and scrollChild and directions then
  local width=math.max(300,w-46)
  scrollChild:SetWidth(width)
  directions:SetWidth(width-2)
  -- String height updates after width changes; keep full text scrollable.
  local size=math.max(185,math.ceil((directions:GetStringHeight() or 160)+20))
  directions:SetHeight(size)
  scrollChild:SetHeight(size)
  local maxScroll=math.max(0,size-(scroll:GetHeight() or 0))
  if scroll:GetVerticalScroll()>maxScroll then scroll:SetVerticalScroll(maxScroll) end
 end
 if settings and settings:IsShown() then
  if widthBox then widthBox:SetText(tostring(math.floor(hud:GetWidth()+.5))) end
  if heightBox then heightBox:SetText(tostring(math.floor((G.db and G.db.hudSize and G.db.hudSize.height) or hud:GetHeight()+.5))) end
 end
end
local function stopSizing()
 if not resizing or not hud then return end
 hud:StopMovingOrSizing()
 resizing=false
 local w,h=clamp(hud:GetWidth(),MINW,MAXW),clamp(hud:GetHeight(),MINH,MAXH)
 hud:SetSize(w,h)
 saveSize();layout();savePosition()
end
function G.HUDSetSize(w,h)
 if not G.db or not hud then return false end
 w,h=clamp(w,MINW,MAXW),clamp(h,MINH,MAXH)
 G.db.hudSize={width=math.floor(w+.5),height=math.floor(h+.5)}
 if not G.db.hudCollapsed then hud:SetSize(w,h) end
 layout()
 return true
end
function G.HUDSetOpacity(value)
 if not G.db then return false end
 local amount=clamp(value,0,85)
 G.db.hudOpacity=1-amount/100
 applyOpacity()
 return true
end
local function updateExpandedState()
 if not hud or not G.db then return end
 local collapsed=G.db.hudCollapsed==true
 if resizing then stopSizing() end
 local height=(G.db.hudSize and G.db.hudSize.height) or 415
 hud:SetHeight(collapsed and 46 or clamp(height,MINH,MAXH))
 for _,f in ipairs({progress,current,scroll,distance,nextOne,nextTwo,source,resizeGrip}) do
  if collapsed then f:Hide() else f:Show() end
 end
 for _,b in ipairs(buttons) do
  if collapsed then b:Hide() else b:Show() end
 end
 if collapseButton then collapseButton:SetText(collapsed and "+" or "-") end
 if collapsed and settings then settings:Hide() end
 if not collapsed then layout() end
end
local function configFrame()
 if settings then return settings end
 settings=CreateFrame("Frame","ForeverDungeonQuestGuideHUDSettings",UIParent)
 settings:SetSize(335,244)
 settings:SetFrameStrata("DIALOG");settings:SetToplevel(true)
 settings:SetClampedToScreen(true)
 settings:SetMovable(true);settings:EnableMouse(true)
 settings:RegisterForDrag("LeftButton")
 settings:SetScript("OnDragStart",function(self)
  if not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
 end)
 settings:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 settings:SetPoint("TOPLEFT",hud,"TOPRIGHT",8,0)
 local bg=settings:CreateTexture(nil,"BACKGROUND")
 bg:SetAllPoints();bg:SetColorTexture(.065,.071,.085,.97)
 local rim=settings:CreateTexture(nil,"BORDER")
 rim:SetPoint("TOPLEFT",settings,"TOPLEFT",0,0)
 rim:SetPoint("TOPRIGHT",settings,"TOPRIGHT",0,0)
 rim:SetHeight(3);rim:SetColorTexture(.92,.69,.28,1)
 local title=font(settings,"GameFontNormal")
 title:SetPoint("TOPLEFT",settings,"TOPLEFT",13,-14)
 title:SetText("안내창 설정")
 local close=button(settings,"X",28,24,function()settings:Hide()end)
 close:SetPoint("TOPRIGHT",settings,"TOPRIGHT",-8,-9)
 opacityLabel=font(settings,"GameFontHighlightSmall")
 opacityLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",15,-48)
 -- A stable global slider name avoids template-created texture name collisions.
 local okSlider,created=pcall(CreateFrame,"Slider","ForeverDungeonQuestGuideHUDOpacitySlider",settings,"OptionsSliderTemplate")
 if okSlider and created then opacitySlider=created
 else
  opacitySlider=CreateFrame("Slider","ForeverDungeonQuestGuideHUDOpacitySlider",settings)
  if type(opacitySlider.SetOrientation)=="function" then opacitySlider:SetOrientation("HORIZONTAL") end
  if type(opacitySlider.SetThumbTexture)=="function" then
   opacitySlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  end
 end
 opacitySlider:SetPoint("TOPLEFT",settings,"TOPLEFT",29,-75)
 opacitySlider:SetSize(265,17)
 opacitySlider:SetMinMaxValues(0,85)
 opacitySlider:SetValueStep(5)
 if type(opacitySlider.SetObeyStepOnDrag)=="function" then opacitySlider:SetObeyStepOnDrag(true) end
 opacitySlider:SetScript("OnValueChanged",function(self,v)
  if G.db then G.HUDSetOpacity(math.floor(v/5+.5)*5) end
 end)
 local note=font(settings,"GameFontHighlightSmall")
 note:SetPoint("TOPLEFT",settings,"TOPLEFT",15,-105)
 note:SetWidth(307);note:SetText("배경만 투명해지며 글자는 선명하게 유지됩니다.")
 local wLabel=font(settings,"GameFontHighlightSmall")
 wLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",17,-135)
 wLabel:SetText("가로")
 local hLabel=font(settings,"GameFontHighlightSmall")
 hLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",165,-135)
 hLabel:SetText("세로")
 local function entry(x)
  local edit=CreateFrame("EditBox",nil,settings,"InputBoxTemplate")
  edit:SetSize(83,24);edit:SetPoint("TOPLEFT",settings,"TOPLEFT",x,-153)
  edit:SetAutoFocus(false);edit:SetMaxLetters(4)
  edit:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
  return edit
 end
 widthBox=entry(57);heightBox=entry(201)
 local function apply()
  G.HUDSetSize(tonumber(widthBox:GetText()) or hud:GetWidth(),
   tonumber(heightBox:GetText()) or (G.db.hudSize and G.db.hudSize.height) or 415)
  widthBox:ClearFocus();heightBox:ClearFocus()
 end
 widthBox:SetScript("OnEnterPressed",apply)
 heightBox:SetScript("OnEnterPressed",apply)
 local applyButton=button(settings,"적용",94,25,apply)
 applyButton:SetPoint("BOTTOMLEFT",settings,"BOTTOMLEFT",16,14)
 local resetButton=button(settings,"초기값",93,25,function()
  G.HUDSetSize(440,415);G.HUDSetOpacity(5)
  opacitySlider:SetValue(5)
 end)
 resetButton:SetPoint("LEFT",applyButton,"RIGHT",7,0)
 local hideButton=button(settings,"닫기",91,25,function()settings:Hide()end)
 hideButton:SetPoint("LEFT",resetButton,"RIGHT",7,0)
 local help=font(settings,"GameFontHighlightSmall")
 help:SetPoint("BOTTOMLEFT",settings,"BOTTOMLEFT",13,47)
 help:SetWidth(305);help:SetText("오른쪽 아래 모서리를 드래그해 크기를 조절하세요.")
 settings:SetScript("OnShow",function()
  opacitySlider:SetValue(math.floor((1-G.db.hudOpacity)*100+.5))
  widthBox:SetText(tostring(math.floor(hud:GetWidth()+.5)))
  heightBox:SetText(tostring(math.floor((G.db.hudSize and G.db.hudSize.height) or 415)+.5))
  applyOpacity()
 end)
 settings:Hide()
 return settings
end
function G.ToggleHUDSettings()
 if not hud then return false end
 local config=configFrame()
 if config:IsShown() then config:Hide() else config:Show() end
 return true
end
local function initialize()
 if hud or not UIParent then return end
 hud=CreateFrame("Frame","ForeverDungeonQuestGuideHUD",UIParent)
 hud:SetSize((G.db and G.db.hudSize and G.db.hudSize.width) or 440,
  (G.db and G.db.hudSize and G.db.hudSize.height) or 415)
 local pos=G.db and G.db.hudPosition
 if pos and pos.anchor=="TOPLEFT" then
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",pos.x or 32,pos.y or -195)
 elseif pos then
  hud:SetPoint("TOP",UIParent,"TOP",pos.x or 0,pos.y or -125)
 else
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",30,-210)
 end
 hud:SetClampedToScreen(true)
 hud:SetFrameStrata("MEDIUM");hud:SetToplevel(true)
 hud:SetMovable(true);hud:EnableMouse(true);hud:RegisterForDrag("LeftButton")
 if type(hud.SetResizable)=="function" then pcall(hud.SetResizable,hud,true) end
 if type(hud.SetMinResize)=="function" then pcall(hud.SetMinResize,hud,MINW,MINH) end
 if type(hud.SetMaxResize)=="function" then pcall(hud.SetMaxResize,hud,MAXW,MAXH) end
 if type(hud.SetResizeBounds)=="function" then pcall(hud.SetResizeBounds,hud,MINW,MINH,MAXW,MAXH) end
 back=hud:CreateTexture(nil,"BACKGROUND")
 back:SetAllPoints()
 local border=hud:CreateTexture(nil,"BORDER")
 border:SetPoint("TOPLEFT",hud,"TOPLEFT",0,0)
 border:SetPoint("TOPRIGHT",hud,"TOPRIGHT",0,0)
 border:SetHeight(3)
 hud.goldBar=border
 local divider=hud:CreateTexture(nil,"BORDER")
 divider:SetPoint("TOPLEFT",hud,"TOPLEFT",10,-47)
 divider:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-10,-47)
 divider:SetHeight(1)
 hud.divider=divider
 hud:SetScript("OnDragStart",function(self)
  if not (InCombatLockdown and InCombatLockdown()) and not resizing then self:StartMoving() end
 end)
 hud:SetScript("OnDragStop",function(self)self:StopMovingOrSizing();savePosition()end)
 hud:SetScript("OnHide",function(self)
  if resizing then stopSizing() end
  self:StopMovingOrSizing()
  if settings then settings:Hide() end
 end)
 hud:SetScript("OnMouseUp",function()if resizing then stopSizing()end end)
 hud:SetScript("OnUpdate",function()
  if resizing and type(IsMouseButtonDown)=="function" and not IsMouseButtonDown("LeftButton") then stopSizing() end
 end)
 hud:SetScript("OnSizeChanged",layout)
 heading=font(hud,"GameFontNormal")
 heading:SetPoint("TOPLEFT",hud,"TOPLEFT",13,-11)
 heading:SetHeight(25)
 progress=font(hud,"GameFontHighlightSmall")
 progress:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-53);progress:SetHeight(20)
 current=font(hud,"GameFontHighlight")
 current:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-76);current:SetHeight(38)
 scroll=CreateFrame("ScrollFrame",nil,hud)
 scroll:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-119)
 scroll:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-18,122)
 scroll:EnableMouseWheel(true)
 scroll:SetScript("OnMouseWheel",function(self,delta)
  local maxScroll=math.max(0,(scrollChild and scrollChild:GetHeight() or 0)-(self:GetHeight() or 0))
  self:SetVerticalScroll(clamp(self:GetVerticalScroll()-delta*34,0,maxScroll))
 end)
 scrollChild=CreateFrame("Frame",nil,scroll)
 scrollChild:SetSize(382,240);scroll:SetScrollChild(scrollChild)
 directions=font(scrollChild,"GameFontHighlightSmall")
 directions:SetPoint("TOPLEFT",scrollChild,"TOPLEFT",0,0)
 directions:SetWidth(375)
 if type(directions.SetSpacing)=="function" then directions:SetSpacing(5) end
 directions:SetText("")
 distance=font(hud,"GameFontNormalSmall")
 distance:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,96);distance:SetHeight(20)
 nextOne=font(hud,"GameFontHighlightSmall")
 nextOne:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,75);nextOne:SetHeight(17)
 nextTwo=font(hud,"GameFontHighlightSmall")
 nextTwo:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,57);nextTwo:SetHeight(17)
 source=font(hud,"GameFontHighlightSmall")
 source:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,39);source:SetHeight(17)
 collapseButton=button(hud,"-",29,26,function()
  if G.db then G.db.hudCollapsed=not G.db.hudCollapsed;updateExpandedState() end
 end)
 collapseButton:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-77,-8)
 configButton=button(hud,"안내창 설정",43,26,function()G.ToggleHUDSettings()end)
 configButton:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-33,-8)
 -- Compact title bar: settings uses an icon-like short label below to avoid overlap.
 configButton:SetText("CFG")
 local close=button(hud,"X",27,26,function()
  if G.db then G.db.hudHidden=true;hud:Hide() end
 end)
 close:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-3,-8)
 buttons={
  button(hud,"< 이전",72,25,function()G.NextGuide(-1,false)end),
  button(hud,"다음 완료 >",103,25,function()G.NextGuide(1,true)end),
  button(hud,"지도",56,25,function()
   local st=G.CurrentStep()
   if st and st.point then G.Navigate(st.point,true)
   else G.Print("좌표 정보 없음") end
  end),
  button(hud,"동선표",64,25,function()G.TogglePlanWindow()end),
  button(hud,"전체",48,25,function()G.ShowUI(true)end)
 }
 local xs={12,89,198,261,332}
 for i,b in ipairs(buttons) do b:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",xs[i],9) end
 -- Visible corner handle does not replace or intercept the right-hand route addon.
 resizeGrip=CreateFrame("Button",nil,hud)
 resizeGrip:SetSize(18,18)
 resizeGrip:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-1,1)
 resizeGrip:EnableMouse(true)
 local gripTexture=resizeGrip:CreateTexture(nil,"OVERLAY")
 gripTexture:SetAllPoints()
 gripTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
 resizeGrip:SetScript("OnMouseDown",function(self,mouse)
  if mouse~="LeftButton" or resizing or G.db.hudCollapsed then return end
  if InCombatLockdown and InCombatLockdown() then return end
  if type(hud.StartSizing)=="function" then
   local ok=pcall(hud.StartSizing,hud,"BOTTOMRIGHT")
   if ok then resizing=true
   else G.Print("Drag-resize unavailable: set width and height in CFG.") end
  end
 end)
 resizeGrip:SetScript("OnMouseUp",function()stopSizing()end)
 resizeGrip:SetScript("OnHide",function()stopSizing()end)
 hud:Hide()
 applyOpacity();layout();updateExpandedState()
end
function G.HUDUpdateDistance()
 if not hud or not hud:IsShown() or not G.db or G.db.hudCollapsed then return end
 local step=G.CurrentStep()
 if not step then distance:SetText("");return end
 local location=G.PlayerLocation and G.PlayerLocation()
 local info,dir
 if G.RouteDistanceLabel then info,dir=G.RouteDistanceLabel(location,step.point) end
 distance:SetText("|cff9cbfff"..(info or "현재 위치 정보 미확인").."|r"..(dir and dir~="" and "  |cffffd47c"..dir.." 방향|r" or ""))
end
function G.HUDRefresh()
 if not G.db or not G.db.manualProgress then return end
 initialize()
 if not hud then return end
 local route=G.db.guide
 if not route or not route.steps or #route.steps==0 or G.db.hudHidden then hud:Hide();return end
 hud:Show()
 updateExpandedState()
 local done,total=G.GuideProgress()
 heading:SetText("|cffffdf92퀘스트 이동 가이드|r  |cffaac4ca"..done.."/"..total.."|r")
 if route.mode=="selected" then
  local q=route.optimization and route.optimization.selectedQuestCount or (G.SelectedCount and G.SelectedCount()) or 0
  progress:SetText("|cff88d7e9선택 "..q.."개 퀘스트|r  |cff9da8ac- 전체 방문 "..total.."단계"..(route.turninOnly and " - 보고만" or "").."|r")
 else
  progress:SetText("|cff88d7e9던전 준비|r - "..total.."단계")
 end
 local step=G.CurrentStep()
 local stepKey=step and (step.key or tostring(route.index)..":"..tostring(step.title)) or "finished"
 if step then
  local result=G.BuildStepDirections and G.BuildStepDirections(step,G.PlayerLocation and G.PlayerLocation())
  current:SetText("|cffffefbc"..(route.index or 1)..". |r"..(result and result.title or (step.title or "")))
  directions:SetText(result and table.concat(result.lines,"\n\n") or (step.note or "위치 좌표 미확인: 퀘스트 로그와 지도에서 확인하세요."))
 else
  current:SetText("|cff87dc98모든 방문 단계 완료|r")
  directions:SetText("퀘스트 완료 상태를 확인하세요.")
 end
 local ix=route.index or 1
 local st1,st2=route.steps[ix+1],route.steps[ix+2]
 nextOne:SetText(st1 and ("|cff99a5af다음  |r"..(G.BuildStepDirections and G.BuildStepDirections(st1) or {}).title) or "|cff99a5af다음 단계 없음|r")
 nextTwo:SetText(st2 and ("|cff99a5af그다음  |r"..(G.BuildStepDirections and G.BuildStepDirections(st2) or {}).title) or "")
 source:SetText("|cffd8aa67실시간 지형 경로는 오른쪽 애드온이 별도로 표시합니다.|r")
 layout()
 if lastStepKey~=stepKey then scroll:SetVerticalScroll(0);lastStepKey=stepKey end
 G.HUDUpdateDistance()
end
function G.ToggleHUD()
 if not G.db then return end
 G.db.hudHidden=not G.db.hudHidden
 G.HUDRefresh()
end

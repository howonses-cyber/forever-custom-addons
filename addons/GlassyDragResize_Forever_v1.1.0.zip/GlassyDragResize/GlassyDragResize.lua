-- Glassy Drag Resize 1.1.0 / WoW Forever (Interface 16001).
-- Only resizes chat windows: Glassy owns the primary renderer and Blizzard
-- owns the position/dimensions of each independently undocked ChatFrameN.
-- Do not modify the user's chat tabs, chat messages, or EUI configuration.

local _G = _G
local floor, min, max = math.floor, math.min, math.max
local panes = {}
local mainPane
local dragging
local elapsedScan, elapsedHover, loginAge = 0, 0, 0
local started = false
local saved = nil
local restored = {}
local MIN_WIDTH, MIN_HEIGHT = 220, 110
local EDGE_MARGIN = 6

local function Inform(msg)
    local chat = _G.DEFAULT_CHAT_FRAME
    if chat and chat.AddMessage then
        chat:AddMessage("|cff92a5c1[Glassy 크기]|r " .. tostring(msg))
    end
end

local function InCombat()
    return type(_G.InCombatLockdown) == "function" and _G.InCombatLockdown()
end

local function GetGlassy()
    local core = _G.Glassy
    if type(core) == "table" and core.db and core.db.profile
        and type(core.Dispatch) == "function" then
        return core
    end
end

local function GetName(i)
    if type(_G.GetChatWindowInfo) == "function" then
        local name = _G.GetChatWindowInfo(i)
        if type(name) == "string" and name ~= "" then return name end
    end
    return "ChatFrame" .. tostring(i)
end

local function IsUndocked(frame)
    if not frame or not frame.IsShown or not frame:IsShown() then return false end
    if frame.isDocked then return false end
    if frame.minimized then return false end
    local w, h = frame:GetWidth() or 0, frame:GetHeight() or 0
    return w > 20 and h > 20
end

local function SavedKey(index)
    return tostring(index) .. ":" .. GetName(index)
end

local function CursorScale(frame)
    local scale = frame and frame.GetEffectiveScale and frame:GetEffectiveScale()
    if type(scale) ~= "number" or scale <= 0 then
        scale = _G.UIParent and _G.UIParent:GetEffectiveScale() or 1
    end
    if type(scale) ~= "number" or scale <= 0 then return 1 end
    return scale
end

local function SafeWindowBounds(target)
    local root = _G.UIParent
    if not root then return 1500, 950 end
    local rootRight = root:GetRight() or (root:GetWidth() or 1920)
    local rootBottom = root:GetBottom() or 0
    local left, top = target:GetLeft(), target:GetTop()
    -- TOPLEFT stays in place. A bottom-right drag changes width to the right
    -- and height down, never the top edge or the left edge.
    local rightRoom = left and (rootRight - left - EDGE_MARGIN) or 1500
    local bottomRoom = top and (top - rootBottom - EDGE_MARGIN) or 950
    return max(MIN_WIDTH, min(2000, rightRoom)),
           max(MIN_HEIGHT, min(1200, bottomRoom))
end

local function PersistUndocked(pane)
    if not pane or pane.main or not IsUndocked(pane.target) then return end
    local target, i = pane.target, pane.index
    local width, height = floor(target:GetWidth() + 0.5), floor(target:GetHeight() + 0.5)
    if saved then
        saved.windows = saved.windows or {}
        saved.windows[SavedKey(i)] = {width = width, height = height}
    end
    -- Blizzard saves both dimensions and position for this particular window.
    if type(_G.FCF_SavePositionAndDimensions) == "function" then
        local ok = pcall(_G.FCF_SavePositionAndDimensions, target)
        if ok then return end
    end
    if type(_G.SetChatWindowSavedDimensions) == "function" then
        pcall(_G.SetChatWindowSavedDimensions, i, width, height)
    end
end

local function SetGlassySize(width, height)
    local core = GetGlassy()
    if not core then return false end
    local profile = core.db.profile
    if profile.frameWidth ~= width then
        profile.frameWidth = width
        core:Dispatch("Glassy/UPDATE_CONFIG", "frameWidth")
    end
    if profile.frameHeight ~= height then
        profile.frameHeight = height
        core:Dispatch("Glassy/UPDATE_CONFIG", "frameHeight")
    end
    return true
end

local function FinishDrag()
    local state = dragging
    if not state then return end
    dragging = nil
    if state.pane.main then
        local core = GetGlassy()
        if core then
            core:Dispatch("Glassy/UPDATE_CONFIG", "frameWidth")
            core:Dispatch("Glassy/UPDATE_CONFIG", "frameHeight")
        end
    else
        PersistUndocked(state.pane)
    end
end

local function StartDrag(pane)
    if dragging or InCombat() then return end
    if pane.main then
        if not GetGlassy() then return end
    elseif not IsUndocked(pane.target) then
        return
    end
    local target = pane.target
    local width, height
    if pane.main then
        local profile = GetGlassy().db.profile
        width = tonumber(profile.frameWidth) or target:GetWidth()
        height = tonumber(profile.frameHeight) or target:GetHeight()
    else
        width, height = target:GetWidth(), target:GetHeight()
        local left, top = target:GetLeft(), target:GetTop()
        local parent = _G.UIParent
        if not left or not top or not parent then return end
        local parentLeft, parentTop = parent:GetLeft() or 0, parent:GetTop() or 0
        -- Blizzard normally anchors detached frames relative to various edges.
        -- Stabilize TOPLEFT for this drag so height changes do not shift the tab.
        target:ClearAllPoints()
        target:SetPoint("TOPLEFT", parent, "TOPLEFT", left - parentLeft, top - parentTop)
        if type(target.SetUserPlaced) == "function" then target:SetUserPlaced(true) end
    end
    if not width or not height then return end
    local x, y = _G.GetCursorPosition()
    dragging = {pane = pane, x = x, y = y, width = width, height = height,
                lastWidth = width, lastHeight = height, scale = CursorScale(target)}
end

local function DragStep()
    local state = dragging
    if not state then return end
    if InCombat() or (not state.pane.main and not IsUndocked(state.pane.target)) then
        FinishDrag()
        return
    end
    local x, y = _G.GetCursorPosition()
    local maxWidth, maxHeight = SafeWindowBounds(state.pane.target)
    local width = floor(min(max(MIN_WIDTH, state.width + (x - state.x) / state.scale), maxWidth) + 0.5)
    local height = floor(min(max(MIN_HEIGHT, state.height + (state.y - y) / state.scale), maxHeight) + 0.5)
    if width == state.lastWidth and height == state.lastHeight then return end
    state.lastWidth, state.lastHeight = width, height
    if state.pane.main then
        SetGlassySize(width, height)
    else
        state.pane.target:SetSize(width, height)
    end
end

local function CreatePane(target, index, isMain)
    local overlay = _G.CreateFrame("Frame", nil, _G.UIParent)
    overlay:SetAllPoints(target)
    overlay:SetFrameStrata("DIALOG")
    overlay:SetFrameLevel(max(10, (target:GetFrameLevel() or 1) + 12))
    overlay:EnableMouse(false)

    local grip = _G.CreateFrame("Button", nil, overlay)
    grip:SetSize(17, 17)
    grip:SetPoint("BOTTOMRIGHT", overlay, "BOTTOMRIGHT", -2, 2)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    grip:SetAlpha(0.62)

    -- Three subtle diagonal marks: no oversized border, label, or edit mode.
    for n = 0, 2 do
        local line = grip:CreateTexture(nil, "OVERLAY")
        line:SetColorTexture(0.72, 0.80, 0.89, 0.95)
        line:SetSize(1.5, 5 + n * 3)
        line:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", -4 - n * 4, 3)
        if type(line.SetRotation) == "function" then line:SetRotation(math.pi / 4) end
    end
    local pane = {target = target, overlay = overlay, grip = grip,
                  main = isMain, index = index}
    grip:SetScript("OnDragStart", function() StartDrag(pane) end)
    grip:SetScript("OnDragStop", function() if dragging and dragging.pane == pane then FinishDrag() end end)
    grip:SetScript("OnMouseUp", function() if dragging and dragging.pane == pane then FinishDrag() end end)
    grip:SetScript("OnEnter", function(self)
        self:SetAlpha(1)
        if _G.GameTooltip then
            _G.GameTooltip:SetOwner(self, "ANCHOR_TOP")
            _G.GameTooltip:AddLine("채팅창 크기 조절", 0.9, 0.95, 1)
            _G.GameTooltip:AddLine("오른쪽 아래로 드래그", 0.8, 0.85, 0.91)
            _G.GameTooltip:Show()
        end
    end)
    grip:SetScript("OnLeave", function(self)
        self:SetAlpha(0.62)
        if _G.GameTooltip then _G.GameTooltip:Hide() end
    end)
    overlay:Hide()
    return pane
end

local function RestoreUndocked(pane)
    if not saved or not saved.windows or InCombat() or loginAge < 1.0 then return end
    if not IsUndocked(pane.target) then return end
    local key = SavedKey(pane.index)
    if restored[key] then return end
    -- Restore once per window after Blizzard/Glassy have created their frames.
    -- Never continuously override a player resizing the window elsewhere.
    local entry = saved.windows[key]
    if entry then
        local w, h = tonumber(entry.width), tonumber(entry.height)
        if w and h and w >= MIN_WIDTH and h >= MIN_HEIGHT then
            pane.target:SetSize(min(w, 2000), min(h, 1200))
        end
    end
    restored[key] = true
end

local function ScanWindows()
    local limit = max(10, tonumber(_G.NUM_CHAT_WINDOWS) or 10) + 20
    for i = 2, limit do
        local target = _G["ChatFrame" .. i]
        if target then
            local old = panes[i]
            if old and old.target ~= target then
                old.overlay:Hide()
                panes[i] = nil
                old = nil
            end
            if not old and IsUndocked(target) then
                panes[i] = CreatePane(target, i, false)
            end
            if panes[i] then RestoreUndocked(panes[i]) end
        end
    end
end

local function TryStart()
    if not started then
        if not GetGlassy() or not _G.GlassyFrame or not _G.UIParent then return end
        if not _G.GlassyFrame.GetWidth then return end
        if type(_G.GlassyDragResizeDB) ~= "table" then _G.GlassyDragResizeDB = {} end
        saved = _G.GlassyDragResizeDB
        if type(saved.windows) ~= "table" then saved.windows = {} end
        mainPane = CreatePane(_G.GlassyFrame, 1, true)
        started = true
    end
    ScanWindows()
end

local function UpdateHover(pane)
    if not pane then return end
    local visible = pane.main and pane.target:IsShown() or IsUndocked(pane.target)
    local hovered = visible and (pane.target:IsMouseOver() or pane.grip:IsMouseOver())
    local active = dragging and dragging.pane == pane
    if (hovered or active) and not InCombat() then
        pane.overlay:Show()
    else
        pane.overlay:Hide()
    end
end

local driver = _G.CreateFrame("Frame")
driver:RegisterEvent("PLAYER_LOGIN")
driver:RegisterEvent("PLAYER_ENTERING_WORLD")
driver:RegisterEvent("UPDATE_CHAT_WINDOWS")
driver:SetScript("OnEvent", TryStart)
driver:SetScript("OnUpdate", function(_, dt)
    loginAge = loginAge + dt
    if dragging then DragStep() end
    elapsedScan = elapsedScan + dt
    if elapsedScan >= 0.5 then elapsedScan = 0; TryStart() end
    elapsedHover = elapsedHover + dt
    if elapsedHover < 0.08 then return end
    elapsedHover = 0
    if not started then return end
    UpdateHover(mainPane)
    for _, pane in pairs(panes) do UpdateHover(pane) end
end)

_G.SLASH_GLASSYDRAGRESIZE1 = "/gdr"
_G.SLASH_GLASSYDRAGRESIZE2 = "/채팅크기"
_G.SlashCmdList.GLASSYDRAGRESIZE = function(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$")
    if arg == "status" then
        local n = 0
        for _, pane in pairs(panes) do if IsUndocked(pane.target) then n = n + 1 end end
        Inform("Glassy=" .. tostring(GetGlassy() ~= nil) .. ", 분리 채팅창=" .. n)
    else
        Inform("각 채팅창에 마우스를 올리고 우측 하단 작은 손잡이를 드래그하세요.")
    end
end

Glassy Drag Resize 1.1.0 - WoW Forever (Interface 16001)

설치:
- Glassy가 설치되어 있어야 합니다.
- GlassyDragResize 폴더를 _forever_/Interface/AddOns에 설치합니다.
- 게임을 재시작하거나 /reload 합니다.

사용:
- 기본 채팅창 또는 바깥으로 분리한 채팅창에 마우스를 올립니다.
- 오른쪽 아래 구석에 나타나는 작은 사선 손잡이를 왼쪽 클릭한 채 드래그합니다.
- 오른쪽으로 드래그하면 넓어지고, 아래로 드래그하면 높아집니다.
- 분리한 창은 각각 독립적으로 조절됩니다.
- /gdr status 로 Glassy와 분리 창 감지 상태를 확인할 수 있습니다.

저장:
- 메인 채팅창: Glassy 프로필의 frameWidth/frameHeight에 저장됩니다.
- 분리 채팅창: Blizzard chat saved dimensions/position과
  GlassyDragResizeDB(캐릭터별 백업)에 저장됩니다.
- 일반 채팅창의 메시지/탭 이름 및 EUI 설정은 변경하지 않습니다.

변경 사항:
- 이전의 상단 '크기' 버튼 / + 버튼 / 조절 모드 / 노란 테두리 제거.
- 탭 버튼 크기가 아니라 실제로 분리된 ChatFrame의 크기를 변경.
- 우하단 손잡이 및 TOPLEFT 고정 드래그, 창별 저장/복원 추가.

주의:
- 전투 중에는 변경하지 않습니다.
- Glassy 또는 EUI의 채팅 리사이징 기능이 동시에 제어하면 충돌할 수 있으므로
  기존의 별도 채팅 크기조절 애드온은 비활성화하십시오.
- WoW Forever 실제 클라이언트 및 Glassy 설치 버전과의 실사용 확인이 필요합니다.

-- Deterministic native-widget test double. This validates callback/data wiring,
-- not WoW rendering, pointer capture, font metrics, or game API behavior.
local M={objects={},names={}}
local Widget={}
local unpackValues=table.unpack or unpack
local function new(kind,name,parent)
 local o=setmetatable({kind=kind,name=name,parent=parent,shown=true,enabled=true,width=0,height=0,scale=1,scripts={},points={},children={},regions={},value=0,low=0,high=1,text=""},{__index=Widget})
 M.objects[#M.objects+1]=o
 if parent then parent.children[#parent.children+1]=o end
 if name then M.names[name]=o;_G[name]=o end
 return o
end
function Widget:SetSize(w,h) self.width=w;self.height=h;if self.scripts.OnSizeChanged then self.scripts.OnSizeChanged(self,w,h) end end
function Widget:SetWidth(w) self:SetSize(w,self.height) end
function Widget:SetHeight(h) self:SetSize(self.width,h) end
function Widget:GetWidth() return self.width end
function Widget:GetHeight() return self.height end
function Widget:SetPoint(...) self.points[#self.points+1]={...} end
function Widget:GetPoint(i) return unpackValues(self.points[i or 1] or {}) end
function Widget:ClearAllPoints() self.points={};self.allPoints=nil end
function Widget:SetAllPoints(target) self.allPoints=target or self.parent end
function Widget:CreateTexture(name,layer) local r=new("Texture",name,self);r.layer=layer;self.regions[#self.regions+1]=r;return r end
function Widget:CreateFontString(name,layer,font) local r=new("FontString",name,self);r.layer=layer;r.font=font;self.regions[#self.regions+1]=r;return r end
function Widget:SetScript(event,fn) self.scripts[event]=fn end
function Widget:GetScript(event) return self.scripts[event] end
function Widget:HookScript(event,fn) local prior=self.scripts[event];self.scripts[event]=function(...) if prior then prior(...) end;fn(...) end end
function Widget:Show() local changed=not self.shown;self.shown=true;if changed and self.scripts.OnShow then self.scripts.OnShow(self) end end
function Widget:Hide() local changed=self.shown;self.shown=false;if changed and self.scripts.OnHide then self.scripts.OnHide(self) end end
function Widget:SetShown(v) if v then self:Show() else self:Hide() end end
function Widget:IsShown() return self.shown end
function Widget:IsVisible() return self.shown and (not self.parent or self.parent:IsVisible()) end
function Widget:Enable() self.enabled=true end
function Widget:Disable() self.enabled=false end
function Widget:SetEnabled(v) self.enabled=v end
function Widget:IsEnabled() return self.enabled end
function Widget:SetText(s) self.text=tostring(s or "");if self.fontString then self.fontString:SetText(s) end;if self.kind=="EditBox" and self.scripts.OnTextChanged then self.scripts.OnTextChanged(self,false) end end
function Widget:GetText() return self.text end
function Widget:SetFontString(f) self.fontString=f end
function Widget:GetFontString() return self.fontString end
function Widget:GetStringHeight()
 local lines=1;for _ in self.text:gmatch("\n") do lines=lines+1 end
 -- Conservative wrapping estimate for text-scroll behavior only.
 if self.width>0 and self.wordWrap~=false then lines=math.max(lines,math.ceil(#self.text/math.max(1,self.width/5))) end
 return lines*(self.fontSize or 13)+(lines-1)*(self.spacing or 0)
end
function Widget:GetStringWidth() return #self.text*6 end
function Widget:SetFont(path,size,flags) self.font=path;self.fontSize=size;self.fontFlags=flags end
function Widget:GetFont() return self.font or "Fonts/test.ttf",self.fontSize or 12,self.fontFlags end
function Widget:SetTextColor(...) self.textColor={...} end
function Widget:SetColorTexture(...) self.color={...} end
function Widget:SetVertexColor(...) self.vertexColor={...} end
function Widget:SetTexture(texture) self.texture=texture end
function Widget:SetTexCoord(...) self.texcoord={...} end
function Widget:SetAlpha(a) self.alpha=a end
function Widget:SetScale(s) self.scale=s end
function Widget:GetScale() return self.scale end
function Widget:GetEffectiveScale() return self.scale*(self.parent and self.parent:GetEffectiveScale() or 1) end
function Widget:GetCenter() return self.width/2,self.height/2 end
function Widget:SetChecked(v) self.checked=v end
function Widget:GetChecked() return self.checked end
function Widget:SetMinMaxValues(lo,hi) self.low=lo;self.high=hi;self:SetValue(self.value) end
function Widget:GetMinMaxValues() return self.low,self.high end
function Widget:SetValue(v)
 local value=math.max(self.low,math.min(self.high,v));local changed=value~=self.value;self.value=value
 if changed and self.scripts.OnValueChanged then self.scripts.OnValueChanged(self,value) end
end
function Widget:GetValue() return self.value end
function Widget:SetThumbTexture(t) self.thumb=type(t)=="table" and t or new("Texture",nil,self);self.thumb.texture=t end
function Widget:GetThumbTexture() return self.thumb end
function Widget:SetScrollChild(c) self.scrollChild=c end
function Widget:GetScrollChild() return self.scrollChild end
function Widget:SetVerticalScroll(v) self.scroll=v end
function Widget:GetVerticalScroll() return self.scroll or 0 end
function Widget:SetSpacing(v) self.spacing=v end
function Widget:SetWordWrap(v) self.wordWrap=v end
function Widget:SetMaxLines(v) self.maxLines=v end
function Widget:SetJustifyH(v) self.justifyH=v end
function Widget:SetJustifyV(v) self.justifyV=v end
function Widget:SetFocus() self.focus=true;if self.scripts.OnEditFocusGained then self.scripts.OnEditFocusGained(self) end end
function Widget:ClearFocus() self.focus=false;if self.scripts.OnEditFocusLost then self.scripts.OnEditFocusLost(self) end end
function Widget:HasFocus() return self.focus==true end
function Widget:SetNormalTexture(t) self.normalTexture=t end
function Widget:SetPushedTexture(t) self.pushedTexture=t end
function Widget:SetHighlightTexture(t) self.highlightTexture=t end
function Widget:SetDisabledTexture(t) self.disabledTexture=t end
function Widget:Click(mouse)
 if not self.enabled then return false end
 if self.kind=="CheckButton" then self.checked=not self.checked end
 if self.scripts.OnClick then self.scripts.OnClick(self,mouse or "LeftButton") end
 return true
end
function Widget:Wheel(delta) if self.scripts.OnMouseWheel then self.scripts.OnMouseWheel(self,delta) end end
function Widget:SetOwner(...) self.owner={...} end
function Widget:AddLine(text) self.lines=self.lines or {};self.lines[#self.lines+1]=text end
function Widget:AddDoubleLine(a,b) self:AddLine(a.." "..b) end
function Widget:ClearLines() self.lines={} end
function Widget:SetParent(parent) self.parent=parent end
function Widget:GetParent() return self.parent end
function Widget:GetFrameLevel() return self.frameLevel or 1 end
local inert={"SetClampedToScreen","SetMovable","EnableMouse","EnableMouseWheel","RegisterForDrag","SetFrameStrata","SetToplevel","StartMoving","StopMovingOrSizing","SetAutoFocus","SetOrientation","SetValueStep","SetObeyStepOnDrag","SetNormalFontObject","SetHighlightFontObject","SetDisabledFontObject","SetFontObject","SetDrawLayer","SetFrameLevel","SetHitRectInsets","RegisterForClicks","RegisterEvent","UnregisterEvent","UnregisterAllEvents","SetBackdrop","SetBackdropColor","SetBackdropBorderColor","SetResizable","SetResizeBounds","SetMinResize","SetMaxResize","SetUserPlaced","SetClipsChildren","SetTextInsets"}
for _,name in ipairs(inert) do Widget[name]=function(self,...) self[name.."Args"]={...} end end
function M.install()
 _G.unpack=unpackValues
 _G.CreateFrame=function(kind,name,parent,template) local f=new(kind,name,parent);f.template=template;return f end
 _G.UIParent=new("Frame","UIParent");UIParent:SetSize(1920,1080)
 _G.GameTooltip=new("GameTooltip","GameTooltip")
 _G.UnitName=function()return "테스트 캐릭터"end
 _G.UnitFactionGroup=function()return "Alliance"end
 _G.UnitLevel=function()return 55 end
 _G.UnitClass=function()return "주술사","SHAMAN",7 end
 _G.InCombatLockdown=function()return false end
 _G.IsShiftKeyDown=function()return false end
 _G.DEFAULT_CHAT_FRAME={AddMessage=function()end}
 _G.SlashCmdList={}
 return M
end
function M.find(fn) for _,o in ipairs(M.objects) do if fn(o) then return o end end end
function M.all(fn) local a={};for _,o in ipairs(M.objects) do if fn(o) then a[#a+1]=o end end;return a end
function M.button(text) return M.find(function(o)return (o.kind=="Button" or o.kind=="CheckButton") and o:GetText()==text end) end
function M.visibleText(parent)
 local out={}
 local function visit(o) if not o.shown then return end;if o.kind=="FontString" then out[#out+1]=o.text end;for _,c in ipairs(o.children) do visit(c) end end
 visit(parent or UIParent);return table.concat(out,"\n")
end
return M

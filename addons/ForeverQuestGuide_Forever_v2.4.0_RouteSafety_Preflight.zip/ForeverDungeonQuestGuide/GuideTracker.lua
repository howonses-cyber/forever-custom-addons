local addon,G = ...
-- In-world guide: grounded written directions live in this window, while the
-- independent real-time navigation addon continues to own its arrow/path.
local hud,back,heading,progress,current,distance,nextOne,nextTwo,source
local scroll,scrollChild,directions,collapseButton,configButton,resizeGrip
local progressBar,stageLabel,footerDivider,scrollHint,hudCount,returnButton
local phaseText={accept="수락",objective="수행",turnin="보고",entrance="입구",inside="던전"}
local phaseColor={accept="83d4fa",objective="f6ca77",turnin="84dba0",entrance="f4ad7b",inside="c5b9f5"}
local settings,opacityLabel,opacitySlider,widthBox,heightBox
local buttons={}
local resizing=false
local lastStepKey=nil
local lastDirectionText=nil
local lastFeedback=nil
local MINW,MAXW,MINH,MAXH=420,760,360,700
local function clamp(v,min,max)
 v=tonumber(v) or min
 if v<min then return min end
 if v>max then return max end
 return v
end
local function button(parent,text,width,height,action)
 return G.UIButton(parent,text,width,height,action)
end
local function font(parent,template)
 local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlightSmall")
 f:SetJustifyH("LEFT");f:SetJustifyV("TOP")
 return f
end
local function savePosition()
 if not hud or not G.db then return end
 local x,y=hud:GetLeft(),hud:GetTop()
 local px,py=UIParent:GetLeft() or 0,UIParent:GetTop() or 0
 if x and y then G.db.hudPosition={anchor="TOPLEFT",x=x-px,y=y-py} end
end
local function applyOpacity()
 if not hud or not G.db then return end
 local alpha=clamp(G.db.hudOpacity,.15,1)
 back:SetColorTexture(.047,.060,.078,alpha)
 if hud.goldBar then hud.goldBar:SetColorTexture(.93,.71,.27,math.max(.50,alpha)) end
 if hud.divider then hud.divider:SetColorTexture(.33,.31,.22,math.max(.45,alpha)) end
 if opacityLabel then opacityLabel:SetText("배경 투명도: "..tostring(math.floor((1-alpha)*100+.5)).."%") end
end
local function saveSize()
 if not hud or not G.db or G.db.hudCollapsed then return end
 G.db.hudSize={width=math.floor(clamp(hud:GetWidth(),MINW,MAXW)+.5),
  height=math.floor(clamp(hud:GetHeight(),MINH,MAXH)+.5)}
end
local function layout()
 if not hud then return end
 local w=math.max(MINW,hud:GetWidth() or MINW)
 heading:SetWidth(w-210)
 progress:SetWidth(w-28)
 stageLabel:SetWidth(w-28)
 current:SetWidth(w-29)
 distance:SetWidth(w-29)
 nextOne:SetWidth(w-29)
 nextTwo:SetWidth(w-29)
 source:SetWidth(w-29-((G.HasSuspendedGuide and G.HasSuspendedGuide()) and 102 or 0))
 -- Size buttons from available width: no overlap with the resize grip.
 local weights={1.0,1.65,.8,1.0,.83,1.1}
 local sum=6.38;local available=w-34-5*5
 local x=10
 for i,b in ipairs(buttons) do
  local bw=math.floor(available*weights[i]/sum)
  b:ClearAllPoints();b:SetSize(bw,28);b:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",x,11);x=x+bw+5
 end
 if scroll and scrollChild and directions then
  local width=math.max(300,w-46)
  scrollChild:SetWidth(width)
  directions:SetWidth(width-2)
  -- String height updates after width changes; keep full text scrollable.
  local path,sizeFont,flags=directions:GetFont()
  local desired=G.db and G.db.hudTextSize or 12
  if path and sizeFont~=desired then pcall(directions.SetFont,directions,path,desired,flags or "") end
  -- Measure after removing old height limit.
  directions:SetHeight(0)
  local size=math.max(1,math.ceil((directions:GetStringHeight() or 0)+8))
  directions:SetHeight(size)
  scrollChild:SetHeight(size)
  local maxScroll=math.max(0,size-(scroll:GetHeight() or 0))
  if scroll:GetVerticalScroll()>maxScroll then scroll:SetVerticalScroll(maxScroll) end
  if scrollHint then scrollHint:SetText(maxScroll>1 and ("휠: 상세 안내 · "..math.floor(100*clamp(scroll:GetVerticalScroll()/maxScroll,0,1)+.5).."%") or "") end
 end
 if settings and settings:IsShown() then
  if widthBox and not (widthBox.HasFocus and widthBox:HasFocus()) then widthBox:SetText(tostring(math.floor(hud:GetWidth()+.5))) end
  if heightBox and not (heightBox.HasFocus and heightBox:HasFocus()) then heightBox:SetText(tostring(math.floor((G.db and G.db.hudSize and G.db.hudSize.height) or hud:GetHeight()+.5))) end
 end
end
local function stopSizing()
 if not resizing or not hud then return end
 hud:StopMovingOrSizing()
 resizing=false
 local w,h=clamp(hud:GetWidth(),MINW,MAXW),clamp(hud:GetHeight(),MINH,MAXH)
 hud:SetSize(w,h)
 saveSize();layout();savePosition()
end
function G.HUDSetSize(w,h)
 if not G.db or not hud then return false end
 w,h=clamp(w,MINW,MAXW),clamp(h,MINH,MAXH)
 G.db.hudSize={width=math.floor(w+.5),height=math.floor(h+.5)}
 if G.db.hudCollapsed then hud:SetWidth(w) else hud:SetSize(w,h) end
 layout()
 return true
end
function G.HUDSetOpacity(value)
 if not G.db then return false end
 local amount=clamp(value,0,85)
 G.db.hudOpacity=1-amount/100
 applyOpacity()
 return true
end
local function updateExpandedState()
 if not hud or not G.db then return end
 local collapsed=G.db.hudCollapsed==true
 if collapsed and resizing then stopSizing() end
 local height=(G.db.hudSize and G.db.hudSize.height) or 455
 local target=collapsed and 42 or clamp(height,MINH,MAXH)
 if not resizing and math.abs(hud:GetHeight()-target)>.5 then hud:SetHeight(target) end
 for _,f in ipairs({progressBar,progress,stageLabel,current,scroll,distance,nextOne,nextTwo,source,footerDivider,scrollHint,resizeGrip}) do
  if collapsed then f:Hide() else f:Show() end
 end
 for _,b in ipairs(buttons) do
  if collapsed then b:Hide() else b:Show() end
 end
 if returnButton then if not collapsed and G.HasSuspendedGuide and G.HasSuspendedGuide() then returnButton:Show() else returnButton:Hide() end end
 if collapseButton then collapseButton:SetText(collapsed and "+" or "-") end
 if collapsed and settings then settings:Hide() end
 if not collapsed then layout() end
end
local function configFrame()
 if settings then return settings end
 settings=CreateFrame("Frame","ForeverDungeonQuestGuideHUDSettings",UIParent)
 settings:SetSize(335,289)
 settings:SetFrameStrata("DIALOG");settings:SetToplevel(true)
 settings:SetClampedToScreen(true)
 settings:SetMovable(true);settings:EnableMouse(true)
 settings:RegisterForDrag("LeftButton")
 settings:SetScript("OnDragStart",function(self)
  if not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
 end)
 settings:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 settings:SetPoint("TOPLEFT",hud,"TOPRIGHT",8,0)
 local bg=settings:CreateTexture(nil,"BACKGROUND")
 bg:SetAllPoints();bg:SetColorTexture(.065,.071,.085,.97)
 local rim=settings:CreateTexture(nil,"BORDER")
 rim:SetPoint("TOPLEFT",settings,"TOPLEFT",0,0)
 rim:SetPoint("TOPRIGHT",settings,"TOPRIGHT",0,0)
 rim:SetHeight(3);rim:SetColorTexture(.92,.69,.28,1)
 local title=font(settings,"GameFontNormal")
 title:SetPoint("TOPLEFT",settings,"TOPLEFT",13,-14)
 title:SetText("안내창 설정")
 local close=button(settings,"X",28,24,function()settings:Hide()end)
 close:SetPoint("TOPRIGHT",settings,"TOPRIGHT",-8,-9)
 opacityLabel=font(settings,"GameFontHighlightSmall")
 opacityLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",15,-48)
 -- A stable global slider name avoids template-created texture name collisions.
 local okSlider,created=pcall(CreateFrame,"Slider","ForeverDungeonQuestGuideHUDOpacitySlider",settings,"OptionsSliderTemplate")
 if okSlider and created then opacitySlider=created
 else
  opacitySlider=CreateFrame("Slider","ForeverDungeonQuestGuideHUDOpacitySlider",settings)
  if type(opacitySlider.SetOrientation)=="function" then opacitySlider:SetOrientation("HORIZONTAL") end
  if type(opacitySlider.SetThumbTexture)=="function" then
   opacitySlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  end
 end
 opacitySlider:SetPoint("TOPLEFT",settings,"TOPLEFT",29,-75)
 opacitySlider:SetSize(265,17)
 opacitySlider:SetMinMaxValues(0,85)
 opacitySlider:SetValueStep(5)
 if type(opacitySlider.SetObeyStepOnDrag)=="function" then opacitySlider:SetObeyStepOnDrag(true) end
 opacitySlider:SetScript("OnValueChanged",function(self,v)
  if G.db then G.HUDSetOpacity(math.floor(v/5+.5)*5) end
 end)
 local note=font(settings,"GameFontHighlightSmall")
 note:SetPoint("TOPLEFT",settings,"TOPLEFT",15,-105)
 note:SetWidth(307);note:SetText("배경만 투명해지며 글자는 선명하게 유지됩니다.")
 local wLabel=font(settings,"GameFontHighlightSmall")
 wLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",17,-135)
 wLabel:SetText("가로")
 local hLabel=font(settings,"GameFontHighlightSmall")
 hLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",165,-135)
 hLabel:SetText("세로")
 local function entry(x)
  local edit=CreateFrame("EditBox",nil,settings,"InputBoxTemplate")
  edit:SetSize(83,24);edit:SetPoint("TOPLEFT",settings,"TOPLEFT",x,-153)
  edit:SetAutoFocus(false);edit:SetMaxLetters(4)
  edit:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
  return edit
 end
 widthBox=entry(57);heightBox=entry(201)
 local function apply()
  G.HUDSetSize(tonumber(widthBox:GetText()) or hud:GetWidth(),
   tonumber(heightBox:GetText()) or (G.db.hudSize and G.db.hudSize.height) or 455)
  widthBox:ClearFocus();heightBox:ClearFocus()
 end
 widthBox:SetScript("OnEnterPressed",apply)
 heightBox:SetScript("OnEnterPressed",apply)
 local sizeLabel=font(settings,"GameFontHighlightSmall")
 sizeLabel:SetPoint("TOPLEFT",settings,"TOPLEFT",16,-188);sizeLabel:SetWidth(175)
 local function textSize(delta)
  G.db.hudTextSize=clamp((G.db.hudTextSize or 12)+delta,10,17)
  sizeLabel:SetText("안내 글자 크기: "..G.db.hudTextSize);layout()
 end
 local minus=button(settings,"-",45,24,function()textSize(-1)end);minus:SetPoint("TOPLEFT",settings,"TOPLEFT",191,-182)
 local plus=button(settings,"+",45,24,function()textSize(1)end);plus:SetPoint("LEFT",minus,"RIGHT",8,0)
 local applyButton=button(settings,"적용",94,25,apply)
 applyButton:SetPoint("BOTTOMLEFT",settings,"BOTTOMLEFT",16,14)
 local resetButton=button(settings,"초기값",93,25,function()
  G.HUDSetSize(460,455);G.HUDSetOpacity(5);G.db.hudTextSize=12;textSize(0)
  opacitySlider:SetValue(5)
 end)
 resetButton:SetPoint("LEFT",applyButton,"RIGHT",7,0)
 local hideButton=button(settings,"닫기",91,25,function()settings:Hide()end)
 hideButton:SetPoint("LEFT",resetButton,"RIGHT",7,0)
 local help=font(settings,"GameFontHighlightSmall")
 help:SetPoint("BOTTOMLEFT",settings,"BOTTOMLEFT",13,47)
 help:SetWidth(305);help:SetText("오른쪽 아래 모서리를 드래그해 크기를 조절하세요.")
 settings:SetScript("OnShow",function()
  textSize(0)
  opacitySlider:SetValue(math.floor((1-G.db.hudOpacity)*100+.5))
  widthBox:SetText(tostring(math.floor(hud:GetWidth()+.5)))
  heightBox:SetText(tostring(math.floor((G.db.hudSize and G.db.hudSize.height) or 455)+.5))
  applyOpacity()
 end)
 settings:Hide()
 return settings
end
function G.ToggleHUDSettings()
 if not hud then return false end
 local config=configFrame()
 if config:IsShown() then config:Hide() else config:Show() end
 return true
end
local function initialize()
 if hud or not UIParent then return end
 hud=CreateFrame("Frame","ForeverDungeonQuestGuideHUD",UIParent)
 hud:SetSize((G.db and G.db.hudSize and G.db.hudSize.width) or 460,
  (G.db and G.db.hudSize and G.db.hudSize.height) or 455)
 local pos=G.db and G.db.hudPosition
 if pos and pos.anchor=="TOPLEFT" then
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",pos.x or 32,pos.y or -195)
 elseif pos then
  hud:SetPoint("TOP",UIParent,"TOP",pos.x or 0,pos.y or -125)
 else
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",30,-210)
 end
 hud:SetClampedToScreen(true)
 hud:SetFrameStrata("MEDIUM");hud:SetToplevel(true)
 hud:SetMovable(true);hud:EnableMouse(true);hud:RegisterForDrag("LeftButton")
 if type(hud.SetResizable)=="function" then pcall(hud.SetResizable,hud,true) end
 if type(hud.SetMinResize)=="function" then pcall(hud.SetMinResize,hud,MINW,MINH) end
 if type(hud.SetMaxResize)=="function" then pcall(hud.SetMaxResize,hud,MAXW,MAXH) end
 if type(hud.SetResizeBounds)=="function" then pcall(hud.SetResizeBounds,hud,MINW,MINH,MAXW,MAXH) end
 back=hud:CreateTexture(nil,"BACKGROUND")
 back:SetAllPoints()
 local border=hud:CreateTexture(nil,"BORDER")
 border:SetPoint("TOPLEFT",hud,"TOPLEFT",0,0)
 border:SetPoint("TOPRIGHT",hud,"TOPRIGHT",0,0)
 border:SetHeight(3)
 hud.goldBar=border
 local divider=hud:CreateTexture(nil,"BORDER")
 divider:SetPoint("TOPLEFT",hud,"TOPLEFT",10,-35)
 divider:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-10,-35)
 divider:SetHeight(1)
 hud.divider=divider
 hud:SetScript("OnDragStart",function(self)
  if not (InCombatLockdown and InCombatLockdown()) and not resizing then self:StartMoving() end
 end)
 hud:SetScript("OnDragStop",function(self)self:StopMovingOrSizing();savePosition()end)
 hud:SetScript("OnHide",function(self)
  if resizing then stopSizing() end
  self:StopMovingOrSizing()
  if settings then settings:Hide() end
 end)
 hud:SetScript("OnMouseUp",function()if resizing then stopSizing()end end)
 hud:SetScript("OnUpdate",function()
  if resizing and type(IsMouseButtonDown)=="function" and not IsMouseButtonDown("LeftButton") then stopSizing() end
 end)
 heading=font(hud,"GameFontNormal")
 heading:SetPoint("TOPLEFT",hud,"TOPLEFT",13,-12)
 heading:SetHeight(25);heading:SetText(G.displayName or "포에버 퀘스트 가이드")
 hudCount=font(hud,"GameFontHighlightSmall");hudCount:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-111,-14);hudCount:SetWidth(90);hudCount:SetJustifyH("RIGHT");hudCount:SetHeight(18)
 progressBar=G.UIProgress(hud);progressBar:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-39);progressBar:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-12,-39);progressBar:SetHeight(5)
 progress=font(hud,"GameFontHighlightSmall")
 progress:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-48);progress:SetHeight(17)
 stageLabel=font(hud,"GameFontHighlightSmall");stageLabel:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-67);stageLabel:SetHeight(17)
 current=font(hud,"GameFontHighlight")
 current:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-86);current:SetHeight(36)
 if current.SetMaxLines then current:SetMaxLines(2) end
 scroll=CreateFrame("ScrollFrame",nil,hud)
 scroll:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-125)
 scroll:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-14,127)
 scroll:EnableMouseWheel(true)
 scroll:SetScript("OnMouseWheel",function(self,delta)
  local maxScroll=math.max(0,(scrollChild and scrollChild:GetHeight() or 0)-(self:GetHeight() or 0))
  self:SetVerticalScroll(clamp(self:GetVerticalScroll()-delta*34,0,maxScroll))
  if scrollHint and maxScroll>1 then scrollHint:SetText("휠: 상세 안내 · "..math.floor(100*clamp(self:GetVerticalScroll()/maxScroll,0,1)+.5).."%") end
 end)
 scrollChild=CreateFrame("Frame",nil,scroll)
 scrollChild:SetSize(382,240);scroll:SetScrollChild(scrollChild)
 directions=font(scrollChild,"GameFontHighlightSmall")
 directions:SetPoint("TOPLEFT",scrollChild,"TOPLEFT",0,0)
 directions:SetWidth(375)
 if type(directions.SetSpacing)=="function" then directions:SetSpacing(3) end
 directions:SetText("")
 footerDivider=hud:CreateTexture(nil,"BORDER");footerDivider:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,111);footerDivider:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-12,111);footerDivider:SetHeight(1);footerDivider:SetColorTexture(.26,.33,.39,.95)
 scrollHint=font(hud,"GameFontDisableSmall");scrollHint:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-15,112);scrollHint:SetJustifyH("RIGHT");scrollHint:SetWidth(155);scrollHint:SetHeight(15)
 distance=font(hud,"GameFontNormalSmall")
 distance:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,91);distance:SetHeight(19)
 nextOne=font(hud,"GameFontHighlightSmall")
 nextOne:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,74);nextOne:SetHeight(16)
 nextTwo=font(hud,"GameFontHighlightSmall")
 nextTwo:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,58);nextTwo:SetHeight(16)
 source=font(hud,"GameFontHighlightSmall")
 source:SetPoint("BOTTOMLEFT",hud,"BOTTOMLEFT",12,42);source:SetHeight(16)
 returnButton=button(hud,"기존 동선 복귀",98,20,function()G.ResumeSuspendedGuide()end)
 returnButton:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-14,41);returnButton:Hide()
 for _,f in ipairs({distance,nextOne,nextTwo,source}) do if f.SetMaxLines then f:SetMaxLines(1) end end
 collapseButton=button(hud,"-",29,26,function()
  if G.db then G.db.hudCollapsed=not G.db.hudCollapsed;updateExpandedState() end
 end)
 collapseButton:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-77,-8)
 configButton=button(hud,"안내창 설정",43,26,function()G.ToggleHUDSettings()end)
 configButton:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-33,-8)
 -- Compact title bar: settings uses an icon-like short label below to avoid overlap.
 configButton:SetText("설정")
 local close=button(hud,"X",27,26,function()
  if G.db then G.db.hudHidden=true;hud:Hide() end
 end)
 close:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-3,-8)
 buttons={
  button(hud,"< 이전",65,25,function()G.NextGuide(-1,false)end),
  button(hud,"다음 확인",90,25,function()if G.GuideViewingHistory() then G.ReturnToActiveGuide() else G.NextGuide(1,true) end end),
  button(hud,"지도",48,25,function()
   if G.GuideViewingHistory() then G.Print("기록 보기 중: 현재 단계 버튼으로 돌아가세요.");return end
   local st=G.CurrentStep()
   G.OpenGuideStepMap(st)
  end),
  button(hud,"동선표",56,25,function()G.TogglePlanWindow()end),
  button(hud,"전체",42,25,function()G.ShowUI(true)end),
  button(hud,"나중에",60,25,function()G.DeferCurrentQuest()end)
 }
 buttons[2]._fdqStyle="primary";G.UIButtonState(buttons[2],true)
 local tips={"이전 단계 기록 열람 (실제 경로 유지)","실제 수락·수행·보고 상태 확인 / 기록에서 현재로 복귀","현재 목적지 지도 표시","전체 방문 순서 확인","퀘스트 검색 및 목록","현재 퀘스트를 완료 처리하지 않고 보류"}
 for i,b in ipairs(buttons) do
  local tip=tips[i]
  b:SetScript("OnEnter",function(self)if GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetText(tip);GameTooltip:Show()end end)
  b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 -- Visible corner handle does not replace or intercept the right-hand route addon.
 resizeGrip=CreateFrame("Button",nil,hud)
 resizeGrip:SetSize(18,18)
 resizeGrip:SetPoint("BOTTOMRIGHT",hud,"BOTTOMRIGHT",-1,1)
 resizeGrip:EnableMouse(true)
 local gripTexture=resizeGrip:CreateTexture(nil,"OVERLAY")
 gripTexture:SetAllPoints()
 gripTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
 resizeGrip:SetScript("OnMouseDown",function(self,mouse)
  if mouse~="LeftButton" or resizing or G.db.hudCollapsed then return end
  if InCombatLockdown and InCombatLockdown() then return end
  if type(hud.StartSizing)=="function" then
   local ok=pcall(hud.StartSizing,hud,"BOTTOMRIGHT")
   if ok then resizing=true
   else G.Print("드래그로 크기를 바꿀 수 없습니다. 안내창 설정에서 가로·세로를 입력하세요.") end
  end
 end)
 resizeGrip:SetScript("OnMouseUp",function()stopSizing()end)
 resizeGrip:SetScript("OnHide",function()stopSizing()end)
 hud:SetScript("OnSizeChanged",layout)
 hud:Hide()
 applyOpacity();layout();updateExpandedState()
end
function G.HUDUpdateDistance()
 if not hud or not hud:IsShown() or not G.db or G.db.hudCollapsed then return end
 local step=G.DisplayGuideStep()
 if not step then distance:SetText("");return end
 if G.GuideViewingHistory() then distance:SetText("|cff87dc98"..(G.GuideViewStatus(step,G.GuideViewIndex()) or "기록 보기").."|r");return end
 local location=G.PlayerLocation and G.PlayerLocation()
 local info,dir
 if G.RouteDistanceLabel then info,dir=G.RouteDistanceLabel(location,step.point) end
 if step.landmark then
  info=(step.landmark.zone or "퀘스트 장소").." · "..(step.landmark.site or "위치 설명 참고");dir=nil
 elseif step.indoor and not step.point then
  info=step.indoor.dungeon.." · "..step.indoor.room;dir=nil
 elseif step.regionHint and not step.point then
  info=step.regionHint.." · 관련 지역 (목적지 아님)";dir=nil
 end
 distance:SetText("|cff9cbfff"..((G.KoreanText and G.KoreanText(info)) or info or "현재 위치 정보 미확인").."|r"..(dir and dir~="" and "  |cffffd47c"..dir.." 방향|r" or ""))
end
function G.HUDRefresh()
 if not G.db or not G.db.manualProgress then return end
 initialize()
 if not hud then return end
 local route=G.db.guide
 if not route or not route.steps or (#route.steps==0 and not (G.HasSuspendedGuide and G.HasSuspendedGuide()) and not route.halted) or G.db.hudHidden then hud:Hide();return end
 hud:Show()
 updateExpandedState()
 local done,total=G.GuideProgress()
 hudCount:SetText("|cffaac4ca"..done.."/"..total.."|r")
 progressBar:SetProgress(done,total)
 if route.mode=="selected" then
  local q=route.admittedCount or (route.optimization and route.optimization.selectedQuestCount) or 0
  progress:SetText("|cff88d7e9"..G.RouteScopeLabel(route).."|r · 가능 "..q.." · 제외 "..#(route.excluded or {}).." · 남은 "..math.max(0,total-done))
 else
  local d=G.GetDungeon and G.GetDungeon(route.dungeon)
  progress:SetText("|cff88d7e9"..(d and d.name or "던전 준비").."|r  · 남은 "..math.max(0,total-done).."단계")
 end
 local step=G.DisplayGuideStep()
 local viewIndex=G.GuideViewIndex()
 local review=G.GuideViewingHistory()
 local status=review and G.GuideViewStatus(step,viewIndex) or nil
 local stepKey=step and (step.key or tostring(viewIndex)..":"..tostring(step.title)) or "finished"
 if buttons[2] then buttons[2]:SetText(review and "현재 단계" or "다음 확인");if step or review then buttons[2]:Enable() else buttons[2]:Disable() end end
 if buttons[1] then if viewIndex>1 then buttons[1]:Enable() else buttons[1]:Disable() end end
 for _,i in ipairs({3,6}) do
  if buttons[i] then if review or not step or (i==6 and not step.quest) then buttons[i]:Disable() else buttons[i]:Enable() end end
 end
 if step then
  local result=G.BuildStepDirections and G.BuildStepDirections(step,not review and G.PlayerLocation and G.PlayerLocation() or nil,status)
  local phase=phaseText[step.kind] or "이동"
  local modeText=review and (viewIndex<(route.index or 1) and "이전 기록" or "예정 미리보기") or "현재 진행"
  stageLabel:SetText("|cff"..(review and "99b9d4" or "83d4fa")..modeText.."|r  ·  |cff"..(phaseColor[step.kind] or "e0e6eb")..phase.."|r  ·  "..viewIndex.." / "..total)
  local title=result and result.title or (step.title or "")
  local prefix="["..phase.."] "
  if title:sub(1,#prefix)==prefix then title=title:sub(#prefix+1) end
  current:SetText(G.KoreanText and G.KoreanText(title) or title)
  local detail=result and table.concat(result.lines,"\n\n") or (step.note or "실제 방문 장소를 확인할 자료가 부족합니다.")
  -- Directions remain source-grounded; present compact paragraphs, with no duplicate numbering.
  if result and result.lines then
   local display={};local n=0
   for _,line in ipairs(result.lines) do
    local clean=line:gsub("^%d+%.%s*","")
    if not review and clean~=line then n=n+1;clean="|cff86c8ec"..n..".|r "..clean end
    display[#display+1]=clean
   end
   detail=table.concat(display,"\n")
  end
  if G.guideFeedback then detail="|cffffd47c"..G.guideFeedback.."|r\n\n"..detail end
  if G.KoreanText then detail=G.KoreanText(detail) end
  if detail~=lastDirectionText then directions:SetText(detail);lastDirectionText=detail end
 else
  if route.halted then
   stageLabel:SetText("|cffffc675진행 보류|r");current:SetText("진행 가능한 단계 없음")
   lastDirectionText=(route.statusReason or "수락 조건 확인 필요").."\n동선표 → 제외/보류에서 이유를 확인하세요."
   directions:SetText(lastDirectionText)
  else
   stageLabel:SetText("|cff87dc98동선 완료|r");current:SetText("모든 방문 단계 완료")
   lastDirectionText=(G.HasSuspendedGuide and G.HasSuspendedGuide()) and "퀘스트 진행 완료. [기존 동선 복귀]로 이전 통합 동선을 이어가세요." or "퀘스트 완료 상태를 확인하세요.";directions:SetText(lastDirectionText)
  end
 end
 local ix=route.index or 1
 local st1,st2=route.steps[ix+1],route.steps[ix+2]
 nextOne:SetText(st1 and ("|cff99a5af다음  |r"..((G.StepDisplayTitle and G.StepDisplayTitle(st1)) or st1.title or "")) or "|cff99a5af다음 단계 없음|r")
 nextTwo:SetText(st2 and ("|cff99a5af그다음  |r"..((G.StepDisplayTitle and G.StepDisplayTitle(st2)) or st2.title or "")) or "")
 if review then local t=route.steps[ix] and route.steps[ix].title or "모든 단계 완료";nextOne:SetText("|cff99a5af현재 진행  |r"..(G.KoreanText and G.KoreanText(t) or t));nextTwo:SetText("") end
 source:SetText("|cffd8aa67"..(G.GuideNavigationInfo and G.GuideNavigationInfo() or "현재 동선 기준 안내").."|r")
 layout()
 if lastStepKey~=stepKey or (G.guideFeedback and G.guideFeedback~=lastFeedback) then scroll:SetVerticalScroll(0);lastStepKey=stepKey end
 lastFeedback=G.guideFeedback
 G.HUDUpdateDistance()
end
function G.ToggleHUD()
 if not G.db then return end
 G.db.hudHidden=not G.db.hudHidden
 G.HUDRefresh()
end

local addon,G=...
G.rewardsVersion="2.9.1"
-- QuestieDB's quest schema has reputationReward but no equipment reward fields.
-- Use Blizzard's quest-ID APIs when that quest's reward data is actually available.
-- Never read the currently selected game's quest without its explicit ID.
local waiting={}
local rewardLoader
local function requestReward(id)
 if not (C_QuestLog and type(C_QuestLog.RequestLoadQuestByID)=="function") or waiting[id] then return end
 waiting[id]=true
 local ok=pcall(C_QuestLog.RequestLoadQuestByID,id)
 if not ok then waiting[id]=nil end
end
local references={
 [4024]={
  choices={{12066,"Shaleskin Cape"},{12082,"Wyrmhide Spaulders"},{12083,"Valconian Sash"}},
  money=26500,
  source="Wowhead Forever / Forever Guide · 자료상 보상 (실제 지급은 게임에서 확인)",
 },
}
local function safe(fn,...)
 if type(fn)~="function" then return nil end
 local ok,a,b,c,d,e,f=pcall(fn,...)
 if ok then return a,b,c,d,e,f end
end
local function nameOf(id,fallback)
 local native=safe(C_Item and C_Item.GetItemNameByID,id) or safe(GetItemInfo,id)
 local dbName=ItemDB and G.DBGet and G.DBGet(ItemDB,id,"name")
 local name=type(native)=="string" and native~="" and native or type(dbName)=="string" and dbName~="" and dbName or fallback
 if G.KoreanName and name then return G.KoreanName("item",id,name) or name end
 return name or ("아이템 "..tostring(id))
end
local function moneyText(copper)
 copper=math.floor(tonumber(copper) or 0)
 if copper<=0 then return nil end
 local gold=math.floor(copper/10000);local silver=math.floor(copper%10000/100);local coin=copper%100
 local bits={}
 if gold>0 then bits[#bits+1]=gold.."골드" end
 if silver>0 then bits[#bits+1]=silver.."실버" end
 if coin>0 then bits[#bits+1]=coin.."코퍼" end
 return table.concat(bits," ")
end
function G.QuestRewardInfo(id)
 id=tonumber(id)
 if not id or id<1 or id%1~=0 then return {available=false,reason="퀘스트 선택 필요"} end
 local result={id=id,choices={},fixed={},available=false,source=nil}
 local inLog=G.IsInLog and G.IsInLog(id)==true
 local dataAvailable=safe(HaveQuestRewardData,id)==true
 if not inLog and not dataAvailable then requestReward(id) end
 if inLog or dataAvailable then
  local n=safe(GetNumQuestLogChoices,id)
  if type(n)=="number" and n>0 then
   for i=1,math.min(n,20) do
    local name,icon,count,quality,usable,itemId=safe(GetQuestLogChoiceInfo,i,id)
    if type(name)=="string" and name~="" then
     result.choices[#result.choices+1]={id=tonumber(itemId),name=name,count=tonumber(count) or 1,icon=icon,quality=quality}
    end
   end
  end
  n=safe(GetNumQuestLogRewards,id)
  if type(n)=="number" and n>0 then
   for i=1,math.min(n,20) do
    local name,icon,count,quality,usable,itemId=safe(GetQuestLogRewardInfo,i,id)
    if type(name)=="string" and name~="" then
     result.fixed[#result.fixed+1]={id=tonumber(itemId),name=name,count=tonumber(count) or 1,icon=icon,quality=quality}
    end
   end
  end
  result.money=tonumber(safe(GetQuestLogRewardMoney,id))
  result.xp=tonumber(safe(GetQuestLogRewardXP,id))
  result.source="게임 퀘스트 보상 데이터"
 end
 local known=references[id]
 if known and #result.choices==0 and #result.fixed==0 then
  for _,item in ipairs(known.choices or {}) do
   result.choices[#result.choices+1]={id=item[1],name=nameOf(item[1],item[2]),count=1}
  end
  result.money=result.money or known.money
  result.source=known.source
  result.reference=true
 end
 result.available=#result.choices>0 or #result.fixed>0 or (result.money and result.money>0) or (result.xp and result.xp>0) or false
 result.moneyText=moneyText(result.money)
 if not result.available then result.reason="보상 자료 미확인 · 실제 퀘스트 수락/보고 화면에서 확인" end
 return result
end
if type(CreateFrame)=="function" and C_QuestLog and type(C_QuestLog.RequestLoadQuestByID)=="function" then
 rewardLoader=CreateFrame("Frame")
 rewardLoader:RegisterEvent("QUEST_DATA_LOAD_RESULT")
 rewardLoader:SetScript("OnEvent",function(self,event,id,success)
  id=tonumber(id)
  if id and waiting[id] then
   waiting[id]=nil
   if success and G.selection and G.selection.quest==id and G.UIRefresh then G.UIRefresh() end
  end
 end)
end
function G.QuestRewardBrief(info)
 if not info or not info.available then return "보상 · 자료 확인 필요" end
 local out={}
 if #info.choices>0 then out[#out+1]="선택 "..#info.choices.."종 중 1개" end
 if #info.fixed>0 then out[#out+1]="확정 아이템 "..#info.fixed.."종" end
 if info.moneyText then out[#out+1]=info.moneyText end
 if info.xp and info.xp>0 then out[#out+1]=math.floor(info.xp).." 경험치" end
 local summary="보상 · "..table.concat(out," · ")
 return info.reference and (summary.." (자료 참고)") or summary
end
function G.QuestRewardLines(info)
 if not info or not info.available then return {"보상 자료 확인 필요",(info and info.reason) or "게임에서 보상을 확인하세요."} end
 local lines={info.reference and "|cffffc77d보상 (외부 자료 참고 · 게임에서 확인 필요)|r" or "|cff8cdbad보상 (게임 데이터)|r"}
 if #info.choices>0 then
  lines[#lines+1]="선택 보상 · 다음 중 하나"
  for _,entry in ipairs(info.choices) do lines[#lines+1]="• "..entry.name..(entry.count>1 and (" ×"..entry.count) or "") end
 end
 if #info.fixed>0 then
  lines[#lines+1]="확정 보상"
  for _,entry in ipairs(info.fixed) do lines[#lines+1]="• "..entry.name..(entry.count>1 and (" ×"..entry.count) or "") end
 end
 if info.moneyText then lines[#lines+1]="골드: "..info.moneyText end
 if info.xp and info.xp>0 then lines[#lines+1]="경험치: "..math.floor(info.xp) end
 if info.source then lines[#lines+1]="출처: "..info.source end
 return lines
end

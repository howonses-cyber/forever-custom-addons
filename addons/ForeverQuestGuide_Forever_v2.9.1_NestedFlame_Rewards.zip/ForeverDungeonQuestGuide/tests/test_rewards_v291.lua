-- Rewards use quest-ID game APIs when available. Unsupported/unknown rewards
-- stay unknown; never use the currently selected quest as a silent fallback.
local base=(arg and arg[1]) or './'
local G={selection={quest=91},uiRefreshes=0}
function G.IsInLog(id)return id==91 end
function G.KoreanName(_,id,name)return name end
local fromGame={}
GetNumQuestLogChoices=function(id)if id==91 then return 2 end end
GetQuestLogChoiceInfo=function(i,id)
 if id~=91 then return end
 return i==1 and '보상 방패' or '보상 반지','tex'..i,1,4,true,601+i
end
GetNumQuestLogRewards=function(id)if id==91 then return 1 end end
GetQuestLogRewardInfo=function(i,id)if id==91 then return '고정 약초','tex',4,2,true,666 end end
GetQuestLogRewardMoney=function(id)if id==91 then return 12345 end end
GetQuestLogRewardXP=function(id)if id==91 then return 6790 end end
HaveQuestRewardData=function(id)return id==91 end
local requested={}
C_QuestLog={RequestLoadQuestByID=function(id)requested[id]=(requested[id] or 0)+1 end}
local frame
CreateFrame=function()
 frame={events={}}
 function frame:RegisterEvent(e)self.events[e]=true end
 function frame:SetScript(which,fn)self[which]=fn end
 return frame
end
local checks=0
local function check(v,m)assert(v,m);checks=checks+1 end
assert(loadfile(base..'QuestRewards.lua'))('ForeverDungeonQuestGuide',G)
local info=G.QuestRewardInfo(91)
check(info.available and not info.reference,'actual game data is authoritative')
check(#info.choices==2 and info.choices[1].name=='보상 방패','two alternative rewards')
check(#info.fixed==1 and info.fixed[1].count==4,'fixed item quantity')
check(info.money==12345 and info.xp==6790,'money and xp supplied by the game')
check(G.QuestRewardBrief(info):find('선택 2종 중 1개',1,true)~=nil,'choice not falsely labeled all rewards')
local detail=table.concat(G.QuestRewardLines(info),'\n')
check(detail:find('보상 방패',1,true) and detail:find('보상 반지',1,true),'choice item names displayed')
check(detail:find('고정 약초',1,true) and detail:find('경험치: 6790',1,true),'fixed reward and XP displayed')
check(frame and frame.events.QUEST_DATA_LOAD_RESULT,'late reward data refresh listener installed')
local flame=G.QuestRewardInfo(4024)
check(flame.available and flame.reference,'4024 uses explicit source-labeled reference if client data unavailable')
check(#flame.choices==3 and flame.choices[1].id==12066 and flame.choices[3].id==12083,'reference carries three choice items')
check(flame.money==26500 and not flame.xp,'reference money is sourced and XP not invented')
check(G.QuestRewardBrief(flame):find('자료 참고',1,true)~=nil,'external reference explicitly flagged')
local absent=G.QuestRewardInfo(77777)
check(not absent.available and absent.reason:find('확인',1,true)~=nil,'unknown rewards stay unknown')
check(#absent.choices==0 and #absent.fixed==0 and not absent.money,'no invented rewards')
check(requested[77777]==1,'non-log quest loaded by explicit ID')
local again=G.QuestRewardInfo(77777)
check(requested[77777]==1,'repeat request suppressed while pending')
G.UIRefresh=function() G.uiRefreshes=G.uiRefreshes+1 end
frame.OnEvent(frame,'QUEST_DATA_LOAD_RESULT',77777,true)
check(G.uiRefreshes==0,'data event does not redraw unrelated selected quest')
G.QuestRewardInfo(77777)
check(requested[77777]==2,'successful load invalidates pending request')
G.selection.quest=77777
frame.OnEvent(frame,'QUEST_DATA_LOAD_RESULT',77777,true)
check(G.uiRefreshes==1,'relevant selected quest can refresh on data availability')
check(G.QuestRewardBrief({available=false})=='보상 · 자료 확인 필요','no unsupported reward claim')
print('PASS V2.9.1 client rewards/choice/fixed/money/xp, reference provenance and unknown-state: '..checks..' assertions')

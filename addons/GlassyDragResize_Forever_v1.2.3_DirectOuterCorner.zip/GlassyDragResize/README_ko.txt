GlassyDragResize 1.2.3 / WoW Forever 1.60.1

설치: Forever Addon Manager에서 Glassy Drag Resize 업데이트 설치 후 /reload.
Glassy 애드온이 별도로 설치되어 있어야 합니다.

수정: 메인 창의 손잡이를 내부 GlassyFrame이 아닌 GlassyMoverFrame
(채팅 본문 + 입력창을 감싸는 Glassy의 실제 배치 외곽)의 BOTTOMRIGHT에
오프셋 0,0으로 직접 연결했습니다. V1.2.1~V1.2.2의 임의 픽셀 보정과
오래된 사용자 보정 저장값은 더 이상 적용하지 않습니다.

좌클릭 손잡이 드래그: 채팅창 크기 변경. 마우스 버튼 해제로 종료.
우클릭 손잡이 또는 /gdr: 창별 가로·세로 직접 수치 입력.
/gdr main 600 250: 메인 600 x 250
/gdr 3 400 230: 분리 ChatFrame3 400 x 230
/gdr status: 인식된 분리 창 수와 애드온 버전
/gdr debug: 현재 손잡이의 외곽 기준 프레임과 좌표 출력
/glass: 기존 Glassy 설정 (변경 없음)

메인 창 크기 조절 시 Glassy 프로필 frameWidth/frameHeight가 변경되며
메인 배치 프레임도 함께 갱신됩니다. 분리된 ChatFrame 크기 설정은 별도로
유지하며, 기존 저장된 분리 창 크기 및 /reload 복원은 보존합니다.

메인 Glassy의 기본 탭 레이아웃은 GlassyFrame 너비에 연동될 수 있습니다.
탭 이름 버튼 자체의 크기를 독립적으로 바꾸는 애드온이 아닙니다.

정적·모의 프레임 검증과 실제 게임 내 호환성은 구분합니다.

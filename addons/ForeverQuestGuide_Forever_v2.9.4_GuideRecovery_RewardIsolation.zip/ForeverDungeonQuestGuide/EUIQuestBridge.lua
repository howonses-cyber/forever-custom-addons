local addon,G=...
-- EUI integration: independent tracker launcher + quest-detail action.
-- EUI is never modified. The detail viewport is reserved only when its
-- original geometry matches the known Forever layout; otherwise the action
-- stays visible OUTSIDE the detail window instead of silently disappearing.
local installed,button,window,currentId,reservation
local launcher,launcherParent
local function combat() return InCombatLockdown and InCombatLockdown() end
local function questID(value)
 local n=tonumber(value)
 return n and n>0 and n==math.floor(n) and n or nil
end
local function geometryMatches(r,offset)
 if not r or not r.scroll or not r.scroll.GetNumPoints or r.scroll:GetNumPoints()~=#r.points then return false end
 for i,p in ipairs(r.points) do
  local a,rel,rp,x,y=r.scroll:GetPoint(i)
  if type(p[5])~="number" or a~=p[1] or rel~=p[2] or rp~=p[3] or x~=p[4] or y~=p[5]+(i==r.targetIndex and offset or 0) then return false end
 end
 return true
end
local function restore(r)
 if not geometryMatches(r,30) then return end
 r.scroll:ClearAllPoints()
 for i,p in ipairs(r.points) do r.scroll:SetPoint(p[1],p[2],p[3],p[4],p[5]) end
end
local function findAnchor(win)
 if not win or type(win.GetChildren)~="function" then return nil end
 for _,child in ipairs({win:GetChildren()}) do
  if child.GetObjectType and child:GetObjectType()=="ScrollFrame" and child.GetNumPoints and child:GetNumPoints()==2 then
   local points={}
   for i=1,2 do points[i]={child:GetPoint(i)} end
   for i,p in ipairs(points) do
    if p[1]=="BOTTOMRIGHT" and p[2]==win and p[3]=="BOTTOMRIGHT" and
       type(p[4])=="number" and type(p[5])=="number" and p[5]>=54 and p[5]<=64 then
     return {scroll=child,points=points,targetIndex=i}
    end
   end
  end
 end
 return nil
end
-- EUI's quest-details action has one canonical location: a dedicated row
-- directly above its native four-button footer. It must NEVER jump outside
-- the EUI details window when another EUI build changes its scroll anchors.
local function placeInside(b,win)
 b:ClearAllPoints()
 b:SetSize(math.max(120,(win.GetWidth and win:GetWidth() or 360)-28),24)
 b:SetPoint("BOTTOMLEFT",win,"BOTTOMLEFT",14,54)
 b:SetPoint("BOTTOMRIGHT",win,"BOTTOMRIGHT",-14,54)
end
local function placeDetail(win)
 if not button then return false end
 if reservation and geometryMatches(reservation,30) then restore(reservation) end
 reservation=nil
 local r=findAnchor(win)
 if r then
  local valid=true
  for _,p in ipairs(r.points) do if type(p[5])~="number" then valid=false end end
  if valid then
   placeInside(button,win)
   r.scroll:ClearAllPoints()
   for i,p in ipairs(r.points) do
    r.scroll:SetPoint(p[1],p[2],p[3],p[4],p[5]+(i==r.targetIndex and 30 or 0))
   end
   reservation=r
   return true
  end
 end
 -- Unrecognized scroll geometry stays completely untouched. The action
 -- still remains anchored inside its normal EUI detail row.
 placeInside(button,win)
 return true
end
local function attach(win)
 if not win or combat() or type(G.UIButton)~="function" then return false end
 if button and window==win then
  if reservation and geometryMatches(reservation,30) then return true end
  -- EUI can rebuild its detail layout after an OnShow. Never leave an old
  -- caption or stale button position on top of the native footer.
  return placeDetail(win)
 end
 if button then
  restore(reservation)
  button:Hide()
 end
 local b=G.UIButton(win,G.displayName or "포에버 퀘스트 가이드",150,24,function()
  if combat() then G.Print("전투가 끝난 뒤 가이드를 시작하세요.");return end
  local id=window==win and win:IsShown() and questID(currentId)
  if not id then G.Print("EUI 퀘스트 상세창을 다시 열어주세요.");return end
  if G.StartQuickGuide and G.StartQuickGuide(id) then win:Hide() end
 end,"primary")
 b:SetScript("OnEnter",function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,"ANCHOR_TOP")
  GameTooltip:AddLine(G.displayName or "포에버 퀘스트 가이드",.9,.75,.4)
  GameTooltip:AddLine("선택한 퀘스트의 수행/보고 동선을 엽니다.",1,1,1,true)
  GameTooltip:AddLine("기존 EUI 버튼과 진행 중인 동선은 보존합니다.",.8,.85,.9,true)
  GameTooltip:Show()
 end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 b:Hide()
 button,window=b,win
 win:HookScript("OnHide",function()
  if window==win and button==b then
   restore(reservation)
   reservation=nil
   currentId=nil
   b:Hide()
  end
 end)
 return placeDetail(win)
end
function G.RefreshEUITrackerLauncher()
 local frame=_G.EUI_CustomQuestTracker
 if not frame or not frame.GetWidth or not frame.IsShown or type(G.UIButton)~="function" then return false end
 if launcher and launcherParent~=frame then launcher:Hide();launcher=nil end
 if not launcher then
  launcher=G.UIButton(frame,"가이드",56,22,function()
   if combat() then G.Print("전투가 끝난 뒤 가이드를 여세요.");return end
   if G.ToggleUI then G.ToggleUI() end
  end,"primary")
  launcher:SetScript("OnEnter",function(self)
   if not GameTooltip then return end
   GameTooltip:SetOwner(self,"ANCHOR_TOP")
   GameTooltip:AddLine("포에버 퀘스트 가이드",.9,.75,.4)
   GameTooltip:AddLine("클릭: 전체 퀘스트 검색과 동선 가이드",1,1,1)
   GameTooltip:Show()
  end)
  launcher:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
  -- Separate from the native header's collapse/count controls and rows.
  launcher:SetPoint("TOPLEFT",frame,"TOPRIGHT",6,-1)
  launcherParent=frame
 end
 return true
end
function G.RefreshEUIQuestBridge()
 G.RefreshEUITrackerLauncher()
 local win=_G.EUI_QuestDetails
 if not win or not win:IsShown() then
  currentId=nil
  if button then button:Hide() end
  return false
 end
 local id=questID(currentId)
 if not id then if button then button:Hide() end;return false end
 if not attach(win) then return false end
 button:SetText(G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) and
  ((G.displayName or "포에버 퀘스트 가이드").." · 보고") or (G.displayName or "포에버 퀘스트 가이드"))
 button:Show()
 return true
end
function G.InstallEUIQuestBridge()
 G.RefreshEUITrackerLauncher()
 local tracker=_G.EllesmereUIQuestTracker
 if type(tracker)~="table" or type(tracker.ShowQuestDetails)~="function" or type(hooksecurefunc)~="function" then return false end
 if installed==tracker then return true end
 local ok=pcall(hooksecurefunc,tracker,"ShowQuestDetails",function(first,second)
  -- Current Forever uses ShowQuestDetails(id). Some builds use : syntax.
  local id=questID(first) or questID(second)
  local win=_G.EUI_QuestDetails
  currentId=win and win:IsShown() and id or nil
  G.RefreshEUIQuestBridge()
 end)
 if ok then installed=tracker end
 return ok
end
function G.EUIBridgeStatus()
 local min=_G.ForeverDungeonQuestGuideMinimapButton
 local inFlyout=false
 for _,candidate in ipairs(type(_G._EBS_CachedAddonButtons)=="table" and _G._EBS_CachedAddonButtons or {}) do
  if candidate==min then inFlyout=true;break end
 end
 return "EUI 모듈 "..(type(_G.EllesmereUIQuestTracker)=="table" and "발견" or "대기")..
  " / 상세창 연결 "..(installed and "연결" or "대기")..
  " / 추적기 바로가기 "..(launcher and "생성" or "대기")..
  " / EUI 버튼 모음 "..(inFlyout and "등록 확인" or "수집 대기")..
  " / 미니맵 버튼 "..(min and "생성" or "미생성")
end

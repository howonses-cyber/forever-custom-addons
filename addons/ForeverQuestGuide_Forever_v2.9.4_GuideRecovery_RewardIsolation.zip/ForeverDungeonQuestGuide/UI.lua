local addon,G=...
G.uiVersion="2.9.4"
local C={bg={.055,.065,.082,.98},panel={.085,.10,.13,.96},gold={.95,.77,.39},cyan={.41,.82,.91},dim={.64,.69,.74},green={.4,.85,.54},gray={.85,.86,.89}}
-- One shared table keeps each callback below Lua 5.1's 60-upvalue limit.
-- Widget identities and the exported UIJourneyWidgets keys stay unchanged.
local widgets={phaseButtons={},chainFrames={},statusCache={},progressCache={}}
local statusFilter="all"
local visibleDisplay,visibleSummary,journeyCache={},{},{}
local stateCache={}
-- Nine compact cards are visible without changing the window's overall scale.
-- Five taller cards remain available as an opt-in reading mode.
local QUEST_ROW_HEIGHT,QUEST_ROW_STRIDE,QUEST_ROW_COUNT,QUEST_ROW_TOP=34,38,9,133
local QUEST_MAX_ROWS=14
local DUNGEON_MAX_ROWS=17
local layoutExtra=0
local pendingScrollAnchor=nil
local QUEST_LIST_HEIGHT=(QUEST_ROW_COUNT-1)*QUEST_ROW_STRIDE+QUEST_ROW_HEIGHT
local pendingReveal=false
local detailScroll,detailChild,detailQuest,lastDetailText,detailScrollbar
local detailsExpanded=false
local planOffset,planBar,planProgress,planGuide=0,nil,nil,nil
local footerProgress,footerPrev,footerNext
local deferredListButton,resumeOneButton,resumeAllButton,resetButton,scopeStartButton,quickStartButton,characterInfo
local planPrev,planNext,planExclusionButton
local showExcluded=false
local dungeonMaxScroll,questMaxScroll=0,0
local modeButtons={}
local planFrame,planRows,planHeading,planCounter=nil,nil,nil,nil
local dungeonOffset,questOffset=0,0
local browsePage=0
local browsePageSize=180
local browseLevel="all"
local browseSort="id"
local lastBrowseFaction
local preserveCategoryScroll=false
local lastBrowseMode,lastBrowseSearch,lastBrowseCategory
local DASH_COLOR={deferred="|cffe6ab63",dependentDeferred="|cffe6ab63",superseded="|cff96d9ed",done="|cff7ccf84",active="|cff7dd1ed",ready="|cfff5da80",turnin="|cff56e28e",low="|cffa7a8aa",blocked="|cffbb7777",locked="|cffdbad62",unknown="|cffabb3b7"}
local function label(parent,text,x,y,w,h,size,color)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h)
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
 if color then f:SetTextColor(color[1],color[2],color[3]) end
 if text then f:SetText(text) end
 return f
end
local function panel(parent,x,y,w,h)
 local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h);f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(C.panel))
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=G.UIButton(parent,text,w,h,fn)
 b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 return b
end
local function row(parent,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent);b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=b:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.12,.15,.19,.54);b.fill=t
 local glow=b:CreateTexture(nil,"HIGHLIGHT");glow:SetAllPoints();glow:SetColorTexture(.35,.40,.43,.22)
 b.marker=b:CreateTexture(nil,"ARTWORK");b.marker:SetPoint("LEFT",b,"LEFT",0,0);b.marker:SetSize(3,h)
 b.marker:SetColorTexture(.31,.36,.39,.8)
 b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 b.text:SetPoint("LEFT",b,"LEFT",9,0);b.text:SetPoint("RIGHT",b,"RIGHT",-4,0)
 b.text:SetJustifyH("LEFT");b.text:SetHeight(h);if b.text.SetMaxLines then b.text:SetMaxLines(1) end
 b:SetScript("OnClick",fn)
 return b
end
-- Four explicit edges: a tinted background or a left stripe alone is not a
-- boundary. Cards are inset inside chain frames, with seven pixels between
-- rows. All edges are reset when recycled rows change their relationship.
local function makeBorder(parent,layer)
 local border={}
 for _,side in ipairs({"top","right","bottom","left"}) do border[side]=parent:CreateTexture(nil,layer or "BORDER");border[side]:Hide() end
 return border
end
local function hideBorder(border) for _,edge in pairs(border) do edge:Hide() end end
local function paintBorder(parent,border,inset,width,color)
 local left,right=inset or 0,inset or 0
 for _,edge in pairs(border) do edge:ClearAllPoints();edge:SetColorTexture(unpack(color));edge:Show() end
 border.top:SetPoint("TOPLEFT",parent,"TOPLEFT",left,0);border.top:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-right,0);border.top:SetHeight(width)
 border.bottom:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",left,0);border.bottom:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-right,0);border.bottom:SetHeight(width)
 border.left:SetPoint("TOPLEFT",parent,"TOPLEFT",left,0);border.left:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",left,0);border.left:SetWidth(width)
 border.right:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-right,0);border.right:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-right,0);border.right:SetWidth(width)
end
local function chainKey(entry)
 if not entry then return nil end
 return (entry.kind=="chain" or entry.kind=="chainEnd") and entry.key
  or (entry.kind=="subchapter" and entry.parentKey)
  or (entry.kind=="standaloneHeader" and entry.key)
  or (entry.kind=="quest" and (entry.chainKey or entry.singleSectionKey)) or nil
end
function widgets.ChapterKey(entry)
 if not entry then return nil end
 if entry.kind=="subchapter" then return entry.key end
 return entry.kind=="quest" and entry.subchapterKey or nil
end
function widgets.RefreshChapterFrames(display,offset)
 for _,group in ipairs(widgets.chapterFrames) do group:Hide();group.chapterKey=nil end
 local i,used=1,0
 while i<=QUEST_ROW_COUNT do
  local key=widgets.ChapterKey(display[offset+i])
  if not key then i=i+1 else
   local first,last=i,i
   while last<QUEST_ROW_COUNT and widgets.ChapterKey(display[offset+last+1])==key do last=last+1 end
   used=used+1;local group=widgets.chapterFrames[used]
   group.chapterKey=key;group.firstRow=first;group.lastRow=last
   group:ClearAllPoints();group:SetPoint("TOPLEFT",widgets.frame.mid,"TOPLEFT",20,-QUEST_ROW_TOP-(first-1)*QUEST_ROW_STRIDE)
   group:SetSize(widgets.frame.mid:GetWidth()-67,(last-first)*QUEST_ROW_STRIDE+QUEST_ROW_HEIGHT)
   paintBorder(group,group.border,0,2,{.4032,.4347,.4662,1})
   if widgets.ChapterKey(display[offset+first-1])==key then group.border.top:Hide() end
   if widgets.ChapterKey(display[offset+last+1])==key then group.border.bottom:Hide() end
   group:Show();i=last+1
  end
 end
end
local function refreshChainFrames(display,offset)
 for _,group in ipairs(widgets.chainFrames) do group:Hide();group.chainKey=nil end
 local i,used=1,0
 while i<=QUEST_ROW_COUNT do
  local entry=display[offset+i]
  local key=chainKey(entry)
  if not key then i=i+1 else
   local first,last=i,i
   while last<QUEST_ROW_COUNT and chainKey(display[offset+last+1])==key do last=last+1 end
   used=used+1;local group=widgets.chainFrames[used]
   group.chainKey=key;group.firstRow=first;group.lastRow=last
   group.singleGroup=key:sub(1,11)=="individual:"
   group.continuesBefore=chainKey(display[offset+first-1])==key
   group.continuesAfter=chainKey(display[offset+last+1])==key
   group:ClearAllPoints();group:SetPoint("TOPLEFT",widgets.frame.mid,"TOPLEFT",8,-QUEST_ROW_TOP-(first-1)*QUEST_ROW_STRIDE)
   group:SetSize(widgets.frame.mid:GetWidth()-43,(last-first)*QUEST_ROW_STRIDE+QUEST_ROW_HEIGHT)
   local color=group.singleGroup and {.55,.57,.61,1} or {.45,.75,.90,1}
   paintBorder(group,group.border,0,2,color)
   if group.continuesBefore then group.border.top:Hide() end
   if group.continuesAfter then group.border.bottom:Hide() end
   group:Show()
   i=last+1
  end
 end
end
-- Continuous scrolling by row, instead of jumping by entire pages.
local function clampOffset(value,total,visible)
 return math.max(0,math.min(value,math.max(0,total-visible)))
end
local function setScrollbar(bar,offset,maxOffset,visible)
 if not bar then return end
 bar.updating=true
 local high=math.max(1,maxOffset)
 local changed=bar._range~=high
 if changed then bar:SetMinMaxValues(0,high);bar._range=high end
 local value=math.max(0,math.min(maxOffset,offset))
 if changed or bar._value~=value then bar:SetValue(value);bar._value=value end
 local thumb=bar:GetThumbTexture()
 if thumb and visible then thumb:SetHeight(math.max(18,math.min(bar:GetHeight(),bar:GetHeight()*visible/(maxOffset+visible)))) end
 if maxOffset>0 then bar:Show() else bar:Hide() end
 bar.updating=false
end
local function setDungeonOffset(offset)
 local target=math.max(0,math.min(dungeonMaxScroll,math.floor(offset+.5)))
 if target~=dungeonOffset then dungeonOffset=target;G.UIRefresh() end
end
local function setQuestOffset(offset)
 local target=math.max(0,math.min(questMaxScroll,math.floor(offset+.5)))
 if target~=questOffset then questOffset=target;G.UIRefresh() end
end
local function scrollDungeon(delta) setDungeonOffset(dungeonOffset+delta) end
local function scrollQuest(delta) setQuestOffset(questOffset+delta) end
local function bindWheel(widget,fn)
 widget:EnableMouseWheel(true)
 widget:SetScript("OnMouseWheel",function(_,wheel)
  fn(-wheel*3)
 end)
end
local function makeScrollbar(parent,x,y,height,update)
 local bar=CreateFrame("Slider",nil,parent)
 bar:SetSize(13,height)
 bar:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 bar:SetOrientation("VERTICAL")
 bar:SetMinMaxValues(0,1)
 bar:SetValueStep(1)
 if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(true) end
 local background=bar:CreateTexture(nil,"BACKGROUND")
 background:SetAllPoints();background:SetColorTexture(.05,.065,.085,.95)
 bar:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
 local thumb=bar:GetThumbTexture()
 if thumb then thumb:SetSize(11,35);thumb:SetVertexColor(.84,.62,.28,.95) end
 bar:SetScript("OnValueChanged",function(self,value)
  if self.updating then return end
  self._value=value
  update(math.floor((tonumber(value) or 0)+.5))
 end)
 return bar
end
local function displayText(value)
 return G.KoreanText and G.KoreanText(value) or value
end
local function itemTooltip(self,lines)
 if not GameTooltip then return end
 GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
 for i,v in ipairs(lines) do
  if i==1 then GameTooltip:SetText(displayText(v)) else GameTooltip:AddLine(displayText(v),.84,.85,.89,true) end
 end
 GameTooltip:Show()
end
local function versionHeading()
 return (G.displayName or "포에버 퀘스트 가이드").." · "..tostring(G.version or "버전 확인 필요")
  ..(G.version~=G.uiVersion and " · 파일 버전 다름" or "").."  |  무엇부터 할까요?"
end
local function journey(id)
 if not id then return nil end
 if not journeyCache[id] then journeyCache[id]=G.QuestJourney(id,stateCache) end
 return journeyCache[id]
end
local function questStatus(id)
 if G.QuestListStatus then return G.QuestListStatus(id,widgets.statusCache) end
 return {key="unknown",label="기록 확인",color={.69,.73,.79},reason="상태 자료 확인 필요",detail="실제 퀘스트 기록을 확인하세요."}
end
local function matchesStatus(status,filter)
 if G.QuestStatusMatches then return G.QuestStatusMatches(status,filter) end
 return filter=="all" or (status and status.key==filter)
end
local function objectiveProgress(id)
 if G.QuestObjectiveProgress then return G.QuestObjectiveProgress(id,widgets.progressCache) end
 return {available=false,summary="목표 기록 확인 필요",objectives={}}
end
local function statusTag(status)
 local c=status.color or {.69,.73,.79}
 return string.format("|cff%02x%02x%02x",math.floor(c[1]*255+.5),math.floor(c[2]*255+.5),math.floor(c[3]*255+.5))
end
local function progressLine(progress)
 if not progress or not progress.available then return "목표 수량 기록 확인 필요" end
 local summary=progress.summary or "실제 목표 진행"
 -- Keep at least one actual live quantity readable when another objective
 -- remains unfinished. The quantity is read from WoW, never estimated.
 local chosen
 for _,goal in ipairs(progress.objectives or {}) do
  if goal.quantity and (not chosen or (chosen.finished and not goal.finished)) then chosen=goal end
 end
 if chosen then return chosen.quantity.." · "..summary end
 return summary..(progress.partialText and progress.partialText~="" and (" · "..progress.partialText) or "")
end
-- Keep full content in hover/detail, but never let long CJK text bleed over
-- a neighboring card. Lua 5.1 has no utf8 library; advance by lead bytes only.
local function shortLine(value,maxWidth)
 local text=tostring(value or ""):gsub("[\r\n]+"," "):gsub("%s+"," ")
 local width,max,parts=0,maxWidth or 300,{}
 for rune in text:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
  local bytes=#rune
  local extent=bytes>=3 and 13 or bytes==2 and 9 or 6
  if width+extent>max-14 then return table.concat(parts).."…" end
  parts[#parts+1]=rune;width=width+extent
 end
 return text
end
local function readableSize(fontstring,size)
 if fontstring and fontstring.GetFont and fontstring.SetFont then
  local face,_,flags=fontstring:GetFont()
  if face and face~="" then fontstring:SetFont(face,size,flags) end
 end
end
local function journeyFlow(code)
 if code=="active" then return "|cff7ccf84받기 완료|r → |cff7dd1ed목표 수행 중|r → 보고 남음" end
 if code=="turnin" then return "받기 완료 → 목표 완료 → |cff56e28e지금 보고하기|r" end
 if code=="done" then return "|cff7ccf84받기 완료 → 목표 완료 → 보고 완료|r" end
 if code=="ready" then return "|cfff5da80지금 받기|r → 목표 수행 → 완료 보고" end
 if code=="locked" then return "|cffdbad62선행부터 진행|r → 이 퀘스트 받기 → 수행 → 보고" end
 if code=="superseded" then return "후속 진행 확인 · 실제 보고 완료 기록과 구분" end
 if code=="deferred" or code=="dependentDeferred" then return "|cffe6ab63보류 해제|r → 남은 단계 이어서 진행" end
 return "|cffdbad62현재 조건 확인|r → 받기 → 목표 수행 → 완료 보고"
end
-- Filters keep an entire related group visible. A predecessor is never made
-- to look like an unrelated quest by removing only part of its chain.
local function statusRows(rows,matchingSet)
 local result,pendingHeader={},nil
 local function matches(id)
  return matchingSet[id]==true
 end
 local function append(group)
  if pendingHeader then result[#result+1]=pendingHeader;pendingHeader=nil end
  for _,entry in ipairs(group) do
   if entry.kind=="quest" then entry.filterContext=not matches(entry.id) end
   result[#result+1]=entry
  end
 end
 local i=1
 while i<=#rows do
  local entry=rows[i]
  if entry.kind=="header" then pendingHeader=entry;i=i+1
  elseif entry.kind=="chain" then
   local group={entry};local include=false
   for _,id in ipairs(entry.memberIds or {}) do if matches(id) then include=true;break end end
   i=i+1
   while rows[i] and ((rows[i].kind=="quest" and rows[i].chainKey==entry.key) or (rows[i].kind=="chainEnd" and rows[i].key==entry.key)) do
    group[#group+1]=rows[i];i=i+1
   end
   if include then append(group) end
  else
   if entry.kind=="quest" and matches(entry.id) then append({entry}) end
   i=i+1
  end
 end
 return result
end
local function revealQuest(id)
 if not id then return end
 -- Opening a presentation group does not add/check/complete any quest.
 for _,entry in ipairs(visibleDisplay) do
  if entry.kind=="chain" or entry.kind=="subchapter" then
   for _,member in ipairs(entry.memberIds or {}) do
    if member==id then G.db.chainCollapsed[entry.key]=false;break end
   end
  end
 end
 pendingReveal=true;G.SetQuest(id)
end
local function showQuestMap()
 local q=G.selection.quest
 local j=journey(q)
 if not j or not j.canGuide then G.Print("진행 조건을 확인한 뒤 위치를 표시하세요.");return end
 local target=j.actionQuestId or q
 local kind=j.actionPhase or j.phase
 if kind~="accept" and kind~="turnin" then kind="objective" end
 local p=not j.inside and G.QuestPoint(target,kind) or nil
 if not p and not j.inside and kind=="objective" then local obj=G.QuestObjectivePoints(target);p=obj[1] and obj[1].point end
 if p then G.OpenPointMap(p) else
  local st={quest=target,kind=kind};G.EnrichStepLocation(st);G.OpenGuideStepMap(st)
 end
end
local function filteredQuests(d,options)
 local ids={}
 if not d then return ids end
 for _,id in ipairs(d.ids) do
  if G.IsQuestBrowseVisible(id,options) then ids[#ids+1]=id end
 end
 table.sort(ids,function(a,b)
  local _,as=G.QuestState(a);local _,bs=G.QuestState(b)
  local w={ready=1,active=2,locked=3,low=4,done=5,blocked=6}
  if (w[as] or 9)~=(w[bs] or 9) then return (w[as] or 9)<(w[bs] or 9) end
  return a<b
 end)
 return ids
end
local function prereqString(ids)
 local names={}
 for _,id in ipairs(ids) do
  local abs=math.abs(id)
  local mark=G.IsCompleted(abs) and "|cff75cf86[완료]|r " or
   (G.RoutePrereqEvidence(abs) and "|cff96d9ed[후속 진행 확인]|r " or (G.db.deferredQuests[abs] and "|cffe6ab63[사용자 보류]|r " or (G.IsInLog(abs) and "|cff7dd1ed[진행 중]|r " or "|cffffd06c[미완료]|r ")))
  names[#names+1]=mark..G.GetQuestName(abs)
 end
 return #names>0 and table.concat(names,"\n") or "없음"
end
local function makeQuestCheckbox(r)
 local check=CreateFrame("CheckButton",nil,r,"UICheckButtonTemplate")
 check:SetSize(25,25)
 check:SetPoint("LEFT",r,"LEFT",5,0)
 check:SetScript("OnClick",function(self)
  if r.quest then
   if G.TryQuestChatClick(r.quest) then self:SetChecked(G.db.selectedQuests[r.quest]==true);return end
   G.ToggleQuestChecked(r.quest,self:GetChecked())
  end
 end)
 check:SetScript("OnEnter",function(self)
  itemTooltip(self,{"함께 안내할 퀘스트 선택", "체크는 동선 선택입니다. 퀘스트 완료 표시와 다릅니다.","실제 상태는 카드 오른쪽의 미수락·수행 중·보고 가능·완료 배지로 확인하세요.","체크한 퀘스트는 하나의 동선으로 실시간 재계산됩니다."})
 end)
 check:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 r.text:ClearAllPoints()
 r.text:SetPoint("LEFT",r,"LEFT",35,0)
 r.text:SetPoint("RIGHT",r,"RIGHT",-4,0)
 r.checkbox=check
 r.statusText=r:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 r.statusText:SetPoint("TOPLEFT",r,"TOPLEFT",35,-51);r.statusText:SetPoint("TOPRIGHT",r,"TOPRIGHT",-6,-51);r.statusText:SetHeight(11);r.statusText:SetJustifyH("LEFT")
 if r.statusText.SetWordWrap then r.statusText:SetWordWrap(false) end
 if r.statusText.SetMaxLines then r.statusText:SetMaxLines(1) end
 r.text:ClearAllPoints();r.text:SetPoint("TOPLEFT",r,"TOPLEFT",35,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-6,-3);r.text:SetHeight(16)
 if r.text.SetWordWrap then r.text:SetWordWrap(false) end
 if r.text.SetMaxLines then r.text:SetMaxLines(1) end
 r.blockerText=r:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 r.blockerText:SetJustifyH("LEFT");r.blockerText:SetJustifyV("MIDDLE")
 r.blockerText:SetTextColor(.91,.73,.48);r.blockerText:Hide()
 if r.blockerText.SetWordWrap then r.blockerText:SetWordWrap(false) end
 if r.blockerText.SetMaxLines then r.blockerText:SetMaxLines(1) end
 r.statusStripe=r:CreateTexture(nil,"ARTWORK");r.statusStripe:Hide()
 r.badgeFill=r:CreateTexture(nil,"ARTWORK");r.badgeFill:Hide()
 r.statusBadge=r:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
 r.statusBadge:SetJustifyH("CENTER");r.statusBadge:SetJustifyV("MIDDLE");r.statusBadge:Hide()
 r.progressText=r:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 r.progressText:SetJustifyH("LEFT");r.progressText:SetJustifyV("MIDDLE");r.progressText:SetTextColor(.84,.88,.93);r.progressText:Hide()
 if r.progressText.SetWordWrap then r.progressText:SetWordWrap(false);r.statusBadge:SetWordWrap(false) end
 if r.progressText.SetMaxLines then r.progressText:SetMaxLines(1);r.statusBadge:SetMaxLines(1) end
 r.progressTrack=r:CreateTexture(nil,"ARTWORK");r.progressTrack:Hide()
 r.progressBar=r:CreateTexture(nil,"ARTWORK");r.progressBar:Hide()
end
local function paintQuestCard(r,entry,j,meta,groupNumber,selected)
 local id=entry.id
 local status=questStatus(id)
 local color=status.color or {.69,.73,.79}
 if entry.subchapterSkipped then
  -- Presentation-only. The unaccepted quest flag stays unmodified: its
  -- alternative has already been accepted/completed by this character.
  local updated={};for k,v in pairs(status) do updated[k]=v end
  updated.label="선택 불필요";updated.color={.62,.70,.75}
  status=updated;color=updated.color
 end
 local cardInset=entry.chainKey and 12 or entry.singleSectionKey and 8 or 0
 local inset=cardInset+35+(entry.subchapterKey and 12 or 0)
 r.quest=id;r.cardInset=cardInset;r.status=status;r.statusKey=status.key;r.filterContext=entry.filterContext==true
 r:Show();r.checkbox:Show();r.statusText:Show();r.statusBadge:Show();r.badgeFill:Show();r.statusStripe:Show();r.progressText:Show();r.blockerText:Show();r.marker:Hide()
 r.fill:ClearAllPoints();r.fill:SetPoint("TOPLEFT",r,"TOPLEFT",cardInset,0);r.fill:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-cardInset,0)
 r.fill:SetColorTexture(.075+color[1]*.075,.09+color[2]*.075,.11+color[3]*.075,.98)
 r.checkbox:ClearAllPoints();r.checkbox:SetPoint("LEFT",r,"LEFT",cardInset+5+(entry.subchapterKey and 12 or 0),0)
 r.checkbox:SetChecked(G.db.selectedQuests[id]==true)
 local canCheck=G.db.selectedQuests[id]==true or j.canGuide
 if r.checkbox.SetEnabled then r.checkbox:SetEnabled(canCheck) elseif canCheck then r.checkbox:Enable() else r.checkbox:Disable() end
 r.text:ClearAllPoints();r.text:SetPoint("TOPLEFT",r,"TOPLEFT",inset,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-87,-3);r.text:SetHeight(16)
 r.text:SetTextColor(.93,.94,.96)
 local name=G.GetQuestName(id)
 local compact=G.db.questListCompact~=false
 local chapter=compact and entry.chainLinear and entry.chainIndex and ("["..entry.chainIndex.."/"..entry.chainCount.."] ") or ""
 local continueLabel=entry._viewportContinuation and "↳ " or ""
 r.text:SetText(shortLine(continueLabel..(entry.subchapterStepLabel or (chapter..(entry.sameTitle and (name.." #"..id) or name))),r:GetWidth()-inset-cardInset-96))
 r.badgeFill:ClearAllPoints();r.badgeFill:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-6,-3);r.badgeFill:SetSize(74,16)
 r.badgeFill:SetColorTexture(color[1]*.30,color[2]*.30,color[3]*.30,1)
 r.statusBadge:ClearAllPoints();r.statusBadge:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-6,-3);r.statusBadge:SetSize(74,16)
 r.statusBadge:SetText(status.label);r.statusBadge:SetTextColor(color[1],color[2],color[3])
 r.statusStripe:ClearAllPoints();r.statusStripe:SetPoint("TOPLEFT",r,"TOPLEFT",cardInset+3,-2);r.statusStripe:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",cardInset+3,2);r.statusStripe:SetWidth(3)
 r.statusStripe:SetColorTexture(color[1],color[2],color[3],1)
 -- Consistent card reading order: name / main action / location or blocker / compact metadata.
 -- Long source wording stays available in the tooltip and detailed pane.
 local relation=entry.chainIndex and (entry.chainLinear and ("연계 · "..entry.chainIndex.."/"..entry.chainCount)
  or "연계 · 분기") or entry.relatedOutside and "개별 표시 · 외부 연계 확인" or "개별 표시"
 local factionTag=(G.selection.mode=="all" or (G.db.factionFilter or "auto")~="auto") and G.QuestFactionTag(id) or ""
 local metaLine=relation.." · "..tostring(meta.level).."레벨"..(factionTag~="" and (" · "..factionTag) or "")
 if entry.filterContext then metaLine="연계 참고 · "..metaLine end
 r.statusText:ClearAllPoints();r.statusText:SetPoint("TOPLEFT",r,"TOPLEFT",inset,-50);r.statusText:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-7,-50);r.statusText:SetHeight(12)
 r.statusText:SetTextColor(.68,.76,.82);r.statusText:SetText(shortLine(metaLine,r:GetWidth()-inset-cardInset-9))
 if compact then r.statusText:Hide() end
 local progress
 if status.key=="active" or status.key=="turnin" then progress=objectiveProgress(id) end
 r.objectiveProgress=progress;r.progressRatio=progress and progress.ratio or nil
 local actionLine
 if entry.subchapterSkipped then actionLine="택일 경로를 이미 진행 · 별도로 받을 필요 없음"
 elseif status.key=="done" then actionLine="보고와 보상 수령 완료"
 elseif status.key=="turnin" then actionLine="지금 보고: "..((j.detail or j.title):match("[^\n]+") or "보고 대상 확인")
 elseif status.key=="active" then actionLine="지금 수행: "..(progress and progress.available and progressLine(progress) or (j.detail or j.title):match("[^\n]+") or "퀘스트 목표 확인")
 elseif status.key=="unaccepted" then actionLine="지금 확인: "..(j.prerequisite and "선행 퀘스트 진행" or ((j.detail or j.title):match("[^\n]+") or "수락 대상 확인"))
 else actionLine="지금 확인: "..(j.detail or "실제 퀘스트 기록 확인 필요"):match("[^\n]+") end
 r.progressText:ClearAllPoints();r.progressText:SetPoint("TOPLEFT",r,"TOPLEFT",inset,compact and -19 or -20);r.progressText:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-7,compact and -19 or -20);r.progressText:SetHeight(compact and 12 or 15)
 r.progressText:SetText(shortLine(actionLine,r:GetWidth()-inset-cardInset-9))
 local blockerLine
 if status.blocked then blockerLine="조건 확인: "..(status.reason~="" and status.reason or "진행 조건 확인 필요")
 elseif status.key=="unknown" then blockerLine="기록 확인: "..(status.reason or "완료 이력 조회 필요")
 elseif entry.chainContext then blockerLine="연계 참고: 외부 선행의 실제 완료 기록 확인"
 elseif entry.filterContext then blockerLine="연계 참고: 현재 필터 밖의 퀘스트"
 elseif status.key=="done" then blockerLine="다음: 후속 퀘스트가 있는지 확인"
 else blockerLine="이동: "..(j.location or "실제 위치 확인 필요") end
 r.blockerText:ClearAllPoints();r.blockerText:SetPoint("TOPLEFT",r,"TOPLEFT",inset,-36);r.blockerText:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-7,-36);r.blockerText:SetHeight(13)
 r.blockerText:SetTextColor(status.blocked and .99 or .66,status.blocked and .72 or .82,status.blocked and .49 or .88)
 r.blockerText:SetText(shortLine(blockerLine,r:GetWidth()-inset-cardInset-9))
 if compact then r.blockerText:Hide() end
 if progress and progress.available and type(progress.ratio)=="number" then
  local width=r:GetWidth()-inset-cardInset-7
  r.progressTrack:ClearAllPoints();r.progressTrack:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",inset,3);r.progressTrack:SetSize(width,2);r.progressTrack:SetColorTexture(.21,.25,.30,1);r.progressTrack:Show()
  if progress.ratio>0 then
   r.progressBar:ClearAllPoints();r.progressBar:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",inset,3);r.progressBar:SetSize(math.max(1,width*math.min(1,progress.ratio)),2)
   r.progressBar:SetColorTexture(color[1],color[2],color[3],1);r.progressBar:Show()
  end
 end
 -- Selection is a separate gold outline. The status badge, stripe and text
 -- remain visible with the same state color, including completed cards.
 if entry.subchapterKey then
  -- A step is part of its parent card. A continuous dark inset and a thin
  -- timeline replace the repeated full-width card, even while scrolling.
  r.fill:ClearAllPoints();r.fill:SetPoint("TOPLEFT",r,"TOPLEFT",cardInset,entry._chapterContinuesBefore and (QUEST_ROW_STRIDE-QUEST_ROW_HEIGHT) or 0)
  r.fill:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-cardInset,0)
  r.fill:SetColorTexture(.065,.10,.14,.99)
  r.statusStripe:Hide()
  r.rail:ClearAllPoints();r.rail:SetPoint("TOPLEFT",r,"TOPLEFT",cardInset+8,entry._chapterContinuesBefore and (QUEST_ROW_STRIDE-QUEST_ROW_HEIGHT) or 0)
  r.rail:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",cardInset+8,entry._chapterContinuesAfter and -(QUEST_ROW_STRIDE-QUEST_ROW_HEIGHT) or 6)
  r.rail:SetWidth(2);r.rail:SetColorTexture(.30,.45,.55,1);r.rail:Show()
  r.stepDot:ClearAllPoints();r.stepDot:SetPoint("LEFT",r,"LEFT",cardInset+5,0);r.stepDot:SetSize(8,8)
  r.stepDot:SetColorTexture(unpack(entry.subchapterSkipped and {.43,.46,.49,1} or {color[1],color[2],color[3],1}));r.stepDot:Show()
  if selected then
   -- Selected step gets a small gold underline, not another independent card.
   r.edge:ClearAllPoints();r.edge:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",inset,2);r.edge:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-cardInset-5,2);r.edge:SetHeight(1);r.edge:SetColorTexture(1,.80,.34,1);r.edge:Show()
  end
 else
  paintBorder(r,r.cardBorder,cardInset,2,selected and {1,.80,.34,1} or {color[1]*.63,color[2]*.63,color[3]*.63,1})
 end
 r:SetScript("OnEnter",function(self)
  local tips={name.." (#"..id..")",status.label..(status.reason and (" · "..status.reason) or ""),status.detail or "실제 퀘스트 기록 기준",
   entry.chainLabel and ("연계: "..entry.chainLabel..(entry.chainContext and " · 외부 선행" or "")) or entry.relatedOutside and "이 목록에서는 별도 표시 · 목록 밖 선행/후속은 상세에서 확인" or entry.relationship=="ungrouped" and "연계 묶기 꺼짐 · 상세의 선행 조건 확인" or "위 연계 묶음에 속하지 않는 개별 표시 퀘스트"}
  if entry.filterContext then tips[#tips+1]="연계 참고: 현재 검색·상태 필터의 대상은 아니며 앞뒤 관계를 설명하기 위해 함께 표시합니다. 상태별 건수에서 제외됩니다." end
  if G.QuestRewardInfo and G.QuestRewardBrief then
   tips[#tips+1]=G.QuestRewardBrief(G.QuestRewardInfo(id))
  end
  if progress and progress.available then
   tips[#tips+1]=progress.summary
   for _,objective in ipairs(progress.objectives or {}) do tips[#tips+1]=(objective.display or objective.text or "목표")..(objective.finished and " · 목표 완료" or "") end
   tips[#tips+1]=progress.detail or "막대는 완료한 목표 항목 수 / 전체 목표 항목 수입니다."
  end
  tips[#tips+1]="퀘스트 레벨 "..tostring(meta.level).." · 최소 수락 "..(G.GetQuestMinLevel(id)>0 and tostring(G.GetQuestMinLevel(id)) or "자료 미확인").."레벨"
  local fact=G.QuestEligibilityFacts and G.QuestEligibilityFacts(id)
  if fact then for _,line in ipairs(fact.lines) do tips[#tips+1]=line end end
  tips[#tips+1]=j.title;tips[#tips+1]=j.location;tips[#tips+1]=j.detail;tips[#tips+1]=j.nextText
  tips[#tips+1]="체크 = 함께 안내할 동선 선택 · 실제 퀘스트 완료와 다릅니다."
  tips[#tips+1]="클릭: 진행 방법 확인 / 채팅창에서 시프트 클릭: 퀘스트 링크"
  itemTooltip(self,tips)
 end)
end
local function setDetailOffset(offset)
 if not detailScroll or not detailChild then return end
 local visible=math.max(1,math.floor(detailScroll:GetHeight()))
 local maximum=math.max(0,math.ceil(detailChild:GetHeight()-visible))
 local value=math.max(0,math.min(maximum,math.floor(offset+.5)))
 detailScroll:SetVerticalScroll(value)
 setScrollbar(detailScrollbar,value,maximum,visible)
end
function widgets.ResetRewardScroll() lastDetailText=nil;setDetailOffset(0) end
local function detailText(text,q)
 if not detailScroll then widgets.detailPrereqs:SetText(text);return end
 if text~=lastDetailText or q~=detailQuest then
  local old=detailScroll:GetVerticalScroll()
  widgets.detailPrereqs:SetHeight(0);widgets.detailPrereqs:SetText(text)
  local h=math.max(1,math.ceil((widgets.detailPrereqs:GetStringHeight() or 0)+12))
  widgets.detailPrereqs:SetHeight(h);detailChild:SetHeight(h)
  local max=math.max(0,h-detailScroll:GetHeight())
  setDetailOffset(q~=detailQuest and 0 or math.min(old,max))
  detailQuest=q;lastDetailText=text
 end
end
function widgets.RecordExtraError(section,err)
 local message=tostring(err or "응답 형식 확인 필요")
 G.uiOptionalErrors=G.uiOptionalErrors or {}
 if G.uiOptionalErrors[section]~=message then
  G.uiOptionalErrors[section]=message
  if G.Print then G.Print(section.." 확인 오류 · "..message) end
 end
end
function widgets.TryExtra(section,fn,...)
 if type(fn)~="function" then return nil end
 local ok,value=pcall(fn,...)
 if not ok then widgets.RecordExtraError(section,value);return nil end
 return value
end
function widgets.RewardRows(id,info)
 info=info or widgets.TryExtra("보상 조회",G.QuestRewardInfo,id)
 if type(info)~="table" then
  return {"보상 자료를 읽지 못했습니다.","공략은 계속 사용할 수 있습니다. [보상 다시 조회]로 재시도하세요."},nil
 end
 local lines=widgets.TryExtra("보상 표시",G.QuestRewardLines,info)
 if type(lines)~="table" or #lines==0 then return {"보상 표시 자료 확인 필요","[보상 다시 조회]로 재시도하세요."},info end
 local clean={}
 for _,line in ipairs(lines) do if type(line)=="string" then clean[#clean+1]=line end end
 if #clean==0 then clean={"보상 표시 자료 확인 필요"} end
 return clean,info
end
function widgets.RewardOffset(value)
 local p=widgets.rewardPopup;if not p then return end
 local max=math.max(0,math.ceil(p.child:GetHeight()-p.scroll:GetHeight()))
 value=math.max(0,math.min(max,tonumber(value) or 0))
 p.scroll:SetVerticalScroll(value);setScrollbar(p.bar,value,max,p.scroll:GetHeight())
end
function widgets.RefreshRewardPopup(info,reset)
 local p=widgets.rewardPopup;if not p or not p:IsShown() then return end
 local id=G.selection.quest
 if not id then p:Hide();return end
 if id~=p.questId then reset=true end
 p.questId=id
 p.heading:SetText(widgets.TryExtra("보상 제목",G.GetQuestName,id) or ("퀘스트 "..id))
 local rows,reward=widgets.RewardRows(id,info)
 widgets.rewardCacheId=id;widgets.rewardCache=reward
 local brief=reward and widgets.TryExtra("보상 요약",G.QuestRewardBrief,reward)
 widgets.rewardPreview=type(brief)=="string" and brief or "보상 · 자료 확인 필요"
 if widgets.detailHint and not detailsExpanded then widgets.detailHint:SetText(shortLine(widgets.rewardPreview,480)) end
 local old=reset and 0 or p.scroll:GetVerticalScroll()
 p.body:SetText(table.concat(rows,"\n"));p.body:SetHeight(0)
 local h=math.max(1,math.ceil((p.body:GetStringHeight() or 0)+16));p.body:SetHeight(h);p.child:SetHeight(h)
 widgets.RewardOffset(old)
end
function widgets.OpenRewardPopup(id)
 if not id then return end
 local p=widgets.rewardPopup
 if not p then
  p=CreateFrame("Frame","ForeverQuestGuideRewardWindow",UIParent);widgets.rewardPopup=p
  p:SetSize(490,425);p:SetPoint("CENTER",UIParent,"CENTER",230,0);p:SetClampedToScreen(true)
  p:SetFrameStrata("FULLSCREEN_DIALOG");p:SetToplevel(true);p:EnableMouse(true);p:SetMovable(true);p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
  p:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
  local bg=p:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.055,.075,.095,1)
  p.border=makeBorder(p,"BORDER");paintBorder(p,p.border,0,2,{.43,.67,.77,1})
  label(p,"퀘스트 보상",16,-10,350,24,"GameFontNormalLarge",C.gold)
  button(p,"닫기",407,-10,68,25,function()p:Hide()end)
  p.heading=label(p,"",16,-44,450,42,"GameFontHighlight",C.cyan);p.heading:SetJustifyV("TOP");p.heading:SetWordWrap(true)
  p.scroll=CreateFrame("ScrollFrame",nil,p);p.scroll:SetPoint("TOPLEFT",p,"TOPLEFT",16,-95);p.scroll:SetSize(441,276)
  p.child=CreateFrame("Frame",nil,p.scroll);p.child:SetSize(441,1);p.scroll:SetScrollChild(p.child)
  p.body=label(p.child,"",0,0,434,1,"GameFontHighlight",C.gray);p.body:SetJustifyV("TOP");p.body:SetWordWrap(true);p.body:SetSpacing(5)
  p.bar=makeScrollbar(p,463,-95,276,widgets.RewardOffset)
  p.scroll:EnableMouseWheel(true);p.scroll:SetScript("OnMouseWheel",function(_,delta)widgets.RewardOffset(p.scroll:GetVerticalScroll()-delta*36)end)
  p.retry=button(p,"보상 다시 조회",16,-385,132,26,function()
   widgets.TryExtra("보상 재조회",G.RetryQuestReward,G.selection.quest)
   widgets.RefreshRewardPopup(nil,true)
  end)
  label(p,"게임 정보 우선 · 외부/과거 자료는 별도 표시",157,-385,318,26,"GameFontHighlightSmall",C.dim)
  if G.UIJourneyWidgets then G.UIJourneyWidgets.rewardPopup=p end
 end
 widgets.TryExtra("보상 재조회",G.RetryQuestReward,id)
 G.UIFit(p);p:Show();widgets.RefreshRewardPopup(nil,true)
end
local function buildUI()
 if widgets.frame or not UIParent then return end
 widgets.frame=CreateFrame("Frame","ForeverDungeonQuestGuideFrame",UIParent)
 widgets.frame:SetSize(1200,844)
 widgets.frame:SetPoint("CENTER",UIParent,"CENTER",(G.db.position and G.db.position.x)or 0,(G.db.position and G.db.position.y)or 0)
 widgets.frame:SetClampedToScreen(true);widgets.frame:SetMovable(true);widgets.frame:EnableMouse(true);widgets.frame:RegisterForDrag("LeftButton")
 widgets.frame:SetFrameStrata("DIALOG");widgets.frame:SetToplevel(true)
 local base=widgets.frame:CreateTexture(nil,"BACKGROUND");base:SetAllPoints();base:SetColorTexture(unpack(C.bg))
 local top=widgets.frame:CreateTexture(nil,"BORDER");top:SetPoint("TOPLEFT",0,-1);top:SetPoint("TOPRIGHT",0,-1);top:SetHeight(2);top:SetColorTexture(.85,.63,.26)
 widgets.frame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 widgets.frame:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then
   local ratio=(self.GetEffectiveScale and UIParent.GetEffectiveScale and self:GetEffectiveScale()/UIParent:GetEffectiveScale()) or 1
   G.db.position={x=x-ux/ratio,y=y-uy/ratio}
  end
 end)
 widgets.titleInfo=label(widgets.frame,versionHeading(),19,-12,1014,28,"GameFontNormalLarge",C.gold)
 widgets.versionButton=button(widgets.frame,"버전 확인",1048,-14,94,26,function()
  G.Print(G.VersionReport and G.VersionReport() or ("현재 가이드 버전: "..tostring(G.version or "미확인").." · 화면 버전: "..tostring(G.uiVersion or "미확인")))
 end)
 widgets.versionButton:SetScript("OnEnter",function(self)itemTooltip(self,{"현재 불러온 버전 확인","게임이 실제로 불러온 애드온과 화면 파일의 버전을 채팅창에 표시합니다.","이전 화면이 계속 보일 때 설치된 파일과 불러온 파일의 차이를 확인하세요."})end)
 widgets.versionButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 characterInfo=label(widgets.frame,"",20,-44,586,18,"GameFontHighlightSmall",C.dim)
 widgets.partyButton=button(widgets.frame,"파티 공유 끔",617,-42,128,23,function()
  if G.PartyShareSetEnabled then
   G.PartyShareSetEnabled(not G.PartyShareEnabled())
   G.Print("파티 퀘스트 공유: "..G.PartyShareStatus())
  end
 end)
 widgets.partyButton:SetScript("OnEnter",function(self)
  itemTooltip(self,{"파티 퀘스트 공유 · 직접 동의",G.PartyShareStatus and G.PartyShareStatus() or "모듈 미연결",
   "기본 꺼짐. 양쪽 이용자 모두 켜야 상태를 볼 수 있습니다.",
   "현재 수락·보고 가능 퀘스트 ID만 전달합니다. 완료 기록·위치·설정은 보내지 않습니다."})
 end)
 widgets.partyButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.dataInfo=label(widgets.frame,"",753,-42,300,19,"GameFontHighlightSmall",C.cyan);widgets.dataInfo:SetJustifyH("RIGHT")
 widgets.diagnosticPanel=panel(widgets.frame,666,-78,504,264)
 widgets.diagnosticPanel:SetFrameLevel(widgets.frame:GetFrameLevel()+15)
 widgets.diagText=label(widgets.diagnosticPanel,"",14,-14,470,228,"GameFontHighlightSmall",C.gray)
 widgets.diagText:SetJustifyV("TOP")
 widgets.diagnosticPanel:Hide()
 widgets.diagButton=button(widgets.frame,"자료 진단",1061,-42,105,23,function()
  local diagnostics=G.QuestDataDiagnostics and G.QuestDataDiagnostics()
  widgets.diagText:SetText(diagnostics and table.concat(diagnostics.details,"\n") or "진단 모듈을 불러오지 못했습니다.")
  if widgets.diagnosticPanel:IsShown() then widgets.diagnosticPanel:Hide() else widgets.diagnosticPanel:Show()end
 end)
 widgets.diagButton:SetScript("OnEnter",function(self)
  local d=G.QuestDataDiagnostics and G.QuestDataDiagnostics()
  itemTooltip(self,{"QuestieDB/Questie 데이터 진단",d and d.summary or "진단 정보 확인 필요","클릭하면 설치·활성화·API·색인 진행과 해결 절차를 확인합니다."})
 end)
 widgets.diagButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 button(widgets.frame,"×",1155,-12,28,28,function()G.CloseContactPreview();widgets.frame:Hide()end)
 widgets.frame:HookScript("OnHide",function()if widgets.rewardPopup then widgets.rewardPopup:Hide()end;G.CloseContactPreview();if widgets.diagnosticPanel then widgets.diagnosticPanel:Hide()end end)
 label(widgets.frame,"찾기",20,-80,45,22,"GameFontNormal",C.gold)
 widgets.searchInput=CreateFrame("EditBox",nil,widgets.frame,"InputBoxTemplate")
 widgets.searchInput:SetSize(337,25);widgets.searchInput:SetPoint("TOPLEFT",widgets.frame,"TOPLEFT",65,-77);widgets.searchInput:SetAutoFocus(false);widgets.searchInput:SetText("")
 local placeholder=label(widgets.searchInput,"퀘스트 이름 · 번호 · 지역",7,0,316,25,"GameFontDisableSmall",C.dim)
 button(widgets.frame,"×",410,-77,30,25,function()widgets.searchInput:SetText("");widgets.searchInput:ClearFocus()end)
 widgets.searchInput:SetScript("OnEditFocusGained",function()placeholder:Hide()end)
 widgets.searchInput:SetScript("OnEditFocusLost",function(self)if self:GetText()=="" then placeholder:Show() end end)
 widgets.searchInput:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 widgets.searchInput:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
 widgets.searchInput:SetScript("OnTextChanged",function(self)
  if self:GetText()~="" or (self.HasFocus and self:HasFocus()) then placeholder:Hide() else placeholder:Show() end
  if not preserveCategoryScroll then dungeonOffset=0 end
  questOffset=0;browsePage=0
  if G.UIRefresh then G.UIRefresh() end
 end)
 local tabs={{"active","현재 퀘스트"},{"all","전체 검색"},{"zone","지역별"},{"dungeon","던전별"},{"turnin","보고 대기"},{"selected","체크 목록"}}
 for i,tab in ipairs(tabs) do modeButtons[tab[1]]=button(widgets.frame,tab[2],458+(i-1)*122,-77,116,27,function()
  questOffset=0;dungeonOffset=0;browsePage=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.SetViewMode(tab[1])
 end) end
 local now=panel(widgets.frame,12,-116,1176,94)
 now:EnableMouse(true)
 now:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  if j then itemTooltip(self,{j.title,j.location,j.detail,j.nextText}) end
 end)
 now:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 local stripe=now:CreateTexture(nil,"ARTWORK");stripe:SetPoint("TOPLEFT",0,0);stripe:SetPoint("BOTTOMLEFT",0,0);stripe:SetWidth(4);stripe:SetColorTexture(.43,.77,.89,1)
 widgets.nowTitle=label(now,"지금 할 일",15,-6,724,22,"GameFontNormal",C.gold)
 widgets.nowAction=label(now,"",15,-30,724,25,"GameFontHighlight",C.gray)
 widgets.nowPlace=label(now,"",15,-57,724,31,"GameFontHighlightSmall",C.cyan)
 if widgets.nowAction.SetMaxLines then widgets.nowAction:SetMaxLines(1);widgets.nowTitle:SetMaxLines(1);widgets.nowPlace:SetMaxLines(2) end
 quickStartButton=button(now,"이 퀘스트 안내 시작",752,-10,204,32,function()
  local q=G.selection.quest;local j=journey(q)
  if j and j.canGuide then G.StartQuickGuide(q) end
 end)
 G.UIButtonState(quickStartButton,true)
 quickStartButton:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  itemTooltip(self,{"선택한 퀘스트를 따라 진행",j and j.detail or "목록에서 퀘스트를 고르세요.","필요한 선행부터 수락·수행·보고를 안내합니다.","기존 통합 동선은 보관하며 이동 안내창에서 복귀할 수 있습니다."})
 end)
 quickStartButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.locationButton=button(now,"지금 갈 곳 지도",752,-51,204,30,showQuestMap)
 widgets.locationButton:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  itemTooltip(self,{"지금 할 행동의 위치",j and j.location or "퀘스트를 선택하세요.","선행이 필요하면 선행 퀘스트 위치를 표시합니다.","던전 내부 위치가 없으면 입구 접근용 지도와 내부 설명을 구분합니다."})
 end)
 widgets.locationButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.findNextButton=button(now,"우선 할 일 선택",967,-10,197,32,function()
  if visibleSummary.nextQuestId then revealQuest(visibleSummary.nextQuestId) end
 end)
 widgets.findNextButton:SetScript("OnEnter",function(self)
  local r=visibleSummary.recommendation
  itemTooltip(self,{"현재 목록에서 다음 할 일 추천",r and r.reason or "보고 가능 → 수행 중 → 수락 가능 → 실제 진행 가능한 선행 순입니다.","게임 퀘스트 상태·제한 조건을 우선하며 수락/완료/보류 상태를 바꾸지 않습니다.","길찾기 최단 시간이나 경험치 효율을 계산한 결과는 아닙니다."})
 end)
 widgets.findNextButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.nowProgress=label(now,"하나 고르기 → 안내 시작\n여러 개는 체크 후 통합 안내",974,-50,190,34,"GameFontHighlightSmall",C.dim)
 widgets.nowProgress:Hide() -- Replaced by an explicit story/catch-up entry point.
 widgets.catchupButton=button(now,"연계 전체 · 동행 안내",967,-51,197,30,function()
  if G.selection.quest and G.ShowCatchupUI then G.ShowCatchupUI(G.selection.quest)
  else G.Print("먼저 목록에서 퀘스트를 선택하세요.") end
 end)
 widgets.catchupButton:SetScript("OnEnter",function(self)
  itemTooltip(self,{"연계 전체와 친구 따라잡기", "선행·후속·선택 퀘스트를 묶어 처음부터 합류 위치까지 표시합니다.",
   "양쪽에서 동행 공유에 동의해야 친구의 완료·수행·보고 상태를 비교합니다.","동행 공유는 기본 꺼짐, 조회한 기록은 저장하지 않습니다."})
 end)
 widgets.catchupButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 local left=panel(widgets.frame,12,-220,202,500)
 local mid=panel(widgets.frame,224,-220,432,500)
 local right=panel(widgets.frame,666,-220,522,500)
 widgets.leftTitle=label(left,"1  장소 고르기",10,-7,183,24,"GameFontNormal",C.gold)
 widgets.factionButtons={}
 local factionItems={{"auto","자동"},{"Alliance","얼라"},{"Horde","호드"},{"all","전체"}}
 for i,entry in ipairs(factionItems) do
  local x=({8,75,115,155})[i];local width=({64,37,37,39})[i]
  widgets.factionButtons[entry[1]]=button(left,entry[2],x,-36,width,23,function()questOffset=0;dungeonOffset=0;browsePage=0;G.SetFactionFilter(entry[1])end)
  widgets.factionButtons[entry[1]]:SetScript("OnEnter",function(self)itemTooltip(self,{"표시 진영: "..entry[2],"자동은 현재 캐릭터의 실제 진영입니다.","다른 진영 보기는 검색용입니다. 수행 불가 퀘스트는 안내에 추가하지 않습니다."})end)
  widgets.factionButtons[entry[1]]:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 widgets.hideToggle=button(left,"제한 숨김",8,-65,90,23,function()G.db.hideUnavailable=not G.db.hideUnavailable;G.UIRefresh()end)
 widgets.incompleteToggle=button(left,"완료 제외",102,-65,92,23,function()G.db.onlyIncomplete=not G.db.onlyIncomplete;G.UIRefresh()end)
 widgets.hideToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"전체 목록에서 제한 퀘스트 숨기기","지역·던전·전체 검색의 [전체] 상태에서 적용합니다.","[미수락]·[조건 필요] 등 상태를 직접 고르면 숨긴 항목도 확인할 수 있습니다.","실제로 수락한 퀘스트와 체크·보류 목록은 유지됩니다."})end)
 widgets.hideToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.incompleteToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"전체 목록에서 완료 퀘스트 숨기기","지역·던전·전체 검색의 [전체] 상태에서 적용합니다.","[완료]를 누르면 이 설정을 바꾸지 않고 완료 기록을 볼 수 있습니다.","상태별 건수는 숨기기 전의 현재 검색 범위를 기준으로 표시합니다."})end)
 widgets.incompleteToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.dungeonRows={};bindWheel(left,scrollDungeon)
 for i=1,DUNGEON_MAX_ROWS do
  local r=row(left,8,-98-(i-1)*30,165,28,function(self)
   if self.dungeon or self.zone then
    questOffset=0;local dungeon,zone=self.dungeon,self.zone;preserveCategoryScroll=true
    if widgets.searchInput:GetText()~="" then widgets.searchInput:SetText("") end
    if dungeon then G.SetDungeon(dungeon) else G.SetZone(zone) end
    preserveCategoryScroll=false
   end
  end)
  bindWheel(r,scrollDungeon);widgets.dungeonRows[i]=r
 end
 widgets.dungeonScrollbar=makeScrollbar(left,181,-98,358,setDungeonOffset);bindWheel(widgets.dungeonScrollbar,scrollDungeon)
 left.pagination=label(left,"",10,-469,182,20,"GameFontHighlightSmall",C.dim)
 label(mid,"2  퀘스트 보기",12,-7,113,25,"GameFontNormal",C.gold)
 widgets.levelButton=button(mid,"레벨 전체",125,-9,86,23,function()
  local nextMode={all="near",near="available",available="above",above="all"}
  browseLevel=nextMode[browseLevel] or "all";browsePage=0;questOffset=0;G.UIRefresh()
 end)
 widgets.levelButton:SetScript("OnEnter",function(self)itemTooltip(self,{"퀘스트 레벨 필터","전체 → 캐릭터 레벨 ±5 → 현재 최소 수락 수준 → 최소 수락 레벨 초과 순서로 전환합니다.","자료에 없는 최소 수락 레벨은 추측하지 않습니다."})end)
 widgets.levelButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.sortButton=button(mid,"정렬 번호",213,-9,76,23,function()
  local nextMode={id="level",level="status",status="distance",distance="id"}
  browseSort=nextMode[browseSort] or "id";browsePage=0;questOffset=0;G.UIRefresh()
 end)
 widgets.sortButton:SetScript("OnEnter",function(self)itemTooltip(self,{"전체 범위 정렬","번호 → 퀘스트 레벨 → 수락 상태 → 같은 지도상 실제 좌표 직선거리 순서입니다.","거리 정보가 없는 퀘스트는 뒤에 배치합니다. 실제 지형 이동 시간 계산은 아닙니다."})end)
 widgets.sortButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.chainToggle=button(mid,"연계 켬",292,-9,59,23,function()G.db.groupChains=not G.db.groupChains;questOffset=0;G.UIRefresh()end)
 widgets.chainToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"연계 묶기","실제 선행 관계로 연결된 퀘스트만 하나의 테두리 안에 표시합니다.","연계 끝 표시 뒤부터는 별개의 퀘스트입니다.","목록 번호는 분기가 있는 경우 수행 순서를 뜻하지 않습니다."})end)
 widgets.chainToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.densityButton=button(mid,"상세 5줄",354,-9,65,23,function()
  pendingScrollAnchor=G.QuestVisibleAnchor and G.QuestVisibleAnchor(visibleDisplay,questOffset)
  if pendingScrollAnchor then pendingScrollAnchor.slot=1 end
  G.db.questListCompact=not (G.db.questListCompact~=false)
  widgets.ApplyListLayout();G.UIRefresh()
 end)
 widgets.densityButton:SetScript("OnEnter",function(self)itemTooltip(self,{"퀘스트 카드 밀도", "간단 9줄: 제목·상태·지금 행동을 동시에 9줄 표시", "상세 5줄: 이동·선행 조건·레벨 정보까지 카드에 표시", "설정은 캐릭터에 저장되며 실제 퀘스트·동선은 바꾸지 않습니다."})end)
 widgets.densityButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 local phases={{"all","전체"},{"unaccepted","미수락"},{"active","수행 중"},{"turnin","보고 가능"},{"done","완료"},{"blocked","조건 필요"}}
 for i,entry in ipairs(phases) do
  widgets.phaseButtons[entry[1]]=button(mid,entry[2],8+((i-1)%3)*139,-36-math.floor((i-1)/3)*32,134,28,function()statusFilter=entry[1];questOffset=0;browsePage=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.UIRefresh()end)
  widgets.phaseButtons[entry[1]]:SetScript("OnEnter",function(self)
   local note=entry[1]=="unaccepted" and "아직 받지 않은 퀘스트입니다. 선행·레벨 등 조건이 남은 항목도 포함됩니다."
    or entry[1]=="turnin" and "목표를 채워 보고할 수 있는 상태입니다. 보고하고 보상을 받아야 완료됩니다."
    or entry[1]=="done" and "실제 보고·보상 완료 기록이 확인된 퀘스트입니다. 체크 표시나 후속 진행만으로 완료로 바꾸지 않습니다."
    or entry[1]=="blocked" and "선행·레벨·보류 등 조건 확인이 필요한 항목입니다. 다른 상태와 겹치므로 전체 건수에 더하지 마세요."
    or "실제 수락·목표·보고 기록을 기준으로 표시합니다."
   itemTooltip(self,{entry[2].." 상태 보기",note,"상태가 맞는 퀘스트의 연계는 앞뒤 관계를 함께 표시합니다. 범위 밖 항목에는 ‘연계 참고’가 붙습니다.","체크와 게임 완료 기록은 필터를 바꿔도 그대로입니다."})
  end)
  widgets.phaseButtons[entry[1]]:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 widgets.headerInfo=label(mid,"",12,-97,288,32,"GameFontHighlightSmall",C.dim)
 widgets.focusButton=button(mid,"목록 넓게",307,-103,110,24,function()
  pendingScrollAnchor=G.QuestVisibleAnchor and G.QuestVisibleAnchor(visibleDisplay,questOffset)
  if pendingScrollAnchor then pendingScrollAnchor.slot=1 end
  G.db.questListWide=not (G.db.questListWide==true)
  widgets.ApplyListLayout();G.UIRefresh()
 end)
 widgets.focusButton:SetScript("OnEnter",function(self)itemTooltip(self,{"목록 중심 / 공략 중심", "목록 넓게: 오른쪽 공략 영역을 잠시 숨기고 목록 가로폭을 늘립니다.", "공략 복귀: 선택 퀘스트를 유지하며 오른쪽 상세 안내를 다시 표시합니다.", "퀘스트·완료·체크·보류·이동 동선 기록은 변하지 않습니다."})end)
 widgets.focusButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.headerInfo:SetJustifyV("TOP");if widgets.headerInfo.SetWordWrap then widgets.headerInfo:SetWordWrap(false) end
 widgets.questRows={};widgets.chapterFrames={};bindWheel(mid,scrollQuest)
 for i=1,QUEST_MAX_ROWS do
  local r=row(mid,8,-QUEST_ROW_TOP-(i-1)*QUEST_ROW_STRIDE,389,QUEST_ROW_HEIGHT,function(self)
   if self.quest then if not G.TryQuestChatClick(self.quest) then G.SetQuest(self.quest) end
   elseif self.subchapterKey then
    local index
    for n,visible in ipairs(widgets.questRows) do if visible==self then index=n;break end end
    pendingScrollAnchor={kind="subchapter",key=self.subchapterKey,slot=index or 1}
    G.db.chainCollapsed[self.subchapterKey]=not self.subchapterCollapsed
    G.UIRefresh()
   elseif self.chainKey then
    local index
    for n,visible in ipairs(widgets.questRows) do if visible==self then index=n;break end end
    pendingScrollAnchor={kind="chain",key=self.chainKey,slot=index or 1}
    G.ToggleChainGroup(self.chainKey);G.UIRefresh()
   end
  end)
  makeQuestCheckbox(r)
  r.cardBorder=makeBorder(r,"BORDER")
  r.rail=r:CreateTexture(nil,"ARTWORK");r.rail:SetPoint("TOPLEFT",r,"TOPLEFT",9,0);r.rail:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",9,0);r.rail:SetWidth(2);r.rail:SetColorTexture(.28,.53,.67,.95);r.rail:Hide()
  r.edge=r:CreateTexture(nil,"ARTWORK");r.edge:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",9,0);r.edge:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-1,0);r.edge:SetHeight(2);r.edge:SetColorTexture(.28,.53,.67,.95);r.edge:Hide()
  r.stepDot=r:CreateTexture(nil,"OVERLAY");r.stepDot:Hide()
  bindWheel(r,scrollQuest);bindWheel(r.checkbox,scrollQuest);widgets.questRows[i]=r
 end
 for i=1,QUEST_MAX_ROWS do
  local group=CreateFrame("Frame",nil,mid);group:EnableMouse(false);group:SetFrameLevel(widgets.questRows[1]:GetFrameLevel()+1)
  group.border=makeBorder(group,"ARTWORK");group:Hide();widgets.chainFrames[i]=group
  local chapter=CreateFrame("Frame",nil,mid);chapter:EnableMouse(false);chapter:SetFrameLevel(widgets.questRows[1]:GetFrameLevel()+1)
  chapter.border=makeBorder(chapter,"ARTWORK");chapter:Hide();widgets.chapterFrames[i]=chapter
 end
 widgets.questScrollbar=makeScrollbar(mid,409,-QUEST_ROW_TOP,QUEST_LIST_HEIGHT,setQuestOffset);bindWheel(widgets.questScrollbar,scrollQuest)
 widgets.browsePrev=button(mid,"◀",10,-475,32,21,function()
  if browsePage>0 then browsePage=browsePage-1;questOffset=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.UIRefresh()end
 end)
 widgets.browseNext=button(mid,"▶",382,-475,34,21,function()
  browsePage=browsePage+1;questOffset=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.UIRefresh()
 end)
 mid.pagination=label(mid,"",49,-478,326,18,"GameFontHighlightSmall",C.dim)
 mid.pagination:SetJustifyH("CENTER")
 widgets.emptyList=label(mid,"",22,-170,374,178,"GameFontHighlight",C.dim);widgets.emptyList:SetJustifyV("TOP")
 label(right,"3  진행 방법 확인",12,-7,201,25,"GameFontNormal",C.gold)
 widgets.ToggleRewardView=function()
  local id=G.selection.quest
  if not id then G.Print("보상을 확인할 퀘스트 또는 하위 단계를 먼저 선택하세요.");return end
  if GameTooltip then GameTooltip:Hide() end
  widgets.OpenRewardPopup(id)
 end
 widgets.rewardButton=button(right,"보상 보기",212,-9,94,23,widgets.ToggleRewardView)
 widgets.wideRewardButton=button(mid,"보상 보기",198,-103,100,24,widgets.ToggleRewardView);widgets.wideRewardButton:Hide()
 widgets.rewardButton:SetScript("OnEnter",function(self)
  local q=G.selection.quest
  itemTooltip(self,{"퀘스트 보상",q and "클릭하면 선택한 퀘스트의 보상 창이 열립니다." or "퀘스트를 선택하세요."})
 end)
 widgets.rewardButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.fontToggle=button(right,"글자 크게",315,-9,89,23,function()
  G.db.uiLargeText=not (G.db.uiLargeText==true)
  widgets.fontSizeState=nil;G.UIRefresh()
 end)
 widgets.fontToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"글자 크기", "퀘스트 카드와 안내문 글씨를 한 단계 키우거나 원래 크기로 되돌립니다.","설정은 이 캐릭터에 저장됩니다."})end)
 widgets.fontToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.detailToggle=button(right,"상세 보기",411,-9,101,23,function()
  widgets.rewardFocusQuest=nil
  detailsExpanded=not detailsExpanded;G.UIRefresh()
 end)
 widgets.detailToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"안내 표시 전환", "요약은 지금 행동·위치·목표·보고·다음을 순서대로 표시합니다.","상세에서는 전체 선행·연계·목표 기록과 설명을 스크롤할 수 있습니다."})end)
 widgets.detailToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.detailHead=label(right,"",12,-33,496,45,"GameFontHighlight",C.cyan)
 local titleClick=CreateFrame("Button",nil,right);titleClick:SetPoint("TOPLEFT",right,"TOPLEFT",12,-33);titleClick:SetSize(496,45)
 titleClick:SetScript("OnClick",function()G.TryQuestChatClick(G.selection.quest)end)
 titleClick:SetScript("OnEnter",function(self)if G.selection.quest then itemTooltip(self,{G.GetQuestName(G.selection.quest),"채팅창이 열린 상태에서 시프트 키를 누르고 클릭: 퀘스트 링크"}) end end)
 titleClick:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.contactStart=button(right,"받는 곳 지도",10,-84,248,26,function()
  if G.QuestStartItemGuide and G.QuestStartItemGuide(G.selection.quest) then
   detailsExpanded=true;G.UIRefresh();return
  end
  G.ShowContactPreview(G.selection.quest,"accept",widgets.frame)
 end)
 widgets.contactEnd=button(right,"보고할 곳 지도",264,-84,248,26,function()G.ShowContactPreview(G.selection.quest,"turnin",widgets.frame)end)
 for _,v in ipairs({{widgets.contactStart,"accept"},{widgets.contactEnd,"turnin"}}) do
  local b,stage=v[1],v[2]
  b:SetScript("OnEnter",function(self)
   local q=G.selection.quest;local c=q and G.ContactPreview(q,stage)
   local item=(stage=="accept" and G.QuestStartItemGuide and q) and G.QuestStartItemGuide(q)
   if item then itemTooltip(self,{"시작 아이템 획득처",item.action,item.sourceText or "출처 확인 필요","클릭: 자세한 공략 창에서 획득·사용 순서 확인"});return end
   itemTooltip(self,{stage=="accept" and "퀘스트 받는 위치" or "퀘스트 보고 위치",c and c.name or "퀘스트를 선택하세요.",c and c.place or "","클릭하면 작은 지도를 엽니다."})
  end)
  b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 widgets.relationshipInfo=label(right,"",12,-115,495,30,"GameFontHighlightSmall",C.gold)
 if widgets.relationshipInfo.SetMaxLines then widgets.relationshipInfo:SetMaxLines(2) end
 widgets.overview=panel(right,11,-149,501,187)
 local summaryLabels={"① 지금 할 일","② 이동 위치","③ 퀘스트 목표","④ 보고할 대상","⑤ 다음 단계 / 조건"}
 widgets.summary={}
 local positions={-5,-46,-82,-118,-154}
 for i,heading in ipairs(summaryLabels) do
  local y=positions[i]
  local head=label(widgets.overview,heading,12,y,472,14,"GameFontNormalSmall",C.gold)
  local body=label(widgets.overview,"",12,y-14,473,i==1 and 25 or 20,"GameFontHighlightSmall",C.gray)
  body:SetJustifyV("TOP")
  if body.SetWordWrap then body:SetWordWrap(i==1) end
  if body.SetMaxLines then body:SetMaxLines(i==1 and 2 or 1) end
  widgets.summary[i]={head=head,text=body}
 end
 detailScroll=CreateFrame("ScrollFrame",nil,right);detailScroll:SetPoint("TOPLEFT",right,"TOPLEFT",13,-150);detailScroll:SetSize(479,186)
 detailChild=CreateFrame("Frame",nil,detailScroll);detailChild:SetSize(479,1);detailScroll:SetScrollChild(detailChild)
 widgets.detailPrereqs=label(detailChild,"",0,0,473,1,"GameFontHighlightSmall",C.gray);widgets.detailPrereqs:SetJustifyV("TOP")
 if widgets.detailPrereqs.SetSpacing then widgets.detailPrereqs:SetSpacing(4) end
 detailScroll:EnableMouseWheel(true);detailScroll:SetScript("OnMouseWheel",function(self,delta)setDetailOffset(self:GetVerticalScroll()-delta*38)end)
 detailScrollbar=makeScrollbar(right,500,-150,186,setDetailOffset)
 detailScrollbar:EnableMouseWheel(true);detailScrollbar:SetScript("OnMouseWheel",function(_,delta)setDetailOffset(detailScroll:GetVerticalScroll()-delta*38)end)
 widgets.detailHint=label(right,"",13,-338,496,16,"GameFontDisableSmall",C.dim)
 local start=button(right,"체크한 퀘스트 통합 안내",10,-360,248,30,function()G.StartSelectedGuide()end)
 start:SetScript("OnEnter",function(self)itemTooltip(self,{"체크한 퀘스트 함께 진행","필수 선행부터 수락·수행·보고 방문을 구성합니다.","현재 통합 동선이 새 동선으로 바뀝니다."})end)
 start:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 button(right,"체크한 퀘스트 보고 안내",264,-360,248,30,function()G.StartTurninGuide()end)
 scopeStartButton=button(right,"현재 목록 전체 안내",10,-398,502,28,function()
  local mode=G.selection.mode
  if mode=="active" then G.StartActiveGuide(false)
  elseif mode=="turnin" then G.StartActiveGuide(true)
  elseif mode=="dungeon" and G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil)
  else G.Print("현재 퀘스트·보고 대기·던전별 탭에서 사용하세요.") end
 end)
 scopeStartButton:SetScript("OnEnter",function(self)itemTooltip(self,{"현재 탭의 전체 범위","현재 퀘스트: 수락 중인 모든 퀘스트 / 보고 대기: 보고 가능한 모든 퀘스트","던전별: 선택 던전의 진행 가능한 퀘스트와 필요한 선행","검색·단계 필터·체크와 관계없이 탭 전체를 구성합니다."})end)
 scopeStartButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 widgets.selectedInfo=label(right,"",12,-432,218,24,"GameFontHighlightSmall",C.cyan)
 button(right,"체크만 해제",237,-434,126,24,function()G.ClearCheckedQuests()end)
 resetButton=button(right,"동선 초기화",370,-434,142,24,function()G.ResetRoutePlanning();questOffset=0;widgets.searchInput:SetText("");G.UIRefresh()end)
 resetButton:SetScript("OnEnter",function(self)itemTooltip(self,{"동선 초기화","체크·보류·이동 안내를 초기화합니다.","게임의 수락·완료 기록과 화면 설정은 유지됩니다."})end)
 resetButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 deferredListButton=button(right,"보류 목록 0",10,-466,162,24,function()questOffset=0;widgets.searchInput:SetText("");G.SetViewMode("deferred")end)
 resumeOneButton=button(right,"선택 보류 해제",180,-466,162,24,function()G.ResumeSelectedBlocker(G.selection.quest)end)
 resumeOneButton:SetScript("OnEnter",function(self)local blocker=G.DeferredBlocker(G.selection.quest);itemTooltip(self,{"선택 보류 해제",blocker and ("대상: "..G.GetQuestName(blocker)) or "보류된 퀘스트나 후속을 선택하세요."})end)
 resumeOneButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 resumeAllButton=button(right,"전체 보류 해제",350,-466,162,24,function()G.ResumeDeferredQuests("all")end)
 local foot=panel(widgets.frame,12,-730,1176,102)
 widgets.frame.footer=foot
 widgets.guideInfo=label(foot,"가이드 대기 중",11,-6,656,21,"GameFontNormal",C.gold)
 widgets.guideNow=label(foot,"",11,-34,1150,22,"GameFontHighlightSmall",C.gray)
 widgets.navStatus=label(foot,"",11,-57,1150,19,"GameFontHighlightSmall",C.cyan)
 widgets.guideNote=label(foot,"",11,-78,1150,19,"GameFontHighlightSmall",C.dim)
 button(foot,"이동 안내",710,-6,81,24,function()G.ToggleHUD()end)
 button(foot,"전체 순서",796,-6,75,24,function()G.TogglePlanWindow()end)
 footerPrev=button(foot,"이전",876,-6,75,24,function()G.NextGuide(-1,false)end)
 footerNext=button(foot,"다음 확인",956,-6,112,24,function()if G.GuideViewingHistory() then G.ReturnToActiveGuide() else G.NextGuide(1,true) end end)
 G.UIButtonState(footerNext,true)
 button(foot,"중지",1073,-6,89,24,function()G.StopGuide()end)
 footerProgress=G.UIProgress(foot);footerProgress:SetPoint("TOPLEFT",foot,"TOPLEFT",11,-30);footerProgress:SetPoint("TOPRIGHT",foot,"TOPRIGHT",-12,-30);footerProgress:SetHeight(3)
 widgets.frame.left=left;widgets.frame.mid=mid;widgets.frame.right=right
 G.UIJourneyWidgets={titleInfo=widgets.titleInfo,versionButton=widgets.versionButton,chainFrames=widgets.chainFrames,rowHeight=QUEST_ROW_HEIGHT,rowStride=QUEST_ROW_STRIDE,scopeStartButton=scopeStartButton,contactStart=widgets.contactStart,contactEnd=widgets.contactEnd,frame=widgets.frame,questRows=widgets.questRows,questScrollbar=widgets.questScrollbar,phaseButtons=widgets.phaseButtons,nowTitle=widgets.nowTitle,nowAction=widgets.nowAction,nowPlace=widgets.nowPlace,quickStartButton=quickStartButton,findNextButton=widgets.findNextButton,locationButton=widgets.locationButton,detailHead=widgets.detailHead,detailText=widgets.detailPrereqs,detailScroll=detailScroll,relationshipInfo=widgets.relationshipInfo,emptyList=widgets.emptyList,search=widgets.searchInput}
 G.UIJourneyWidgets.statusButtons=widgets.phaseButtons;G.UIJourneyWidgets.nowProgress=widgets.nowProgress
 G.UIJourneyWidgets.dataInfo=widgets.dataInfo;G.UIJourneyWidgets.diagButton=widgets.diagButton;G.UIJourneyWidgets.diagnosticPanel=widgets.diagnosticPanel
 G.UIJourneyWidgets.browsePrev=widgets.browsePrev;G.UIJourneyWidgets.browseNext=widgets.browseNext;G.UIJourneyWidgets.browseLevelButton=widgets.levelButton;G.UIJourneyWidgets.browseSortButton=widgets.sortButton
 G.UIJourneyWidgets.headerInfo=widgets.headerInfo;G.UIJourneyWidgets.rowTop=QUEST_ROW_TOP;G.UIJourneyWidgets.rowCount=QUEST_ROW_COUNT
 G.UIJourneyWidgets.listHeight=QUEST_LIST_HEIGHT
 G.UIJourneyWidgets.densityButton=widgets.densityButton;G.UIJourneyWidgets.focusButton=widgets.focusButton
 G.UIJourneyWidgets.overview=widgets.overview;G.UIJourneyWidgets.overviewRows=widgets.summary
 G.UIJourneyWidgets.detailToggle=widgets.detailToggle;G.UIJourneyWidgets.fontToggle=widgets.fontToggle;G.UIJourneyWidgets.partyButton=widgets.partyButton
 G.UIJourneyWidgets.rewardButton=widgets.rewardButton;G.UIJourneyWidgets.wideRewardButton=widgets.wideRewardButton;G.UIJourneyWidgets.chapterFrames=widgets.chapterFrames
 -- Keep the two reading modes on one frame. Widget identities and save data
 -- remain stable; the right-hand guide is hidden only in wide-list mode.
 widgets.ApplyListLayout=function()
  local compact=G.db.questListCompact~=false
  QUEST_ROW_HEIGHT=compact and 34 or 64
  QUEST_ROW_STRIDE=compact and 38 or 69
  local wide=G.db.questListWide==true
  -- Focus mode uses available monitor height, never forcing tiny UI scaling on 768p screens.
  -- All columns, viewport and footer move together. Normal three-panel view is unchanged.
  local screenHeight=UIParent and UIParent:GetHeight() or 844
  layoutExtra=wide and math.max(0,math.min(160,math.floor(screenHeight-864))) or 0
  QUEST_ROW_COUNT=math.min(QUEST_MAX_ROWS,(compact and 9 or 5)+math.floor(layoutExtra/QUEST_ROW_STRIDE))
  QUEST_LIST_HEIGHT=(QUEST_ROW_COUNT-1)*QUEST_ROW_STRIDE+QUEST_ROW_HEIGHT
  widgets.frame:SetHeight(844+layoutExtra)
  mid:SetSize(wide and 964 or 432,500+layoutExtra)
  left:SetHeight(500+layoutExtra)
  right:SetShown(not wide)
  local footer=widgets.frame.footer
  footer:ClearAllPoints();footer:SetPoint("TOPLEFT",widgets.frame,"TOPLEFT",12,-730-layoutExtra)
  widgets.dungeonVisibleCount=math.min(DUNGEON_MAX_ROWS,12+math.floor(layoutExtra/30))
  for i,r in ipairs(widgets.dungeonRows) do r:ClearAllPoints();r:SetPoint("TOPLEFT",left,"TOPLEFT",8,-98-(i-1)*30);if i>widgets.dungeonVisibleCount then r:Hide() end end
  widgets.dungeonScrollbar:ClearAllPoints();widgets.dungeonScrollbar:SetPoint("TOPLEFT",left,"TOPLEFT",181,-98)
  widgets.dungeonScrollbar:SetHeight(358+layoutExtra)
  left.pagination:ClearAllPoints();left.pagination:SetPoint("TOPLEFT",left,"TOPLEFT",10,-469-layoutExtra)
  local rowWidth=mid:GetWidth()-43
  for i,r in ipairs(widgets.questRows) do
   r:SetSize(rowWidth,QUEST_ROW_HEIGHT)
   r:ClearAllPoints();r:SetPoint("TOPLEFT",mid,"TOPLEFT",8,-QUEST_ROW_TOP-(i-1)*QUEST_ROW_STRIDE)
   if i>QUEST_ROW_COUNT then r:Hide() end
  end
  widgets.questScrollbar:ClearAllPoints()
  widgets.questScrollbar:SetPoint("TOPLEFT",mid,"TOPLEFT",mid:GetWidth()-23,-QUEST_ROW_TOP)
  widgets.questScrollbar:SetHeight(QUEST_LIST_HEIGHT)
  widgets.browseNext:ClearAllPoints()
  widgets.browseNext:SetPoint("TOPLEFT",mid,"TOPLEFT",mid:GetWidth()-50,-475-layoutExtra)
  widgets.browsePrev:ClearAllPoints();widgets.browsePrev:SetPoint("TOPLEFT",mid,"TOPLEFT",10,-475-layoutExtra)
  mid.pagination:ClearAllPoints();mid.pagination:SetPoint("TOPLEFT",mid,"TOPLEFT",49,-478-layoutExtra)
  mid.pagination:SetWidth(mid:GetWidth()-106)
  widgets.headerInfo:SetWidth(wide and mid:GetWidth()-268 or 288)
  widgets.wideRewardButton:ClearAllPoints();widgets.wideRewardButton:SetPoint("TOPLEFT",mid,"TOPLEFT",mid:GetWidth()-232,-103);widgets.wideRewardButton:SetShown(wide)
  widgets.focusButton:SetText(wide and "공략 복귀" or "목록 넓게")
  widgets.focusButton:ClearAllPoints()
  widgets.focusButton:SetPoint("TOPLEFT",mid,"TOPLEFT",mid:GetWidth()-125,-103)
  widgets.densityButton:SetText(compact and "카드 상세" or "카드 간단")
  if G.UIFit then G.UIFit(widgets.frame) end
  G.UIJourneyWidgets.rowCount=QUEST_ROW_COUNT;G.UIJourneyWidgets.rowHeight=QUEST_ROW_HEIGHT
  G.UIJourneyWidgets.rowStride=QUEST_ROW_STRIDE;G.UIJourneyWidgets.listHeight=QUEST_LIST_HEIGHT
 end
 widgets.ApplyListLayout()
 G.UIFit(widgets.frame);widgets.frame:Hide()
end
local function buildPlanUI()
 if planFrame or not UIParent then return end
 planFrame=CreateFrame("Frame","ForeverDungeonQuestGuidePlanFrame",UIParent)
 planFrame:SetSize(600,685);planFrame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 planFrame:SetClampedToScreen(true);planFrame:SetFrameStrata("FULLSCREEN_DIALOG")
 planFrame:SetMovable(true);planFrame:EnableMouse(true);planFrame:RegisterForDrag("LeftButton")
 planFrame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 planFrame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 local back=planFrame:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(unpack(C.bg))
 planHeading=label(planFrame,"전체 방문 동선",16,-10,480,31,"GameFontNormalLarge",C.gold)
 button(planFrame,"×",563,-11,26,27,function()planFrame:Hide()end)
 label(planFrame,"완료/예정 단계 열람 · 실제 경로 유지 | 휠 스크롤",16,-42,410,18,"GameFontHighlightSmall",C.dim)
 planProgress=G.UIProgress(planFrame);planProgress:SetPoint("TOPLEFT",planFrame,"TOPLEFT",14,-64);planProgress:SetPoint("TOPRIGHT",planFrame,"TOPRIGHT",-14,-64);planProgress:SetHeight(4)
 local function move(delta)planOffset=math.max(0,planOffset+delta);G.PlanRefresh()end
 bindWheel(planFrame,move)
 planRows={}
 for i=1,17 do
  planRows[i]=row(planFrame,11,-81-(i-1)*31,554,29,function(self)
   local gd=G.db and G.db.guide
   local id=self.exclusionQuest or (gd and gd.steps and self.guideIndex and gd.steps[self.guideIndex] and gd.steps[self.guideIndex].quest)
   if id and G.TryQuestChatClick(id) then return end
   if self.exclusionQuest then
    local id=self.exclusionQuest;planFrame:Hide();G.ShowUI(true);G.SetQuest(id)
   elseif gd and gd.steps and self.guideIndex then
    G.SelectGuideStep(self.guideIndex)
   end
  end)
  bindWheel(planRows[i],move)
 end
 planBar=makeScrollbar(planFrame,574,-81,525,function(offset)planOffset=offset;G.PlanRefresh()end)
 bindWheel(planBar,move)
 planCounter=label(planFrame,"",16,-616,282,26,"GameFontHighlightSmall",C.dim)
 planPrev=button(planFrame,"◀ 이전",301,-614,79,26,function()move(-#planRows)end)
 planNext=button(planFrame,"다음 ▶",385,-614,79,26,function()move(#planRows)end)
 planExclusionButton=button(planFrame,"제외 0",436,-42,147,20,function()
  showExcluded=not showExcluded;planOffset=0;G.PlanRefresh()
 end)
 local jump=button(planFrame,"현재 단계",469,-614,117,26,function()
  showExcluded=false
  local gd=G.db and G.db.guide
  if gd and gd.steps and #gd.steps>0 then
   G.ReturnToActiveGuide();planOffset=math.max(0,(gd.index or 1)-3)
  end
  G.PlanRefresh()
 end)
 G.UIButtonState(jump,true)
 label(planFrame,"지도 좌표는 참고용 · 실제 이동은 오른쪽 여정 또는 장소 설명",16,-645,566,20,"GameFontHighlightSmall",C.dim)
 G.UIFit(planFrame);planFrame:Hide()
end
function G.PlanRefresh()
 if not planFrame or not planFrame:IsShown() then return end
 local gd=G.db and G.db.guide
 local excluded=gd and gd.excluded or {}
 if planGuide~=gd then showExcluded=gd and gd.halted and #excluded>0 or false;planOffset=0 end
 if showExcluded and #excluded==0 and gd and gd.steps and #gd.steps>0 and not gd.halted then showExcluded=false;planOffset=0 end
 planExclusionButton:SetText(showExcluded and "동선 보기" or ("제외/보류 "..#excluded))
 if showExcluded then
  planGuide=gd;planHeading:SetText("제외/보류 퀘스트 · "..#excluded.."개")
  planOffset=clampOffset(planOffset,#excluded,#planRows)
  local maximum=math.max(0,#excluded-#planRows);setScrollbar(planBar,planOffset,maximum,#planRows)
  planProgress:SetProgress(0,0);planCounter:SetText("제외/보류 "..#excluded.."개 · 툴팁 상세")
  if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
  if planOffset<maximum then planNext:Enable() else planNext:Disable() end
  for i,r in ipairs(planRows) do
   local item=excluded[planOffset+i];r.guideIndex=nil;r.exclusionQuest=item and item.id or nil
   if item then
    r.text:SetText(displayText("|cffffc675[제외]|r "..item.name.." · "..item.reason))
    r.fill:SetColorTexture(.14,.12,.10,.95);r.marker:SetColorTexture(.78,.54,.21,1)
    r:SetScript("OnEnter",function(self)itemTooltip(self,{item.name.." (#"..item.id..")",item.reason,"클릭: 퀘스트 상세 및 보류 해제 · 실제 완료/체크 유지"})end);r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end);r:Show()
   else r:Hide() end
  end
  return
 end
 if not gd or not gd.steps or #gd.steps==0 then
  planGuide=gd
  planHeading:SetText(gd and gd.halted and "진행 가능한 동선 없음" or "진행 중인 동선 없음")
  for _,r in ipairs(planRows)do r.exclusionQuest=nil;r.guideIndex=nil;r:Hide()end
  planCounter:SetText("0 / 0");planProgress:SetProgress(0,0);setScrollbar(planBar,0,0);planPrev:Disable();planNext:Disable()
  return
 end
 local dungeon=G.GetDungeon(gd.dungeon)
 planHeading:SetText(displayText(G.RouteScopeLabel(gd)))
 local done,total=G.GuideProgress();planProgress:SetProgress(done,total)
 if planGuide~=gd then planGuide=gd;planOffset=math.max(0,(gd.index or 1)-3) end
 planOffset=clampOffset(planOffset,#gd.steps,#planRows)
 local maxOffset=math.max(0,#gd.steps-#planRows);setScrollbar(planBar,planOffset,maxOffset,#planRows)
 if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
 if planOffset<maxOffset then planNext:Enable() else planNext:Disable() end
 for i,r in ipairs(planRows) do
  r.exclusionQuest=nil
  local ix=planOffset+i
  local st=gd.steps[ix]
  if st then
   r.guideIndex=ix
   local active=ix==(gd.index or 1);local viewed=G.GuideViewingHistory() and ix==G.GuideViewIndex()
   local prefix=active and ("|cff83d4fa"..ix..". 진행|r") or (tostring(ix)..".")
   local status=G.GuideViewStatus(st,ix)
   if status and ix<(gd.index or 1) then prefix=(G.StepIsDone(st,ix) and "|cff87dc98" or "|cff9daab6")..tostring(ix)..". 기록|r" end
   if viewed then prefix="|cffc4b1ff열람|r "..prefix end
   r.fill:SetColorTexture(active and .17 or viewed and .15 or .10,active and .29 or viewed and .20 or .13,active and .36 or viewed and .31 or .16,.95)
   local texts={accept="|cff74d7ff[수락]|r",turnin="|cff7cd18d[보고]|r",objective="|cffffd178[수행]|r",entrance="|cffffa36e[입구]|r",inside="|cffacaad4[던전]|r"}
   r.text:SetText(displayText(prefix.." "..(texts[st.kind] or "[단계]").." "..(st.questName or st.title or "")..(st.point and " |cff72ce98[지도]|r" or st.indoor and " |cffdaaaff[던전 내부]|r" or st.landmark and " |cff96d9ed[장소 안내]|r" or st.regionHint and " |cff96d9ed[지역 안내]|r" or (G.walkthroughRecords and G.walkthroughRecords[tonumber(st.quest)]) and " |cff96d9ed[행동 안내]|r" or " |cff9ba4aa[좌표 미확인]|r")))
   r.marker:SetColorTexture(active and .43 or viewed and .68 or .22,active and .77 or viewed and .56 or .31,active and .94 or viewed and .93 or .39,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{st.title,st.note or "","클릭하여 기록/예정 단계 열람 · 진행 위치 유지"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
   r:Show()
  else r.guideIndex=nil;r:Hide() end
 end
 planCounter:SetText("진행 "..done.."/"..total.." · "..(planOffset+1).."–"..math.min(total,planOffset+#planRows).." 표시")
end
function G.TogglePlanWindow()
 buildPlanUI()
 if not planFrame then return end
 if planFrame:IsShown() then planFrame:Hide() else G.UIFit(planFrame);planGuide=nil;planFrame:Show();G.PlanRefresh() end
end
function G.ShowRouteExclusions()
 buildPlanUI();if not planFrame then return end
 G.UIFit(planFrame);planGuide=G.db and G.db.guide;showExcluded=true;planOffset=0;planFrame:Show();G.PlanRefresh()
end
function G.IsUIShown() return widgets.frame and widgets.frame:IsShown() or false end
function widgets.RenderGuideSummary(q,desc,j,status,isSkipped,startItem,progress)
  local displayName=desc.name or (widgets.TryExtra("퀘스트 이름",G.GetQuestName,q) or ("퀘스트 "..q))
  if (q==4022 or q==4023 or q==4024) and G.TitleChapterStepLabel then
   displayName=displayName.." · "..(widgets.TryExtra("연계 단계 이름",G.TitleChapterStepLabel,q,1) or "진행 단계")
  end
  widgets.detailHead:SetText(displayName.."\n"..(isSkipped and "|cffb4cad8선택 불필요 (택일)|r" or statusTag(status)..status.label.."|r").." · "..j.verb)
  local actionText=(startItem and status.key=="unaccepted" and startItem.action or (j.detail or j.title or "진행 정보 확인 필요")):match("[^\n]+") or "진행 정보 확인 필요"
  widgets.summary[1].text:SetText(shortLine((j.prerequisite and "먼저 선행: " or "")..actionText,870))
  widgets.summary[2].text:SetText(shortLine(startItem and startItem.place or j.location or "실제 위치 확인 필요",455))
  local goalText
  if progress and progress.available then goalText=progressLine(progress)
  elseif status.key=="done" then goalText="게임의 보상 수령 완료 기록 확인"
  else goalText=desc.goal or widgets.TryExtra("퀘스트 목표",G.QuestObjectiveText,q) or "퀘스트 목표 자료 미확인" end
  widgets.summary[3].text:SetText(shortLine(startItem and status.key=="unaccepted" and (startItem.sourceText or goalText) or goalText,455))
  local reportName=widgets.TryExtra("보고 대상",G.QuestContactName,q,"turnin")
  widgets.summary[4].text:SetText(shortLine(reportName and ("보고: "..reportName) or "보고 대상 미확인 · 위 [보고할 곳 지도] 확인",455))
  local condition=status.blocked and (desc.reason or status.reason or "진행 조건 확인 필요")
  widgets.summary[5].text:SetText(shortLine(condition and ("조건: "..condition) or (j.nextText or "다음 진행 상황을 확인하세요."),455))
end
function widgets.PrimeGuide(q)
 if not q then return end
 local j=widgets.TryExtra("기본 공략",journey,q)
 local status=widgets.TryExtra("퀘스트 상태",questStatus,q) or {key="unknown",label="기록 확인",detail="실제 퀘스트 기록을 확인하세요."}
 if type(j)~="table" then j={title="진행 정보 확인",verb="확인 필요",location="실제 위치 확인 필요",detail="게임 퀘스트 로그에서 목표를 확인하세요.",nextText="자료가 로드되면 다시 확인하세요."} end
 local desc={name=widgets.TryExtra("퀘스트 이름",G.GetQuestName,q),goal=widgets.TryExtra("퀘스트 목표",G.QuestObjectiveText,q)}
 widgets.RenderGuideSummary(q,desc,j,status,false,nil,nil)
 if detailQuest~=q then
  local rows={"지금 할 일: "..tostring(j.title or "확인 필요"),"장소: "..tostring(j.location or "위치 확인 필요"),tostring(j.detail or "게임 로그 확인"),"다음: "..tostring(j.nextText or "진행 상황 확인")}
  detailText(table.concat(rows,"\n"),q)
 end
 if widgets.rewardButton then widgets.rewardButton:Enable();widgets.wideRewardButton:Enable() end
end
function G.UIRefresh()
 if not widgets.frame or not widgets.frame:IsShown() or not G.db then return end
 if widgets.titleInfo then widgets.titleInfo:SetText(versionHeading()) end
 if widgets.fontSizeState~= (G.db.uiLargeText==true) then
  local large=G.db.uiLargeText==true
  widgets.fontSizeState=large
  for _,r in ipairs(widgets.questRows) do
   readableSize(r.text,large and 13 or 12)
   readableSize(r.progressText,large and 13 or 12)
   readableSize(r.blockerText,large and 12 or 11)
   readableSize(r.statusText,large and 12 or 11)
  end
  for _,entry in ipairs(widgets.summary or {})do readableSize(entry.text,large and 13 or 12) end
  readableSize(widgets.detailPrereqs,large and 13 or 12)
 end
 if widgets.partyButton and G.PartyShareEnabled then
  widgets.partyButton:SetText(G.PartyShareEnabled() and "파티 공유 켬" or "파티 공유 끔")
  G.UIButtonState(widgets.partyButton,G.PartyShareEnabled())
 end
 widgets.fontToggle:SetText(G.db.uiLargeText==true and "글자 보통" or "글자 크게")
 widgets.detailToggle:SetText(detailsExpanded and "요약 보기" or "상세 보기")
 journeyCache={};stateCache={}
 widgets.statusCache={};widgets.progressCache={}
 local mode=G.selection.mode or "all"
 if characterInfo then
  local n=G.SafeCall(UnitName,"player") or "현재 캐릭터"
  local f=G.player.faction=="Alliance" and "얼라이언스" or G.player.faction=="Horde" and "호드" or "진영 확인 중"
  local active,ready=0,0;for id in pairs(G.activeQuests or {}) do active=active+1;if G.IsReadyToTurnIn(id) then ready=ready+1 end end
  characterInfo:SetText(n.." · "..(G.player.level or 1).."레벨 · "..f.."   |   진행 "..active.." · 보고 "..ready.." · 캐릭터별 저장")
 end
 if scopeStartButton then
  local label=mode=="active" and "수락한 퀘스트 모두 안내" or mode=="turnin" and "보고 대기 모두 안내" or mode=="dungeon" and "선택 던전 전체 안내" or "현재 퀘스트 / 던전 탭에서 전체 안내"
  scopeStartButton:SetText(label)
  if mode=="active" or mode=="turnin" or mode=="dungeon" then scopeStartButton:Enable() else scopeStartButton:Disable() end
 end
 if quickStartButton then if G.selection.quest then quickStartButton:Enable() else quickStartButton:Disable() end end
 local search=widgets.searchInput and widgets.searchInput:GetText() or ""
 local category=mode=="zone" and G.selection.zone or mode=="dungeon" and G.selection.dungeon or nil
 if lastBrowseCategory~=category then questOffset=0;browsePage=0;statusFilter="all";lastBrowseCategory=category end
 if lastBrowseMode~=mode or lastBrowseSearch~=search or lastBrowseFaction~=(G.db.factionFilter or "auto") then
  questOffset=0;browsePage=0;statusFilter="all"
  if not preserveCategoryScroll and lastBrowseMode and (lastBrowseMode=="dungeon")~=(mode=="dungeon") then dungeonOffset=0 end
  lastBrowseMode,lastBrowseSearch=mode,search
  lastBrowseFaction=G.db.factionFilter or "auto"
 end
 if widgets.dataInfo then
  local diagnostic=G.QuestDataDiagnostics and G.QuestDataDiagnostics()
  widgets.dataInfo:SetText(diagnostic and (diagnostic.summary.." · "..G.QuestIndexStatus()) or "자료 상태 미확인")
  if diagnostic and widgets.diagnosticPanel:IsShown() then widgets.diagText:SetText(table.concat(diagnostic.details,"\n")) end
 end
 for key,b in pairs(modeButtons) do
  b:SetText(({all="전체 검색",active="현재 퀘스트",turnin="보고 대기",zone="지역별",dungeon="던전별",selected="체크 목록"})[key]);G.UIButtonState(b,key==mode)
 end
 -- The left category list is separate: region groups everywhere except
 -- dungeon mode. Clicking a category opens that region/dungeon tab.
 local dungeonMode=mode=="dungeon"
 widgets.leftTitle:SetText(dungeonMode and "1  던전 고르기" or "1  지역 고르기")
 local choices
 if dungeonMode then
  choices=G.SearchDungeons(search)
 else
  choices=G.SearchQuestZones(search)
  if #choices==0 and search~="" then choices=G.SearchQuestZones("") end
 end
 dungeonOffset=clampOffset(dungeonOffset,#choices,(widgets.dungeonVisibleCount or 12))
 dungeonMaxScroll=math.max(0,#choices-(widgets.dungeonVisibleCount or 12))
 setScrollbar(widgets.dungeonScrollbar,dungeonOffset,dungeonMaxScroll,(widgets.dungeonVisibleCount or 12))
 for i,r in ipairs(widgets.dungeonRows) do
  local entry=i<=(widgets.dungeonVisibleCount or 12) and choices[dungeonOffset+i] or nil
  if entry then
   r:Show()
   r.dungeon=dungeonMode and entry.dungeon.id or nil
   r.zone=(not dungeonMode) and entry.key or nil
   local id=dungeonMode and entry.dungeon.id or entry.key
   local selected=dungeonMode and G.selection.dungeon==id or G.selection.zone==id
   local name=dungeonMode and entry.dungeon.name or ((entry.kind=="raid" and "[공격대] " or entry.kind=="dungeon" and "[던전] " or entry.kind=="pvp" and "[전장] " or "")..entry.name)
   local count=dungeonMode and #filteredQuests(entry.dungeon) or G.ZoneFactionCount(entry)
   r.text:SetText((selected and "|cffffd77b▶ |r" or "")..name.." |cff899aa3("..count..")|r")
   r.marker:SetColorTexture(selected and .43 or .25,selected and .77 or .39,selected and .94 or .45,1)
   r.fill:SetColorTexture(selected and .17 or .11,selected and .29 or .14,selected and .36 or .17,.92)
   if dungeonMode then
    local d=entry.dungeon
    r:SetScript("OnEnter",function(self)itemTooltip(self,{d.name,"레벨 "..(d.level or "미확인"),d.warning or ("관련 퀘스트 "..#d.ids.."건")})end)
   else
    local z=entry
    r:SetScript("OnEnter",function(self)itemTooltip(self,{z.name,(z.kind=="raid" and "공격대 퀘스트" or z.kind=="dungeon" and "던전 퀘스트" or "지역별 퀘스트 자료 분류"),z.count.."개 등록 (검색 인덱스 누적)","클릭하면 미수락·완료를 포함한 지역 퀘스트를 확인합니다."})end)
   end
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.dungeon=nil;r.zone=nil;r:Hide() end
 end
 widgets.frame.left.pagination:SetText(#choices==0 and "분류 없음" or ((dungeonOffset+1).."–"..math.min(#choices,dungeonOffset+(widgets.dungeonVisibleCount or 12)).." / "..#choices.." 분류"))
 local chosenFaction=G.db.factionFilter or "auto"
 for key,b in pairs(widgets.factionButtons or {}) do
  b:SetText(key=="auto" and ("자동"..(G.player.faction=="Alliance" and "(얼)" or G.player.faction=="Horde" and "(호)" or "(?)")) or
    ({Alliance="얼라",Horde="호드",all="전체"})[key])
  G.UIButtonState(b,key==chosenFaction)
 end
 widgets.hideToggle:SetText(G.db.hideUnavailable and "제한 숨김 켬" or "제한 숨김 끔");G.UIButtonState(widgets.hideToggle,G.db.hideUnavailable)
 widgets.incompleteToggle:SetText(G.db.onlyIncomplete and "완료 제외 켬" or "완료 제외 끔");G.UIButtonState(widgets.incompleteToggle,G.db.onlyIncomplete)
 widgets.levelButton:SetText(({all="레벨 전체",near="레벨 ±5",available="수락 수준",above="레벨 초과"})[browseLevel])
 widgets.sortButton:SetText(({id="정렬 번호",level="정렬 레벨",status="정렬 상태",distance="정렬 거리"})[browseSort])
 local ids,total,building
 local d=G.GetDungeon(G.selection.dungeon)
 if mode=="dungeon" then
  ids=filteredQuests(d,{ignoreStateFilters=true});total=#ids;building=false
  if search~="" then
   local match=G.Clean(search)
   local filtered={}
   for _,id in ipairs(ids) do
    if tostring(id)==match or string.find(G.Clean(G.GetQuestName(id)),match,1,true) or string.find(G.Clean((G.DBRawGet or G.DBGet)(QuestDB,id,"name")),match,1,true) or
       (d and (string.find(G.Clean(d.name),match,1,true) or string.find(G.Clean(d.aliases),match,1,true))) then
     filtered[#filtered+1]=id
    end
   end
   ids=filtered;total=#ids
  end
  local list={}
  for _,id in ipairs(ids) do if not G.QuestBrowseMatchesLevel or G.QuestBrowseMatchesLevel(id,browseLevel) then list[#list+1]=id end end
  if G.SortBrowseResults then G.SortBrowseResults(list,browseSort) else table.sort(list) end
  total=#list;ids={}
  for i=browsePage*browsePageSize+1,math.min((browsePage+1)*browsePageSize,total) do ids[#ids+1]=list[i] end
 else
  ids,total,building=G.SearchQuestIds(mode,search,{ignoreStateFilters=true,offset=browsePage*browsePageSize,limit=browsePageSize,levelFilter=browseLevel,sortMode=browseSort})
 end
 if browsePage>0 and total<=browsePage*browsePageSize then
  browsePage=math.max(0,math.ceil(total/browsePageSize)-1)
  if mode=="dungeon" then
   local source=filteredQuests(d,{ignoreStateFilters=true})
   local list={};for _,id in ipairs(source)do if not G.QuestBrowseMatchesLevel or G.QuestBrowseMatchesLevel(id,browseLevel) then list[#list+1]=id end end
   if G.SortBrowseResults then G.SortBrowseResults(list,browseSort)else table.sort(list)end
   ids={};for i=browsePage*browsePageSize+1,math.min((browsePage+1)*browsePageSize,#list) do ids[#ids+1]=list[i] end
  else
   ids,total,building=G.SearchQuestIds(mode,search,{ignoreStateFilters=true,offset=browsePage*browsePageSize,limit=browsePageSize,levelFilter=browseLevel,sortMode=browseSort})
  end
 end
 -- Region search may choose its first category while it resolves the scoped
 -- list. Remember that choice now, so the next status click is not reset.
 if mode=="zone" and category~=G.selection.zone then category=G.selection.zone;lastBrowseCategory=category end
 local grouped=mode=="active" or mode=="turnin" or mode=="selected" or mode=="deferred" or (mode=="all" and search=="")
 local display=G.QuestListRows(ids,grouped)
 local counts=G.QuestStatusSummary and G.QuestStatusSummary(ids,widgets.statusCache) or {all=#ids,unknown=#ids}
 local candidateSet,matchingSet,actionCandidates={},{},{}
 -- Browse-only preferences must never erase a real accepted quest whose DB
 -- record is missing. Explicit status filters inspect the full scoped set.
 local applyBrowsePreferences=mode=="dungeon" or mode=="zone" or (mode=="all" and search~="")
 for _,id in ipairs(ids) do
  if not candidateSet[id] then
   candidateSet[id]=true
   if matchesStatus(questStatus(id),statusFilter) and
     (statusFilter~="all" or not applyBrowsePreferences or G.IsQuestBrowseVisible(id)) then
    matchingSet[id]=true;actionCandidates[#actionCandidates+1]=id
   end
  end
 end
 if widgets.chainToggle then widgets.chainToggle:SetText(G.db.groupChains~=false and "연계 켬" or "연계 끔");G.UIButtonState(widgets.chainToggle,G.db.groupChains~=false) end
 if G.QuestChainRows then display=G.QuestChainRows(display,mode..":"..tostring(category or ""),(mode=="dungeon" or mode=="zone") and search=="",{expandCompleted=statusFilter~="all"}) end
 display=statusRows(display,matchingSet)
 if G.QuestTitleNestedRows then display=G.QuestTitleNestedRows(display) end
 if G.QuestListSeparateBlocks then display=G.QuestListSeparateBlocks(display,mode..":"..tostring(category or "")) end
 visibleDisplay=display
 local shownIds,shownSet,chainByQuest={},{},{}
 for _,entry in ipairs(display) do
  local members=entry.kind=="chain" and entry.memberIds or (entry.kind=="quest" and {entry.id}) or {}
  for _,id in ipairs(members) do
   if not shownSet[id] then shownSet[id]=true;shownIds[#shownIds+1]=id end
   if entry.kind=="chain" then chainByQuest[id]=entry end
  end
 end
 visibleSummary=G.JourneySummary(actionCandidates,journeyCache,stateCache)
 if G.RecommendNextQuest then
  local recommended=G.RecommendNextQuest(actionCandidates,journeyCache,stateCache)
  if recommended then
   visibleSummary.nextQuestId=recommended.questId
   visibleSummary.nextAction=recommended.journey
   visibleSummary.recommendation=recommended
  end
 end
 widgets.findNextButton:SetText(visibleSummary.recommendation and ("추천 · "..visibleSummary.recommendation.phaseLabel.."할 일") or "우선 할 일 선택")
 if not G.selection.quest and #shownIds>0 then
  G.selection.quest=visibleSummary.nextQuestId or actionCandidates[1] or shownIds[1];G.db.selectedQuest=G.selection.quest;pendingReveal=true
 end
 -- Commit the basic guide as soon as the selected ID is determined.
 -- Do not let a failing secondary pane leave five empty headings.
 if G.selection.quest then widgets.PrimeGuide(G.selection.quest) end
 if pendingScrollAnchor and G.QuestFindAnchor then
  local found=G.QuestFindAnchor(display,pendingScrollAnchor)
  if found then questOffset=found-(pendingScrollAnchor.slot or 1) end
  pendingScrollAnchor=nil
 end
 if pendingReveal then
  local wanted=G.selection.quest
  for index,entry in ipairs(display) do
   local found=entry.kind=="quest" and entry.id==wanted
   if (entry.kind=="chain" or entry.kind=="subchapter") and entry.collapsed then for _,member in ipairs(entry.memberIds or {}) do if member==wanted then found=true;break end end end
   if found then
    if index<=questOffset or index>questOffset+QUEST_ROW_COUNT then questOffset=index-2 end
    break
   end
  end
  pendingReveal=false
 end
 questOffset=clampOffset(questOffset,#display,QUEST_ROW_COUNT);questMaxScroll=math.max(0,#display-QUEST_ROW_COUNT)
 setScrollbar(widgets.questScrollbar,questOffset,questMaxScroll,QUEST_ROW_COUNT)
 local pages=math.max(1,math.ceil(total/browsePageSize))
 widgets.frame.mid.pagination:SetText(string.format("%d/%d 페이지 · %d–%d / %d건",browsePage+1,pages,
  total>0 and browsePage*browsePageSize+1 or 0,math.min(total,(browsePage+1)*browsePageSize),total))
 if browsePage>0 then widgets.browsePrev:Enable() else widgets.browsePrev:Disable() end
 if browsePage+1<pages then widgets.browseNext:Enable() else widgets.browseNext:Disable() end
 for key,b in pairs(widgets.phaseButtons) do
  local names={all="전체",unaccepted="미수락",active="수행 중",turnin="보고 가능",done="완료",blocked="조건 필요"}
  b:SetText(names[key].." "..(counts[key] or 0));G.UIButtonState(b,key==statusFilter)
 end
 local scopeName=mode=="dungeon" and (d and d.name or "던전 선택") or mode=="zone" and "선택 지역" or ({active="수락한 퀘스트",turnin="보고 대기",selected="체크 목록",deferred="보류 목록",all="검색 결과"})[mode] or "퀘스트"
 if mode=="all" and search=="" then scopeName="현재 퀘스트" end
 widgets.headerInfo:SetText(scopeName.." · 검색 "..total.."건 / 현재 페이지 "..#ids.."건 · 표시 "..#actionCandidates.."건\n"..(building and "색인 중(총건수 증가 가능) · " or "").."상태별 건수는 이 페이지 기준 · ◀ ▶ 이동")
 local limited=false
 if #display==0 then
  widgets.emptyList:SetText(limited and "현재 불러온 검색 범위에는 이 상태의 퀘스트가 없습니다.\n\n검색어를 더 입력해 범위를 줄인 뒤 다시 확인하세요."
   or statusFilter~="all" and "현재 범위에 이 상태의 퀘스트가 없습니다.\n\n[전체]를 누르면 다른 상태도 확인할 수 있습니다."
   or not G.Ready() and "퀘스트 자료가 아직 연결되지 않았습니다.\n\n퀘스트 자료 불러오기 상태를 확인하세요. 이미 수락한 퀘스트는 [현재 퀘스트]에서 확인할 수 있습니다."
   or building and "검색 목록을 준비하고 있습니다.\n\n잠시 후 목록이 갱신됩니다."
   or mode=="active" and "아직 수락한 퀘스트가 없습니다.\n\n[지역별] 또는 [던전별]에서 장소를 고르고 [미수락]을 눌러 시작할 퀘스트를 찾으세요."
   or "조건에 맞는 퀘스트가 없습니다.\n\n검색어·진영·완료 제외·제한 숨김 설정을 확인하세요.")
  widgets.emptyList:Show()
 else widgets.emptyList:Hide() end

 for i,r in ipairs(widgets.questRows) do
  local entry=i<=QUEST_ROW_COUNT and display[questOffset+i] or nil;r.entry=entry;r.quest=nil;r.chainKey=nil;r.subchapterKey=nil;r.subchapterCollapsed=nil;r.rail:Hide();r.edge:Hide();r.stepDot:Hide()
  r.edge:ClearAllPoints();r.edge:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",9,0);r.edge:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-1,0);r.edge:SetHeight(2);r.edge:SetColorTexture(.28,.53,.67,.95)
  r.status=nil;r.statusKey=nil;r.filterContext=false;r.objectiveProgress=nil;r.progressRatio=nil
  r.statusStripe:Hide();r.badgeFill:Hide();r.statusBadge:Hide();r.progressText:Hide();r.blockerText:Hide();r.progressTrack:Hide();r.progressBar:Hide()
  hideBorder(r.cardBorder);r.cardInset=0;r.fill:ClearAllPoints();r.fill:SetAllPoints(r)
  r.checkbox:Hide();r.statusText:Hide();r.marker:Show();r:SetScript("OnEnter",nil);r:SetScript("OnLeave",nil)
  r.text:ClearAllPoints();r.statusText:ClearAllPoints();r.progressText:SetTextColor(.84,.88,.93)
  if entry and entry.kind=="chain" then
   r.chainKey=entry.key;r:Show();r.statusText:Show();r.edge:Show()
   r.text:SetPoint("TOPLEFT",r,"TOPLEFT",12,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-7,-3);r.text:SetHeight(18)
   r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",12,4);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-7,4);r.statusText:SetHeight(14)
   r.fill:SetColorTexture(.15,.25,.32,.98);r.marker:SetColorTexture(.45,.76,.91,1)
   r.text:SetText("|cff9cddf2"..(entry.collapsed and "▶ " or "▼ ").."[연계"..(entry.branch and "·분기" or "").."] "..shortLine(entry.label,r:GetWidth()-133).."|r")
   r.statusText:SetText("|cffb5c7d4"..entry.count.."개 · 보고 완료 "..entry.completed..(entry.superseded>0 and (" · 지난 단계 "..entry.superseded) or "")..(entry.extra>0 and (" · 외부 선행 "..entry.extra) or "").."|r")
   r:SetScript("OnEnter",function(self)
    local tips={entry.label.." 연계", "큰 파란 테두리 안의 퀘스트만 같은 연계입니다. 작은 네모는 각각의 퀘스트입니다.","클릭: 접기/펼치기",entry.linear and "앞 단계의 조건을 마쳐야 다음 퀘스트를 진행합니다." or "분기 또는 확인이 필요한 단계가 있습니다. 번호를 그대로 수행 순서로 해석하지 마세요."}
    if entry.nextQuestId then tips[#tips+1]="지금: "..entry.nextLabel.." · "..G.GetQuestName(entry.nextQuestId) end
    if entry.cycle then tips[#tips+1]="자료에서 선행 관계가 순환합니다. 실제 퀘스트 조건 확인이 필요합니다." end
    itemTooltip(self,tips)
   end)
  elseif entry and entry.kind=="subchapter" then
   r.subchapterKey=entry.key;r.subchapterCollapsed=entry.collapsed
   local inset=12;local color={.64,.69,.74};local complete=entry.stepsDone==entry.steps
   r.cardInset=inset;r:Show();r.marker:Hide();r.statusBadge:Show();r.badgeFill:Show();r.progressText:Show();r.statusStripe:Show()
   r.fill:ClearAllPoints();r.fill:SetPoint("TOPLEFT",r,"TOPLEFT",inset,0);r.fill:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-inset,0)
   r.fill:SetColorTexture(.075+color[1]*.075,.09+color[2]*.075,.11+color[3]*.075,.98)
   r.text:SetPoint("TOPLEFT",r,"TOPLEFT",inset+35,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-inset-87,-3);r.text:SetHeight(16);r.text:SetTextColor(.93,.94,.96)
   r.text:SetText(shortLine((entry.collapsed and "▶ " or "▼ ")..entry.label,r:GetWidth()-2*inset-131))
   r.statusStripe:ClearAllPoints();r.statusStripe:SetPoint("TOPLEFT",r,"TOPLEFT",inset+3,-2);r.statusStripe:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",inset+3,2);r.statusStripe:SetWidth(3);r.statusStripe:SetColorTexture(unpack(color))
   r.badgeFill:ClearAllPoints();r.badgeFill:SetPoint("TOPRIGHT",r,"TOPRIGHT",-inset-6,-3);r.badgeFill:SetSize(74,16);r.badgeFill:SetColorTexture(color[1]*.30,color[2]*.30,color[3]*.30,1)
   r.statusBadge:ClearAllPoints();r.statusBadge:SetPoint("TOPRIGHT",r,"TOPRIGHT",-inset-6,-3);r.statusBadge:SetSize(74,16);r.statusBadge:SetText(entry.stepsDone.."/"..entry.steps..(complete and " 완료" or " 단계"));r.statusBadge:SetTextColor(unpack(color))
   r.progressText:ClearAllPoints();r.progressText:SetPoint("TOPLEFT",r,"TOPLEFT",inset+35,-19);r.progressText:SetPoint("TOPRIGHT",r,"TOPRIGHT",-inset-7,-19);r.progressText:SetHeight(12)
   r.progressText:SetText((entry.collapsed and "하위 단계 펼치기" or "하위 단계 접기")..(entry.hasAlternatives and " · 첫 단계는 택일" or ""))
   r.progressText:SetTextColor(.68,.76,.82)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label.." · 같은 제목의 연계", "같은 이름의 퀘스트를 진행 목표별 하위 단계로 구분합니다.",entry.hasAlternatives and "첫 단계는 두 경로 중 하나만 하면 됩니다. 다른 경로를 완료했다고 단정하지 않습니다." or "각 하위 퀘스트의 실제 상태와 보상은 선택해 확인하세요.", "퀘스트 번호는 각 단계의 상세 정보에서 확인 가능합니다."})end)
  elseif entry and entry.kind=="standaloneHeader" then
   r:Show();r.marker:Show();r.statusText:Show()
   r.text:SetPoint("TOPLEFT",r,"TOPLEFT",12,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-7,-3);r.text:SetHeight(18)
   r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",12,3);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-7,3);r.statusText:SetHeight(13)
   r.fill:SetColorTexture(.14,.16,.18,.99);r.marker:SetColorTexture(.62,.64,.66,1)
   r.text:SetText("|cffd9dee5개별 표시 퀘스트 · "..entry.count.."개|r")
   r.statusText:SetText(entry.external and "|cffb9c8ce위 연계와 별개 · 다른 선행/후속은 상세 확인|r" or "|cffb9c8ce바로 위 연계 묶음에 포함되지 않음|r")
   r:SetScript("OnEnter",function(self)itemTooltip(self,{"개별 표시 퀘스트", "위에 나온 연계 묶음에 포함되지 않은 항목만 따로 보여줍니다.","연계 없음이 확정된 뜻이 아닙니다. 검색 범위 밖 선행/후속은 상세에서 확인하세요."})end)
  elseif entry and entry.kind=="chainEnd" then
   r:Show();r.marker:Hide()
   r.text:SetPoint("LEFT",r,"LEFT",21,0);r.text:SetPoint("RIGHT",r,"RIGHT",-7,0);r.text:SetHeight(36)
   r.fill:SetColorTexture(.075,.12,.16,.95)
   r.text:SetText("|cff91b5cb이 연계 묶음 끝 · "..entry.label.."|r")
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label.." 연계는 여기까지", "아래에 표시되는 개별 퀘스트는 이 묶음에 속하지 않습니다."})end)
  elseif entry and entry.kind=="header" then
   r:Show();r.text:SetPoint("LEFT",r,"LEFT",10,0);r.text:SetPoint("RIGHT",r,"RIGHT",-6,0);r.text:SetHeight(36)
   r.fill:SetColorTexture(.19,.18,.14,.96);r.marker:SetColorTexture(.86,.65,.29,1)
   r.text:SetText("|cffffd486"..(entry.category=="raid" and "공격대 · " or entry.isDungeon and "던전 · " or "지역 · ")..entry.label.."|r")
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label,"장소별 분류입니다. 같은 장소라고 같은 연계 퀘스트는 아닙니다."})end)
  elseif entry and entry.kind=="quest" then
   local id=entry.id;local j=journey(id);local meta=entry.meta or G.QuestListMeta(id)
   entry._viewportContinuation=chainKey(entry) and chainKey(display[questOffset+i-1])==chainKey(entry) and i==1
   entry._chapterContinuesBefore=entry.subchapterKey and widgets.ChapterKey(display[questOffset+i-1])==entry.subchapterKey and i>1
   entry._chapterContinuesAfter=entry.subchapterKey and widgets.ChapterKey(display[questOffset+i+1])==entry.subchapterKey and i<QUEST_ROW_COUNT
   paintQuestCard(r,entry,j,meta,nil,G.selection.quest==id)
  else r:Hide() end
  r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 refreshChainFrames(display,questOffset);widgets.RefreshChapterFrames(display,questOffset)
 if G.UIJourneyWidgets then
  local export=G.UIJourneyWidgets
  export.display=display;export.summary=visibleSummary;export.recommendation=visibleSummary.recommendation;export.phase=statusFilter;export.statusFilter=statusFilter
  export.statusSummary=counts;export.statusCounts=counts;export.scopeIds=ids;export.matchedIds=actionCandidates
  export.statusCache=widgets.statusCache;export.progressCache=widgets.progressCache;export.searchTotal=total;export.resultsLimited=false
  export.browsePage=browsePage;export.browsePageSize=browsePageSize;export.browseSort=browseSort;export.browseLevel=browseLevel
 end
 local current=journey(G.selection.quest)
 if current then
  local isSkipped=G.TitleBranchSkipped and G.TitleBranchSkipped(G.selection.quest)
  widgets.nowTitle:SetText((isSkipped and "택일 경로 · 선택 불필요" or matchingSet[G.selection.quest] and "지금 할 일" or shownSet[G.selection.quest] and "연계 참고로 선택한 퀘스트" or "목록 밖에서 선택한 퀘스트").." · "..current.title)
  local itemAction=(G.QuestStartItemGuide and current.actionQuestId==G.selection.quest and current.phase=="accept") and G.QuestStartItemGuide(G.selection.quest)
  widgets.nowAction:SetText(isSkipped and "다른 허물 전달 경로를 이미 진행했습니다. 이 경로는 다시 받을 필요가 없습니다."
   or ((current.prerequisite and "먼저 · " or "")..((itemAction and itemAction.action or current.detail or current.title):match("[^\n]+") or current.title)))
  widgets.nowPlace:SetText("장소 · "..(itemAction and itemAction.place or current.location or "확인 필요"))
  quickStartButton:SetText(current.prerequisite and "선행부터 안내 시작" or current.phase=="turnin" and "보고하러 가기 안내" or "이 퀘스트 안내 시작")
  if current.canGuide and not isSkipped then quickStartButton:Enable();widgets.locationButton:Enable() else quickStartButton:Disable();widgets.locationButton:Disable() end
  local selectedStatus=questStatus(G.selection.quest)
  local progress=(selectedStatus.key=="active" or selectedStatus.key=="turnin") and objectiveProgress(G.selection.quest) or nil
  if progress and progress.available then
   widgets.nowProgress:SetText((progress.summary or "목표 진행").."\n"..(progress.partialText or (selectedStatus.key=="turnin" and "보고하고 보상을 받으세요" or "목표 기록을 확인하세요")))
  else widgets.nowProgress:SetText((isSkipped and "선택 불필요 (택일 경로)" or selectedStatus.label).."\n체크는 동선 선택입니다") end
  if G.UIJourneyWidgets then G.UIJourneyWidgets.selectedStatus=selectedStatus;G.UIJourneyWidgets.selectedProgress=progress end
 else
  widgets.nowTitle:SetText("지금 할 일 · 퀘스트를 골라 주세요")
  widgets.nowAction:SetText("[현재 퀘스트]를 열거나 왼쪽에서 지역·던전을 선택하세요.")
  widgets.nowPlace:SetText("목록에서 퀘스트 클릭 → 진행 방법 확인 → [이 퀘스트 안내 시작]")
  quickStartButton:Disable();widgets.locationButton:Disable()
  widgets.nowProgress:SetText("하나 고르기 → 안내 시작\n체크는 함께 안내할 동선 선택")
  if G.UIJourneyWidgets then G.UIJourneyWidgets.selectedStatus=nil;G.UIJourneyWidgets.selectedProgress=nil end
 end
 if visibleSummary.nextQuestId then widgets.findNextButton:Enable() else widgets.findNextButton:Disable() end
 local readyCount=0
 for id,yes in pairs(G.db.selectedQuests or {}) do
  if yes and G.IsReadyToTurnIn(tonumber(id)) then readyCount=readyCount+1 end
 end
 widgets.selectedInfo:SetText("동선 체크 "..G.SelectedCount().." · 보고 가능 "..readyCount)
 local count=G.DeferredCount()
 deferredListButton:SetText("보류 목록 "..count);G.UIButtonState(deferredListButton,mode=="deferred")
 if count>0 then resumeAllButton:Enable() else resumeAllButton:Disable() end
 if G.DeferredBlocker(G.selection.quest) then resumeOneButton:Enable() else resumeOneButton:Disable() end
 local q=G.selection.quest
 if widgets.rewardFocusQuest and widgets.rewardFocusQuest~=q then
  if q then widgets.rewardFocusQuest=q;widgets.ResetRewardScroll()
  else widgets.rewardFocusQuest=nil;detailsExpanded=widgets.rewardReturnExpanded==true end
 end
 G.ContactPreviewSelectionChanged(q)
 if widgets.contactStart then
  widgets.contactStart:SetText(q and G.QuestStartItemGuide and G.QuestStartItemGuide(q) and "아이템 획득처·방법" or "받는 곳 지도")
  if q then widgets.contactStart:Enable();widgets.contactEnd:Enable() else widgets.contactStart:Disable();widgets.contactEnd:Disable() end
 end
 if q then
  local desc=widgets.TryExtra("퀘스트 상세",G.QuestDetails,q) or {name=G.GetQuestName(q),all={},one={}}
  local j=journey(q);local chain=chainByQuest[q];local startItem=widgets.TryExtra("시작 아이템",G.QuestStartItemGuide,q)
  widgets.rewardPreview="보상 · [보상 보기]에서 확인"
  if widgets.rewardCacheId==q and widgets.rewardCache then
   widgets.rewardPreview=widgets.TryExtra("보상 요약",G.QuestRewardBrief,widgets.rewardCache) or widgets.rewardPreview
  end
  local status=questStatus(q)
  local isSkipped=G.TitleBranchSkipped and G.TitleBranchSkipped(q)
  local progress=(status.key=="active" or status.key=="turnin") and objectiveProgress(q) or nil
  widgets.RenderGuideSummary(q,desc,j,status,isSkipped,startItem,progress)
  -- Optional detail text is independent of the overview and navigation buttons.
  local ok,why=pcall(function()
  local lines={isSkipped and "|cff9bbbc9경로 안내: 대체 경로를 진행하여 이 단계는 선택 불필요|r" or (statusTag(status).."현재 상태: "..status.label.."|r"),status.detail or "실제 퀘스트 기록을 확인하세요."}
  if status.reason and status.reason~="" then lines[#lines+1]="확인할 내용: "..status.reason end
  if startItem then
   lines[#lines+1]="\n|cffffd787시작 아이템 획득 · 사용 순서|r"
   if status.key=="unaccepted" then lines[#lines+1]=startItem.action
   else lines[#lines+1]="이 항목은 아이템으로 시작하는 퀘스트입니다. 이미 수락·보고했다면 다시 획득할 필요가 없습니다." end
   if startItem.sourceText then lines[#lines+1]="획득처: "..startItem.sourceText end
   lines[#lines+1]="순서: 아이템 확보 → 가방에서 사용 → 퀘스트 수락 → 목표/보고 확인"
   if startItem.uncertain then lines[#lines+1]="몬스터별 드롭률·실제 위치는 포에버 게임에서 확인이 필요합니다." end
  end
  if progress and progress.available then
   lines[#lines+1]="\n|cff9cd9f0실제 목표 진행 · "..progress.summary.."|r"
   for _,objective in ipairs(progress.objectives or {}) do
    lines[#lines+1]="• "..(objective.display or objective.text or "목표")..(objective.finished and " · 목표 완료" or "")
   end
   lines[#lines+1]=progress.detail or "진행 막대는 완료한 목표 항목 수 / 전체 목표 항목 수입니다."
  elseif status.key=="active" then lines[#lines+1]="실제 목표 수량을 아직 읽지 못했습니다. 퀘스트 로그를 확인하세요." end
  lines[#lines+1]="\n체크박스는 함께 안내할 동선 선택입니다. 실제 퀘스트 완료 기록은 바꾸지 않습니다.\n"
  if G.PartyShareEnabled and G.PartyShareEnabled() and G.PartyQuestSummary then
   lines[#lines+1]="\n|cff98d9dd파티원 퀘스트 참고 (상대방 공유 동의 필요)|r\n"..G.PartyQuestSummary(q)
  end
  local journeyLines=widgets.TryExtra("상세 동선",G.JourneyDetailLines,q)
  if type(journeyLines)=="table" then
   for _,line in ipairs(journeyLines) do if type(line)=="string" then lines[#lines+1]=line end end
  else
   lines[#lines+1]="지금 할 일: "..tostring(j.title or "확인 필요")
   lines[#lines+1]="장소: "..tostring(j.location or "위치 확인 필요")
   lines[#lines+1]=tostring(j.detail or "게임 퀘스트 로그 확인")
   lines[#lines+1]="다음: "..tostring(j.nextText or "진행 상황 확인")
   lines[#lines+1]="추가 동선 자료 확인 필요 · 기본 공략은 유지됩니다."
  end
  lines[#lines+1]="\n|cff9cd9f0퀘스트 보상|r · 위 [보상 보기]에서 별도 조회"
  if chain then
   local position
   for ix,id in ipairs(chain.memberIds) do if id==q then position=ix;break end end
   widgets.relationshipInfo:SetText((chain.branch and "연계·분기 · " or "연계 · ")..chain.label.." · "..(chain.linear and ("현재 "..tostring(position or "?").."/"..chain.count) or ("구성 "..chain.count.."개")).."\n"..journeyFlow(j.code))
   lines[#lines+1]="\n|cff9cd9f0이 연계에 포함된 퀘스트|r"
   lines[#lines+1]=chain.linear and "앞 단계의 조건을 마친 뒤 다음 퀘스트를 진행합니다." or "갈라지거나 합쳐지는 관계가 포함될 수 있습니다. 이 번호는 수행 순서가 아닙니다."
   if chain.optional then lines[#lines+1]="선택 안내·후속 연계가 포함됩니다. 모든 단계를 필수 선행으로 처리하지 마세요. [연계 전체 · 동행 안내]에서 전체 목록을 확인하세요." end
   for ix,id in ipairs(chain.memberIds) do
    local member=journey(id)
    local siblingName=G.GetQuestName(id)
    local repeats=0
    for _,other in ipairs(chain.memberIds) do if G.GetQuestName(other)==siblingName then repeats=repeats+1 end end
    local stageName=(repeats>1 and G.TitleChapterStepLabel and G.TitleChapterStepLabel(id,ix)) or siblingName
    lines[#lines+1]=(id==q and "|cffffd787[선택] " or "")..ix..". "..stageName.." · "..member.verb..(id==q and "|r" or "")
   end
   if chain.nextQuestId then lines[#lines+1]="지금 가능한 일: "..G.GetQuestName(chain.nextQuestId).." · "..chain.nextLabel end
   if chain.incomplete then lines[#lines+1]="일부 선행이 현재 표시 범위 밖에 있습니다. 아래 조건도 확인하세요." end
  elseif G.db.groupChains==false then
   widgets.relationshipInfo:SetText("연계 묶기 끔 · 실제 관계는 아래 선행 조건 참고\n"..journeyFlow(j.code))
  elseif not G.Ready() then
   widgets.relationshipInfo:SetText("퀘스트 자료 미연결 · 연계 관계 확인 필요\n"..journeyFlow(j.code))
  elseif not shownSet[q] then
   widgets.relationshipInfo:SetText("현재 목록 밖에서 선택된 퀘스트\n"..journeyFlow(j.code))
  else
   widgets.relationshipInfo:SetText("개별 퀘스트 · 앞 연계 묶음과 별도 항목\n"..journeyFlow(j.code))
  end
  if j.prerequisite then
   lines[#lines+1]="\n|cffffd89b먼저 진행할 선행|r"
   lines[#lines+1]="‘"..G.GetQuestName(j.actionQuestId).."’부터 안내합니다. 위 [선행부터 안내 시작]을 누르세요."
  end
  local walkthrough=widgets.TryExtra("자세한 수행 방법",G.WalkthroughDetails,q)
  if walkthrough then lines[#lines+1]="\n|cffffdc88자세한 수행 방법|r\n"..walkthrough end
  if desc.requirements then lines[#lines+1]="\n|cffffdc88진행 조건|r\n"..desc.requirements end
  if #(desc.all or {})>0 then lines[#lines+1]="\n|cffffd89b모두 마쳐야 하는 선행 퀘스트|r\n"..prereqString(desc.all) end
  if #(desc.one or {})>0 then lines[#lines+1]="\n|cffffd89b이 중 하나를 마치면 되는 선행 퀘스트|r\n"..prereqString(desc.one) end
  if #(desc.all or {})==0 and #(desc.one or {})==0 then lines[#lines+1]="\n등록된 직접 선행 퀘스트: 없음" end
  if desc.reason then
   lines[#lines+1]="\n|cffffa173현재 막힌 이유|r\n"..desc.reason
   if desc.blocker and desc.blocker.path and #desc.blocker.path>1 then local path={};for _,qid in ipairs(desc.blocker.path) do path[#path+1]=G.GetQuestName(qid) end;lines[#lines+1]="필요한 선행: "..table.concat(path," → ") end
  end
  if desc.nameNote then lines[#lines+1]="\n|cff9fcce4명칭·서버 확인 사항|r\n"..desc.nameNote end
  if desc.note then lines[#lines+1]="\n|cffffa173주의할 점|r\n"..desc.note end
  if mode=="dungeon" and G.selection.dungeon and G.DungeonPreflightLines then
   lines[#lines+1]="\n|cff9cd9f0던전 출발 점검 (목록 참고, 필수/완료 확정 아님)|r"
   for _,line in ipairs(G.DungeonPreflightLines(G.selection.dungeon,8)) do lines[#lines+1]=line end
  end
  lines[#lines+1]="\n확인용 퀘스트 번호: "..q
  detailText(table.concat(lines,"\n"),q)
  end)
  if not ok then
   widgets.RecordExtraError("상세 공략",why)
   widgets.relationshipInfo:SetText("추가 공략 자료 확인 필요 · 기본 공략 유지")
   local rows={"지금 할 일: "..tostring(j.title or "확인 필요"),"장소: "..tostring(j.location or "위치 확인 필요"),tostring(j.detail or "게임 로그 확인"),"다음: "..tostring(j.nextText or "진행 상황 확인"),"","일부 상세 자료를 읽지 못했습니다. 기본 공략과 지도 버튼은 계속 사용할 수 있습니다."}
   detailText(table.concat(rows,"\n"),q)
  end
 else
  widgets.rewardPreview="보상 · 퀘스트 선택 후 확인"
  widgets.detailHead:SetText("목록에서 퀘스트를 고르면\n받는 곳부터 보고할 곳까지 안내합니다.")
  widgets.relationshipInfo:SetText("연계 = 앞 퀘스트를 이어서 진행하는 묶음\n개별 = 앞 묶음과 분리된 퀘스트 항목")
  widgets.summary[1].text:SetText("왼쪽에서 퀘스트를 고르세요.")
  widgets.summary[2].text:SetText("[현재 퀘스트] 또는 지역·던전별 목록")
  widgets.summary[3].text:SetText("선택 후 실제 목표와 진행도를 확인")
  widgets.summary[4].text:SetText("보고 가능이 되면 보고하고 보상을 받기")
  widgets.summary[5].text:SetText("여러 퀘스트는 체크해 통합 안내 시작")
  local onboarding="처음 사용하는 방법\n\n1. [현재 퀘스트]에서 이미 받은 퀘스트를 보세요. 새로 받을 퀘스트는 [지역별]·[던전별]에서 찾습니다.\n\n2. 퀘스트를 누르면 위쪽 ‘지금 할 일’에 행동과 장소가 나옵니다.\n\n3. [이 퀘스트 안내 시작]을 누르고 화면의 이동 안내를 따라가세요.\n\n여러 퀘스트를 함께 진행하려면 왼쪽 체크박스로 고른 뒤 [체크한 퀘스트 통합 안내]를 누르세요.\n\n받기 = 사람이나 물건에서 퀘스트 수락\n수행 = 퀘스트의 목표를 채우기\n보고 = 목표를 채운 뒤 보상을 받기\n선행 = 그보다 먼저 끝내야 하는 퀘스트"
  if mode=="dungeon" and G.selection.dungeon and G.DungeonPreflightLines then
   onboarding=onboarding.."\n\n"..table.concat(G.DungeonPreflightLines(G.selection.dungeon,8),"\n")
  end
  detailText(onboarding,nil)
 end
 if widgets.rewardButton then
  widgets.rewardButton:SetText(widgets.rewardFocusQuest and widgets.rewardFocusQuest==G.selection.quest and "보상 닫기" or "보상 보기")
  if G.selection.quest then widgets.rewardButton:Enable();widgets.wideRewardButton:Enable() else widgets.rewardButton:Disable();widgets.wideRewardButton:Disable() end
 end
 if detailsExpanded then
  widgets.overview:Hide();detailScroll:Show();setDetailOffset(detailScroll:GetVerticalScroll())
  widgets.detailHint:SetText(widgets.rewardFocusQuest and "보상 정보 · 마우스 휠로 스크롤 · [보상 닫기]로 복귀" or "상세 설명 · 마우스 휠로 스크롤 · [요약 보기]로 돌아가기")
 else
  detailScroll:Hide();detailScrollbar:Hide();widgets.overview:Show()
  widgets.detailHint:SetText(shortLine(widgets.rewardPreview or "보상 · 상세 정보 확인 필요",480))
 end
 local guide=G.db.guide
 local done,total=G.GuideProgress();footerProgress:SetProgress(done,total)
 local reviewing=G.GuideViewingHistory();footerNext:SetText(reviewing and "현재 단계" or "다음 확인");if G.CurrentStep() or reviewing then footerNext:Enable() else footerNext:Disable() end
 if total>0 and G.GuideViewIndex()>1 then footerPrev:Enable() else footerPrev:Disable() end
 if guide and guide.halted then
  widgets.guideInfo:SetText(displayText("|cffffc675진행 가능한 동선 없음|r · "..G.RouteScopeLabel(guide)))
  widgets.guideNow:SetText(displayText(guide.statusReason or "수락 조건 확인 필요"))
  widgets.guideNote:SetText("제외/보류 목록에서 사유 확인 → 보류 해제 또는 동선 초기화 · 실제 완료 기록 유지")
 elseif guide and guide.completed then
  widgets.guideInfo:SetText("|cff8be19e동선 완료|r")
  widgets.guideNow:SetText("현재 방문 가능한 단계가 모두 처리되었습니다.")
  widgets.guideNote:SetText("체크 목록은 그대로 유지됩니다. 필요하면 다른 퀘스트를 추가하고 다시 시작하세요.")
 elseif guide and guide.steps and #guide.steps>0 then
  local done,count=G.GuideProgress();local step=G.CurrentStep()
  local guideDungeon=G.GetDungeon(guide.dungeon)
  local title=displayText(G.RouteScopeLabel(guide))
  local multi=guide.optimization and (" · 가능 "..(guide.admittedCount or guide.optimization.selectedQuestCount or 0).."개 · 제외 "..#(guide.excluded or {}).."개") or ""
  widgets.guideInfo:SetText("|cffffdc89진행 "..done.."/"..count.."|r  ·  "..title..multi)
  widgets.guideNow:SetText(displayText(step and ("|cff8adff1다음:|r "..(guide.index or 1)..". "..step.title) or "|cff86d695모든 단계 완료 · 퀘스트 창 확인|r"))
  local routeWarning=guide.optimization and guide.optimization.approximate and " · 여러 지역/좌표 미확인: 이동 시간 최적 보장 불가" or ""
  widgets.guideNote:SetText(displayText(step and ((step.note or "")..routeWarning) or ""))
 else
  widgets.guideInfo:SetText("가이드 대기 중")
  widgets.guideNow:SetText("처음이라면: [현재 퀘스트] → 퀘스트 하나 선택 → 위쪽 [이 퀘스트 안내 시작]")
  widgets.guideNote:SetText("받기 → 목표 수행 → 보고 대상에게 보고. 목표를 채운 뒤에도 보고와 보상을 받아야 퀘스트가 끝납니다.")
 end
 widgets.navStatus:SetText(displayText(G.guideFeedback or ("지도 길찾기: "..(G.navStatus or "대기"))))
 if widgets.rewardPopup and widgets.rewardPopup:IsShown() then
  widgets.TryExtra("보상 창 갱신",widgets.RefreshRewardPopup)
 end
end
function G.ShowUI(show)
 buildUI();if not widgets.frame then return end
 if show==false or (show==nil and widgets.frame:IsShown()) then widgets.frame:Hide();return end
 G.UIFit(widgets.frame);widgets.frame:Show();G.UIRefresh()
end
function G.ToggleUI() G.ShowUI(nil) end

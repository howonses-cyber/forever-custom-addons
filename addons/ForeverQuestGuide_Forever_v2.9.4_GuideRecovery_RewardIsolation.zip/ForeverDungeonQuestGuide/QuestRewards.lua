local addon,G=...
G.rewardsVersion="2.9.4"
-- QuestieDB's quest schema has reputationReward but no equipment reward fields.
-- Use Blizzard's quest-ID APIs when that quest's reward data is actually available.
-- Never read the currently selected game's quest without its explicit ID.
local waiting,attempted,loaded,observed={},{},{},{}
local rewardLoader
local function requestReward(id)
 if not (C_QuestLog and type(C_QuestLog.RequestLoadQuestByID)=="function") or waiting[id] or attempted[id] then return end
 local token={};waiting[id]=token;attempted[id]=true
 local ok=pcall(C_QuestLog.RequestLoadQuestByID,id)
 if not ok then waiting[id]=nil end
 -- A missing server event must not leave a permanent loading spinner.
 if ok and waiting[id]==token and C_Timer and type(C_Timer.After)=="function" then
  C_Timer.After(8,function()
   if waiting[id]==token then waiting[id]=nil;if G.selection and G.selection.quest==id and G.UIRefresh then G.UIRefresh() end end
  end)
 end
end
function G.RetryQuestReward(id)
 id=tonumber(id);if id and not waiting[id] then attempted[id]=nil;loaded[id]=nil end
end
local function ref(id,xp,money,choices,fixed,wowhead)
 return {xp=xp,money=money,choices=choices,fixed=fixed,source=(wowhead and "Wowhead Forever" or "ForeverQuestLog").." · 퀘스트 "..id.." · 기준 자료 (실제 지급은 게임 확인)"}
end
local references={
 [3441]=ref(3441,440),
 [3442]=ref(3442,4400,14000),
 [3443]=ref(3443,4400,14000),
 [3452]=ref(3452,4700,7500),
 [3453]=ref(3453,470,nil,nil,nil,true),
 [3454]=ref(3454,4700,nil,nil,{{10515,"Torch of Retribution"}}),
 [3462]=ref(3462,470),
 [3463]=ref(3463,7600,23000,{{10742,"Dragonflight Leggings"},{10743,"Drakefire Headguard"},{10744,"Axe of the Ebon Drake"},{270114,"Dragonscale Pants"}},nil,true),
 [3481]=ref(3481,470,nil,nil,{{10569,"Hoard of the Black Dragonflight"}}),
 [4022]=ref(4022,5450),
 [4023]=ref(4023,5450),
 [4024]={
  choices={{12066,"Shaleskin Cape"},{12082,"Wyrmhide Spaulders"},{12083,"Valconian Sash"}},
  money=26500,xp=6200,
  source="Wowhead Forever / Forever Guide · 자료상 보상 (실제 지급은 게임에서 확인)",
 },
}
local function safe(fn,...)
 if type(fn)~="function" then return nil end
 local ok,a,b,c,d,e,f=pcall(fn,...)
 if ok then return a,b,c,d,e,f end
end
local function nameOf(id,fallback)
 local native=safe(C_Item and C_Item.GetItemNameByID,id) or safe(GetItemInfo,id)
 local dbName=ItemDB and safe(G.DBGet,ItemDB,id,"name")
 local name=type(native)=="string" and native~="" and native or type(dbName)=="string" and dbName~="" and dbName or fallback
 if G.KoreanName and type(name)=="string" then return safe(G.KoreanName,"item",id,name) or name end
 return name or ("아이템 "..tostring(id))
end
local function moneyText(copper)
 copper=math.floor(tonumber(copper) or 0)
 if copper<=0 then return nil end
 local gold=math.floor(copper/10000);local silver=math.floor(copper%10000/100);local coin=copper%100
 local bits={}
 if gold>0 then bits[#bits+1]=gold.."골드" end
 if silver>0 then bits[#bits+1]=silver.."실버" end
 if coin>0 then bits[#bits+1]=coin.."코퍼" end
 return table.concat(bits," ")
end
function G.QuestRewardInfo(id)
 id=tonumber(id)
 if not id or id<1 or id%1~=0 then return {available=false,reason="퀘스트 선택 필요"} end
 local result={id=id,choices={},fixed={},available=false,source=nil}
 local inLog=safe(G.IsInLog,id)==true
 local dataAvailable=safe(HaveQuestRewardData,id)==true
 if not dataAvailable and not loaded[id] then requestReward(id) end
 do
  local n=safe(GetNumQuestLogChoices,id)
  if type(n)=="number" and n>0 then
   for i=1,math.min(n,20) do
    local name,icon,count,quality,usable,itemId=safe(GetQuestLogChoiceInfo,i,id)
    if (type(name)=="string" and name~="") or (tonumber(itemId) or 0)>0 then
     name=(type(name)=="string" and name~="") and name or nameOf(itemId)
     result.choices[#result.choices+1]={id=tonumber(itemId),name=name,count=tonumber(count) or 1,icon=icon,quality=quality}
    end
   end
  end
  n=safe(GetNumQuestLogRewards,id)
  if type(n)=="number" and n>0 then
   for i=1,math.min(n,20) do
    local name,icon,count,quality,usable,itemId=safe(GetQuestLogRewardInfo,i,id)
    if (type(name)=="string" and name~="") or (tonumber(itemId) or 0)>0 then
     name=(type(name)=="string" and name~="") and name or nameOf(itemId)
     result.fixed[#result.fixed+1]={id=tonumber(itemId),name=name,count=tonumber(count) or 1,icon=icon,quality=quality}
    end
   end
  end
  result.money=tonumber(safe(GetQuestLogRewardMoney,id))
  result.xp=tonumber(safe(GetQuestLogRewardXP,id))
  result.source="게임 퀘스트 보상 데이터"
 end
 -- Keep only positive game observations, separately from reference facts.
 local live=#result.choices>0 or #result.fixed>0 or (result.money or 0)>0 or (result.xp or 0)>0
 local history=G.db and G.db.questRewardHistory
 if type(history)~="table" and G.db then history={};G.db.questRewardHistory=history end
 local function validRecord(record)
  return type(record)=="table" and record or nil
 end
 local function validItems(items)
  return type(items)=="table" and items or {}
 end
 if live then
  local previous=validRecord(observed[id]) or validRecord(history and history[id]) or {}
  local saved={choices=#result.choices>0 and result.choices or validItems(previous.choices),fixed=#result.fixed>0 and result.fixed or validItems(previous.fixed),money=(result.money or 0)>0 and result.money or tonumber(previous.money),xp=(result.xp or 0)>0 and result.xp or tonumber(previous.xp)}
  observed[id]=saved
  if history then history[id]=saved end
 end
 local old=validRecord(observed[id]) or validRecord(history and history[id])
 local known=references[id]
 local function historical(info,source)
  local extra={choices={},fixed={},money=tonumber(info.money),xp=tonumber(info.xp),source=source,reference=true,referenceXP=tonumber(info.xp)~=nil}
  for _,key in ipairs({"choices","fixed"})do
   for _,entry in ipairs(validItems(info[key])) do
    if type(entry)=="table" then
     local itemId=tonumber(entry.id or entry[1]);local name=entry.name or entry[2]
     if itemId and itemId>0 then extra[key][#extra[key]+1]={id=itemId,name=nameOf(itemId,type(name)=="string" and name or nil),count=math.max(1,tonumber(entry.count) or 1)}
     elseif type(name)=="string" and name~="" then extra[key][#extra[key]+1]={name=name,count=math.max(1,tonumber(entry.count) or 1)} end
    end
   end
  end
  extra.moneyText=moneyText(extra.money)
  extra.available=#extra.choices>0 or #extra.fixed>0 or (extra.money or 0)>0 or (extra.xp or 0)>0
  return extra
 end
 local function missing(info)
  if not info then return nil end
  if #result.choices>0 then info.choices={} end
  if #result.fixed>0 then info.fixed={} end
  if (result.money or 0)>0 then info.money=nil;info.moneyText=nil end
  if (result.xp or 0)>0 then info.xp=nil end
  info.available=#info.choices>0 or #info.fixed>0 or (info.money or 0)>0 or (info.xp or 0)>0
  return info.available and info or nil
 end
 if old then result.previous=missing(historical(old,"이 캐릭터의 이전 게임 조회 기록 · 현재 지급 보장 아님")) end
 if known then result.referenceDetail=missing(historical(known,known.source)) end
 if not live then
  local fallback=result.previous or result.referenceDetail
  if fallback then
   result.choices=fallback.choices;result.fixed=fallback.fixed;result.money=fallback.money;result.xp=fallback.xp
   result.source=fallback.source;result.reference=true;result.referenceXP=fallback.referenceXP
   if result.previous then result.previous=nil else result.referenceDetail=nil end
  end
 end
 result.available=live or result.reference==true
 result.moneyText=moneyText(result.money)
 if waiting[id] then result.pending=true end
 if not result.available then
  if waiting[id] then result.pending=true;result.reason="게임 서버에서 보상 자료 요청 중 · 응답 후 자동 갱신"
  elseif dataAvailable or loaded[id] then result.reason="퀘스트 자료 로드는 완료되었지만 보상 정보는 제공되지 않았습니다. 보상 없음으로 단정하지 않습니다."
  else result.reason="보상 자료 미확인 · 보상 닫기 후 다시 열거나 실제 수락/보고 화면에서 확인" end
 end
 return result
end
if type(CreateFrame)=="function" and C_QuestLog and type(C_QuestLog.RequestLoadQuestByID)=="function" then
 rewardLoader=CreateFrame("Frame")
 rewardLoader:RegisterEvent("QUEST_DATA_LOAD_RESULT")
 rewardLoader:SetScript("OnEvent",function(self,event,id,success)
  id=tonumber(id)
  if id and waiting[id] then
   waiting[id]=nil;loaded[id]=success==true or nil
   local function refresh() if G.selection and G.selection.quest==id and G.UIRefresh then G.UIRefresh() end end
   if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(0,refresh) else refresh() end
  end
 end)
end
function G.QuestRewardBrief(info)
 if info and info.pending and not info.available then return "보상 · 게임 자료 요청 중" end
 if not info or not info.available then return "보상 · 자료 확인 필요" end
 local out={}
 if #info.choices>0 then out[#out+1]="선택 "..#info.choices.."종 중 1개" end
 if #info.fixed>0 then out[#out+1]="확정 아이템 "..#info.fixed.."종" end
 if info.moneyText then out[#out+1]=info.moneyText end
 if info.xp and info.xp>0 then out[#out+1]=math.floor(info.xp)..(info.referenceXP and " 기준 경험치" or " 경험치") end
 local summary="보상 · "..table.concat(out," · ")
 return info.reference and (summary.." (자료 참고)") or summary
end
function G.QuestRewardLines(info)
 if not info or not info.available then return {info and info.pending and "보상 자료 요청 중" or "보상 자료 확인 필요",(info and info.reason) or "게임에서 보상을 확인하세요."} end
 local lines={info.reference and "|cffffc77d보상 (외부 자료 참고 · 게임에서 확인 필요)|r" or "|cff8cdbad보상 (게임 데이터)|r"}
 if #info.choices>0 then
  lines[#lines+1]="선택 보상 · 다음 중 하나"
  for _,entry in ipairs(info.choices) do lines[#lines+1]="• "..entry.name..(entry.count>1 and (" ×"..entry.count) or "") end
 end
 if #info.fixed>0 then
  lines[#lines+1]="확정 보상"
  for _,entry in ipairs(info.fixed) do lines[#lines+1]="• "..entry.name..(entry.count>1 and (" ×"..entry.count) or "") end
 end
 if info.moneyText then lines[#lines+1]="골드: "..info.moneyText end
 if info.xp and info.xp>0 then lines[#lines+1]=(info.referenceXP and "기준 경험치(자료): " or "경험치: ")..math.floor(info.xp) end
 if info.source then lines[#lines+1]="출처: "..info.source end
 if info.pending then lines[#lines+1]="|cff9cd9f0게임 자료도 조회 중입니다. 응답 후 갱신됩니다.|r" end
 for _,key in ipairs({"previous","referenceDetail"})do
  local extra=info[key]
  if extra and extra.available then
   lines[#lines+1]=""
   for _,line in ipairs(G.QuestRewardLines(extra))do lines[#lines+1]=line end
  end
 end
 return lines
end

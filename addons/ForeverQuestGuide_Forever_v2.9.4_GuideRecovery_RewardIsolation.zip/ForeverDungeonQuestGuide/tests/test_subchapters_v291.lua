-- Real issue: three quests with the same localized title must become one nested,
-- expandable stage selector, not three indistinguishable quest cards.
local base=(arg and arg[1]) or './'
local db={groupChains=true,chainCollapsed={},selectedQuests={[11]=true},deferredQuests={[22]=true},guide={sentinel=true}}
local G={db=db}
local names={[4022]='화염의 맛',[4023]='화염의 맛',[4024]='화염의 맛',[70]='일반 퀘스트',[81]='다른 연계',[82]='다른 연계',[801]='임무',[802]='임무'}
local completed={[4022]=true,[4024]=true};local inLog={}
function G.GetQuestName(id)return names[id] or ('퀘스트 '..id)end
function G.IsCompleted(id)return completed[id]==true end
function G.IsInLog(id)return inLog[id]==true end
local function load(file)assert(loadfile(base..file))('ForeverDungeonQuestGuide',G)end
load('QuestTitleGroups.lua');load('QuestSections.lua')
local checks=0
local function check(ok,message)assert(ok,message);checks=checks+1 end
local function quest(id,key)return {kind='quest',id=id,chainKey=key}end
local rows={
 {kind='chain',key='flame-chain',label='화염의 맛 전체 연계',collapsed=false},
 quest(4022,'flame-chain'),quest(4023,'flame-chain'),quest(4024,'flame-chain'),
 {kind='chainEnd',key='flame-chain',label='화염의 맛 전체 연계'},
 quest(70,nil),
 {kind='chain',key='other-chain',label='다른 연계',collapsed=false},
 quest(81,'other-chain'),quest(82,'other-chain'),
 {kind='chainEnd',key='other-chain',label='다른 연계'},
}
local savedSelected,savedDefer,savedGuide=db.selectedQuests,db.deferredQuests,db.guide
local collapsed=G.QuestTitleNestedRows(rows)
local chapter
for _,e in ipairs(collapsed)do if e.kind=='subchapter' and e.label=='화염의 맛' then chapter=e end end
check(chapter~=nil,'same-name flame quests are nested')
check(chapter.label=='화염의 맛','one parent label is the recognizable quest title')
check(chapter.collapsed==true,'flame chapter defaults collapsed')
check(chapter.steps==2 and chapter.stepsDone==2,'two story steps, one alternative path, both done')
check(chapter.count==3 and chapter.hasAlternatives,'three IDs but only two stages')
check(#collapsed==9,'three flame quest cards reduce to one nested chapter without hiding unrelated groups')
check(collapsed[1].kind=='chain' and collapsed[2].kind=='subchapter' and collapsed[3].kind=='chainEnd','nested chapter contained in verified parent story')
check(collapsed[4].id==70 and collapsed[4].kind=='quest','unrelated single remains separate')
check(chapter.memberIds[1]==4022 and chapter.memberIds[2]==4023 and chapter.memberIds[3]==4024,'underlying IDs preserved')
check(G.QuestFindAnchor(collapsed,{kind='quest',id=4023})==2,'hidden quest scrolling resolves to collapsed chapter')
check(G.TitleBranchSkipped(4023)==true,'unused alternative is marked as not needed')
check(G.TitleBranchSkipped(4022)==false,'actually completed route is not marked skipped')
check(G.TitleBranchSkipped(4024)==false,'downstream completed stage is not skipped')
check(G.TitleChapterStepLabel(4024,3):find('밸가르',1,true)~=nil,'user recognizes stage by objective')
check(G.TitleChapterStepLabel(4022,1):find('전달',1,true)~=nil,'first path has an action label')
check(G.TitleChapterStepLabel(4023,2):find('대체',1,true)~=nil,'alternate path clearly indicated')
db.chainCollapsed[chapter.key]=false
local expanded=G.QuestTitleNestedRows(rows)
local children={};for _,e in ipairs(expanded) do if e.kind=='quest' and e.subchapterKey==chapter.key then children[#children+1]=e end end
check(#children==3,'expanded nested chapter shows all three original quest IDs')
check(children[1].subchapterSkipped==false and children[2].subchapterSkipped==true and children[3].subchapterSkipped==false,'only unused alternative is marked skipped')
check(children[1].subchapterStepLabel~=children[2].subchapterStepLabel and children[2].subchapterStepLabel~=children[3].subchapterStepLabel,'all stage labels distinguish objectives')
check(G.QuestFindAnchor(expanded,{kind='quest',id=4023})>0,'expanded child can be scrolled into view')
check(db.selectedQuests==savedSelected and db.deferredQuests==savedDefer and db.guide==savedGuide,'nested rendering cannot mutate player planning records')
inLog[4023]=true
check(not G.TitleBranchSkipped(4023),'active alternative never wrongly skipped')
inLog[4023]=nil
completed[4022]=nil;completed[4024]=nil
local zero=G.QuestTitleNestedRows(rows)
for _,e in ipairs(zero)do if e.kind=='subchapter' and e.label=='화염의 맛' then check(e.stepsDone==0,'uncompleted chapters never appear completed')end end
db.groupChains=false
check(G.QuestTitleNestedRows(rows)==rows,'disabling grouping returns the same original rows')
print('PASS V2.9.1 flame nested story, alternative path, grouping boundaries and planning integrity: '..checks..' assertions')

-- V2.8.2: acquisition is a distinct phase for item-start quests.
-- Mocks exercise code behavior; no simulated drop rates, game loot, or saved mutations.
local root=arg[1] or './'
local G={db={selectedQuests={[4264]=true},deferredQuests={[9]={reason='user'}},guide={index=1}},player={level=55},selection={quest=4264}}
local initialDB=G.db;local initialRoute=G.db.guide;local initialSelected=G.db.selectedQuests
local counts={}
C_Item={GetItemCount=function(id) return counts[id] end}
function G.GetQuestName(id)return id==4264 and '꼬깃꼬깃한 쪽지' or '시작 아이템 검사' end
function G.RouteAssessment(id)return '지금 받기','ready' end
function G.QuestContactName(id,stage)
 if stage=='accept' and id==4264 then return '꼬깃꼬깃한 쪽지',11446,{},'item' end
 if stage=='accept' and id==90001 then return '불확실 아이템',80001,{},'item' end
 if stage=='accept' and id==90002 then return '출처 미확인 아이템',80002,{},'item' end
 return nil
end
function G.DBGet(db,id,key)return db.Get and db:Get(id,key) or nil end
ItemDB={Get=function(self,id,key)if id==80001 and key=='npcDrops' then return {11,12,13} end end}
NpcDB={Get=function(self,id,key)if key=='name' then return ({[11]='첫 번째 적',[12]='두 번째 적',[13]='세 번째 적'})[id] end end}
ObjectDB={Get=function()return nil end}
function G.QuestPoint()return nil end
function G.QuestStageLandmark()return nil end
function G.QuestContactLandmark()return nil end
function G.QuestInsideInfo()return nil end
assert(loadfile(root..'QuestStartItems.lua'))('ForeverDungeonQuestGuide',G)
assert(loadfile(root..'QuestJourney.lua'))('ForeverDungeonQuestGuide',G)
local n=0
local function eq(a,b,label) n=n+1;assert(a==b,(label or 'equal')..': '..tostring(a)..' != '..tostring(b)) end
local function contains(a,b) n=n+1;assert(type(a)=='string' and a:find(b,1,true),'missing '..b..': '..tostring(a))end
counts[11446]=0
local info=assert(G.QuestStartItemGuide(4264));eq(info.itemId,11446);eq(info.owned,0)
contains(info.action,'찾지 못했습니다');contains(info.action,'성난모루단');contains(info.sourceText,'교도관')
contains(info.note,'치안대장 윈저')
local j=G.QuestJourney(4264);eq(j.phase,'accept');eq(j.verb,'시작 아이템 획득')
contains(j.detail,'전리품');contains(j.detail,'우클릭');contains(j.location,'검은바위 나락')
counts[11446]=1
info=G.QuestStartItemGuide(4264);eq(info.owned,1);contains(info.action,'1개 보유')
j=G.QuestJourney(4264);eq(j.verb,'시작 아이템 사용');contains(j.detail,'우클릭');contains(j.detail,'윈저')
counts[11446]=nil
info=G.QuestStartItemGuide(4264);eq(info.owned,nil);contains(info.action,'소지 여부 미확인');contains(info.action,'가방에 없으면')
counts[80001]=0
info=assert(G.QuestStartItemGuide(90001));contains(info.sourceText,'첫 번째 적');contains(info.sourceText,'세 번째 적')
eq(info.known,true);eq(info.uncertain,true)
counts[80002]=0
info=assert(G.QuestStartItemGuide(90002));eq(info.sourceText,nil);eq(info.known,false);contains(info.action,'획득처를 확인')
eq(G.QuestStartItemGuide(42),nil)
eq(G.db,initialDB);eq(G.db.guide,initialRoute);eq(G.db.selectedQuests,initialSelected)
print('PASS V2.8.2 acquisition: '..n..' validated states and read-only source guidance')

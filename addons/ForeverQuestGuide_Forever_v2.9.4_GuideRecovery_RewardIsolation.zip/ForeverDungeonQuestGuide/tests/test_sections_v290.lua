-- V2.9.0 user-reported scenario: collapsed chain -> separate singles -> chain.
-- Only verified relations are grouped; no state or other data is mutated.
local base=(arg and arg[1]) or './'
local G={db={groupChains=true,chainCollapsed={},selectedQuests={[77]=true},deferredQuests={[99]=true},guide={sentinel=true}}}
local names={[10]='노트 구출 대작전',[11]='노트 구출 대작전',[20]='고르독 술 맛보기',[21]='푸실린과 노쇠한 아즈토르딘',[30]='분기 내면의 광기',[31]='분기 내면의 광기'}
local parents={[11]={10},[31]={30},[20]={999}}
local done={[10]=true}
QuestDB={}
function G.Ready()return true end
function G.MandatoryRoutePrereqs(id)return parents[id] or {} end
function G.QuestPrerequisite(id)return parents[id] or {},{} end
function G.DBGet(_,id,key)if key=='name' then return names[id] end end
function G.QuestListMeta(id)return{label='test',level='60'}end
function G.IsQuestBrowseVisible()return false end -- No context nodes: 20 remains standalone-with-external-prereq.
function G.GetQuestName(id)return names[id] or ('Quest '..id)end
function G.RouteAssessment(id)return done[id] and 'done' or 'ready',done[id] and 'done' or 'ready' end
function G.IsCompleted(id)return done[id] or false end
function G.IsRouteSatisfied(id)return done[id] or false end
local function read(file)assert(loadfile(base..file))('ForeverDungeonQuestGuide',G)end
read('QuestChains.lua');read('QuestSections.lua')
local checks=0
local function verify(value,message)assert(value,message);checks=checks+1 end
local function row(id)return{kind='quest',id=id,meta={label='test'}}end
local input={row(10),row(11),row(20),row(21),row(30),row(31)}
local savedGuide,savedChecks,savedDefer=G.db.guide,G.db.selectedQuests,G.db.deferredQuests
local raw=G.QuestChainRows(input,'dir:dm',false)
local processed=G.QuestListSeparateBlocks(raw,'dir:dm')
local header1,header2,standalone
for _,entry in ipairs(processed)do
 if entry.kind=='chain' then if not header1 then header1=entry else header2=entry end end
 if entry.kind=='standaloneHeader' then standalone=entry end
end
verify(header1~=nil and header2~=nil,'both stories must be grouped')
verify(standalone~=nil and standalone.count==2,'two independent quests need their own section')
verify(standalone.external==true,'a quest with prerequisites out of the current scope must be labelled incomplete')
local seq={};for _,e in ipairs(processed) do seq[#seq+1]=e.kind end
verify(table.concat(seq,',')=='chain,quest,quest,chainEnd,standaloneHeader,quest,quest,chain,quest,quest,chainEnd','boundary order must be chain/singles/chain')
local isolated={};for _,e in ipairs(processed)do if e.kind=='quest' and (e.id==20 or e.id==21) then isolated[#isolated+1]=e end end
verify(isolated[1].singleSectionKey==standalone.key and isolated[2].singleSectionKey==standalone.key,'both singles must be inside the neutral frame')
verify(isolated[1].relatedOutside==true and isolated[2].relatedOutside==false,'external prerequisite must not become a fake group')
verify(isolated[1].chainKey==nil and isolated[2].chainKey==nil,'single rows must not inherit a chain key')
verify(header1.key~=header2.key,'separate chains must preserve their identities')
verify(G.QuestFindAnchor(processed,{kind='quest',id=21})>0,'scroll anchor for single quest')
verify(G.QuestFindAnchor(processed,{kind='chain',key=header2.key})>0,'scroll anchor for other chain')
local foldedKey=header1.key
G.ToggleChainGroup(foldedKey)
local collapsed=G.QuestListSeparateBlocks(G.QuestChainRows(input,'dir:dm',false),'dir:dm')
verify(collapsed[1].kind=='chain' and collapsed[1].collapsed==true,'first chain collapsed')
verify(collapsed[2].kind=='standaloneHeader' and collapsed[3].id==20 and collapsed[4].id==21,'singles still separate after collapse')
verify(collapsed[5].kind=='chain' and collapsed[5].key==header2.key,'second chain retains stable key after collapse')
verify(G.db.guide==savedGuide and G.db.selectedQuests==savedChecks and G.db.deferredQuests==savedDefer,'UI operations must not change route/progress/deferred')
verify(G.db.selectedQuests[77]==true,'unrelated saved quest selection preserved')
verify(G.QuestVisibleAnchor(collapsed,0).key==foldedKey,'visible anchor starts on collapsed header')
G.db.groupChains=false
verify(#G.QuestListSeparateBlocks(input,'none')==#input,'grouping off must retain original rows')
print('PASS V2.9.0 neutral single group boundary, story anchors, external relation and state preservation: '..checks..' assertions')

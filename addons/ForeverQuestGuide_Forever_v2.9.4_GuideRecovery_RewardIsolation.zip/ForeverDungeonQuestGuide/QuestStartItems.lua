local addon,G=...
-- Read-only item-start quest acquisition instructions. DB links are source
-- candidates, not guaranteed drops or measured Forever probabilities.
-- The current inventory is never inferred from a missing API.
local curated={
 [4264]={itemId=11446,name="꼬깃꼬깃한 쪽지",place="검은바위 나락 · 입구/채석장 및 검은무쇠 적 활동 구역",
  sources="성난모루단 감독관·교도관·보초 등 검은바위 나락 적들의 전리품 (확률 드롭 · 반복 처치 가능)",
  after="획득한 쪽지를 가방에서 우클릭하여 수락한 다음, 검은바위 나락 감금 구역의 치안대장 윈저에게 보고하세요.",
  source="포에버 와우헤드 퀘스트 #4264 및 공개 드롭 대상 목록 · 실게임 드롭률 미측정"},
}
local function dbget(db,id,key)
 if not db or not G.DBGet then return nil end
 local ok,value=pcall(G.DBGet,db,id,key)
 return ok and value or nil
end
local function itemCount(id)
 local fn=C_Item and C_Item.GetItemCount or GetItemCount
 if type(fn)~="function" then return nil end
 local ok,value=pcall(fn,id,false)
 if ok and type(value)=="number" and value>=0 then return value end
 return nil
end
local function sourceNames(itemId)
 local found={}
 for _,entry in ipairs({{ItemDB and dbget(ItemDB,itemId,"npcDrops"),NpcDB},
                         {ItemDB and dbget(ItemDB,itemId,"objectDrops"),ObjectDB}}) do
  local ids,db=entry[1],entry[2]
  if type(ids)=="table" then
   for _,source in ipairs(ids) do
    local id=type(source)=="table" and tonumber(source[1]) or tonumber(source)
    local name=id and dbget(db,math.abs(id),"name")
    if type(name)=="string" and name~="" then
     if G.KoreanText then name=G.KoreanText(name) end
     found[#found+1]=name
     if #found>=3 then return table.concat(found," · ").." 등 (QuestieDB 출처 후보)" end
    end
   end
  end
 end
 if #found>0 then return table.concat(found," · ").." (QuestieDB 출처 후보)" end
 return nil
end
function G.QuestStartItemGuide(questId)
 local id=tonumber(questId)
 if not id or id%1~=0 then return nil end
 local recipe=curated[id]
 local name,itemId,_,kind
 if type(G.QuestContactName)=="function" then name,itemId,_,kind=G.QuestContactName(id,"accept") end
 if kind~="item" and not recipe then return nil end
 itemId=kind=="item" and tonumber(itemId) or recipe and recipe.itemId
 if not itemId then return nil end
 name=(recipe and recipe.name) or name or ("아이템 #"..itemId)
 if G.KoreanText then name=G.KoreanText(name) end
 local count=itemCount(itemId)
 local sources=(recipe and recipe.sources) or sourceNames(itemId)
 local place=(recipe and recipe.place) or "시작 아이템 획득처 확인 필요 · 퀘스트 원문/QuestieDB"
 local after=(recipe and recipe.after) or ("‘"..name.."’을 가방에서 사용한 뒤 실제 목표와 보고 대상을 확인하세요.")
 local action,verb
 if count and count>0 then
  verb="시작 아이템 사용"
  action="가방에 ‘"..name.."’ "..count.."개 보유 · 우클릭해 퀘스트를 수락하세요."
 elseif count==0 then
  verb="시작 아이템 획득"
  action="시작 아이템 ‘"..name.."’을 가방에서 찾지 못했습니다. "..(sources and (sources.."에서 먼저 획득하세요.") or "퀘스트 아이템의 실제 획득처를 확인하세요.")
 else
  verb="시작 아이템 확보 확인"
  action="시작 아이템 ‘"..name.."’ 소지 여부 미확인 · 가방에 없으면 "..(sources and (sources.."에서 먼저 획득하세요.") or "획득처 자료를 확인하세요.")
 end
 return {itemId=itemId,name=name,owned=count,place=place,sourceText=sources,source=recipe and recipe.source,
  action=action,verb=verb,note=after,uncertain=true,known=recipe~=nil or sources~=nil,inside=recipe~=nil}
end

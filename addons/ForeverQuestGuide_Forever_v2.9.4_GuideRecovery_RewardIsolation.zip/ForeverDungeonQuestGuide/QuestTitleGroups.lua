local addon,G=...
G.titleGroupsVersion="2.9.4"
-- Read-only nested chapters inside verified story chains. This never rewrites
-- actual quest IDs, completion flags, routing requirements, or checkboxes.
local function copy(entry)
 local out={};for k,v in pairs(entry) do out[k]=v end;return out
end
local specialSteps={
 [4022]="1단계 · 검은용군단 허물 전달 (첫 번째 경로)",
 [4023]="1단계 · 허물 획득·전달 (대체 경로)",
 [4024]="2단계 · 밸가르 처치·불의 정수 회수",
}
function G.TitleChapterStepLabel(id,number)
 if specialSteps[id] then return specialSteps[id] end
 local objective=G.QuestObjectiveText and G.QuestObjectiveText(id)
 if type(objective)=="string" and objective~="" then
  local first=objective:match("[^\n]+")
  if first and #first<160 then return "진행 "..tostring(number).." · "..first end
 end
 return "진행 "..tostring(number).." · 퀘스트 목표 확인"
end
local function completed(id)
 return G.IsCompleted and G.IsCompleted(id)==true
end
function G.TitleBranchSkipped(id)
 if id==4022 then
  return not completed(id) and not (G.IsInLog and G.IsInLog(id))
   and (completed(4023) or (G.IsInLog and G.IsInLog(4023))) or false
 elseif id==4023 then
  return not completed(id) and not (G.IsInLog and G.IsInLog(id))
   and (completed(4022) or (G.IsInLog and G.IsInLog(4022))) or false
 end
 return false
end
local function chosenAlternate(id,seen)
 return seen[id] and G.TitleBranchSkipped(id) or false
end
local function makeChapter(rows,header)
 if #rows<2 then return rows end
 local byName={}
 for _,entry in ipairs(rows) do
  if entry.kind=="quest" and entry.chainKey==header.key then
   local title=G.GetQuestName(entry.id)
   if type(title)=="string" and title~="" then
    local g=byName[title] or {members={},firstId=entry.id,name=title}
    g.members[#g.members+1]=entry
    if entry.id<g.firstId then g.firstId=entry.id end
    byName[title]=g
   end
  end
 end
 local emitted,out={},{}
 for _,entry in ipairs(rows) do
  local title=entry.kind=="quest" and G.GetQuestName(entry.id)
  local group=title and byName[title]
  if not group or #group.members<2 then out[#out+1]=entry
  elseif not emitted[group] then
   emitted[group]=true
   local key="chapter:"..header.key..":"..group.firstId
   local collapsed=G.db and G.db.chainCollapsed and G.db.chainCollapsed[key]
   local done,seen=0,{}
   for _,member in ipairs(group.members) do
    seen[member.id]=true
    if completed(member.id) then done=done+1 end
   end
   local isFlame=seen[4024] and (seen[4022] or seen[4023])
   -- Collapse the verified mutually-exclusive flame alternatives by default.
   -- Other same-name chains start expanded so previously visible rows remain visible.
   if collapsed==nil then collapsed=isFlame and true or false end
   local stepCount,stepsDone=#group.members,done
   if isFlame then
    stepCount=2
    stepsDone=((completed(4022) or completed(4023)) and 1 or 0)+(completed(4024) and 1 or 0)
   end
   local ids={};for _,member in ipairs(group.members) do ids[#ids+1]=member.id end
   out[#out+1]={kind="subchapter",key=key,parentKey=header.key,label=title,
    count=#ids,memberIds=ids,collapsed=collapsed,done=done,
    steps=stepCount,stepsDone=stepsDone,hasAlternatives=isFlame}
   if not collapsed then
    for index,member in ipairs(group.members) do
     local card=copy(member)
     card.subchapterKey=key;card.subchapterLabel=title
     card.subchapterStepLabel=G.TitleChapterStepLabel(card.id,index)
     card.subchapterSkipped=chosenAlternate(card.id,seen) and not completed(card.id)
     out[#out+1]=card
    end
   end
  end
 end
 return out
end
function G.QuestTitleNestedRows(rows)
 if not G.db or G.db.groupChains==false then return rows end
 local out,i={},1
 while i<=#rows do
  local entry=rows[i]
  if entry.kind=="chain" and not entry.collapsed then
   out[#out+1]=entry
   local group={};i=i+1
   while rows[i] and not (rows[i].kind=="chainEnd" and rows[i].key==entry.key) do
    group[#group+1]=rows[i];i=i+1
   end
   for _,member in ipairs(makeChapter(group,entry)) do out[#out+1]=member end
   if rows[i] then out[#out+1]=rows[i];i=i+1 end
  else out[#out+1]=entry;i=i+1 end
 end
 return out
end

-- Bootstrap smoke of the actual TOC and event handlers. Mock widgets/APIs are
-- deliberately separate from any assertion of compatibility with a live client.
local Mock=assert(loadfile('tests/mock_wow.lua'))().install()
local base=arg[1] or './'
local G={}
GetTime=function()return 100 end
GetLocale=function()return 'koKR' end
UnitRace=function()return '드워프','Dwarf',3 end
Minimap=CreateFrame('Frame','Minimap',UIParent);Minimap:SetSize(140,140)
local loaded={}
for line in io.lines(base..'ForeverDungeonQuestGuide.toc') do
 local name=line:match('^([^#].-%.lua)%s*$')
 if name then
  local chunk,err=loadfile(base..name);assert(chunk,err)
  local ok,why=pcall(chunk,'ForeverDungeonQuestGuide',G)
  assert(ok,'TOC load failed: '..name..': '..tostring(why))
  loaded[#loaded+1]=name
 end
end
local controller=assert(Mock.find(function(o)return o.scripts.OnEvent and o.scripts.OnUpdate end),'event controller missing')
controller.scripts.OnEvent(controller,'ADDON_LOADED','ForeverDungeonQuestGuide')
assert(type(G.db)=='table' and type(G.db.selectedQuests)=='table')
assert(G.player.faction=='Alliance' and G.player.classId==7)
assert(G.QuestJourney and G.JourneySummary,'Journey module missing from TOC')
G.ShowUI(true)
assert(G.IsUIShown(),'main UI did not show')
assert(G.UIJourneyWidgets.emptyList:IsShown(),'missing DB empty state did not show')
G.ShowUI(false)
controller.scripts.OnEvent(controller,'PLAYER_LOGIN')
controller.scripts.OnUpdate(controller,.51)
assert(type(G.API.StartQuest)=='function','public focus API missing')
assert(type(SlashCmdList.FOREVERDUNGEONQUESTGUIDE)=='function','slash command missing')
local printed={};local oldPrint=G.Print;G.Print=function(s)printed[#printed+1]=s end
SlashCmdList.FOREVERDUNGEONQUESTGUIDE('버전')
assert(#printed>0 and printed[#printed]:find('2.1.1',1,true),'Korean version command did not report loaded version')
G.Print=oldPrint
print('PASS full TOC bootstrap: '..#loaded..' modules, ADDON_LOADED, PLAYER_LOGIN, one update tick and missing-DB UI (mock only)')
-- Repeat with synthetic live data through the real event→state→UI pipeline.
-- These fixture IDs are not asserted to be real quests or route facts.
local fixture={
 [91001]={name='검사 선행',requiredLevel=40,questLevel=50,zoneOrSort=46,startedBy={{71}},finishedBy={{72}},objectivesText={'검사 물건 3개 획득'}},
 [91002]={name='검사 최종',requiredLevel=40,questLevel=51,zoneOrSort=46,preQuestGroup={91001},startedBy={{72}},finishedBy={{73}},objectivesText={'검사 대상과 대화'}},
 [91003]={name='검사 개별',requiredLevel=40,questLevel=50,zoneOrSort=46,startedBy={{71}},finishedBy={{73}},objectivesText={'검사 대상 처치'}},
}
local liveComplete=false
QuestDB={Get=function(id,key)return fixture[id] and fixture[id][key] end,GetAllIds=function()return{91001,91002,91003}end}
NpcDB={Get=function(id,key)if key=='name'then return '검사 NPC '..id elseif key=='spawns'then return{[46]={{66,22}}}end end}
C_QuestLog={
 GetNumQuestLogEntries=function()return 1 end,
 GetInfo=function(index)return index==1 and{questID=91001,title=fixture[91001].name,level=50,isComplete=liveComplete,isHeader=false}end,
 GetLogIndexForQuestID=function(id)return id==91001 and 1 or 0 end,
 IsOnQuest=function(id)return id==91001 end,
 IsComplete=function(id)return id==91001 and liveComplete end,
 IsQuestFlaggedCompleted=function()return false end,
}
local narrativeReads=0
GetQuestLogQuestText=function(index)assert(index==1,'narrative requested wrong log entry');narrativeReads=narrativeReads+1;return '검사 원문','실제 로그 목표: 검사 물건 3개'end
SelectQuestLogEntry=function()error('read-only journey must not select a game quest')end
controller.scripts.OnEvent(controller,'ADDON_LOADED','QuestieDB')
controller.scripts.OnUpdate(controller,.51)
G.TickQuestIndex(170)
G.SetViewMode('active');G.ShowUI(true);G.SetQuest(91001)
assert(G.QuestJourney(91001).phase=='objective')
assert(G.UIJourneyWidgets.nowAction:GetText():find('실제 로그 목표',1,true),'live objective not propagated to now card')
assert(narrativeReads>0,'live narrative was not read')
G.API.Open(nil,91002)
assert(G.selection.quest==91002,'explicit final target selection lost')
assert(G.QuestJourney(91002).actionQuestId==91001,'real chosen predecessor not shown')
liveComplete=true
controller.scripts.OnEvent(controller,'QUEST_LOG_UPDATE')
controller.scripts.OnUpdate(controller,.51)
assert(G.QuestJourney(91001).phase=='turnin','report-ready transition lost')
assert(not G.IsCompleted(91001),'report-ready became rewarded completion')
assert(G.QuestJourney(91002).actionPhase=='turnin','locked target should report its ready predecessor')
G.ShowUI(false)
print('PASS full runtime fixture: DB load/index, live narrative without quest selection, explicit target, report-ready event transition')

local addon,G=...
local controller=CreateFrame("Frame")
local dirty=false
local bagDirty=false
local elapsed=0
local movementElapsed=0
local indexElapsed=0
local statusElapsed=0
local hudElapsed=0
local lastPosition=nil
local lastIndoorStep,lastIndoorState
local function refreshIndoor()
 local st=G.CurrentStep and G.CurrentStep()
 local id=st and ((st.indoor and st.indoor.dungeonId) or (st.landmark and st.landmark.dungeonId))
 local state=id and G.IsInGuideDungeon and G.IsInGuideDungeon(id) or false
 if st and st==lastIndoorStep and state~=lastIndoorState then G.ActivateGuideStep(false);if G.HUDRefresh then G.HUDRefresh() end end
 lastIndoorStep=st;lastIndoorState=state
end
local function sync()
 G.PlayerRefresh()
 G.RefreshQuestLog()
 if G.RefreshEUIQuestBridge then G.RefreshEUIQuestBridge() end
 if G.HydrateGuideLocations then G.HydrateGuideLocations() end
 if G.UpgradeSavedRoute and G.UpgradeSavedRoute() then G.NotifyDataChange();return end
 if G.db and G.db.guide and G.db.guide.mode=="selected" and G.ReplanSelectedGuide then
  G.ReplanSelectedGuide("퀘스트 상태 변경")
 elseif G.ReconcileGuide then G.ReconcileGuide() end
 G.NotifyDataChange()
end
controller:SetScript("OnEvent",function(self,event,arg1,...)
 if event=="ADDON_LOADED" then
  if arg1==addon then
   G.StartSaved()
   G.PlayerRefresh()
   G.RefreshQuestLog()
  elseif arg1=="QuestieDB" then
   G.nameCache={}
   if G.RestartQuestIndex then G.RestartQuestIndex() end
   dirty=true
  elseif arg1=="Blizzard_WorldMap" then
   dirty=true
  elseif arg1=="ShortestPathForever" and G.InitializeNavigationSubscription then
   G.InitializeNavigationSubscription()
  elseif arg1=="EllesmereUIQuestTracker" and G.InstallEUIQuestBridge then
   G.InstallEUIQuestBridge()
  end
 elseif event=="PLAYER_LOGIN" then
  G.StartSaved()
  sync()
  if G.RestartQuestIndex then G.RestartQuestIndex() end
  if G.CreateMinimapButton then G.CreateMinimapButton() end
  if G.InstallEUIQuestBridge then G.InstallEUIQuestBridge() end
  if G.InitializeNavigationSubscription then G.InitializeNavigationSubscription() end
  local gd=G.db.guide
  if gd and gd.steps and #gd.steps>0 then G.ReconcileGuide();G.ActivateGuideStep(false) end
  if G.db.openOnLogin then G.ShowUI(true) end
  if not G.Ready() then G.Print("퀘스트 자료 애드온이 없어 퀘스트·선행 정보를 표시할 수 없습니다. 설치·로드 상태를 확인한 뒤 게임을 다시 실행하세요.") end
 elseif event=="QUEST_LOG_UPDATE" or event=="QUEST_ACCEPTED" or event=="QUEST_TURNED_IN" or event=="QUEST_REMOVED" or event=="PLAYER_LEVEL_UP" then
  if event=="QUEST_TURNED_IN" then
   if G.MarkQuestTurnedIn then G.MarkQuestTurnedIn(arg1) end
   if G.db and G.db.deferredQuests and tonumber(arg1) then
    G.db.deferredQuests[tonumber(arg1)]=nil
   end
  end
  if event=="QUEST_ACCEPTED" and G.MarkQuestAccepted then
   local questID=tonumber(select(1,...) or arg1)
   if questID then G.MarkQuestAccepted(questID) end
  end
  dirty=true
  if (event=="QUEST_ACCEPTED" or event=="QUEST_TURNED_IN" or event=="QUEST_REMOVED") and G.ScheduleQuestJourneyRepair then
   G.ScheduleQuestJourneyRepair()
  end
 elseif event=="BAG_UPDATE_DELAYED" or event=="BAG_UPDATE" then
  bagDirty=true
 elseif event=="SKILL_LINES_CHANGED" or event=="UPDATE_FACTION" or event=="SPELLS_CHANGED" then
  dirty=true
 elseif event=="ZONE_CHANGED_NEW_AREA" or event=="WORLD_MAP_UPDATE" then
  if G.RefreshMapPins then G.RefreshMapPins() end
  if event=="ZONE_CHANGED_NEW_AREA" and G.db and G.db.guide and G.db.guide.mode=="selected" then
   if G.ReplanSelectedGuide then G.ReplanSelectedGuide("지역 변경") end
  end
 elseif event=="PLAYER_ENTERING_WORLD" then
  if G.CreateMinimapButton then G.CreateMinimapButton() end
  if G.InstallEUIQuestBridge then G.InstallEUIQuestBridge() end
  refreshIndoor()
 elseif event=="PLAYER_REGEN_ENABLED" then
  if G.OnLeaveCombat then G.OnLeaveCombat() end
  if G.RefreshEUIQuestBridge then G.RefreshEUIQuestBridge() end
 end
end)
controller:SetScript("OnUpdate",function(_,dt)
 if G.TickQuestJourneyRepair then G.TickQuestJourneyRepair(dt) end
 elapsed=elapsed+dt
 hudElapsed=hudElapsed+dt
 if hudElapsed>=.65 then
  hudElapsed=0
  if G.HUDUpdateDistance then G.HUDUpdateDistance() end
 end
 indexElapsed=indexElapsed+dt
 if indexElapsed>=.12 then
  indexElapsed=0
  if G.TickQuestIndex then G.TickQuestIndex(170) end
 end
 -- Questie can finish loading its objective cache after QUEST_LOG_UPDATE.
 -- Poll only while the guide or UI is active; replan only on state changes.
 statusElapsed=statusElapsed+dt
 if statusElapsed>=2 then
  statusElapsed=0
  refreshIndoor()
  if not dirty and G.db and ((G.db.guide and G.db.guide.steps and #G.db.guide.steps>0) or (G.IsUIShown and G.IsUIShown())) then
   if G.RefreshQuestLog and G.RefreshQuestLog() then
    if G.db.guide and G.db.guide.mode=="selected" and G.ReplanSelectedGuide then G.ReplanSelectedGuide("퀘스트 완료 상태 갱신")
    elseif G.ReconcileGuide then G.ReconcileGuide() end
    G.NotifyDataChange()
   else
    local st=G.CurrentStep and G.CurrentStep()
    if st and G.StepIsDone(st,G.db.guide.index) then G.ReconcileGuide();G.NotifyDataChange() end
   end
  end
 end
 movementElapsed=movementElapsed+dt
 if movementElapsed>=4 then
  movementElapsed=0
  if G.db and G.db.guide and G.db.guide.mode=="selected" and G.CurrentStep() and G.PlayerLocation and not G.GuideViewingHistory() then
   local loc=G.PlayerLocation()
   if loc and (not lastPosition or lastPosition.map~=loc.map or
      (not loc.approx and (lastPosition.approx or type(lastPosition.x)~="number" or type(lastPosition.y)~="number" or
       ((loc.x-lastPosition.x)^2+(loc.y-lastPosition.y)^2)>.0004))) then
    lastPosition=loc
    if G.ReplanSelectedGuide then G.ReplanSelectedGuide("플레이어 위치 변경") end
   end
  else lastPosition=nil end
 end
 if elapsed<.5 then return end
 elapsed=0
 if dirty then dirty=false;sync() end
 if bagDirty then
  bagDirty=false
  if G.CurrentStep and G.CurrentStep() and G.HUDRefresh then G.HUDRefresh() end
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
end)
for _,ev in ipairs({"ADDON_LOADED","PLAYER_LOGIN","QUEST_LOG_UPDATE","QUEST_ACCEPTED","QUEST_TURNED_IN","QUEST_REMOVED","PLAYER_LEVEL_UP","ZONE_CHANGED_NEW_AREA","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED"}) do
 controller:RegisterEvent(ev)
end
for _,ev in ipairs({"SKILL_LINES_CHANGED","UPDATE_FACTION","SPELLS_CHANGED","BAG_UPDATE_DELAYED","BAG_UPDATE"}) do
 pcall(controller.RegisterEvent,controller,ev)
end
-- WORLD_MAP_UPDATE is not available on all Forever-era clients.
if C_EventUtils and C_EventUtils.IsEventValid and C_EventUtils.IsEventValid("WORLD_MAP_UPDATE") then
 controller:RegisterEvent("WORLD_MAP_UPDATE")
end
SLASH_FOREVERDUNGEONQUESTGUIDE1="/fdq"
SLASH_FOREVERDUNGEONQUESTGUIDE2="/던전퀘"
SlashCmdList.FOREVERDUNGEONQUESTGUIDE=function(msg)
 msg=tostring(msg or ""):gsub("^%s+",""):gsub("%s+$","")
 local cmd,rest=msg:match("^(%S+)%s*(.-)$")
 cmd=cmd or ""
 if cmd=="" then G.ToggleUI();return end
 if cmd=="version" or cmd=="버전" then G.Print(G.VersionReport());return end
 if cmd=="focus" or cmd=="바로시작" then G.StartQuickGuide(tonumber(rest));return end
 if cmd=="back" or cmd=="이전동선" then G.ResumeSuspendedGuide();return end
 if cmd=="activeall" or cmd=="전체진행" then G.StartActiveGuide(false);return end
 if cmd=="reportall" or cmd=="전체보고" then G.StartActiveGuide(true);return end
 if cmd=="stop" or cmd=="중지" then G.StopGuide();return end
 if cmd=="reset" or cmd=="초기화" then G.ResetRoutePlanning();return end
 if cmd=="deferred" or cmd=="보류목록" then G.SetViewMode("deferred");G.ShowUI(true);return end
 if cmd=="hud" or cmd=="표시" then if G.ToggleHUD then G.ToggleHUD() end;return end
 if cmd=="steps" or cmd=="동선" then if G.TogglePlanWindow then G.TogglePlanWindow() end;return end
 if cmd=="hudcfg" or cmd=="config" or cmd=="설정" then
  if G.HUDRefresh then G.HUDRefresh() end
  if G.ToggleHUDSettings then G.ToggleHUDSettings() end
  return
 end
 if cmd=="opacity" or cmd=="alpha" or cmd=="투명도" then
  local n=tonumber(rest)
  if n and G.HUDSetOpacity then G.HUDSetOpacity(n)
  else G.Print("사용법: /던전퀘 투명도 0~85 사이의 숫자") end
  return
 end
 if cmd=="size" or cmd=="크기" then
  local a,b=rest:match("^(%d+)%s+(%d+)$")
  if a and b and G.HUDSetSize then
   if G.HUDRefresh then G.HUDRefresh() end
   G.HUDSetSize(tonumber(a),tonumber(b))
  else G.Print("사용법: /던전퀘 크기 520 430 (가로 세로)") end
  return
 end

 if cmd=="next" or cmd=="다음" then if G.GuideViewingHistory() then G.ReturnToActiveGuide() else G.NextGuide(1,true) end;return end
 if cmd=="later" or cmd=="보류" or cmd=="나중에" then G.DeferCurrentQuest();return end
 if cmd=="resume" or cmd=="복귀" or cmd=="보류해제" then
  G.ResumeDeferredQuests(rest~="" and rest or "all");return
 end
 if cmd=="map" or cmd=="지도" then
  if G.GuideViewingHistory() then G.Print("기록 보기 중입니다. 현재 단계로 돌아가세요.");return end
  local step=G.CurrentStep()
  G.OpenGuideStepMap(step)
  return
 end
 if cmd=="faction" or cmd=="진영" then
  local factions={auto="auto",alliance="Alliance",ally="Alliance",horde="Horde",all="all",["얼라"]="Alliance",["얼라이언스"]="Alliance",["호드"]="Horde",["전체"]="all",["자동"]="auto"}
  local v=factions[(rest or ""):lower()]
  if not v then G.Print("진영 검색: /던전퀘 진영 자동 / 얼라이언스 / 호드 / 전체 (현재: "..(G.FactionFilterLabel and G.FactionFilterLabel() or "확인 필요")..")");return end
  G.SetFactionFilter(v)
  G.Print("퀘스트 검색 진영: "..G.FactionFilterLabel().." · 실제 동선은 플레이어 진영 기준")
  G.ShowUI(true)
  return
 end
 if cmd=="all" or cmd=="전체" then G.SetViewMode("all");G.ShowUI(true);return end
 if cmd=="dungeon" or cmd=="던전" then G.SetViewMode("dungeon");G.ShowUI(true);return end
 if cmd=="zone" or cmd=="지역" then G.SetViewMode("zone");G.ShowUI(true);return end
 if cmd=="active" or cmd=="진행" then G.SetViewMode("active");G.ShowUI(true);return end
 if cmd=="turnin" or cmd=="보고" then G.SetViewMode("turnin");G.ShowUI(true);return end
 if cmd=="turnins" or cmd=="보고동선" then G.StartTurninGuide();G.ShowUI(true);return end
 if cmd=="checked" or cmd=="체크" then G.SetViewMode("selected");G.ShowUI(true);return end
 if cmd=="sync" or cmd=="여정" then
  if G.db and G.db.guide and G.db.guide.steps and G.db.guide.steps[G.db.guide.index or 1] then
   G.NavigateGuideRoute(G.db.guide,false,true)
  else G.Print("실행 중인 통합 동선이 없습니다. 먼저 여러 퀘스트를 체크해 동선을 시작하세요.") end
  return
 end
 if cmd=="pins" or cmd=="지도표시" then
  local mode=rest:lower()
  if mode=="off" or mode=="0" or mode=="none" or mode=="끔" then G.db.mapPinMode="off"
  elseif mode=="on" or mode=="1" or mode=="current" or mode=="현재" then G.db.mapPinMode="current"
  elseif mode=="next" or mode=="2" or mode=="다음" then G.db.mapPinMode="next"
  elseif mode=="auto" or mode=="자동" then G.db.mapPinMode="auto"
  else G.Print("사용법: /던전퀘 지도표시 자동 / 현재 / 다음 / 끔");return end
  if G.RefreshMapPins then G.RefreshMapPins() end
  local labels={auto="자동",current="현재 단계",next="다음 단계까지",off="끔"}
  G.Print("지도 표시: "..labels[G.db.mapPinMode])
  return
 end
 if cmd=="excluded" or cmd=="제외" then G.PrintRouteExclusions();return end
 if cmd=="route" or cmd=="경로" then G.StartSelectedGuide();G.ShowUI(true);return end
 if cmd=="guide" or cmd=="시작" then
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil);G.ShowUI(true)
  else G.Print("먼저 던전을 선택하세요.") end
  return
 end
 if cmd=="quest" or cmd=="퀘스트" then
  local qid=tonumber(rest)
  if qid and G.DBGet(QuestDB,qid,"name") then
   G.SetViewMode("all");G.SetQuest(qid);G.ShowUI(true)
  else G.Print("퀘스트 자료에서 해당 번호를 찾을 수 없습니다: "..tostring(rest)) end
  return
 end
 if cmd=="check" or cmd=="추가" then
  local qid=tonumber(rest)
  if qid and G.DBGet(QuestDB,qid,"name") then G.ToggleQuestChecked(qid,true);G.SetQuest(qid);G.ShowUI(true)
  else G.Print("퀘스트 번호를 확인하세요.") end
  return
 end
 local found=G.SearchDungeons(msg)
 if found and #found>0 then
  G.SetDungeon(found[1].dungeon.id)
  if found[1].matchedQuest then G.SetQuest(found[1].matchedQuest) end
  G.ShowUI(true)
 else G.SetViewMode("all");G.ShowUI(true);G.Print("전체 퀘스트 검색창에 검색어를 입력하세요: "..msg) end
end

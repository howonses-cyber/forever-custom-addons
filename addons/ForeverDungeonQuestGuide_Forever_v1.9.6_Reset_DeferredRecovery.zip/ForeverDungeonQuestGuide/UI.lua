local addon,G=...
local C={bg={.055,.065,.082,.98},panel={.085,.10,.13,.96},gold={.95,.77,.39},cyan={.41,.82,.91},dim={.64,.69,.74},green={.4,.85,.54},gray={.85,.86,.89}}
local frame,searchInput,dataInfo,headerInfo,detailHead,detailPrereqs,guideInfo,guideNow,guideNote,navStatus
local dungeonRows,questRows,hideToggle,incompleteToggle,selectedInfo,leftTitle,factionButtons
local dungeonScrollbar,questScrollbar
local detailScroll,detailChild,detailQuest,lastDetailText
local planOffset,planBar,planProgress,planGuide=0,nil,nil,nil
local footerProgress,footerPrev,footerNext
local deferredListButton,resumeOneButton,resumeAllButton,resetButton
local planPrev,planNext,planExclusionButton
local showExcluded=false
local dungeonMaxScroll,questMaxScroll=0,0
local modeButtons={}
local planFrame,planRows,planHeading,planCounter=nil,nil,nil,nil
local dungeonOffset,questOffset=0,0
local DASH_COLOR={deferred="|cffe6ab63",dependentDeferred="|cffe6ab63",superseded="|cff96d9ed",done="|cff7ccf84",active="|cff7dd1ed",ready="|cfff5da80",turnin="|cff56e28e",low="|cffa7a8aa",blocked="|cffbb7777",locked="|cffdbad62",unknown="|cffabb3b7"}
local function label(parent,text,x,y,w,h,size,color)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h)
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
 if color then f:SetTextColor(color[1],color[2],color[3]) end
 if text then f:SetText(text) end
 return f
end
local function panel(parent,x,y,w,h)
 local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h);f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(C.panel))
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=G.UIButton(parent,text,w,h,fn)
 b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 return b
end
local function row(parent,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent);b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=b:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.12,.15,.19,.54);b.fill=t
 local glow=b:CreateTexture(nil,"HIGHLIGHT");glow:SetAllPoints();glow:SetColorTexture(.35,.40,.43,.22)
 b.marker=b:CreateTexture(nil,"ARTWORK");b.marker:SetPoint("LEFT",b,"LEFT",0,0);b.marker:SetSize(3,h)
 b.marker:SetColorTexture(.31,.36,.39,.8)
 b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 b.text:SetPoint("LEFT",b,"LEFT",9,0);b.text:SetPoint("RIGHT",b,"RIGHT",-4,0)
 b.text:SetJustifyH("LEFT");b.text:SetHeight(h);if b.text.SetMaxLines then b.text:SetMaxLines(1) end
 b:SetScript("OnClick",fn)
 return b
end
-- Continuous scrolling by row, instead of jumping by entire pages.
local function clampOffset(value,total,visible)
 return math.max(0,math.min(value,math.max(0,total-visible)))
end
local function setScrollbar(bar,offset,maxOffset)
 if not bar then return end
 bar.updating=true
 bar:SetMinMaxValues(0,maxOffset>0 and maxOffset or 1)
 bar:SetValue(maxOffset-offset)
 if maxOffset>0 then bar:Show() else bar:Hide() end
 bar.updating=false
end
local function scrollDungeon(delta)
 local target=math.max(0,math.min(dungeonMaxScroll,dungeonOffset+delta))
 if target~=dungeonOffset then dungeonOffset=target;G.UIRefresh() end
end
local function scrollQuest(delta)
 local target=math.max(0,math.min(questMaxScroll,questOffset+delta))
 if target~=questOffset then questOffset=target;G.UIRefresh() end
end
local function bindWheel(widget,fn)
 widget:EnableMouseWheel(true)
 widget:SetScript("OnMouseWheel",function(_,wheel)
  fn(-wheel*3)
 end)
end
local function makeScrollbar(parent,x,y,height,update)
 local bar=CreateFrame("Slider",nil,parent)
 bar:SetSize(13,height)
 bar:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 bar:SetOrientation("VERTICAL")
 bar:SetMinMaxValues(0,1)
 bar:SetValueStep(1)
 if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(true) end
 local background=bar:CreateTexture(nil,"BACKGROUND")
 background:SetAllPoints();background:SetColorTexture(.05,.065,.085,.95)
 bar:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
 local thumb=bar:GetThumbTexture()
 if thumb then thumb:SetSize(11,35);thumb:SetVertexColor(.84,.62,.28,.95) end
 bar:SetScript("OnValueChanged",function(self,value)
  if self.updating then return end
  local low,high=self:GetMinMaxValues()
  update(math.floor(high-(tonumber(value) or 0)+.5))
 end)
 return bar
end
local function itemTooltip(self,lines)
 if not GameTooltip then return end
 GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
 for i,v in ipairs(lines) do
  if i==1 then GameTooltip:SetText(v) else GameTooltip:AddLine(v,.84,.85,.89,true) end
 end
 GameTooltip:Show()
end
local function filteredQuests(d)
 local ids={}
 if not d then return ids end
 for _,id in ipairs(d.ids) do
  if G.IsQuestBrowseVisible(id) then ids[#ids+1]=id end
 end
 table.sort(ids,function(a,b)
  local _,as=G.QuestState(a);local _,bs=G.QuestState(b)
  local w={ready=1,active=2,locked=3,low=4,done=5,blocked=6}
  if (w[as] or 9)~=(w[bs] or 9) then return (w[as] or 9)<(w[bs] or 9) end
  return a<b
 end)
 return ids
end
local function prereqString(ids)
 local names={}
 for _,id in ipairs(ids) do
  local abs=math.abs(id)
  local mark=G.IsCompleted(abs) and "|cff75cf86[완료]|r " or
   (G.RoutePrereqEvidence(abs) and "|cff96d9ed[후속 진행 확인]|r " or (G.db.deferredQuests[abs] and "|cffe6ab63[사용자 보류]|r " or (G.IsInLog(abs) and "|cff7dd1ed[진행 중]|r " or "|cffffd06c[미완료]|r ")))
  names[#names+1]=mark..G.GetQuestName(abs)
 end
 return #names>0 and table.concat(names,"\n") or "없음"
end
local function makeQuestCheckbox(r)
 local check=CreateFrame("CheckButton",nil,r,"UICheckButtonTemplate")
 check:SetSize(25,25)
 check:SetPoint("LEFT",r,"LEFT",5,0)
 check:SetScript("OnClick",function(self)
  if r.quest then G.ToggleQuestChecked(r.quest,self:GetChecked()) end
 end)
 check:SetScript("OnEnter",function(self)
  itemTooltip(self,{"퀘스트 동선에 포함", "체크한 퀘스트는 하나의 동선으로 실시간 재계산됩니다."})
 end)
 check:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 r.text:ClearAllPoints()
 r.text:SetPoint("LEFT",r,"LEFT",35,0)
 r.text:SetPoint("RIGHT",r,"RIGHT",-4,0)
 r.checkbox=check
 r.statusText=r:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",35,1);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-6,1);r.statusText:SetHeight(13);r.statusText:SetJustifyH("LEFT")
 if r.statusText.SetWordWrap then r.statusText:SetWordWrap(false) end
 r.text:ClearAllPoints();r.text:SetPoint("TOPLEFT",r,"TOPLEFT",35,-1);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-6,-1);r.text:SetHeight(16)
end
local function detailText(text,q)
 if not detailScroll then detailPrereqs:SetText(text);return end
 if text~=lastDetailText or q~=detailQuest then
  local old=detailScroll:GetVerticalScroll()
  detailPrereqs:SetHeight(0);detailPrereqs:SetText(text)
  local h=math.max(1,math.ceil((detailPrereqs:GetStringHeight() or 0)+12))
  detailPrereqs:SetHeight(h);detailChild:SetHeight(h)
  local max=math.max(0,h-detailScroll:GetHeight())
  detailScroll:SetVerticalScroll(q~=detailQuest and 0 or math.min(old,max))
  detailQuest=q;lastDetailText=text
 end
end
local function buildUI()
 if frame or not UIParent then return end
 frame=CreateFrame("Frame","ForeverDungeonQuestGuideFrame",UIParent)
 frame:SetSize(1080,734)
 frame:SetPoint("CENTER",UIParent,"CENTER",(G.db.position and G.db.position.x)or 0,(G.db.position and G.db.position.y)or 0)
 frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag("LeftButton")
 frame:SetFrameStrata("DIALOG");frame:SetToplevel(true)
 local base=frame:CreateTexture(nil,"BACKGROUND");base:SetAllPoints();base:SetColorTexture(unpack(C.bg))
 local top=frame:CreateTexture(nil,"BORDER");top:SetPoint("TOPLEFT",0,-1);top:SetPoint("TOPRIGHT",0,-1)
 top:SetHeight(2);top:SetColorTexture(.85,.63,.26)
 frame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 frame:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then
   local ratio=(self.GetEffectiveScale and UIParent.GetEffectiveScale and self:GetEffectiveScale()/UIParent:GetEffectiveScale()) or 1
   G.db.position={x=x-ux/ratio,y=y-uy/ratio}
  end
 end)
 label(frame,"포에버 퀘스트 동선 가이드",19,-12,590,28,"GameFontNormalLarge",C.gold)
 label(frame,"지역·던전 검색  →  퀘스트 체크  →  통합 동선 시작",20,-43,610,18,"GameFontHighlightSmall",C.dim)
 dataInfo=label(frame,"",641,-42,411,19,"GameFontHighlightSmall",C.cyan);dataInfo:SetJustifyH("RIGHT")
 button(frame,"×",1036,-12,28,28,function()frame:Hide()end)
 label(frame,"검색",20,-80,50,22,"GameFontNormal",C.gold)
 searchInput=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
 searchInput:SetSize(369,25);searchInput:SetPoint("TOPLEFT",frame,"TOPLEFT",73,-77)
 searchInput:SetAutoFocus(false);searchInput:SetText("")
 local placeholder=label(searchInput,"퀘스트 이름 · ID · 지역",7,0,335,25,"GameFontDisableSmall",C.dim)
 local clear=button(frame,"×",448,-77,30,25,function()searchInput:SetText("");searchInput:ClearFocus()end)
 searchInput:SetScript("OnEditFocusGained",function()placeholder:Hide()end)
 searchInput:SetScript("OnEditFocusLost",function(self)if self:GetText()=="" then placeholder:Show() end end)
 searchInput:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnTextChanged",function(self)
  if self:GetText()~="" or (self.HasFocus and self:HasFocus()) then placeholder:Hide() else placeholder:Show() end
  dungeonOffset=0;questOffset=0
  if G.UIRefresh then G.UIRefresh() end
 end)
 local tabs={{"active","현재 퀘스트"},{"all","전체 검색"},{"zone","지역별"},{"dungeon","던전별"},{"turnin","보고 대기"},{"selected","체크 목록"}}
 for i,tab in ipairs(tabs) do
  modeButtons[tab[1]]=button(frame,tab[2],489+(i-1)*97,-78,93,27,function()
   questOffset=0;dungeonOffset=0;G.SetViewMode(tab[1])
  end)
 end
 local left=panel(frame,12,-117,232,487)
 local mid=panel(frame,254,-117,383,487)
 local right=panel(frame,647,-117,421,487)
 leftTitle=label(left,"지역/던전 분류",12,-7,215,24,"GameFontNormal",C.gold)
 -- Explicit browse filter. 'auto' uses the actual faction of this character.
 -- Opposite faction view is informational; route eligibility remains strict.
 factionButtons={}
 local factionItems={{"auto","자동"},{"Alliance","얼라"},{"Horde","호드"},{"all","전체"}}
 for i,entry in ipairs(factionItems) do
  local x=({8,92,137,182})[i]
  local width=({80,42,42,42})[i]
  factionButtons[entry[1]]=button(left,entry[2],x,-32,width,23,function()
   questOffset=0;dungeonOffset=0;G.SetFactionFilter(entry[1])
  end)
  factionButtons[entry[1]]:SetScript("OnEnter",function(self)
   itemTooltip(self,{"퀘스트 표시 진영: "..entry[2],
    "자동은 현재 캐릭터 진영을 인식합니다.",
    "호드/얼라 전환은 검색용입니다. 다른 진영 퀘스트는 동선에 추가할 수 없습니다.",
    "현재 퀘스트/보고 대기는 실제 퀘스트 로그를 그대로 표시합니다."})
  end)
  factionButtons[entry[1]]:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 end
 hideToggle=button(left,"제한 숨김",8,-61,103,23,function()
  G.db.hideUnavailable=not G.db.hideUnavailable;G.UIRefresh()
 end)
 incompleteToggle=button(left,"완료 제외",119,-61,105,23,function()
  G.db.onlyIncomplete=not G.db.onlyIncomplete;G.UIRefresh()
 end)
 dungeonRows={}
 bindWheel(left,scrollDungeon)
 for i=1,12 do
  local r=row(left,8,-92-(i-1)*29,193,27,function(self)
   if self.dungeon or self.zone then
    questOffset=0;dungeonOffset=0
    if self.dungeon then G.SetDungeon(self.dungeon)
    else G.SetZone(self.zone) end
    searchInput:SetText("")
   end
  end)
  bindWheel(r,scrollDungeon)
  dungeonRows[i]=r
 end
 dungeonScrollbar=makeScrollbar(left,209,-92,341,scrollDungeon)
 left.pagination=label(left,"",12,-460,195,20,"GameFontHighlightSmall",C.dim)
 label(mid,"퀘스트 목록 · ☑ 여러 개 선택",12,-7,350,25,"GameFontNormal",C.gold)
 headerInfo=label(mid,"",12,-31,357,27,"GameFontHighlightSmall",C.dim)
 questRows={}
 bindWheel(mid,scrollQuest)
 for i=1,12 do
  local r=row(mid,8,-65-(i-1)*32,340,30,function(self)
   if self.quest then G.SetQuest(self.quest) end
  end)
  makeQuestCheckbox(r)
  bindWheel(r,scrollQuest)
  bindWheel(r.checkbox,scrollQuest)
  questRows[i]=r
 end
 questScrollbar=makeScrollbar(mid,357,-68,375,scrollQuest)
 mid.pagination=label(mid,"",12,-460,346,20,"GameFontHighlightSmall",C.dim)
 label(right,"선택 퀘스트 · 선행 관계",12,-7,396,25,"GameFontNormal",C.gold)
 detailHead=label(right,"",12,-34,392,52,"GameFontHighlight",C.cyan)
 detailScroll=CreateFrame("ScrollFrame",nil,right)
 detailScroll:SetPoint("TOPLEFT",right,"TOPLEFT",13,-90);detailScroll:SetSize(391,196)
 detailChild=CreateFrame("Frame",nil,detailScroll);detailChild:SetSize(381,1);detailScroll:SetScrollChild(detailChild)
 detailPrereqs=label(detailChild,"",0,0,377,1,"GameFontHighlightSmall",C.gray);detailPrereqs:SetJustifyV("TOP")
 if detailPrereqs.SetSpacing then detailPrereqs:SetSpacing(4) end
 detailScroll:EnableMouseWheel(true);detailScroll:SetScript("OnMouseWheel",function(self,delta)
  local max=math.max(0,detailChild:GetHeight()-self:GetHeight());self:SetVerticalScroll(math.max(0,math.min(max,self:GetVerticalScroll()-delta*38)))
 end)
 label(right,"휠: 선행·조건 상세 보기",13,-288,390,17,"GameFontDisableSmall",C.dim)
 local start=button(right,"체크 퀘스트 통합 동선",10,-311,196,33,function()
  G.StartSelectedGuide()
 end)
 start:SetScript("OnEnter",function(self)itemTooltip(self,{"체크한 퀘스트만","수락 가능한 퀘스트 및 필수 선행을 통합합니다.","새 동선은 이전 동선을 교체합니다."})end)
 start:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 G.UIButtonState(start,true)
 button(right,"보고 대기만 동선",212,-311,197,33,function()
  G.StartTurninGuide()
 end)
 button(right,"선택 퀘스트 체크",10,-351,194,30,function()
  local id=G.selection.quest
  if not id then G.Print("퀘스트를 선택하세요.");return end
  G.ToggleQuestChecked(id,true)
 end)
 button(right,"퀘스트 위치 표시",210,-351,199,30,function()
  local q=G.selection.quest
  if not q then G.Print("퀘스트를 선택하세요.");return end
  if G.IsRouteSatisfied(q) then G.Print("완료/동선 제외된 퀘스트입니다. 이동할 필요가 없습니다.");return end
  local kind=G.IsReadyToTurnIn(q) and "turnin" or G.IsInLog(q) and "objective" or "accept"
  local p=G.QuestPoint(q,kind)
  if not p and kind=="objective" then
   local obj=G.QuestObjectivePoints(q)
   p=obj[1] and obj[1].point
  end
  -- Showing a quest location must never overwrite the multi-quest Journey.
  if p then G.OpenPointMap(p) else
   local st={quest=q,kind=kind};G.EnrichStepLocation(st)
   G.OpenGuideStepMap(st)
  end
 end)
 local dungeonStart=button(right,"던전 전체 통합 동선",10,-390,399,31,function()
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil)
  else G.Print("왼쪽에서 던전을 선택하세요.") end
 end)
 dungeonStart:SetScript("OnEnter",function(self)itemTooltip(self,{"선택 던전 전체","체크와 무관하게 현재 진행 가능한 던전 퀘스트를 통합합니다.","체크 목록은 변경하지 않습니다."})end)
 dungeonStart:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 selectedInfo=label(right,"",12,-432,158,23,"GameFontHighlightSmall",C.cyan)
 local clearChecks=button(right,"체크만 해제",174,-429,111,26,function()G.ClearCheckedQuests()end)
 clearChecks:SetScript("OnEnter",function(self)itemTooltip(self,{"체크만 해제","보류 기록은 유지합니다. 전체 초기화는 동선 초기화를 사용하세요."})end)
 clearChecks:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 resetButton=button(right,"동선 초기화",290,-429,119,26,function()
  G.ResetRoutePlanning();questOffset=0;searchInput:SetText("");G.UIRefresh()
 end)
 resetButton:SetScript("OnEnter",function(self)itemTooltip(self,{"새로 시작하기","체크, 보류, 동선 및 이동 안내를 초기화합니다.","실제 수락/완료한 퀘스트와 화면 설정은 유지합니다."})end)
 resetButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 deferredListButton=button(right,"보류 목록 0",10,-459,130,24,function()
  questOffset=0;searchInput:SetText("");G.SetViewMode("deferred")
 end)
 resumeOneButton=button(right,"선택 보류 해제",145,-459,130,24,function()G.ResumeSelectedBlocker(G.selection.quest)end)
 resumeOneButton:SetScript("OnEnter",function(self)
  local blocker=G.DeferredBlocker(G.selection.quest)
  itemTooltip(self,{"선택 보류 해제",blocker and ("해제 대상: "..G.GetQuestName(blocker)) or "보류된 퀘스트 또는 그 후속 퀘스트를 선택하세요."})
 end)
 resumeOneButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 resumeAllButton=button(right,"전체 보류 해제",280,-459,129,24,function()G.ResumeDeferredQuests("all")end)
 local foot=panel(frame,12,-611,1056,112)
 guideInfo=label(foot,"가이드 대기 중",11,-7,570,21,"GameFontNormal",C.gold)
 guideNow=label(foot,"",11,-34,1014,23,"GameFontHighlightSmall",C.gray)
 guideNote=label(foot,"",11,-80,1020,23,"GameFontHighlightSmall",C.dim)
 navStatus=label(foot,"",11,-58,1020,21,"GameFontHighlightSmall",C.cyan)
 button(foot,"이동 안내",611,-6,74,24,function()G.ToggleHUD()end)
 button(foot,"동선표",689,-6,68,24,function()G.TogglePlanWindow()end)
 footerPrev=button(foot,"◀ 이전",762,-6,83,24,function()G.NextGuide(-1,false)end)
 footerNext=button(foot,"다음 확인",849,-6,108,24,function()if G.GuideViewingHistory() then G.ReturnToActiveGuide() else G.NextGuide(1,true) end end)
 G.UIButtonState(footerNext,true)
 footerProgress=G.UIProgress(foot);footerProgress:SetPoint("TOPLEFT",foot,"TOPLEFT",11,-30);footerProgress:SetPoint("TOPRIGHT",foot,"TOPRIGHT",-12,-30);footerProgress:SetHeight(3)
 button(foot,"중지",961,-6,76,24,function()G.StopGuide()end)
 frame.left=left;frame.mid=mid
 G.UIFit(frame);frame:Hide()
end
local function buildPlanUI()
 if planFrame or not UIParent then return end
 planFrame=CreateFrame("Frame","ForeverDungeonQuestGuidePlanFrame",UIParent)
 planFrame:SetSize(600,685);planFrame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 planFrame:SetClampedToScreen(true);planFrame:SetFrameStrata("FULLSCREEN_DIALOG")
 planFrame:SetMovable(true);planFrame:EnableMouse(true);planFrame:RegisterForDrag("LeftButton")
 planFrame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 planFrame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 local back=planFrame:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(unpack(C.bg))
 planHeading=label(planFrame,"전체 방문 동선",16,-10,480,31,"GameFontNormalLarge",C.gold)
 button(planFrame,"×",563,-11,26,27,function()planFrame:Hide()end)
 label(planFrame,"완료/예정 단계 열람 · 실제 경로 유지 | 휠 스크롤",16,-42,410,18,"GameFontHighlightSmall",C.dim)
 planProgress=G.UIProgress(planFrame);planProgress:SetPoint("TOPLEFT",planFrame,"TOPLEFT",14,-64);planProgress:SetPoint("TOPRIGHT",planFrame,"TOPRIGHT",-14,-64);planProgress:SetHeight(4)
 local function move(delta)planOffset=math.max(0,planOffset+delta);G.PlanRefresh()end
 bindWheel(planFrame,move)
 planRows={}
 for i=1,17 do
  planRows[i]=row(planFrame,11,-81-(i-1)*31,554,29,function(self)
   local gd=G.db and G.db.guide
   if self.exclusionQuest then
    local id=self.exclusionQuest;planFrame:Hide();G.ShowUI(true);G.SetQuest(id)
   elseif gd and gd.steps and self.guideIndex then
    G.SelectGuideStep(self.guideIndex)
   end
  end)
  bindWheel(planRows[i],move)
 end
 planBar=makeScrollbar(planFrame,574,-81,525,function(offset)planOffset=offset;G.PlanRefresh()end)
 planCounter=label(planFrame,"",16,-616,282,26,"GameFontHighlightSmall",C.dim)
 planPrev=button(planFrame,"◀ 이전",301,-614,79,26,function()move(-#planRows)end)
 planNext=button(planFrame,"다음 ▶",385,-614,79,26,function()move(#planRows)end)
 planExclusionButton=button(planFrame,"제외 0",436,-42,147,20,function()
  showExcluded=not showExcluded;planOffset=0;G.PlanRefresh()
 end)
 local jump=button(planFrame,"현재 단계",469,-614,117,26,function()
  showExcluded=false
  local gd=G.db and G.db.guide
  if gd and gd.steps and #gd.steps>0 then
   G.ReturnToActiveGuide();planOffset=math.max(0,(gd.index or 1)-3)
  end
  G.PlanRefresh()
 end)
 G.UIButtonState(jump,true)
 label(planFrame,"지도 좌표는 참고용 · 실제 이동은 오른쪽 여정 또는 장소 설명",16,-645,566,20,"GameFontHighlightSmall",C.dim)
 G.UIFit(planFrame);planFrame:Hide()
end
function G.PlanRefresh()
 if not planFrame or not planFrame:IsShown() then return end
 local gd=G.db and G.db.guide
 local excluded=gd and gd.excluded or {}
 if planGuide~=gd then showExcluded=gd and gd.halted and #excluded>0 or false;planOffset=0 end
 if showExcluded and #excluded==0 and gd and gd.steps and #gd.steps>0 and not gd.halted then showExcluded=false;planOffset=0 end
 planExclusionButton:SetText(showExcluded and "동선 보기" or ("제외/보류 "..#excluded))
 if showExcluded then
  planGuide=gd;planHeading:SetText("제외/보류 퀘스트 · "..#excluded.."개")
  planOffset=clampOffset(planOffset,#excluded,#planRows)
  local maximum=math.max(0,#excluded-#planRows);setScrollbar(planBar,planOffset,maximum)
  planProgress:SetProgress(0,0);planCounter:SetText("제외/보류 "..#excluded.."개 · 툴팁 상세")
  if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
  if planOffset<maximum then planNext:Enable() else planNext:Disable() end
  for i,r in ipairs(planRows) do
   local item=excluded[planOffset+i];r.guideIndex=nil;r.exclusionQuest=item and item.id or nil
   if item then
    r.text:SetText("|cffffc675[제외]|r "..item.name.." · "..item.reason)
    r.fill:SetColorTexture(.14,.12,.10,.95);r.marker:SetColorTexture(.78,.54,.21,1)
    r:SetScript("OnEnter",function(self)itemTooltip(self,{item.name.." (#"..item.id..")",item.reason,"클릭: 퀘스트 상세 및 보류 해제 · 실제 완료/체크 유지"})end);r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end);r:Show()
   else r:Hide() end
  end
  return
 end
 if not gd or not gd.steps or #gd.steps==0 then
  planGuide=gd
  planHeading:SetText(gd and gd.halted and "진행 가능한 동선 없음" or "진행 중인 동선 없음")
  for _,r in ipairs(planRows)do r.exclusionQuest=nil;r.guideIndex=nil;r:Hide()end
  planCounter:SetText("0 / 0");planProgress:SetProgress(0,0);setScrollbar(planBar,0,0);planPrev:Disable();planNext:Disable()
  return
 end
 local dungeon=G.GetDungeon(gd.dungeon)
 planHeading:SetText(G.RouteScopeLabel(gd))
 local done,total=G.GuideProgress();planProgress:SetProgress(done,total)
 if planGuide~=gd then planGuide=gd;planOffset=math.max(0,(gd.index or 1)-3) end
 planOffset=clampOffset(planOffset,#gd.steps,#planRows)
 local maxOffset=math.max(0,#gd.steps-#planRows);setScrollbar(planBar,planOffset,maxOffset)
 if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
 if planOffset<maxOffset then planNext:Enable() else planNext:Disable() end
 for i,r in ipairs(planRows) do
  r.exclusionQuest=nil
  local ix=planOffset+i
  local st=gd.steps[ix]
  if st then
   r.guideIndex=ix
   local active=ix==(gd.index or 1);local viewed=G.GuideViewingHistory() and ix==G.GuideViewIndex()
   local prefix=active and ("|cff83d4fa"..ix..". 진행|r") or (tostring(ix)..".")
   local status=G.GuideViewStatus(st,ix)
   if status and ix<(gd.index or 1) then prefix=(G.StepIsDone(st,ix) and "|cff87dc98" or "|cff9daab6")..tostring(ix)..". 기록|r" end
   if viewed then prefix="|cffc4b1ff열람|r "..prefix end
   r.fill:SetColorTexture(active and .17 or viewed and .15 or .10,active and .29 or viewed and .20 or .13,active and .36 or viewed and .31 or .16,.95)
   local texts={accept="|cff74d7ff[수락]|r",turnin="|cff7cd18d[보고]|r",objective="|cffffd178[수행]|r",entrance="|cffffa36e[입구]|r",inside="|cffacaad4[던전]|r"}
   r.text:SetText(prefix.." "..(texts[st.kind] or "[단계]").." "..(st.questName or st.title or "")..(st.point and " |cff72ce98[지도]|r" or st.indoor and " |cffdaaaff[던전 내부]|r" or st.landmark and " |cff96d9ed[장소 안내]|r" or st.regionHint and " |cff96d9ed[지역 안내]|r" or " |cff9ba4aa[좌표 미확인]|r"))
   r.marker:SetColorTexture(active and .43 or viewed and .68 or .22,active and .77 or viewed and .56 or .31,active and .94 or viewed and .93 or .39,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{st.title,st.note or "","클릭하여 기록/예정 단계 열람 · 진행 위치 유지"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
   r:Show()
  else r.guideIndex=nil;r:Hide() end
 end
 planCounter:SetText("진행 "..done.."/"..total.." · "..(planOffset+1).."–"..math.min(total,planOffset+#planRows).." 표시")
end
function G.TogglePlanWindow()
 buildPlanUI()
 if not planFrame then return end
 if planFrame:IsShown() then planFrame:Hide() else G.UIFit(planFrame);planGuide=nil;planFrame:Show();G.PlanRefresh() end
end
function G.ShowRouteExclusions()
 buildPlanUI();if not planFrame then return end
 G.UIFit(planFrame);planGuide=G.db and G.db.guide;showExcluded=true;planOffset=0;planFrame:Show();G.PlanRefresh()
end
function G.IsUIShown() return frame and frame:IsShown() or false end
function G.UIRefresh()
 if not frame or not G.db then return end
 local mode=G.selection.mode or "all"
 local search=searchInput and searchInput:GetText() or ""
 if dataInfo then
  dataInfo:SetText(G.Ready() and ("QuestieDB 연결 · "..G.QuestIndexStatus()) or "QuestieDB 미연결")
 end
 for key,b in pairs(modeButtons) do
  b:SetText(({all="전체 검색",active="현재 퀘스트",turnin="보고 대기",zone="지역별",dungeon="던전별",selected="체크 목록"})[key]);G.UIButtonState(b,key==mode)
 end
 -- The left category list is separate: region groups everywhere except
 -- dungeon mode. Clicking a category opens that region/dungeon tab.
 local dungeonMode=mode=="dungeon"
 leftTitle:SetText(dungeonMode and "던전 퀘스트 분류" or "지역별 퀘스트 분류")
 local choices
 if dungeonMode then
  choices=G.SearchDungeons(search)
 else
  choices=G.SearchQuestZones(search)
  if #choices==0 and search~="" then choices=G.SearchQuestZones("") end
 end
 dungeonOffset=clampOffset(dungeonOffset,#choices,#dungeonRows)
 dungeonMaxScroll=math.max(0,#choices-#dungeonRows)
 setScrollbar(dungeonScrollbar,dungeonOffset,dungeonMaxScroll)
 for i,r in ipairs(dungeonRows) do
  local entry=choices[dungeonOffset+i]
  if entry then
   r:Show()
   r.dungeon=dungeonMode and entry.dungeon.id or nil
   r.zone=(not dungeonMode) and entry.map or nil
   local id=dungeonMode and entry.dungeon.id or entry.map
   local selected=dungeonMode and G.selection.dungeon==id or G.selection.zone==id
   local name=dungeonMode and entry.dungeon.name or entry.name
   local count=dungeonMode and #filteredQuests(entry.dungeon) or G.ZoneFactionCount(entry)
   r.text:SetText((selected and "|cffffd77b▶ |r" or "")..name.." |cff899aa3("..count..")|r")
   r.marker:SetColorTexture(selected and .43 or .25,selected and .77 or .39,selected and .94 or .45,1)
   r.fill:SetColorTexture(selected and .17 or .11,selected and .29 or .14,selected and .36 or .17,.92)
   if dungeonMode then
    local d=entry.dungeon
    r:SetScript("OnEnter",function(self)itemTooltip(self,{d.name,"레벨 "..(d.level or "미확인"),d.warning or ("관련 퀘스트 "..#d.ids.."건")})end)
   else
    local z=entry
    r:SetScript("OnEnter",function(self)itemTooltip(self,{z.name,"지역별 QuestieDB 분류",z.count.."개 등록 (검색 인덱스 누적)","클릭하면 미수락·완료를 포함한 지역 퀘스트를 확인합니다."})end)
   end
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.dungeon=nil;r.zone=nil;r:Hide() end
 end
 frame.left.pagination:SetText(#choices==0 and "분류 없음" or (#choices.."개 분류 · 휠 스크롤"))
 local chosenFaction=G.db.factionFilter or "auto"
 for key,b in pairs(factionButtons or {}) do
  b:SetText(key=="auto" and ("자동"..(G.player.faction=="Alliance" and "(얼)" or G.player.faction=="Horde" and "(호)" or "(?)")) or
    ({Alliance="얼라",Horde="호드",all="전체"})[key])
  G.UIButtonState(b,key==chosenFaction)
 end
 hideToggle:SetText(G.db.hideUnavailable and "제한 숨김 ON" or "제한 숨김 OFF");G.UIButtonState(hideToggle,G.db.hideUnavailable)
 incompleteToggle:SetText(G.db.onlyIncomplete and "완료 제외 ON" or "완료 제외 OFF");G.UIButtonState(incompleteToggle,G.db.onlyIncomplete)
 local ids,total,building
 local d=G.GetDungeon(G.selection.dungeon)
 if mode=="dungeon" then
  ids=filteredQuests(d);total=#ids;building=false
  if search~="" then
   local match=G.Clean(search)
   local filtered={}
   for _,id in ipairs(ids) do
    if tostring(id)==match or string.find(G.Clean(G.GetQuestName(id)),match,1,true) or
       (d and (string.find(G.Clean(d.name),match,1,true) or string.find(G.Clean(d.aliases),match,1,true))) then
     filtered[#filtered+1]=id
    end
   end
   ids=filtered;total=#ids
  end
 else
  ids,total,building=G.SearchQuestIds(mode,search)
 end
 -- Only current/checked/reward-ready lists need section headers.  Zone and
 -- dungeon searches already have their own left-hand category selection.
 local grouped=mode=="active" or mode=="turnin" or mode=="selected" or mode=="deferred" or (mode=="all" and search=="")
 local display=G.QuestListRows(ids,grouped)
 questOffset=clampOffset(questOffset,#display,#questRows)
 questMaxScroll=math.max(0,#display-#questRows)
 setScrollbar(questScrollbar,questOffset,questMaxScroll)
 frame.mid.pagination:SetText(#ids==0 and "퀘스트 없음" or (total.."개 퀘스트 · 휠 스크롤"))
 local suffix=building and " (목록 구성 중)" or ""
 if mode=="dungeon" then
  headerInfo:SetText(d and ((d.name).." · "..#d.ids.."건") or "왼쪽에서 던전을 선택하세요")
 elseif mode=="zone" then
  local selectedZone=G.questIndex and G.questIndex.zones and G.questIndex.zones[G.selection.zone or 0]
  headerInfo:SetText((search~="" and "지역/퀘스트 검색" or (selectedZone and selectedZone.name or "지역 선택")).." · "..total.."개"..suffix)
 elseif mode=="all" then
  headerInfo:SetText(search=="" and "이름·ID·지역 검색 / 검색 전에는 현재 퀘스트만 표시" or ("검색 결과 "..total.."건"..suffix))
 elseif mode=="active" then
  headerInfo:SetText("현재 수락한 퀘스트 "..total.."건 · 지역/던전 묶음")
 elseif mode=="turnin" then
  headerInfo:SetText("목표 완료 · NPC 보고 대기 "..total.."건")
 elseif mode=="deferred" then headerInfo:SetText("보류 퀘스트 "..total.."건 · 선택 후 보류 해제")
 else headerInfo:SetText("체크한 퀘스트 "..total.."건") end
 for i,r in ipairs(questRows) do
  local entry=display[questOffset+i]
  if entry and entry.kind=="header" then
   r.quest=nil;r:Show();r.checkbox:Hide();r.statusText:Hide()
   r.text:ClearAllPoints();r.text:SetPoint("LEFT",r,"LEFT",10,0);r.text:SetPoint("RIGHT",r,"RIGHT",-6,0);r.text:SetHeight(30)
   r.fill:SetColorTexture(.17,.20,.24,.95)
   r.text:SetText("|cffffce75"..(entry.isDungeon and "[던전] " or "[지역] ")..entry.label.."|r  |cff94a5b2("..entry.count..")|r")
   r.marker:SetColorTexture(.84,.58,.19,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label,entry.isDungeon and "던전 관련 퀘스트" or "지역별 진행 퀘스트",entry.count.."개 · 아래 퀘스트를 체크하여 동선에 포함하세요."})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  elseif entry then
   local id=entry.id
   r.quest=id;r:Show();r.checkbox:Show();r.statusText:Show()
   r.text:ClearAllPoints();r.text:SetPoint("TOPLEFT",r,"TOPLEFT",35,-1);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-6,-1);r.text:SetHeight(16)
   local state,code,reason=G.RouteAssessment(id)
   local name=G.GetQuestName(id)
   local col=DASH_COLOR[code] or "|cffffffff"
   local tag=entry.meta.level..(entry.meta.isDungeon and "D" or "")
   r.checkbox:SetChecked(G.db.selectedQuests[id]==true)
   local canCheck=G.db.selectedQuests[id]==true or (code~="done" and code~="superseded" and code~="blocked" and code~="low" and code~="deferred" and code~="dependentDeferred" and code~="unknown")
   if r.checkbox.SetEnabled then r.checkbox:SetEnabled(canCheck)
   elseif not canCheck then r.checkbox:Disable() else r.checkbox:Enable() end
   local factionTag=(mode=="all" or (G.db.factionFilter or "auto")~="auto") and G.QuestFactionTag(id) or ""
   r.text:SetText("|cffefd398"..tag.."|r "..factionTag..name)
   r.statusText:SetText(col..state.."|r"..(not grouped and entry.meta.label and ("  |cff92a0ad· "..entry.meta.label.."|r") or ""))
   local selected=G.selection.quest==id
   r.fill:SetColorTexture(selected and .17 or .11,selected and .29 or .14,selected and .36 or .17,.92)
   r.marker:SetColorTexture(selected and .43 or .25,selected and .77 or .40,selected and .94 or .45,1)
   local fullName=entry.meta.label
   r:SetScript("OnEnter",function(self)itemTooltip(self,{name,"퀘스트 레벨 "..entry.meta.level..(entry.meta.isDungeon and " · 던전" or "").." · "..fullName,"퀘스트 #"..id.." · 최소 수락 레벨 "..G.GetQuestMinLevel(id),state,reason or "왼쪽 체크박스로 통합 동선에 추가"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.quest=nil;r.checkbox:Hide();r.statusText:Hide();r:Hide() end
 end
 local readyCount=0
 for id,yes in pairs(G.db.selectedQuests or {}) do
  if yes and G.IsReadyToTurnIn(tonumber(id)) then readyCount=readyCount+1 end
 end
 selectedInfo:SetText("체크 "..G.SelectedCount().." · 보고 "..readyCount)
 local count=G.DeferredCount()
 deferredListButton:SetText("보류 목록 "..count);G.UIButtonState(deferredListButton,mode=="deferred")
 if count>0 then resumeAllButton:Enable() else resumeAllButton:Disable() end
 if G.DeferredBlocker(G.selection.quest) then resumeOneButton:Enable() else resumeOneButton:Disable() end
 local q=G.selection.quest
 if q then
  local desc=G.QuestDetails(q)
  local lines
  if desc.code=="done" then
   lines={"|cff77d993이미 보고 완료한 퀘스트입니다.|r",
     "이 완료 기록은 지역별/던전별/전체 검색에서 계속 확인할 수 있습니다.",
     "이미 완료된 퀘스트는 새로운 동선에서 제외됩니다."}
  else
   lines={"|cffffdc88"..(G.IsReadyToTurnIn(q) and "보고 NPC: " or "수락 NPC: ").."|r "..desc.starter,"|cffffdc88위치:|r "..(desc.coords or "확인 필요"),
     "|cffffdc88레벨:|r "..desc.level.."  |cffffdc88현재:|r "..desc.status}
  end
  if #desc.all>0 then lines[#lines+1]="\n|cffffd89b모두 완료할 선행 (AND):|r\n"..prereqString(desc.all) end
  if #desc.one>0 then lines[#lines+1]="\n|cffffd89b하나만 완료할 선행 (OR):|r\n"..prereqString(desc.one) end
  if #desc.all==0 and #desc.one==0 then lines[#lines+1]="\n|cff83ce90직접 선행 퀘스트 없음|r" end
  if desc.reason then
   lines[#lines+1]="\n|cffffa173동선 제외 사유:|r "..desc.reason
   if desc.blocker and desc.blocker.path and #desc.blocker.path>1 then
    local path={};for _,qid in ipairs(desc.blocker.path) do path[#path+1]=G.GetQuestName(qid) end
    lines[#lines+1]="선행 경로: "..table.concat(path," → ")
   end
   local blocker=G.DeferredBlocker(q)
   if blocker then lines[#lines+1]="|cffe6ab63[선택 보류 해제] 대상:|r "..G.GetQuestName(blocker) end
  elseif desc.code~="done" and not G.IsRouteSatisfied(q) then
   lines[#lines+1]="\n|cff8bddf3현재 조건에서 선행 포함 동선 생성 가능.|r"
  end
  if desc.note then lines[#lines+1]="\n|cffffa173주의:|r "..desc.note end
  detailHead:SetText(desc.name.."\n|cffacb5be#"..q.."   |r"..(DASH_COLOR[desc.code] or "")..desc.status.."|r")
  detailText(table.concat(lines,"\n"),q)
 else
  detailHead:SetText("퀘스트를 선택하면 선행 조건을 확인할 수 있습니다.")
  detailText("현재 퀘스트는 수락/진행/보고 대기만 표시합니다.\n\n지역별·던전별에는 미수락·이미 완료한 퀘스트도 남아 있습니다.\n\n미수락 퀘스트 여러 개 체크 → 통합 동선: 선행·수락·수행·보고 순서를 작성합니다.\n\n지도 직선은 참고용이며 실제 길과는 다릅니다.",nil)
 end
 local guide=G.db.guide
 local done,total=G.GuideProgress();footerProgress:SetProgress(done,total)
 local reviewing=G.GuideViewingHistory();footerNext:SetText(reviewing and "현재 단계" or "다음 확인");if G.CurrentStep() or reviewing then footerNext:Enable() else footerNext:Disable() end
 if total>0 and G.GuideViewIndex()>1 then footerPrev:Enable() else footerPrev:Disable() end
 if guide and guide.halted then
  guideInfo:SetText("|cffffc675진행 가능한 동선 없음|r · "..G.RouteScopeLabel(guide))
  guideNow:SetText(guide.statusReason or "수락 조건 확인 필요")
  guideNote:SetText("제외/보류 목록에서 사유 확인 → 보류 해제 또는 동선 초기화 · 실제 완료 기록 유지")
 elseif guide and guide.completed then
  guideInfo:SetText("|cff8be19e동선 완료|r")
  guideNow:SetText("현재 방문 가능한 단계가 모두 처리되었습니다.")
  guideNote:SetText("체크 목록은 그대로 유지됩니다. 필요하면 다른 퀘스트를 추가하고 다시 시작하세요.")
 elseif guide and guide.steps and #guide.steps>0 then
  local done,count=G.GuideProgress();local step=G.CurrentStep()
  local guideDungeon=G.GetDungeon(guide.dungeon)
  local title=G.RouteScopeLabel(guide)
  local multi=guide.optimization and (" · 가능 "..(guide.admittedCount or guide.optimization.selectedQuestCount or 0).."개 · 제외 "..#(guide.excluded or {}).."개") or ""
  guideInfo:SetText("|cffffdc89진행 "..done.."/"..count.."|r  ·  "..title..multi)
  guideNow:SetText(step and ("|cff8adff1다음:|r "..(guide.index or 1)..". "..step.title) or "|cff86d695모든 단계 완료 · 퀘스트 창 확인|r")
  local routeWarning=guide.optimization and guide.optimization.approximate and " · 여러 지역/좌표 미확인: 이동 시간 최적 보장 불가" or ""
  guideNote:SetText(step and ((step.note or "")..routeWarning) or "")
 else
  guideInfo:SetText("가이드 대기 중")
  guideNow:SetText("지역/던전/전체 검색 → 미수락 퀘스트 복수 체크 → 선행부터 통합 동선 → 이동 안내 HUD")
  guideNote:SetText("미확인 좌표는 임의 생성하지 않습니다. 필드 최단 길찾기는 ShortestPathForever 연동이 필요합니다.")
 end
 navStatus:SetText(G.guideFeedback or ("지도 길찾기: "..(G.navStatus or "대기")))
end
function G.ShowUI(show)
 buildUI();if not frame then return end
 if show==false or (show==nil and frame:IsShown()) then frame:Hide();return end
 G.UIFit(frame);frame:Show();G.UIRefresh()
end
function G.ToggleUI() G.ShowUI(nil) end

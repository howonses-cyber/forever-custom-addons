local addon, G = ...
local areas={
 [1]=1426,[3]=1418,[8]=1435,[10]=1431,[11]=1437,[12]=1429,[14]=1411,[15]=1445,
 [16]=1447,[17]=1413,[28]=1422,[33]=1434,[36]=1416,[38]=1432,[40]=1436,
 [41]=1430,[44]=1433,[45]=1417,[46]=1428,[47]=1425,[51]=1427,[85]=1420,
 [130]=1421,[139]=1423,[141]=1438,[148]=1439,[215]=1412,[267]=1424,[331]=1440,
 [357]=1444,[361]=1448,[400]=1441,[405]=1443,[406]=1442,[440]=1446,
 [490]=1449,[618]=1452,[1377]=1451,[1519]=1453,[1537]=1455,[1637]=1454,
 [1657]=1457,[1477]=1435,[978]=1446,[1584]=1428,[1583]=1428,[2557]=1444,
 [717]=1453,[718]=1413,[719]=1440,[721]=1426,[722]=1413,[796]=1420,
 [2100]=1443,[2057]=1422,[2017]=1423,[1581]=1436,[2437]=1454,
 [1517]=1418,[133]=1426,[1717]=1413,[209]=1421,
}
local function get(db,id,field)
 if type(db)~="table" then return nil end
 local getter=db.Get
 if type(getter)~="function" then return nil end
 local ok,value=pcall(getter,id,field)
 if ok and value~=0 then return value end
 return nil
end
G.DBGet=get
local mapCache={}
function G.AreaToUiMap(area)
 if not area or type(area)~="number" or area<=0 then return nil end
 if mapCache[area] then return mapCache[area] end
 local guessed=areas[area]
 if LibQuestieDB and LibQuestieDB.Support and type(LibQuestieDB.Support.Get)=="function" then
  local support=G.SafeCall(LibQuestieDB.Support.Get,"ZoneDB")
  local priv=support and support.private
  if priv then
   for _,key in ipairs({"areaIdToUiMapIdOverride","areaIdToUiMapId"}) do
    local lookup=priv[key]
    if type(lookup)=="table" then
     guessed=lookup[area] or guessed
    elseif type(lookup)=="string" and loadstring then
     -- QuestieDB publishes the mapping as a trusted, addon-supplied Lua literal.
     local decoder=loadstring(lookup)
     if decoder then
      local ok,t=pcall(decoder)
      if ok and type(t)=="table" then guessed=t[area] or guessed end
     end
    end
   end
  end
 end
 if guessed and C_Map and C_Map.GetMapInfo and not G.SafeCall(C_Map.GetMapInfo,guessed) then
  -- Keep the known mapping; a map API may not be loaded yet.
 end
 if guessed then mapCache[area]=guessed end
 return guessed
end
-- Quest zoneOrSort is a quest-category hint, not a precise target spawn.
-- Do not guess a coordinate from it; special indoor / mountain zones may
-- have no corresponding open-world UI map at all.
function G.QuestRegionHint(id)
 local area=tonumber(get(QuestDB,id,"zoneOrSort"))
 if not area or area<=0 then return nil end
 local known=G.knownQuestZones and G.knownQuestZones[area]
 if known then return known end
 for _,d in ipairs(G.dungeons or {}) do
  if d.area==area then return d.name end
 end
 local ui=G.AreaToUiMap(area)
 if ui and C_Map and C_Map.GetMapInfo then
  local info=G.SafeCall(C_Map.GetMapInfo,ui)
  if info and type(info.name)=="string" and info.name~="" then return info.name end
 end
 return nil
end
function G.QuestStageLandmark(id,kind)
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 return meta and meta.stageLandmarks and meta.stageLandmarks[kind] or nil
end
function G.GetQuestName(id)
 if not id then return "알 수 없는 퀘스트" end
 local localized=G.koQuestNames and G.koQuestNames[id]
 if localized then return localized end
 if G.nameCache[id] then return G.nameCache[id] end
 local name=get(QuestDB,id,"name")
 if type(name)~="string" or name=="" then return "퀘스트 #"..id.." (DB 확인 필요)" end
 -- If Korean localization is missing, do not fabricate a Korean translation.
 if GetLocale and GetLocale()=="koKR" and not string.find(name,"[\128-\255]") then
  name="한글 명칭 미확인 ("..name..")"
 end
 G.nameCache[id]=name
 return name
end
local verifiedMin={[8929]=58,[8930]=58,[8945]=58,[9015]=58,
 [8926]=58,[8931]=58,[8932]=58,[8933]=58,[8934]=58,[8935]=58,[8936]=58,[8937]=58,
 [8927]=58,[8938]=58,[8939]=58,[8940]=58,[8941]=58,[8942]=58,[8943]=58,[8944]=58}
local knownAlliance={[8929]=true,[8926]=true,[8931]=true,[8932]=true,[8933]=true,[8934]=true,[8935]=true,[8936]=true,[8937]=true}
local knownHorde={[8930]=true,[8927]=true,[8938]=true,[8939]=true,[8940]=true,[8941]=true,[8942]=true,[8943]=true,[8944]=true}
local verifiedClass={[8926]=11,[8931]=3,[8932]=8,[8933]=2,[8934]=5,[8935]=4,[8936]=9,[8937]=1,
 [8927]=11,[8938]=3,[8939]=8,[8940]=5,[8941]=4,[8942]=7,[8943]=9,[8944]=1}
function G.GetQuestMinLevel(id) return math.max(tonumber(get(QuestDB,id,"requiredLevel")) or 0,verifiedMin[id] or 0) end
function G.GetQuestLevel(id) return tonumber(get(QuestDB,id,"questLevel")) or 0 end
-- QuestieDB contract 3 publishes masks for Forever's extra races 95/96.
-- Classic raceId-1 arithmetic is incorrect for those high-ID race masks.
local fallbackRaceMasks={ [1]=1,[2]=2,[3]=4,[4]=8,[5]=16,[6]=32,[7]=64,[8]=128,
 [9]=256,[10]=512,[11]=1024,[22]=2097152,[24]=8388608,[25]=16777216,
 [26]=33554432,[95]=4294967296,[96]=8589934592 }
local fallbackFactionMasks={ Alliance=4294967373,Horde=8589934770 }
local function maskOverlaps(one,two)
 one=tonumber(one);two=tonumber(two)
 if not one or not two or one<=0 or two<=0 then return false end
 while one>0 and two>0 do
  if one%2==1 and two%2==1 then return true end
  one=math.floor(one/2);two=math.floor(two/2)
 end
 return false
end
local function factionMasks()
 local enum=LibQuestieDB and LibQuestieDB.Enum
 return enum and enum.factionRaceMasks or fallbackFactionMasks
end
local function playerRaceMask()
 local raceId=G.GetPlayerRaceId()
 local enum=LibQuestieDB and LibQuestieDB.Enum
 return raceId and ((enum and enum.raceMaskById and enum.raceMaskById[raceId]) or fallbackRaceMasks[raceId])
end
local function normalizeFaction(value)
 if value=="Alliance" or value=="얼라이언스" then return "Alliance" end
 if value=="Horde" or value=="호드" then return "Horde" end
 return nil
end
G.NormalizeFaction=normalizeFaction
function G.GetPlayerRaceId()
 if type(UnitRace)~="function" then return nil end
 local _,__,raceId=UnitRace("player")
 return tonumber(raceId)
end
function G.QuestFaction(id)
 id=tonumber(id)
 if not id then return "Unknown" end
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local explicit=special and normalizeFaction(special.onlyFaction)
 if explicit then return explicit end
 local mask=tonumber(get(QuestDB,id,"requiredRaces"))
 if not mask or mask<=0 then return "Any" end -- No faction restriction published.
 local masks=factionMasks()
 local alliance=maskOverlaps(mask,masks.Alliance)
 local horde=maskOverlaps(mask,masks.Horde)
 if alliance and horde then return "Both" end
 if alliance then return "Alliance" end
 if horde then return "Horde" end
 return "Unknown" -- Do not invent a faction for an unrecognized mask.
end
function G.IsClassAllowedQuest(id)
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local classes=(special and special.classMask) or tonumber(get(QuestDB,id,"requiredClasses"))
 if not classes and verifiedClass[id] then classes=2^(verifiedClass[id]-1) end
 if classes and classes>0 then
  if not G.player.classId or G.player.classId<=0 then return false end
  if not maskOverlaps(classes,2^(G.player.classId-1)) then return false end
 end
 return true
end
function G.IsEligibleQuest(id)
 id=tonumber(id)
 if not id then return false end
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local explicit=special and normalizeFaction(special.onlyFaction)
 if explicit and G.player.faction~=explicit then return false end
 if not G.IsClassAllowedQuest(id) then return false end
 local allowed=tonumber(get(QuestDB,id,"requiredRaces"))
 if not allowed then
  if knownAlliance[id] and G.player.faction~="Alliance" then return false end
  if knownHorde[id] and G.player.faction~="Horde" then return false end
 end
 if allowed and allowed>0 then
  local ownMask=playerRaceMask()
  if not ownMask then return false end -- Missing race data must not fake eligibility.
  return maskOverlaps(allowed,ownMask)
 end
 return true
end
function G.QuestPrerequisite(id)
 local oneOf=get(QuestDB,id,"preQuestSingle")
 local allOf=get(QuestDB,id,"preQuestGroup")
 allOf=type(allOf)=="table" and allOf or {};oneOf=type(oneOf)=="table" and oneOf or {}
 -- Verified minimum chain requirements for the two Anthion referral quests.
 -- Do not overwrite an installed DB's newer Forever-specific alternatives.
 if #allOf==0 and #oneOf==0 then
  if id==8929 then oneOf={8926,8931,8932,8933,8934,8935,8936,8937}
  elseif id==8930 then oneOf={8927,8938,8939,8940,8941,8942,8943,8944} end
 end
 return allOf,oneOf
end
-- Only positive, unambiguous mandatory prerequisites are evidence of a
-- passed stage. Never infer completion from mere sequence/nextQuest or
-- from one of several alternatives, negative IDs or exclusive groups.
local reverseMandatory,activeEvidence,evidenceMemo={}, {}, {}
function G.MandatoryRoutePrereqs(id)
 local all,one=G.QuestPrerequisite(id)
 local result,seen={},{}
 local function add(q)
  q=tonumber(q)
  if not q or q<=0 or q==id or seen[q] then return end
  local alternatives=get(QuestDB,q,"exclusiveTo")
  if type(alternatives)=="table" and next(alternatives) then return end
  seen[q]=true;result[#result+1]=q
 end
 for _,q in ipairs(all) do add(q) end
 if #one==1 then add(one[1]) end
 return result
end
function G.ResetRouteDependencyIndex()
 reverseMandatory={};evidenceMemo={}
 if G.RefreshRouteEvidence then G.RefreshRouteEvidence() end
end
function G.IndexRouteDependencies(id)
 for _,pre in ipairs(G.MandatoryRoutePrereqs(id)) do
  local children=reverseMandatory[pre]
  if not children then children={};reverseMandatory[pre]=children end
  children[id]=true
  evidenceMemo[pre]=nil
 end
end
function G.RefreshRouteEvidence()
 local previous=activeEvidence
 activeEvidence={};evidenceMemo={}
 if not G.Ready() then return false end
 local expanded={}
 local function walk(id,root,depth)
  if depth>25 or expanded[id] then return end
  expanded[id]=true
  for _,pre in ipairs(G.MandatoryRoutePrereqs(id)) do
   if not G.IsInLog(pre) then
    activeEvidence[pre]=root
    walk(pre,root,depth+1)
   end
  end
 end
 -- Accepted and same-session rewarded descendants are direct observations.
 for id in pairs(G.activeQuests or {}) do walk(id,id,0) end
 for id in pairs(G.sessionTurnins or {}) do if G.IsCompleted(id) then walk(id,id,0) end end
 for id,root in pairs(activeEvidence) do if previous[id]~=root then return true end end
 for id in pairs(previous) do if not activeEvidence[id] then return true end end
 return false
end
function G.RoutePrereqEvidence(id)
 id=tonumber(id)
 if not id or G.IsInLog(id) or not G.Ready() then return nil end
 if activeEvidence[id] then return activeEvidence[id] end
 if evidenceMemo[id]~=nil then return evidenceMemo[id] or nil end
 -- The incremental quest index permits lookup of already rewarded downstream
 -- quests even after reload, without scanning the entire database per click.
 local visited={[id]=true}
 local queue={{id=id,depth=0}};local i=1;local found
 while i<=#queue and i<=128 and not found do
  local node=queue[i];i=i+1
  local children=reverseMandatory[node.id] or {}
  -- A forward link alone is NOT proof; validate the child's mandatory edge.
  local linked=tonumber(get(QuestDB,node.id,"nextQuestInChain"))
  local candidates={}
  for child in pairs(children) do candidates[child]=true end
  if linked and linked>0 and not candidates[linked] then
   for _,pre in ipairs(G.MandatoryRoutePrereqs(linked)) do
    if pre==node.id then candidates[linked]=true;break end
   end
  end
  for child in pairs(candidates) do
   if not visited[child] then
    visited[child]=true
    if G.IsInLog(child) or G.IsCompleted(child) then found=child;break end
    if node.depth<24 and #queue<128 then queue[#queue+1]={id=child,depth=node.depth+1} end
   end
  end
 end
 evidenceMemo[id]=found or false
 return found
end
function G.RouteExclusionReason(id)
 id=tonumber(id)
 if not id or G.IsInLog(id) or G.IsCompleted(id) then return nil end
 for _,successor in ipairs((G.routePickupBlockers and G.routePickupBlockers[id]) or {}) do
  if G.IsInLog(successor) or G.IsCompleted(successor) then
   return "후속 퀘스트 "..G.GetQuestName(successor).." 진행/완료로 선행 수락 불가",successor
  end
 end
 local root=G.RoutePrereqEvidence(id)
 if root then return "필수 후속 퀘스트 "..G.GetQuestName(root).." 진행/완료 확인",root end
 return nil
end
function G.IsRouteSatisfied(id)
 return G.IsCompleted(id) or G.RouteExclusionReason(id)~=nil
end
function G.IsRoutePrereqSatisfied(id)
 return G.IsCompleted(id) or G.RoutePrereqEvidence(id)~=nil
end
local function activeOrRewarded(id)
 return type(id)=="number" and id>0 and (G.IsInLog(id) or G.IsCompleted(id))
end
local skillNames={ [164]={"Blacksmithing","대장기술"},[165]={"Leatherworking","가죽세공"},[171]={"Alchemy","연금술"},[182]={"Herbalism","약초채집"},[185]={"Cooking","요리"},[186]={"Mining","채광"},[197]={"Tailoring","재봉술"},[202]={"Engineering","기계공학"},[333]={"Enchanting","마법부여"},[356]={"Fishing","낚시"},[129]={"First Aid","응급치료"} }
function G.RouteSkillRank(id)
 local names=skillNames[id]
 local prof=C_TradeSkillUI and C_TradeSkillUI.GetProfessionInfoBySkillLineID
 local v=G.SafeCall(prof,id)
 if type(v)=="table" then
  local rank=tonumber(v.skillLevel or v.currentSkillLevel)
  if rank then return rank end
 end
 -- Classic and Forever skill panel: name, isHeader, isExpanded, skillRank.
 -- Do not expand/collapse the player's skill panel or treat a missing API as 0.
 if type(GetNumSkillLines)=="function" and type(GetSkillLineInfo)=="function" then
  local n=tonumber(G.SafeCall(GetNumSkillLines)) or 0
  for i=1,n do
   local ok,name,header,expanded,rank=pcall(GetSkillLineInfo,i)
   if ok and (not header or header==0) and names then
    for _,alias in ipairs(names) do if name==alias then return tonumber(rank) end end
   end
  end
 end
 return nil
end
local function skillLabel(id)
 local t=skillNames[id];return t and t[2] or ("전문기술 #"..tostring(id))
end
local function reputationValue(id)
 local d=G.SafeCall(C_Reputation and C_Reputation.GetFactionDataByID,id)
 if type(d)=="table" then return tonumber(d.currentStanding),d.name end
 if type(GetFactionInfoByID)=="function" then
  local ok,name,_,_,_,_,earned=pcall(GetFactionInfoByID,id)
  if ok and name then return tonumber(earned),name end
 end
end
local function knownSpell(id)
 for _,fn in ipairs({IsPlayerSpell or false,IsSpellKnown or false,C_SpellBook and C_SpellBook.IsSpellKnown or false}) do
  local v=G.SafeCall(fn,id)
  if v==true or v==1 then return true end
 end
 return false
end
function G.RouteHardBlock(id)
 id=tonumber(id)
 if not id then return "퀘스트 ID 확인 필요","unknown" end
 -- The actual quest log always wins over stale or missing pickup constraints.
 if G.IsInLog(id) or G.IsCompleted(id) then return nil end
 if not G.Ready() or not get(QuestDB,id,"name") then return "퀘스트 DB 정보 없음 (#"..id..")","unknown" end
 if not G.IsEligibleQuest(id) then return "현재 진영/종족/직업 제한","blocked" end
 local lv=G.GetQuestMinLevel(id);local max=tonumber(get(QuestDB,id,"requiredMaxLevel"))
 local player=tonumber(G.player.level) or 0
 if lv>player then return "레벨 부족 ("..player.." / 최소 "..lv..")","low" end
 if max and max>0 and player>max then return "최대 수락 레벨 초과 ("..max..")","blocked" end
 local skill=get(QuestDB,id,"requiredSkill")
 if id==4083 and (type(skill)~="table" or not tonumber(skill[1]) or tonumber(skill[1])==0) then skill={186,230} end
 if type(skill)=="table" and tonumber(skill[1]) and tonumber(skill[1])>0 then
  local sid=tonumber(skill[1]);local req=tonumber(skill[2]) or 0;local rank=G.RouteSkillRank(sid)
  if not rank or rank<req then return skillLabel(sid).." "..req.." 필요 (현재 "..(rank and tostring(rank) or "확인 불가")..")","blocked" end
 end
 local ranks=get(QuestDB,id,"requiredRanks")
 -- Rank requirements describe profession rank/spell, not ordinary skill points.
 -- Defer unverified rank combinations rather than applying the wrong API.
 if type(ranks)=="table" and next(ranks) then
  return "전문기술 등급 조건 확인 필요","blocked"
 end
 for _,field in ipairs({"requiredMinRep","requiredMaxRep"}) do
  local pair=get(QuestDB,id,field)
  if type(pair)=="table" and tonumber(pair[1]) and tonumber(pair[1])>0 and tonumber(pair[2]) then
   local value,name=reputationValue(tonumber(pair[1]));local need=tonumber(pair[2]);local minimum=field=="requiredMinRep"
   if not value or (minimum and value<need) or (not minimum and value>=need) then
    return (name or ("평판 #"..pair[1])).." "..(minimum and "최소 " or "상한 ")..need.." 조건 (현재 "..(value and tostring(value) or "확인 불가")..")","blocked"
   end
  end
 end
 local spell=tonumber(get(QuestDB,id,"requiredSpell"))
 if spell and spell~=0 and (spell<0 or not knownSpell(spell)) then return "필요 기술/주문 #"..spell.." 확인 필요","blocked" end
 local spec=tonumber(get(QuestDB,id,"requiredSpecialization"))
 if spec and spec>0 and not knownSpell(spec) then return "전문화 #"..spec.." 조건 확인 필요","blocked" end
 local parent=tonumber(get(QuestDB,id,"parentQuest"))
 if parent and parent>0 and not G.IsInLog(parent) then return "활성 선행 필요: "..G.GetQuestName(parent),"locked" end
 local starting=tonumber(get(QuestDB,id,"availableStartingWith"))
 if starting and starting>0 and not activeOrRewarded(starting) then return "선행 활성/완료 필요: "..G.GetQuestName(starting),"locked" end
 local untilId=tonumber(get(QuestDB,id,"availableUntilCompleted"))
 if untilId and untilId>0 and G.IsCompleted(untilId) then return "선행 진행 종료: "..G.GetQuestName(untilId),"blocked" end
 local disabled=tonumber(get(QuestDB,id,"disabledByQuest"))
 if disabled and disabled>0 and G.IsInLog(disabled) then return "동시 수락 불가: "..G.GetQuestName(disabled),"blocked" end
 for _,field in ipairs({"nextQuestInChain","breadcrumbForQuestId"}) do
  local following=tonumber(get(QuestDB,id,field))
  if activeOrRewarded(following) then return "후속 진행으로 수락 불가: "..G.GetQuestName(following),"blocked" end
 end
 local exclusive=get(QuestDB,id,"exclusiveTo")
 if type(exclusive)=="table" then
  for _,other in ipairs(exclusive) do
   if activeOrRewarded(tonumber(other)) then return "택일 퀘스트 진행/완료: "..G.GetQuestName(other),"blocked" end
  end
 end
 return nil
end
local function prereqGroups(id)
 local all,one=G.QuestPrerequisite(id)
 local groups={}
 if #one>0 then
  local g={}
  for _,entry in ipairs(one) do
   local q=tonumber(entry);if q and q~=0 then g[#g+1]={id=math.abs(q),exact=q<0} end
  end
  groups[#groups+1]=g
 end
 for _,entry in ipairs(all) do
  local q=tonumber(entry)
  if q and q~=0 then
   local group={{id=math.abs(q),exact=q<0}}
   -- Only positive grouped requirements permit exclusive alternatives.
   if q>0 then
    local ex=get(QuestDB,q,"exclusiveTo")
    if type(ex)=="table" then for _,alt in ipairs(ex) do if type(alt)=="number" and alt>0 then group[#group+1]={id=alt,exact=true} end end end
   end
   groups[#groups+1]=group
  end
 end
 return groups
end
local function fulfilled(c)
 return c.exact and G.IsCompleted(c.id) or (not c.exact and G.IsRoutePrereqSatisfied(c.id))
end
-- A root is admitted transactionally: no orphan prerequisites from a blocked
-- branch, no missing nodes dropped, no cyclic dependency treated as fulfilled.
function G.ResolveRouteRequirements(root,context)
 context=context or {};context.memo=context.memo or {};local memo=context.memo
 local deferred=G.db and G.db.deferredQuests or {}
 local function resolve(id,stack,depth)
  if depth>32 or stack[id] then return nil,"선행 연결 순환/깊이 제한 #"..id,{id=id,kind="cycle"} end
  if G.IsRouteSatisfied(id) then return nil,"선행 수락 불가: "..G.GetQuestName(id),{id=id,kind="unavailable"} end
  if deferred[id] then return nil,"사용자 보류: "..G.GetQuestName(id),{id=id,kind="deferred"} end
  local hard,code=G.RouteHardBlock(id)
  if hard then return nil,hard,{id=id,kind=code or "blocked"} end
  if memo[id] then return memo[id] end
  stack[id]=true
  local graph={[id]={}}
  if not G.IsInLog(id) then
   for _,group in ipairs(prereqGroups(id)) do
    local satisfied=false
    for _,c in ipairs(group) do if fulfilled(c) then satisfied=true;break end end
    if not satisfied then
     local candidates={};local uniq={}
     for _,c in ipairs(group) do if not uniq[c.id] then candidates[#candidates+1]=c;uniq[c.id]=true end end
     table.sort(candidates,function(a,b)
      local aa,bb=G.IsInLog(a.id),G.IsInLog(b.id)
      if aa~=bb then return aa end
      local ra,rb=context.reserved and context.reserved[a.id]~=nil,context.reserved and context.reserved[b.id]~=nil
      if ra~=rb then return ra end
      return a.id<b.id
     end)
     local winner,branch,why,blocker,alternatives
     for _,c in ipairs(candidates) do
      local nextGraph,err,info=resolve(c.id,stack,depth+1)
      if nextGraph then winner=c.id;branch=nextGraph;break end
      local explanation=G.GetQuestName(c.id).." · "..tostring(err)
      alternatives=alternatives or {};alternatives[#alternatives+1]=explanation
      -- Prefer a user-resolvable postponement if no OR alternative is viable.
      if not why or (info and info.kind=="deferred" and (not blocker or blocker.kind~="deferred")) then
       why=explanation;blocker=info
      end
     end
     if not winner then
      stack[id]=nil
      local info=blocker or {id=id,kind="unknown"}
      local path={id};for _,qid in ipairs(info.path or {info.id}) do path[#path+1]=qid end
      return nil,"선행 불가: "..(why or "선행 DB 확인 필요"),{id=info.id,kind=info.kind,path=path,alternatives=alternatives}
     end
     graph[id][winner]=true
     for q,parents in pairs(branch) do
      graph[q]=graph[q] or {}
      for pre in pairs(parents) do graph[q][pre]=true end
     end
    end
   end
  end
  stack[id]=nil;memo[id]=graph;return graph
 end
 return resolve(tonumber(root) or 0,{},0)
end
function G.RouteAssessment(id)
 local state,code=G.QuestState(id)
 if code=="done" or code=="superseded" or not G.Ready() then return state,code end
 local graph,why,info=G.ResolveRouteRequirements(id,{})
 if not graph then
  local blocker=info and info.id or id
  if info and info.kind=="deferred" then
   if blocker==id then return "사용자 보류","deferred",why,info end
   return "선행 보류: "..G.GetQuestName(blocker),"dependentDeferred",why,info
  end
  if blocker==id then return state=="선행 필요" and "수락 조건 확인 필요" or why or state,code=="low" and "low" or "blocked",why,info end
  return "선행 불가: "..G.GetQuestName(blocker),"blocked",why,info
 end
 local guide=G.db and G.db.guide
 for _,entry in ipairs(guide and guide.excluded or {}) do
  if entry.id==id then
   if entry.kind=="conflict" then return "택일 조건 충돌","blocked",entry.reason,entry end
   if entry.kind=="notReady" and guide.turninOnly and not G.IsReadyToTurnIn(id) then return "보고 대기 아님","blocked",entry.reason,entry end
  end
 end
 if code=="locked" then return "선행 포함 가능","locked" end
 return state,code
end
function G.GetMissingPrereqs(id)
 if not G.Ready() or G.IsInLog(id) or G.IsCompleted(id) then return {} end
 local missing,unique={},{}
 for _,group in ipairs(prereqGroups(id)) do
  local satisfied=false
  for _,c in ipairs(group) do if fulfilled(c) then satisfied=true;break end end
  if not satisfied then
   local chosen
   for _,c in ipairs(group) do if G.IsInLog(c.id) then chosen=c.id;break end end
   if not chosen then for _,c in ipairs(group) do if not G.RouteHardBlock(c.id) then chosen=c.id;break end end end
   chosen=chosen or (group[1] and group[1].id)
   if chosen and not unique[chosen] then unique[chosen]=true;missing[#missing+1]=chosen end
  end
 end
 return missing
end
-- Only the active destination is permitted to request real navigation.
function G.CurrentAcceptanceBlock(step)
 if not step or not step.quest or step.kind~="accept" or G.IsInLog(step.quest) or G.IsRouteSatisfied(step.quest) then return nil end
 local hard=G.RouteHardBlock(step.quest);if hard then return hard end
 local missing=G.GetMissingPrereqs(step.quest)
 if #missing>0 then return "선행 완료 전 수락 불가: "..G.GetQuestName(missing[1]) end
end
local function dungeonForArea(area)
 for _,d in ipairs(G.dungeons or {}) do if d.area and d.area==tonumber(area) then return d end end
end
local function actualZone(area)
 local d=dungeonForArea(area);if d then return d.name,d end
 local known=G.knownQuestZones and G.knownQuestZones[tonumber(area)]
 if known then return known,nil,G.AreaToUiMap(tonumber(area)) end
 local map=G.AreaToUiMap(tonumber(area))
 local info=map and G.SafeCall(C_Map and C_Map.GetMapInfo,map)
 return info and info.name or nil,nil,map
end
-- An instance area's coordinates may be sentinel or instance-relative. Never
-- project them onto the exterior zone ID used by older area mappings.
local function entityArea(db,id)
 local spawns=get(db,id,"spawns")
 if type(spawns)~="table" then return nil end
 local keys={};for area in pairs(spawns) do if tonumber(area) then keys[#keys+1]=tonumber(area) end end
 table.sort(keys)
 local current=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local first
 for _,area in ipairs(keys) do
  local name,d,map=actualZone(area)
  if name then
   local r={zone=name,dungeon=d,map=map}
   if map and map==current then return r end
   first=first or r
  end
 end
 return first
end
function G.QuestObjectiveText(id)
 local lines=get(QuestDB,id,"objectivesText")
 if type(lines)=="string" then return lines end
 if type(lines)=="table" then
  local out={};for _,v in ipairs(lines) do if type(v)=="string" and v~="" then out[#out+1]=v end end
  if #out>0 then return table.concat(out," / ") end
 end
end
local function entityLandmark(db,id,target,instruction)
 local place=entityArea(db,id)
 if not place then return nil end
 return {zone=place.zone,site=target,target=target,instruction=instruction,approxArea=true,map=place.map,
  dungeonId=place.dungeon and place.dungeon.id,approach=place.dungeon and place.dungeon.entrance}
end
local function fromSpawns(entityDB,entityID,preferredMap)
 local spawns=get(entityDB,entityID,"spawns")
 if type(spawns)~="table" then return nil end
 local choice
 for area,points in pairs(spawns) do
  local mapId=not dungeonForArea(area) and G.AreaToUiMap(tonumber(area))
  if mapId and type(points)=="table" then
   for _,coords in ipairs(points) do
    if type(coords)=="table" and type(coords[1])=="number" and type(coords[2])=="number"
       and coords[1]>=0 and coords[1]<=100 and coords[2]>=0 and coords[2]<=100 then
     local candidate={map=mapId,x=coords[1]/100,y=coords[2]/100}
     if mapId==preferredMap then return candidate end
     if not choice then choice=candidate end
    end
   end
  end
 end
 return choice
end

-- Returns named objective locations grounded in current QuestieDB drop/spawn data.
-- These are candidate spawn locations, never a guarantee of drops or a terrain route.
function G.QuestObjectivePoints(id)
 local verified=G.verifiedObjectives and G.verifiedObjectives[id]
 if verified then return verified end
 local objectives=get(QuestDB,id,"objectives")
 if type(objectives)~="table" then return {} end
 local preferred=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local results={}
 local function add(kind,entityId,point,name,landmark)
  results[#results+1]={kind=kind,id=entityId,point=point,title=name or ("대상 #"..tostring(entityId)),landmark=landmark}
 end
 local function spawn(db,entityId)
  local p=fromSpawns(db,entityId,preferred)
  if p then p.name=get(db,entityId,"name") or "목표 위치" end
  return p
 end
 -- Creature objectives.
 for _,entry in ipairs(type(objectives[1])=="table" and objectives[1] or {}) do
  local npcId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if npcId then
   local name=get(NpcDB,npcId,"name") or "처치 대상"
   local p=spawn(NpcDB,npcId)
   add("creature",npcId,p,name,not p and entityLandmark(NpcDB,npcId,name,name.."을(를) 찾아 처치하고 퀘스트 목표 수량을 확인하세요.") or nil)
  end
 end
 -- Game-object objectives.
 for _,entry in ipairs(type(objectives[2])=="table" and objectives[2] or {}) do
  local objectId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if objectId then
   local name=get(ObjectDB,objectId,"name") or "상호작용 대상"
   local p=spawn(ObjectDB,objectId)
   add("object",objectId,p,name,not p and entityLandmark(ObjectDB,objectId,name,name.."와 상호작용해 퀘스트 목표를 수행하세요.") or nil)
  end
 end
 -- Item objectives: look up actual NPC/object drop sources, not invented coordinates.
 for _,entry in ipairs(type(objectives[3])=="table" and objectives[3] or {}) do
  local itemId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if itemId then
   local p,landmark
   local itemName=get(ItemDB,itemId,"name") or ("아이템 #"..itemId)
   for _,spec in ipairs({{db=NpcDB,ids=get(ItemDB,itemId,"npcDrops")},
                          {db=ObjectDB,ids=get(ItemDB,itemId,"objectDrops")}}) do
    if type(spec.ids)=="table" then
     for _,mobId in ipairs(spec.ids) do
      local sourceId=tonumber(mobId)
      local candidate=sourceId and spawn(spec.db,math.abs(sourceId))
      if sourceId and not landmark then
       local sourceName=get(spec.db,math.abs(sourceId),"name")
       if sourceName then landmark=entityLandmark(spec.db,math.abs(sourceId),sourceName,sourceName.."에서 "..itemName.."을(를) 획득하세요. 퀘스트 로그의 필요 수량을 확인하세요.") end
      end
      if candidate then
       if not p then p=candidate end
       if candidate.map==preferred then p=candidate;break end
      end
     end
    end
    if p and p.map==preferred then break end
   end
   add("item",itemId,p,itemName,not p and landmark or nil)
  end
 end
 return results
end
-- NPC/object names can exist in QuestieDB even when no coordinate was stored.
function G.QuestContactName(id,stage)
 if stage~="accept" and stage~="turnin" then return nil end
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 for _,source in ipairs({{db=NpcDB,list=row.npc or row.NPC or row[1],kind="npc"},
                          {db=ObjectDB,list=row.object or row.Object or row[2],kind="object"},
                          {db=ItemDB,list=stage=="accept" and (row.item or row.Item or row[3]),kind="item"}}) do
  if type(source.list)=="table" then
   for _,num in ipairs(source.list) do
    local entityID=tonumber(num)
    local name=entityID and get(source.db,entityID,"name")
    if type(name)=="string" and name~="" then return name,entityID,source.db,source.kind end
   end
  end
 end
 return nil
end
function G.QuestContactLandmark(id,stage)
 local name,eid,db,kind=G.QuestContactName(id,stage)
 if not name then return nil end
 if kind=="item" then
  for _,spec in ipairs({{db=NpcDB,ids=get(ItemDB,eid,"npcDrops")},{db=ObjectDB,ids=get(ItemDB,eid,"objectDrops")}}) do
   for _,source in ipairs(type(spec.ids)=="table" and spec.ids or {}) do
    local sid=tonumber(source);local sn=sid and get(spec.db,math.abs(sid),"name")
    if sn then
     local lm=entityLandmark(spec.db,math.abs(sid),sn,sn.."에서 "..name.."을(를) 얻고 가방에서 사용해 퀘스트를 수락하세요.")
     if lm then return lm end
    end
   end
  end
  return {zone="시작 아이템",site=name,target=name,instruction="가방에 있는 시작 아이템을 사용해 퀘스트를 수락하세요. 미보유 시 아이템 획득처 확인이 필요합니다.",approxArea=true}
 end
 local action=kind=="object" and (name.."와 상호작용해 "..(stage=="accept" and "수락" or "보고").."하세요.") or (name.."에게 "..(stage=="accept" and "수락" or "보고").."하세요.")
 return entityLandmark(db,eid,name,action)
end

-- An instance NPC may be present in finishedBy but have no numeric spawn.
-- Return a trustworthy indoor destination; never substitute entrance coordinates
-- for an indoor hand-in, and never mistake a missing point for a missing NPC.
function G.QuestInsideInfo(id,stage)
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 local hint=meta and meta.insideStages and meta.insideStages[stage]
 local dungeon
 if hint then
  dungeon=G.GetDungeon(hint.dungeon)
 else
  if stage~="accept" and stage~="turnin" then return nil end
  if G.QuestPoint and G.QuestPoint(id,stage) then return nil end
  local name,eid,db,kind=G.QuestContactName(id,stage)
  local place=eid and entityArea(db,eid)
  if place and place.dungeon then
   dungeon=place.dungeon;hint={room="던전 내부",npcId=eid,npcName=name,contactType=kind}
  end
 end
 if not dungeon or not hint then return nil end
 return {dungeon=dungeon.name,dungeonId=dungeon.id,entrance=dungeon.entrance,
  npcId=hint.npcId,npcName=hint.npcName or (hint.npcId and get(NpcDB,hint.npcId,"name")) or G.QuestContactName(id,stage) or "퀘스트 목표",
  room=hint.room or "던전 내부",followup=hint.followup,instruction=hint.instruction,contactType=hint.contactType or "npc",verified=hint.verified}
end

local function questGiver(id,stage)
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 local preferredMap=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local providers={{db=NpcDB,list=row.npc or row.NPC or row[1]},
                  {db=ObjectDB,list=row.object or row.Object or row[2]}}
 local best
 for _,provider in ipairs(providers) do
  if type(provider.list)=="table" then
   for _,entry in ipairs(provider.list) do
    local idNum=tonumber(entry)
    if idNum then
     local point=fromSpawns(provider.db,idNum,preferredMap)
     if point then
      point.name=get(provider.db,idNum,"name") or "NPC/오브젝트 #"..idNum
      if point.map==preferredMap then return point end
      if not best then best=point end
     end
    end
   end
  end
 end
 return best
end
function G.QuestPoint(id,stage)
 local meta=G.specialQuestMeta[id]
 if meta and (meta.inside or (meta.insideStages and meta.insideStages[stage]) or (meta.stageLandmarks and meta.stageLandmarks[stage])) then return nil end
 if stage=="accept" or stage=="turnin" then
  local overrides=stage=="accept" and G.pickupOverrides or G.turninOverrides
  local override=overrides and overrides[id]
  if override then return {map=override.map,x=override.x,y=override.y,name=override.name or (G.GetQuestName(id).." "..stage)} end
 end
 if stage=="objective" then
  local trigger=get(QuestDB,id,"triggerEnd")
  if type(trigger)=="table" and type(trigger[2])=="table" then
   for area,locations in pairs(trigger[2]) do
    local m=not dungeonForArea(area) and G.AreaToUiMap(tonumber(area))
    if m and type(locations)=="table" and type(locations[1])=="table" then
     local p=locations[1]
     if type(p[1])=="number" and type(p[2])=="number" and p[1]>=0 and p[1]<=100 and p[2]>=0 and p[2]<=100 then
      return {map=m,x=p[1]/100,y=p[2]/100,name=G.GetQuestName(id).." 목표"}
     end
    end
   end
  end
  return nil -- Do not synthesize coordinates for drop/kill objectives.
 end
 return questGiver(id,stage)
end
function G.QuestGiverName(id,stage)
 local point=G.QuestPoint(id,stage)
 if point and point.name then return point.name end
 local inside=G.QuestInsideInfo(id,stage)
 local lm=G.QuestStageLandmark(id,stage) or G.QuestContactLandmark(id,stage)
 if lm then return lm.target or lm.site end
 if inside then return inside.npcName.." ("..inside.dungeon.." · "..inside.room..")" end
 return G.QuestContactName(id,stage) or
    ((G.specialQuestMeta[id] and G.specialQuestMeta[id].inside) and "던전 내부" or "위치 데이터 확인 필요")
end
function G.QuestDetails(id)
 local all,one=G.QuestPrerequisite(id)
 local state,code,reason,blocker=G.RouteAssessment(id)
 local stage=G.IsReadyToTurnIn(id) and "turnin" or "accept"
 local point=G.QuestPoint(id,stage)
 local localeName=point and C_Map and C_Map.GetMapInfo and G.SafeCall(C_Map.GetMapInfo,point.map)
 local place=point and ((localeName and localeName.name) or ("지도 #"..point.map)) or nil
 local indoor=G.QuestInsideInfo(id,stage)
 local coords=point and string.format("%s %.1f, %.1f",place,point.x*100,point.y*100) or
   (indoor and (indoor.dungeon.." · "..indoor.room) or nil)
 if not coords then local lm=G.QuestStageLandmark(id,stage) or G.QuestContactLandmark(id,stage);coords=lm and (lm.zone.." · "..lm.site) or "실제 방문 위치 자료 부족" end
 return {id=id,name=G.GetQuestName(id),level=G.GetQuestMinLevel(id),status=state,code=code,
   all=all,one=one,reason=reason,blocker=blocker,starter=G.QuestGiverName(id,stage),coords=coords,
   note=G.specialQuestMeta[id] and G.specialQuestMeta[id].note}
end

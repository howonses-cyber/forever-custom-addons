local addon,G=...
-- Only post-hook the native EUI detail callback; do not replace EUI methods.
-- Reserve one own row while the EUI detail window is open, and restore its
-- exact recognized scroll anchor on hide. Unknown layouts fail closed.
local installed,button,window,currentId,reservation
local function combat() return InCombatLockdown and InCombatLockdown() end
local function currentQuest(id)
 id=tonumber(id)
 return id and id>0 and G.IsInLog(id) and id or nil
end
local function geometryMatches(r,offset)
 if not r or not r.scroll or not r.scroll.GetNumPoints or r.scroll:GetNumPoints()~=#r.points then return false end
 for i,original in ipairs(r.points) do
  local a,rel,rp,x,y=r.scroll:GetPoint(i)
  local expectedY=original[5]+(i==r.targetIndex and offset or 0)
  if a~=original[1] or rel~=original[2] or rp~=original[3] or x~=original[4] or y~=expectedY then return false end
 end
 return true
end
local function layout(r,offset)
 if not r or not r.scroll then return end
 r.scroll:ClearAllPoints()
 for i,original in ipairs(r.points) do
  r.scroll:SetPoint(original[1],original[2],original[3],original[4],original[5]+(i==r.targetIndex and offset or 0))
 end
end
local function isReserved(r) return geometryMatches(r,30) end
local function restore(r)
 if isReserved(r) then layout(r,0) end
end
local function findAnchor(win)
 if not win or type(win.GetChildren)~="function" then return nil end
 for _,child in ipairs({win:GetChildren()}) do
  if child:GetObjectType()=="ScrollFrame" and child:GetNumPoints()==2 then
   local points={}
   for n=1,child:GetNumPoints() do points[n]={child:GetPoint(n)} end
   for n,point in ipairs(points) do
    local a,rel,rp,x,y=point[1],point[2],point[3],point[4],point[5]
    if a=="BOTTOMRIGHT" and rel==win and rp=="BOTTOMRIGHT" and
       type(x)=="number" and type(y)=="number" and y>=54 and y<=64 then
     return {scroll=child,points=points,targetIndex=n}
    end
   end
  end
 end
 return nil
end
local function attach(win)
 if combat() or not win or not win.focus or not win.untrack or not win.share or not win.abandon then return false end
 if button and window==win then
  if isReserved(reservation) then return true end
  local nextAnchor=findAnchor(win)
  if not nextAnchor then button:Hide();return false end
  reservation=nextAnchor
  layout(reservation,30)
  return true
 end
 local r=findAnchor(win)
 if not r or type(G.UIButton)~="function" then return false end
 if button then restore(reservation);button:Hide() end
 local b=G.UIButton(win,G.displayName or "포에버 퀘스트 가이드",math.max(120,win:GetWidth()-28),24,function()
  if combat() then G.Print("전투가 끝난 뒤 포에버 퀘스트 가이드를 눌러주세요.");return end
  local id=window==win and win:IsShown() and currentQuest(currentId)
  if not id then G.Print("퀘스트 상세창을 다시 열어주세요.");return end
  if G.StartQuickGuide(id) then win:Hide() end
 end,"primary")
 b:SetPoint("BOTTOMLEFT",win,"BOTTOMLEFT",14,54)
 b:SetPoint("BOTTOMRIGHT",win,"BOTTOMRIGHT",-14,54)
 layout(r,30)
 b:SetScript("OnEnter",function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,"ANCHOR_TOP")
  GameTooltip:AddLine(G.displayName or "포에버 퀘스트 가이드",.9,.75,.4)
  GameTooltip:AddLine("선택한 퀘스트의 수행 또는 보고부터 시작합니다.",1,1,1,true)
  GameTooltip:AddLine("기존 통합 동선은 보관됩니다.",.8,.85,.9,true)
  GameTooltip:Show()
 end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 win:HookScript("OnHide",function()
  if window==win then restore(reservation);currentId=nil;b:Hide() end
 end)
 button,window,reservation=b,win,r
 return true
end
function G.RefreshEUIQuestBridge()
 local win=_G.EUI_QuestDetails
 if not win or not win:IsShown() then
  currentId=nil
  if button then button:Hide() end
  return false
 end
 local id=currentQuest(currentId)
 if not id then if button then button:Hide() end;return false end
 if not attach(win) then return false end
 button:SetText(G.IsReadyToTurnIn(id) and ((G.displayName or "포에버 퀘스트 가이드").." · 보고") or (G.displayName or "포에버 퀘스트 가이드"))
 button:Show()
 return true
end
function G.InstallEUIQuestBridge()
 local tracker=_G.EllesmereUIQuestTracker
 if type(tracker)~="table" or type(tracker.ShowQuestDetails)~="function" or type(hooksecurefunc)~="function" then return false end
 if installed==tracker then return true end
 local ok=pcall(hooksecurefunc,tracker,"ShowQuestDetails",function(id)
  local win=_G.EUI_QuestDetails
  currentId=win and win:IsShown() and currentQuest(id) or nil
  G.RefreshEUIQuestBridge()
 end)
 if ok then installed=tracker end
 return ok
end

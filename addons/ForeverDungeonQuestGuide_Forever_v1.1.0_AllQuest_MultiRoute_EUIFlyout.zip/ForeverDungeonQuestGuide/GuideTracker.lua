local addon,G=...
local hud,caption,stepText,noteText,navLabel
local function control(parent,text,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 b:SetText(text);b:SetScript("OnClick",fn)
 return b
end
local function text(parent,x,y,w,h,template)
 local t=parent:CreateFontString(nil,"OVERLAY",template)
 t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 t:SetSize(w,h);t:SetJustifyH("LEFT");t:SetJustifyV("MIDDLE")
 return t
end
local function initialize()
 if hud or not UIParent then return end
 hud=CreateFrame("Frame","ForeverDungeonQuestGuideHUD",UIParent)
 hud:SetSize(475,151)
 hud:SetPoint("TOP",UIParent,"TOP",(G.db.hudPosition and G.db.hudPosition.x)or 0,(G.db.hudPosition and G.db.hudPosition.y)or -125)
 hud:SetClampedToScreen(true)
 hud:SetFrameStrata("HIGH");hud:SetMovable(true);hud:EnableMouse(true);hud:RegisterForDrag("LeftButton")
 local back=hud:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(.07,.09,.12,.93)
 local stripe=hud:CreateTexture(nil,"BORDER");stripe:SetPoint("TOPLEFT",0,-1);stripe:SetPoint("TOPRIGHT",0,-1);stripe:SetHeight(2);stripe:SetColorTexture(.91,.69,.31,1)
 hud:SetScript("OnDragStart",function(self) if not(InCombatLockdown and InCombatLockdown()) then self:StartMoving()end end)
 hud:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then
   local topOffset=(y+(self:GetHeight()/2))-(uy+(UIParent:GetHeight()/2))
   G.db.hudPosition={x=x-ux,y=topOffset}
  end
 end)
 caption=text(hud,12,-7,420,20,"GameFontNormal")
 stepText=text(hud,12,-30,451,46,"GameFontHighlight")
 noteText=text(hud,12,-76,451,20,"GameFontHighlightSmall")
 navLabel=text(hud,12,-100,451,17,"GameFontHighlightSmall")
 control(hud,"다음 완료 ▶",12,-119,117,26,function()G.NextGuide(1,true)end)
 control(hud,"지도",136,-119,80,26,function()
  local st=G.CurrentStep()
  if st and st.point then G.Navigate(st.point,true)
  else G.Print("이 단계의 지도 좌표를 확인할 수 없습니다.") end
  G.NotifyDataChange()
 end)
 control(hud,"전체 동선",222,-119,88,26,function()G.TogglePlanWindow()end)
 control(hud,"가이드 창",317,-119,90,26,function()G.ShowUI(true)end)
 control(hud,"×",414,-119,48,26,function()G.db.hudHidden=true;hud:Hide()end)
 hud:Hide()
end
function G.HUDRefresh()
 if not G.db or not G.db.manualProgress then return end
 initialize()
 if not hud then return end
 local g=G.db.guide
 if not g or not g.steps or #g.steps==0 or G.db.hudHidden then hud:Hide();return end
 hud:Show()
 local done,total=G.GuideProgress()
 local dungeon=G.GetDungeon(g.dungeon)
 local name=(g.mode=="selected") and "선택한 퀘스트 통합 동선" or (dungeon and dungeon.name or "던전")
 caption:SetText("|cffffdc85"..name.."|r   |cffb9c1c9"..done.." / "..total.."단계|r")
 local st=G.CurrentStep()
 if st then
  stepText:SetText("|cff78ddff"..(g.index or 1)..".|r "..st.title)
  noteText:SetText(st.note or "")
 else
  stepText:SetText("|cff86df92모든 준비 단계 완료!|r")
  noteText:SetText("던전 입장 후 기존 던전 내비게이터를 함께 사용하세요.")
 end
 navLabel:SetText("|cff96a7b5"..(G.navStatus or "경로 미설정").."|r")
end
function G.ToggleHUD()
 if not G.db or not G.db.manualProgress then return end
 G.db.hudHidden=not G.db.hudHidden
 G.HUDRefresh()
end

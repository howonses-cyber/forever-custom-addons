local addon,G=...
local parent,pins,segments={},{},{}
local color={accept={0.25,0.85,0.96},objective={0.85,0.73,0.31},turnin={0.43,0.88,0.48},entrance={1,0.55,0.15},inside={0.6,0.6,0.6}}
local function mapCanvas()
 local frame=_G.WorldMapFrame
 if not frame or not frame.IsShown or not frame:IsShown() then return nil,nil end
 local mapId=frame.GetMapID and frame:GetMapID()
 local scroll=frame.ScrollContainer
 local canvas=scroll and (scroll.Child or (scroll.GetCanvas and scroll:GetCanvas()))
 if not canvas or type(canvas.GetWidth)~="function" then return nil,nil end
 return canvas,mapId
end
local function ensurePin(i,canvas)
 if pins[i] then return pins[i] end
 local b=CreateFrame("Button",nil,canvas)
 b:SetSize(22,22)
 if b.SetFrameStrata then b:SetFrameStrata("HIGH") end
 local back=b:CreateTexture(nil,"BACKGROUND")
 back:SetAllPoints();back:SetColorTexture(.07,.08,.10,.87)
 local rim=b:CreateTexture(nil,"BORDER")
 rim:SetPoint("TOPLEFT",-1,1);rim:SetPoint("BOTTOMRIGHT",1,-1)
 rim:SetColorTexture(.70,.56,.28,.80)
 local core=b:CreateTexture(nil,"ARTWORK")
 core:SetPoint("TOPLEFT",2,-2);core:SetPoint("BOTTOMRIGHT",-2,2)
 b.core=core
 local label=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 label:SetPoint("CENTER",0,0)
 b.label=label
 b:SetScript("OnEnter",function(self)
  if GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_RIGHT");GameTooltip:SetText(self.tooltip or "경유 지점");GameTooltip:AddLine("방문 순서 마커 (직선 지형 길이 아님)",0.8,0.8,0.8);GameTooltip:Show() end
 end)
 b:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 b:SetScript("OnClick",function(self)
  local g=G.db.guide
  if g and g.steps and self.guideIndex then g.index=self.guideIndex;G.ActivateGuideStep(false);G.NotifyDataChange() end
 end)
 pins[i]=b
 return b
end
local function drawSegment(n,canvas,width,height,a,b)
 if not a or not b or a.map~=b.map then return false end
 local x1,y1=width*a.x,-height*a.y
 local x2,y2=width*b.x,-height*b.y
 local dx,dy=x2-x1,y2-y1
 local len=math.sqrt(dx*dx+dy*dy)
 if len<1 then return false end
 local tex=segments[n]
 if not tex then
  tex=canvas:CreateTexture(nil,"ARTWORK")
  tex:SetTexture("Interface\\Buttons\\WHITE8X8")
  segments[n]=tex
 end
 if tex:GetParent()~=canvas then tex:SetParent(canvas) end
 if type(tex.SetRotation)~="function" then tex:Hide();return false end
 tex:ClearAllPoints();tex:SetPoint("CENTER",canvas,"TOPLEFT",(x1+x2)/2,(y1+y2)/2)
 tex:SetSize(len,2)
 tex:SetVertexColor(.91,.69,.3,.63)
 local angle
 if math.atan2 then
  angle=math.atan2(dy,dx)
 elseif dx==0 then
  angle=dy>=0 and math.pi/2 or -math.pi/2
 else
  angle=math.atan(dy/dx)
  if dx<0 then angle=angle+math.pi end
 end
 tex:SetRotation(angle)
 tex:Show()
 return true
end
function G.RefreshMapPins()
 for _,pin in ipairs(pins) do pin:Hide() end
 for _,seg in ipairs(segments) do seg:Hide() end
 local guide=G.db and G.db.guide
 if not guide or not guide.steps then return end
 local canvas,mapId=mapCanvas()
 if not canvas or not mapId then return end
 local width,height=canvas:GetWidth(),canvas:GetHeight()
 if width<1 or height<1 then return end
 local n=0
 local segmentCount=0
 local prev=nil
 for index,step in ipairs(guide.steps) do
  local p=step.point
  if p and p.map==mapId and p.x and p.y and n<35 then
   n=n+1
   local pin=ensurePin(n,canvas)
   if pin:GetParent()~=canvas then pin:SetParent(canvas) end
   pin:ClearAllPoints()
   pin:SetPoint("CENTER",canvas,"TOPLEFT",width*p.x,-height*p.y)
   local c=color[step.kind] or color.objective
   pin.core:SetColorTexture(c[1],c[2],c[3],.94)
   pin.label:SetText(index==guide.index and ">" or tostring(index))
   pin.tooltip=step.title
   pin.guideIndex=index
   pin:Show()
   if prev and segmentCount<34 and guide.mode=="selected" then
    local ok=drawSegment(segmentCount+1,canvas,width,height,prev,p)
    if ok then segmentCount=segmentCount+1 end
   end
   prev=p
  elseif p and p.map~=mapId then
   -- Never connect unrelated maps with misleading straight lines.
   prev=nil
  end
 end
end

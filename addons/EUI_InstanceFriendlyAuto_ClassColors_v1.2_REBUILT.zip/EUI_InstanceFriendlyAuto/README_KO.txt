EUI Instance Friendly Auto - Class Colors
WoW Forever 1.60.1 / Interface 16001
Rebuilt edition 1.2 (not the original v1.1 binary)

INSTALL
1. Exit WoW completely.
2. Delete any older folder named EUI_InstanceFriendlyAuto from:
   World of Warcraft\_forever_\Interface\AddOns\
3. Extract this ZIP directly into the AddOns directory.
4. Final structure must be:
   ...\_forever_\Interface\AddOns\EUI_InstanceFriendlyAuto\EUI_InstanceFriendlyAuto.toc
5. In character select > AddOns, enable EUI Instance Friendly Auto.
6. Launch and type /eif sync.

COMMANDS
/eif names   = Dungeon/raid friendly PLAYER nameplates: show name only, class colors.
/eif hide    = Dungeon/raid friendly PLAYER nameplates: hide entirely.
/eif sync    = Reapply according to current zone.
/eif off     = Disable override and restore saved outside settings.
/eif status  = Show current mode and location.

BEHAVIOR
- Applies only in party or raid instances, not everywhere in the world.
- Captures/restores 3 FRIENDLY PLAYER nameplate CVars.
- Leaves enemy nameplates and all files of EllesmereUI unchanged.
- Does not affect friendly NPC nameplates; class-color names target players only.
- The WoW client may restrict some nameplate changes in combat.
- In instances the default Blizzard UI may still render protected nameplates.
- If friendly nameplate 'Simplified' mode is active, disable it in Blizzard's nameplate settings if class-color-only names do not display correctly.
- The World of Warcraft client has NOT been available for real gameplay testing here.

CVAR DETAILS
nameplateShowFriendlyPlayers
nameplateShowOnlyNameForFriendlyPlayerUnits
nameplateUseClassColorForFriendlyPlayerUnitNames

If this is a NEW install while already inside an instance, the first captured
outside preference may be an instance value. Leave the instance and manually
set your preferred EUI outside nameplate style, then /eif sync before re-entering.

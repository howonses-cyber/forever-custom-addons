-- EUI Instance Friendly Auto - Class Colors (WoW Forever 1.60.1)
-- Rebuilt replacement, not a byte-for-byte copy of the earlier v1.1 ZIP.
-- Does not edit or depend on EllesmereUI code. Does not modify enemy CVars.

local addon = CreateFrame("Frame")
local C_FRIENDLY = "nameplateShowFriendlyPlayers"
local C_ONLY_NAME = "nameplateShowOnlyNameForFriendlyPlayerUnits"
local C_CLASS_COLOR = "nameplateUseClassColorForFriendlyPlayerUnitNames"
local TRACKED = { C_FRIENDLY, C_ONLY_NAME, C_CLASS_COLOR }

local db
local activeInInstance = false
local applying = false
local retryOnLeavingCombat = false
local lastErrors = {}

local function Print(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff74c0fc[EIF]|r " .. tostring(message))
    end
end

local function Get(name)
    local getter = (C_CVar and C_CVar.GetCVar) or GetCVar
    if not getter then return nil end
    local ok, value = pcall(getter, name)
    if ok then return value end
    return nil
end

local function Set(name, value)
    if value == nil then return end
    local setter = (C_CVar and C_CVar.SetCVar) or SetCVar
    if not setter then
        lastErrors[name] = "SetCVar is unavailable"
        return
    end
    -- Only write when different to avoid excessive CVAR_UPDATE events.
    if tostring(Get(name)) == tostring(value) then return end
    local ok, err = pcall(setter, name, tostring(value))
    if not ok then lastErrors[name] = tostring(err) end
end

local function InsideDungeon()
    local _, kind = GetInstanceInfo()
    return kind == "party" or kind == "raid"
end

local function CaptureOutside()
    if not db or db.inInstance then return end
    db.outsideCVars = db.outsideCVars or {}
    for _, key in ipairs(TRACKED) do
        local value = Get(key)
        if value ~= nil then db.outsideCVars[key] = tostring(value) end
    end
end

local function ApplyNames()
    applying = true
    -- The client itself renders the names (including in protected instances).
    Set(C_FRIENDLY, "1")
    Set(C_ONLY_NAME, "1")
    Set(C_CLASS_COLOR, "1")
    applying = false
end

local function ApplyHide()
    applying = true
    Set(C_FRIENDLY, "0")
    applying = false
end

local function RestoreOutside()
    if not db or not db.outsideCVars then return end
    applying = true
    for _, key in ipairs(TRACKED) do
        Set(key, db.outsideCVars[key])
    end
    applying = false
end

local function ApplyForCurrentZone()
    if not db then return end
    local inside = InsideDungeon()
    if InCombatLockdown and InCombatLockdown() then
        -- Changing protected nameplate-related configuration can be restricted.
        retryOnLeavingCombat = true
        return
    end
    if inside then
        if not db.inInstance then
            -- Capture the last non-instance configuration if available.
            -- Initial launch inside an instance may have no outside baseline.
            if not activeInInstance and not db.outsideCVars then
                db.outsideCVars = {}
                for _, key in ipairs(TRACKED) do
                    db.outsideCVars[key] = Get(key)
                end
            end
            db.inInstance = true
        end
        activeInInstance = true
        if db.mode == "names" then
            ApplyNames()
        elseif db.mode == "hide" then
            ApplyHide()
        else
            RestoreOutside()
        end
    else
        if db.inInstance then
            RestoreOutside()
            db.inInstance = false
        end
        activeInInstance = false
        CaptureOutside()
    end
end

local function SyncWithDelayedRecheck()
    ApplyForCurrentZone()
    -- Other UI addons may finish their profile/zone setup shortly after the
    -- zoning event. Reapply once, not in a permanent timer loop.
    if C_Timer and C_Timer.After then
        C_Timer.After(0.5, ApplyForCurrentZone)
        C_Timer.After(2.0, ApplyForCurrentZone)
    end
end

SLASH_EIFRIENDLYAUTO1 = "/eif"
SlashCmdList.EIFRIENDLYAUTO = function(input)
    if not db then
        Print("Not initialized. Try /reload.")
        return
    end
    local command = (input or ""):match("^%s*(%S+)")
    command = command and command:lower() or ""
    if command == "names" or command == "on" then
        db.mode = "names"
        SyncWithDelayedRecheck()
        Print("Mode: names only + class color (in dungeons/raids).")
    elseif command == "hide" then
        db.mode = "hide"
        SyncWithDelayedRecheck()
        Print("Mode: hide friendly PLAYER nameplates in instances.")
    elseif command == "off" then
        db.mode = "off"
        SyncWithDelayedRecheck()
        Print("Instance override disabled. Outside settings restored.")
    elseif command == "sync" then
        SyncWithDelayedRecheck()
        Print("Refreshed for current zone (" .. (InsideDungeon() and "instance" or "outside") .. ").")
    elseif command == "status" then
        Print("Mode: " .. tostring(db.mode) .. "; location: " .. (InsideDungeon() and "instance" or "outside") .. ".")
        if next(lastErrors) then Print("Some CVar writes failed. Check /console scriptErrors 1.") end
    else
        Print("/eif names - name only + class color in instances")
        Print("/eif hide - hide friendly player nameplates in instances")
        Print("/eif off - disable override; /eif sync - reapply; /eif status")
    end
end

addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("PLAYER_ENTERING_WORLD")
addon:RegisterEvent("ZONE_CHANGED_NEW_AREA")
addon:RegisterEvent("PLAYER_REGEN_ENABLED")
addon:RegisterEvent("CVAR_UPDATE")
addon:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_LOGIN" then
        EIFriendlyAutoDB = EIFriendlyAutoDB or {}
        db = EIFriendlyAutoDB
        if db.mode ~= "names" and db.mode ~= "hide" and db.mode ~= "off" then
            db.mode = "names"
        end
        if not InsideDungeon() and not db.inInstance then CaptureOutside() end
        SyncWithDelayedRecheck()
    elseif not db then
        return
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        SyncWithDelayedRecheck()
    elseif event == "PLAYER_REGEN_ENABLED" then
        if retryOnLeavingCombat then
            retryOnLeavingCombat = false
            SyncWithDelayedRecheck()
        end
    elseif event == "CVAR_UPDATE" and not applying and not db.inInstance then
        -- Honor new EUI/player preferences made while outside an instance.
        local changed = tostring(arg1 or ""):lower()
        for _, key in ipairs(TRACKED) do
            if key:lower() == changed then
                CaptureOutside()
                break
            end
        end
    end
end)

-- Forever Dungeon Navigator: ONE selected route instead of the upstream spaghetti.
-- Do not change upstream route data, editor, pins or own-marker handling.
local _, N = ...
local layer, cover, parent, strokes, count, sourceTag, targetTag, signature = nil,nil,nil,{},0,nil,nil,nil
local MAX_STROKES=1400

local function clear()
    if cover then cover:Hide() end
    for i=1,count do if strokes[i] then strokes[i]:Hide() end end
    count=0
    if sourceTag then sourceTag:Hide() end
    if targetTag then targetTag:Hide() end
    signature=nil
end

local function ensure(view)
    if cover and parent==view.layer then return end
    if cover then cover:Hide() end
    parent=view.layer
    cover=CreateFrame("Frame",nil,parent)
    cover:SetAllPoints(parent)
    cover:EnableMouse(false)
    cover:SetFrameLevel(parent:GetFrameLevel()+3)
    strokes={};count=0;signature=nil
    sourceTag=cover:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    targetTag=cover:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    sourceTag:SetText("|cff52ffb0● 출발|r")
    targetTag:SetText("|cffffd25a◎ 목표|r")
    for _,t in ipairs({sourceTag,targetTag}) do
        t:SetShadowColor(0,0,0,1)
        t:SetShadowOffset(1,-1)
    end
end

local function stroke(x1,y1,x2,y2,thick,r,g,b,alpha)
    if count>=MAX_STROKES then return end
    count=count+1
    local line=strokes[count]
    if not line then line=cover:CreateLine(nil,"OVERLAY"); strokes[count]=line end
    line:SetStartPoint("TOPLEFT",cover,x1,-y1)
    line:SetEndPoint("TOPLEFT",cover,x2,-y2)
    line:SetThickness(thick)
    line:SetColorTexture(r,g,b,alpha or 1)
    line:Show()
end

local function canvasPoint(view,x,y)
    if type(view.ToCanvas)=="function" then return view:ToCanvas(x,y) end
    return x*1002,y*668 -- fallback for an older original map
end
local function segment(a,b,view)
    local x1,y1=canvasPoint(view,a.x,a.y)
    local x2,y2=canvasPoint(view,b.x,b.y)
    local s=math.max(0.10,view.scale or 1)
    -- Dark halo separates the chosen route from artwork; mint line is the actual path.
    stroke(x1,y1,x2,y2,9/s,0.025,0.035,0.045,0.94)
    stroke(x1,y1,x2,y2,5/s,0.13,1.00,0.71,1)
    local dx,dy=x2-x1,y2-y1
    local dist=math.sqrt(dx*dx+dy*dy)
    if dist>40/s then
        -- Small directional chevron, drawn along the recorded route (not across walls).
        local ux,uy=dx/dist,dy/dist
        local px,py=x1+dx*.53,y1+dy*.53
        local back=9/s;local wing=6/s
        stroke(px-ux*back-uy*wing,py-uy*back+ux*wing,px,py,2.8/s,1.00,.80,.22,1)
        stroke(px-ux*back+uy*wing,py-uy*back-ux*wing,px,py,2.8/s,1.00,.80,.22,1)
    end
end

local function place(tag,view,p)
    if not tag then return end
    if not p or p.floor~=view.floor then tag:Hide();return end
    local x,y=canvasPoint(view,p.x,p.y)
    tag:ClearAllPoints()
    tag:SetPoint("BOTTOM",cover,"TOPLEFT",x,-y+6/(view.scale or 1))
    tag:Show()
end

function N.ApplyMapClutter(view)
    local d=N.FDR()
    view=view or (d and d.MapView)
    if not view or not view.lines then return end
    local _,key=N.Route()
    local editor=d and d.Editor
    local editing=editor and editor.IsEditing and editor:IsEditing(view.key,view.route)
    local focused=not editing and N.db and N.db.focusOnly and N.db.showOverlay and
        N.solution and view.key==key and #N.solution.edges>0
    -- Only upstream path line objects are hidden. All boss pins, room markers,
    -- map artwork and editor tools remain untouched. Turn original back on when no solution.
    local alpha=focused and 0 or 1
    for i=1,(view.numLines or 0) do
        local line=view.lines[i]
        if line then line:SetAlpha(alpha) end
    end
    for i=1,(view.numDots or 0) do
        local dot=view.dots and view.dots[i]
        if dot then dot:SetAlpha(1) end
    end
end

function N.IsMapVisible()
    local d=N.FDR()
    local f=d and d.Window and d.Window.GetFrame and d.Window:GetFrame()
    return f and f:IsShown()
end

function N.RefreshOverlay()
    local d=N.FDR()
    local view=d and d.MapView
    if not view or not view.layer or not view.frame or not view.frame:IsShown() or
       not N.db or not N.db.showOverlay then
        clear()
        N.ApplyMapClutter(view)
        if N.RefreshBossBanner then N.RefreshBossBanner() end
        return
    end
    if N.dirty then N.Compute() end
    local sol=N.solution
    local _,key=N.Route()
    N.ApplyMapClutter(view)
    if N.RefreshBossBanner then N.RefreshBossBanner() end
    if not sol or view.key~=key or not view.floor then clear();return end
    ensure(view)
    local sig=table.concat({tostring(sol),tostring(view.floor),tostring(view.turn),
        string.format("%.5f",view.scale or 1),tostring(N.db.focusOnly)},"|")
    cover:Show()
    if sig==signature then return end
    signature=sig
    for i=1,count do strokes[i]:Hide() end
    count=0
    for _,e in ipairs(sol.edges) do
        if e.floor==view.floor and e.kind~="floor" then
            segment({x=e.x1,y=e.y1},{x=e.x2,y=e.y2},view)
        end
    end
    place(sourceTag,view,sol.source)
    place(targetTag,view,sol.target)
end

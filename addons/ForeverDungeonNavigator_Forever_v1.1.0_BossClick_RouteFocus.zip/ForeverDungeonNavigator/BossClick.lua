-- Native Forever Dungeon Routes boss-list integration.
-- Normal click selects a navigation goal; Ctrl-click retains the original done action.
-- Original addon files, editor, and saved progress are never overwritten.
local _, N = ...
local hooked
local rowCache=setmetatable({}, {__mode="k"})
local pinCache=setmetatable({}, {__mode="k"})
local banner,caption,detail,toggle
local lastMap
local scanning=false

local function modifier(name)
    local fn=_G[name]
    return type(fn)=="function" and fn() or false
end
local function currentKey(d)
    if d and d.Window and d.Window.GetShownKey then
        return d.Window:GetShownKey()
    end
    return d and d.MapView and d.MapView.key
end
local function isEditing(d,key)
    local e=d and d.Editor
    local route=d and key and d:GetActiveRoute(key)
    return e and type(e.IsEditing)=="function" and e:IsEditing(key,route)
end
local function bossSelected(key,index)
    local t=N.target
    return t and t.key==key and t.kind=="boss" and t.index==index
end

local function applySelected(d)
    local key=currentKey(d)
    for row in pairs(rowCache) do
        if row._fdnavSelected then
            row._fdnavSelected:SetShown(bossSelected(key,row.index) and row:IsShown() or false)
        end
    end
    local view=d and d.MapView
    for pin in pairs(pinCache) do
        if pin._fdnavSelected then
            pin._fdnavSelected:SetShown(view and view.key==key and
                bossSelected(key,pin.index) and pin:IsShown() or false)
        end
    end
end

local function bindRow(row)
    if rowCache[row] then return end
    if type(row.GetScript)~="function" or type(row.SetScript)~="function" then return end
    local originalClick=row:GetScript("OnClick")
    if type(originalClick)~="function" then return end
    local originalEnter=row:GetScript("OnEnter")
    row._fdnavSelected=row:CreateTexture(nil,"BACKGROUND",nil,2)
    row._fdnavSelected:SetAllPoints(row)
    row._fdnavSelected:SetColorTexture(0.12,0.62,0.42,0.30)
    row._fdnavSelected:Hide()
    rowCache[row]=true
    row:SetScript("OnClick",function(self,button)
        local d=N.FDR()
        local key=currentKey(d)
        -- Keep editor operations and the original explicit shortcuts intact.
        if button~="LeftButton" or modifier("IsShiftKeyDown") or modifier("IsAltKeyDown") or
           modifier("IsControlKeyDown") or not key or isEditing(d,key) then
            return originalClick(self,button)
        end
        if N.SetTarget("boss",self.index,key) then
            N.Print("목표 지정: "..tostring(self.stopName).." | Ctrl+클릭: 처치 표시, Shift+클릭: 위치만 보기")
            applySelected(d)
        end
    end)
    row:SetScript("OnEnter",function(self)
        if originalEnter then originalEnter(self) end
        if GameTooltip and not isEditing(N.FDR(),currentKey(N.FDR())) then
            GameTooltip:ClearLines()
            GameTooltip:SetText(tostring(self.stopName or "목표"),1,.86,.4)
            if self.note and self.note~="" then
                GameTooltip:AddLine(self.note,1,1,1,true)
            end
            GameTooltip:AddLine("클릭: 이 보스까지 길찾기",.22,1,.72)
            GameTooltip:AddLine("Ctrl+클릭: 처치 표시/해제",.85,.84,.75)
            GameTooltip:AddLine("Shift+클릭 또는 우클릭: 위치 확대",.75,.75,.75)
            GameTooltip:Show()
        end
    end)
end

-- Numbered boss pins on the map also select goals; the original editor is exempt.
function N.BindBossPins()
    local d=N.FDR()
    local view=d and d.MapView
    if not view or not view.stopPins then return end
    for i=1,(view.numStops or 0) do
        local pin=view.stopPins[i]
        if pin and pin.index and pin.stop and not pinCache[pin] and
           type(pin.GetScript)=="function" and type(pin.SetScript)=="function" then
            local originalClick=pin:GetScript("OnClick")
            local originalEnter=pin:GetScript("OnEnter")
            if type(originalClick)=="function" then
                local glow=pin:CreateTexture(nil,"BACKGROUND",nil,3)
                glow:SetTexture("Interface\\AddOns\\ForeverDungeonRoutes\\media\\glow")
                glow:SetSize(50,50)
                glow:SetPoint("CENTER",pin,"CENTER",0,0)
                glow:SetBlendMode("ADD")
                glow:SetVertexColor(0.19,1.00,0.65,0.82)
                glow:Hide()
                pin._fdnavSelected=glow
                pinCache[pin]=true
                pin:SetScript("OnClick",function(self,button)
                    if self.dragged or button~="LeftButton" or
                       modifier("IsShiftKeyDown") or modifier("IsAltKeyDown") or
                       modifier("IsControlKeyDown") or isEditing(d,view.key) then
                        return originalClick(self,button)
                    end
                    if N.SetTarget("boss",self.index,view.key) then
                        N.Print("목표 지정: "..tostring(d:GetStopName(self.stop)).." | Ctrl+클릭: 처치 표시")
                        applySelected(d)
                    end
                end)
                pin:SetScript("OnEnter",function(self)
                    if originalEnter then originalEnter(self) end
                    if GameTooltip and not isEditing(d,view.key) then
                        GameTooltip:AddLine("클릭: 이 보스까지 길찾기",.22,1,.72)
                        GameTooltip:AddLine("Ctrl+클릭: 처치 표시/해제",.85,.84,.75)
                        GameTooltip:Show()
                    end
                end)
            end
        end
    end
    applySelected(d)
end

-- The upstream list frames are private locals; discover existing row buttons by
-- their stable public frame fields rather than copying/replacing upstream Window.lua.
function N.BindBossRows()
    if scanning then return end
    local d=N.FDR()
    local frame=d and d.Window and d.Window.GetFrame and d.Window:GetFrame()
    if not frame or not frame:IsShown() then return end
    scanning=true
    local key=currentKey(d)
    if key and key~=N.activeKey then N.SetDungeon(key) end
    local todo={frame};local n=0
    while #todo>0 and n<600 do
        local f=table.remove(todo)
        n=n+1
        if f and f.index and f.stopName and f.Badge and f.Check and f.Name then
            bindRow(f)
        end
        if f and type(f.GetChildren)=="function" then
            local children={f:GetChildren()}
            for _,child in ipairs(children) do todo[#todo+1]=child end
        end
    end
    applySelected(d)
    scanning=false
end

local function buildBanner(view)
    if banner and lastMap==view.frame then return end
    if banner then banner:Hide() end
    lastMap=view.frame
    banner=CreateFrame("Frame",nil,view.frame)
    banner:SetPoint("TOPLEFT",view.frame,"TOPLEFT",10,-10)
    banner:SetPoint("TOPRIGHT",view.frame,"TOPRIGHT",-10,-10)
    banner:SetHeight(49)
    banner:SetFrameLevel(view.frame:GetFrameLevel()+50)
    banner:EnableMouse(false)
    local bg=banner:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints(banner)
    bg:SetColorTexture(.025,.045,.055,.88)
    caption=banner:CreateFontString(nil,"OVERLAY","GameFontNormal")
    caption:SetPoint("TOPLEFT",banner,"TOPLEFT",10,-5)
    caption:SetPoint("TOPRIGHT",banner,"TOPRIGHT",-122,-5)
    caption:SetJustifyH("LEFT")
    detail=banner:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    detail:SetPoint("TOPLEFT",banner,"TOPLEFT",10,-26)
    detail:SetPoint("TOPRIGHT",banner,"TOPRIGHT",-122,-26)
    detail:SetJustifyH("LEFT")
    toggle=CreateFrame("Button",nil,banner,"UIPanelButtonTemplate")
    toggle:SetSize(106,28)
    toggle:SetPoint("RIGHT",banner,"RIGHT",-7,0)
    toggle:SetScript("OnClick",function()
        if not N.db then return end
        N.db.focusOnly=not N.db.focusOnly
        N.RefreshOverlay()
    end)
end

function N.RefreshBossBanner()
    local d=N.FDR()
    local view=d and d.MapView
    local frame=d and d.Window and d.Window.GetFrame and d.Window:GetFrame()
    if not view or not view.frame or not frame or not frame:IsShown() or not N.db then
        if banner then banner:Hide() end
        return
    end
    buildBanner(view)
    if not banner then return end
    banner:Show()
    if N.dirty then N.Compute() end
    local entry,kind=N.TargetEntry()
    local _,key=N.Route()
    local goal=N.EntryName(entry,kind,d)
    if not entry then
        caption:SetText("|cffffce55보스를 클릭하면 해당 보스까지 길을 표시해요|r")
    else
        caption:SetText("|cff57ffd2목표:|r "..goal)
    end
    if N.solution then
        local src=N.position
        local source=src and src.label or "위치 정보 없음"
        local floor=(src and entry and src.floor~=entry.floor) and " · 층 이동 필요" or ""
        detail:SetText(source..floor.."  |  Shift+지도 클릭: 출발점 변경")
    else
        local errors={source_off_route="출발점이 통로와 멀어요",target_off_route="보스가 경로와 멀어요",
            disconnected="연결된 길이 없어요",target_missing="보스 좌표가 없어요",no_route="기록된 경로가 없어요"}
        detail:SetText("|cffff9980"..(errors[N.problem] or "위치 또는 경로를 확인해 주세요").."|r · Shift+지도 클릭")
    end
    toggle:SetText(N.db.focusOnly and "전체 경로 보기" or "목표만 보기")
end

function N.InstallBossNavigation(d)
    if not d or hooked==d then return end
    hooked=d
    if type(hooksecurefunc)=="function" then
        hooksecurefunc(d.Window,"Refresh",function()
            N.BindBossRows()
            N.RefreshBossBanner()
        end)
        hooksecurefunc(d.MapView,"DrawLines",function(view)
            if N.ApplyMapClutter then N.ApplyMapClutter(view) end
        end)
        hooksecurefunc(d.MapView,"AddPins",function()
            N.BindBossPins()
        end)
    end
    N.BindBossRows()
    N.BindBossPins()
end

local ticker=CreateFrame("Frame")
local elapsed=0
ticker:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt
    if elapsed<.7 then return end
    elapsed=0
    if N.db and N.FDR() then
        N.InstallBossNavigation(N.FDR())
        N.BindBossRows()
        N.BindBossPins()
        N.RefreshBossBanner()
    end
end)

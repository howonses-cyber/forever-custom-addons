local addon, G = ...
local areas={
 [1]=1426,[3]=1418,[8]=1435,[10]=1431,[11]=1437,[12]=1429,[14]=1411,[15]=1445,
 [16]=1447,[17]=1413,[28]=1422,[33]=1434,[36]=1416,[38]=1432,[40]=1436,
 [41]=1430,[44]=1433,[45]=1417,[46]=1428,[47]=1425,[51]=1427,[85]=1420,
 [130]=1421,[139]=1423,[141]=1438,[148]=1439,[215]=1412,[267]=1424,[331]=1440,
 [357]=1444,[361]=1448,[400]=1441,[405]=1443,[406]=1442,[440]=1446,
 [490]=1449,[618]=1452,[1377]=1451,[1519]=1453,[1537]=1455,[1637]=1454,
 [1657]=1457,[1477]=1435,[978]=1446,[1584]=1428,[1583]=1428,[2557]=1444,
 [717]=1453,[718]=1413,[719]=1440,[721]=1426,[722]=1413,[796]=1420,
 [2100]=1443,[2057]=1422,[2017]=1423,[1581]=1436,[2437]=1454,
 [1517]=1418,[133]=1426,[1717]=1413,[209]=1421,
}
local function get(db,id,field)
 if type(db)~="table" then return nil end
 local getter=db.Get
 if type(getter)~="function" then return nil end
 local ok,value=pcall(getter,id,field)
 if ok and value~=0 then return value end
 return nil
end
G.DBGet=get
local mapCache={}
function G.AreaToUiMap(area)
 if not area or type(area)~="number" or area<=0 then return nil end
 if mapCache[area] then return mapCache[area] end
 local guessed=areas[area]
 if LibQuestieDB and LibQuestieDB.Support and type(LibQuestieDB.Support.Get)=="function" then
  local support=G.SafeCall(LibQuestieDB.Support.Get,"ZoneDB")
  local priv=support and support.private
  if priv then
   for _,key in ipairs({"areaIdToUiMapIdOverride","areaIdToUiMapId"}) do
    local lookup=priv[key]
    if type(lookup)=="table" then
     guessed=lookup[area] or guessed
    elseif type(lookup)=="string" and loadstring then
     -- QuestieDB publishes the mapping as a trusted, addon-supplied Lua literal.
     local decoder=loadstring(lookup)
     local ok,t=decoder and pcall(decoder)
     if ok and type(t)=="table" then guessed=t[area] or guessed end
    end
   end
  end
 end
 if guessed and C_Map and C_Map.GetMapInfo and not G.SafeCall(C_Map.GetMapInfo,guessed) then
  -- Keep the known mapping; a map API may not be loaded yet.
 end
 if guessed then mapCache[area]=guessed end
 return guessed
end
function G.GetQuestName(id)
 if not id then return "알 수 없는 퀘스트" end
 local localized=G.koQuestNames and G.koQuestNames[id]
 if localized then return localized end
 if G.nameCache[id] then return G.nameCache[id] end
 local name=get(QuestDB,id,"name")
 if type(name)~="string" or name=="" then return "퀘스트 #"..id.." (DB 확인 필요)" end
 -- If Korean localization is missing, do not fabricate a Korean translation.
 if GetLocale and GetLocale()=="koKR" and not string.find(name,"[\128-\255]") then
  name="한글 명칭 미확인 ("..name..")"
 end
 G.nameCache[id]=name
 return name
end
function G.GetQuestMinLevel(id) return tonumber(get(QuestDB,id,"requiredLevel")) or 0 end
function G.GetQuestLevel(id) return tonumber(get(QuestDB,id,"questLevel")) or 0 end
function G.GetPlayerRaceId()
 if type(UnitRace)~="function" then return nil end
 local _,__,raceId=UnitRace("player")
 return raceId
end
function G.IsEligibleQuest(id)
 local special=G.specialQuestMeta[id]
 if special and special.onlyFaction and G.player.faction~=special.onlyFaction then return false end
 local classes=(special and special.classMask) or tonumber(get(QuestDB,id,"requiredClasses"))
 if classes and classes>0 and G.player.classId and G.player.classId>0 then
  local bitValue=2^(G.player.classId-1)
  if math.floor(classes/bitValue)%2~=1 then return false end
 end
 local allowed=tonumber(get(QuestDB,id,"requiredRaces"))
 if allowed and allowed>0 then
  local raceId=G.GetPlayerRaceId()
  if raceId and raceId>0 then
   local bitValue=2^(raceId-1)
   if math.floor(allowed/bitValue)%2~=1 then return false end
  else
   if allowed==4294967373 and G.player.faction~="Alliance" then return false end
   if allowed==8589934770 and G.player.faction~="Horde" then return false end
  end
 end
 return true
end
function G.QuestPrerequisite(id)
 local oneOf=get(QuestDB,id,"preQuestSingle")
 local allOf=get(QuestDB,id,"preQuestGroup")
 return type(allOf)=="table" and allOf or {}, type(oneOf)=="table" and oneOf or {}
end
local function meetsOrEquivalent(qid)
 if G.IsCompleted(qid) then return true end
 local exclusive=get(QuestDB,qid,"exclusiveTo")
 if type(exclusive)=="table" then
  for _,alt in ipairs(exclusive) do if G.IsCompleted(math.abs(alt)) then return true end end
 end
 return false
end
function G.SelectOnePrereq(ids)
 for _,id in ipairs(ids) do if meetsOrEquivalent(math.abs(id)) then return math.abs(id),true end end
 for _,id in ipairs(ids) do if G.IsInLog(math.abs(id)) and G.IsEligibleQuest(math.abs(id)) then return math.abs(id),false end end
 for _,id in ipairs(ids) do if G.IsEligibleQuest(math.abs(id)) then return math.abs(id),false end end
 return ids[1] and math.abs(ids[1]) or nil,false
end
function G.GetMissingPrereqs(id)
 if not G.Ready() then return {} end
 local all,one=G.QuestPrerequisite(id)
 local missing,unique={},{}
 local function add(id)
  if id and id>0 and not unique[id] then missing[#missing+1]=id;unique[id]=true end
 end
 -- A group requires all entries, whereas the single list accepts one.
 -- Each nonnegative group requirement may be fulfilled by a completed exclusive alternative.
 if #one>0 then
  local candidate,satisfied=G.SelectOnePrereq(one)
  if candidate and not satisfied then add(candidate) end
 end
 for _,entry in ipairs(all) do
  local q=math.abs(entry)
  local fulfilled=entry<0 and G.IsCompleted(q) or meetsOrEquivalent(q)
  if not fulfilled then
   if G.IsEligibleQuest(q) then add(q)
   elseif entry>=0 then
    local alts=get(QuestDB,q,"exclusiveTo")
    if type(alts)=="table" then
     for _,alt in ipairs(alts) do
      alt=math.abs(alt)
      if G.IsEligibleQuest(alt) then
       if not meetsOrEquivalent(alt) then add(alt) end
       break
      end
     end
    end
   end
  end
 end
 return missing
end
local function fromSpawns(entityDB,entityID,preferredMap)
 local spawns=get(entityDB,entityID,"spawns")
 if type(spawns)~="table" then return nil end
 local choice
 for area,points in pairs(spawns) do
  local mapId=G.AreaToUiMap(tonumber(area))
  if mapId and type(points)=="table" then
   for _,coords in ipairs(points) do
    if type(coords)=="table" and type(coords[1])=="number" and type(coords[2])=="number"
       and coords[1]>=0 and coords[1]<=100 and coords[2]>=0 and coords[2]<=100 then
     local candidate={map=mapId,x=coords[1]/100,y=coords[2]/100}
     if mapId==preferredMap then return candidate end
     if not choice then choice=candidate end
    end
   end
  end
 end
 return choice
end

-- Returns named objective locations grounded in current QuestieDB drop/spawn data.
-- These are candidate spawn locations, never a guarantee of drops or a terrain route.
function G.QuestObjectivePoints(id)
 local objectives=get(QuestDB,id,"objectives")
 if type(objectives)~="table" then return {} end
 local preferred=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local results={}
 local function add(kind,entityId,point,name)
  results[#results+1]={kind=kind,id=entityId,point=point,title=name or ("대상 #"..tostring(entityId))}
 end
 local function spawn(db,entityId)
  local p=fromSpawns(db,entityId,preferred)
  if p then p.name=get(db,entityId,"name") or "목표 위치" end
  return p
 end
 -- Creature objectives.
 for _,entry in ipairs(type(objectives[1])=="table" and objectives[1] or {}) do
  local npcId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if npcId then add("creature",npcId,spawn(NpcDB,npcId),get(NpcDB,npcId,"name") or "처치 대상") end
 end
 -- Game-object objectives.
 for _,entry in ipairs(type(objectives[2])=="table" and objectives[2] or {}) do
  local objectId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if objectId then add("object",objectId,spawn(ObjectDB,objectId),get(ObjectDB,objectId,"name") or "상호작용 대상") end
 end
 -- Item objectives: look up actual NPC/object drop sources, not invented coordinates.
 for _,entry in ipairs(type(objectives[3])=="table" and objectives[3] or {}) do
  local itemId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if itemId then
   local p
   for _,spec in ipairs({{db=NpcDB,ids=get(ItemDB,itemId,"npcDrops")},
                          {db=ObjectDB,ids=get(ItemDB,itemId,"objectDrops")}}) do
    if type(spec.ids)=="table" then
     for _,mobId in ipairs(spec.ids) do
      local candidate=spawn(spec.db,math.abs(mobId))
      if candidate then
       if not p then p=candidate end
       if candidate.map==preferred then p=candidate;break end
      end
     end
    end
    if p and p.map==preferred then break end
   end
   add("item",itemId,p,get(ItemDB,itemId,"name") or ("아이템 #"..itemId))
  end
 end
 return results
end
-- NPC/object names can exist in QuestieDB even when no coordinate was stored.
function G.QuestContactName(id,stage)
 if stage~="accept" and stage~="turnin" then return nil end
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 for _,source in ipairs({{db=NpcDB,list=row.npc or row.NPC or row[1]},
                          {db=ObjectDB,list=row.object or row.Object or row[2]}}) do
  if type(source.list)=="table" then
   for _,num in ipairs(source.list) do
    local entityID=tonumber(num)
    local name=entityID and get(source.db,entityID,"name")
    if type(name)=="string" and name~="" then return name,entityID,source.db end
   end
  end
 end
 return nil
end

-- An instance NPC may be present in finishedBy but have no numeric spawn.
-- Return a trustworthy indoor destination; never substitute entrance coordinates
-- for an indoor hand-in, and never mistake a missing point for a missing NPC.
function G.QuestInsideInfo(id,stage)
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 local hint=meta and meta.insideStages and meta.insideStages[stage]
 local dungeon
 if hint then
  dungeon=G.GetDungeon(hint.dungeon)
 else
  if stage~="accept" and stage~="turnin" then return nil end
  -- The consumer's actual numeric outdoor spawn, when present, wins.
  if G.QuestPoint and G.QuestPoint(id,stage) then return nil end
  local _,npcId,npcDB=G.QuestContactName(id,stage)
  local spawns=npcId and npcDB and get(npcDB,npcId,"spawns")
  if type(spawns)~="table" then return nil end
  for area,locations in pairs(spawns) do
   if type(locations)=="table" then
    local hasSentinel=false
    for _,coords in ipairs(locations) do
     if type(coords)=="table" and coords[1]==-1 and coords[2]==-1 then
      hasSentinel=true;break
     end
    end
    if hasSentinel then
     for _,candidate in ipairs(G.dungeons or {}) do
      if candidate.area==tonumber(area) then
       dungeon=candidate;hint={dungeon=candidate.id,room="내부 위치 미확인"};break
      end
     end
    end
    if dungeon then break end
   end
  end
 end
 if not dungeon then return nil end
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 local ids=type(row)=="table" and (row.npc or row.NPC or row[1]) or nil
 local npcId=hint.npcId
 if type(ids)=="table" then
  for _,value in ipairs(ids) do
   local candidate=tonumber(value)
   if candidate and (candidate==hint.npcId or not npcId) then npcId=candidate;break end
  end
 end
 local knownName=npcId and get(NpcDB,npcId,"name")
 local npcName=hint.npcName or (type(knownName)=="string" and knownName~="" and knownName) or
   ("NPC #"..tostring(npcId or "?"))
 return {dungeon=dungeon.name,dungeonId=dungeon.id,entrance=dungeon.entrance,
         npcId=npcId,npcName=npcName,room=hint.room or "던전 내부",followup=hint.followup}
end

local function questGiver(id,stage)
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 local preferredMap=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local providers={{db=NpcDB,list=row.npc or row.NPC or row[1]},
                  {db=ObjectDB,list=row.object or row.Object or row[2]}}
 local best
 for _,provider in ipairs(providers) do
  if type(provider.list)=="table" then
   for _,entry in ipairs(provider.list) do
    local idNum=tonumber(entry)
    if idNum then
     local point=fromSpawns(provider.db,idNum,preferredMap)
     if point then
      point.name=get(provider.db,idNum,"name") or "NPC/오브젝트 #"..idNum
      if point.map==preferredMap then return point end
      if not best then best=point end
     end
    end
   end
  end
 end
 return best
end
function G.QuestPoint(id,stage)
 local meta=G.specialQuestMeta[id]
 if meta and meta.inside then return nil end
 if stage=="accept" then
  local override=G.pickupOverrides[id]
  if override then return {map=override.map,x=override.x,y=override.y,name=override.name or (G.GetQuestName(id).." 수락")} end
 end
 if stage=="objective" then
  local trigger=get(QuestDB,id,"triggerEnd")
  if type(trigger)=="table" and type(trigger[2])=="table" then
   for area,locations in pairs(trigger[2]) do
    local m=G.AreaToUiMap(tonumber(area))
    if m and type(locations)=="table" and type(locations[1])=="table" then
     local p=locations[1]
     if tonumber(p[1]) and tonumber(p[2]) then
      return {map=m,x=p[1]/100,y=p[2]/100,name=G.GetQuestName(id).." 목표"}
     end
    end
   end
  end
  return nil -- Do not synthesize coordinates for drop/kill objectives.
 end
 return questGiver(id,stage)
end
function G.QuestGiverName(id,stage)
 local point=G.QuestPoint(id,stage)
 if point and point.name then return point.name end
 local inside=G.QuestInsideInfo(id,stage)
 if inside then return inside.npcName.." ("..inside.dungeon.." · "..inside.room..")" end
 return G.QuestContactName(id,stage) or
    ((G.specialQuestMeta[id] and G.specialQuestMeta[id].inside) and "던전 내부" or "위치 데이터 확인 필요")
end
function G.QuestDetails(id)
 local all,one=G.QuestPrerequisite(id)
 local state,code=G.QuestState(id)
 local point=G.QuestPoint(id,code=="turnin" and "turnin" or "accept")
 local localeName=point and C_Map and C_Map.GetMapInfo and G.SafeCall(C_Map.GetMapInfo,point.map)
 local place=point and ((localeName and localeName.name) or ("지도 #"..point.map)) or nil
 local indoor=G.QuestInsideInfo(id,code=="turnin" and "turnin" or "accept")
 local coords=point and string.format("%s %.1f, %.1f",place,point.x*100,point.y*100) or
   (indoor and (indoor.dungeon.." · "..indoor.room.." (던전 내부 좌표 없음)") or "위치 미확인")
 return {id=id,name=G.GetQuestName(id),level=G.GetQuestMinLevel(id),status=state,code=code,
   all=all,one=one,starter=G.QuestGiverName(id,code=="turnin" and "turnin" or "accept"),coords=coords,
   note=G.specialQuestMeta[id] and G.specialQuestMeta[id].note}
end

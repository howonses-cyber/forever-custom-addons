Forever BiS Audit v0.2.0 (2026-11-24)

[설치]
ZIP 안의 ForeverBiSAudit 폴더를 Interface/AddOns 아래에 설치하거나 Forever Addon Manager 온라인 카탈로그로 설치.
기존 애드온/설정/WTF를 수정하지 않습니다.

[열기]
엘스미어UI 애드온 버튼 모음집의 황금색 장비 아이콘 클릭, 또는 /fbis
직업·특성 버튼을 누를 때마다 선택이 바뀝니다. 9개 직업 28개 역할 조합 탐색 지원.

[획득처 / 비스 데이터 범위]
선별된 초기 참고 데이터 74개, 7개 특성(고술, 무기/방어 전사, 사격 냥꾼, 전투 도적, 암사, 냉법)에 한해 등록.
7개도 슬롯별 완성형 검증 BiS는 아닙니다. 다른 21개 특성은 아직 수집 중이며 UI에 수록 목록이 없다고 표시합니다.
모든 '가이드 후보'는 외부 가이드의 후보, 실제 Forever 서버에서 드롭 확인됨을 뜻하지 않습니다.
'확인 필요'는 실제 획득처/진영/시기 미확인, '미개방'은 알방 등 현재 열리지 않은 콘텐츠.
현재 파밍 화면은 기본적으로 미개방을 숨깁니다. 필요 시 [미개방 포함]을 켜서 미래 장비를 참고하세요.
실시간 서버/웹 요청은 WoW 애드온에서 불가능하므로 최신 소스는 관리툴로 배포 업데이트.
검토일 2026-11-24. 실제 인게임 획득처, 직업별 레벨 제한/진영 가능 여부는 검증 필요.
공개된 Wowhead Forever 작성 가이드와 2026-11-23 ForeverWoW.gg 장비 순위 참고.

[비교 퍼센트 주의]
가방/착용 장비에 마우스를 올리면 현재 직업 3~4특성별 스탯 가중 점수(EP)가 표시됩니다.
'% EP' = (새 장비의 적용된 스탯 가중치 합 - 비교 슬롯 착용 장비 점수) / 착용 장비 점수 x 100.
이것은 시뮬레이션으로 측정한 실제 DPS/HPS/생존율 상승 퍼센트가 아닙니다.
무기 DPS, 공속, 효과 발동, 사용 효과, 세트 보너스, 타겟 종족/지역, 명중률 상한, 마법/특성 상호작용,
보석/마법부여, 탄약 및 토템/유물 특수효과를 정확히 반영하지 못합니다.
아이템 데이터가 게임 캐시에 없거나 0점/불일치 슬롯이면 비교 수치를 표시하지 않습니다.
각 특성의 사전 정의 가중치는 추정치이며, 고술/사격/냉법/신사는 출처가 있는 참고 가중치를 씁니다.
스탯 가중치가 1일 때 '+5% EP'가 '+5% DPS'를 뜻하지 않습니다. 절대로 그렇게 읽지 마세요.

[명령어]
/fbis                  창 열기/닫기
/fbis help             명령어 안내
/fbis weight str 1.5   현재 선택 특성 힘 가중치 설정
/fbis reset            현재 특성 가중치 초기화
/fbis tooltip off      가방/장착 장비 툴팁 비교 끄기
/fbis tooltip on       툴팁 비교 켜기
/fbis locked on        미개방 후보 표시
/fbis locked off       미개방 후보 숨김

[출처]
https://www.wowhead.com/forever/guide/classes/shaman/enhancement/bis-gear (updated Nov 20, 2026)
https://www.wowhead.com/forever/guide/classes/warrior/arms/bis-gear (updated Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/warrior/protection/bis-gear (Nov 2026)
https://www.wowhead.com/forever/guide/classes/hunter/marksmanship/bis-gear (Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/rogue/combat/bis-gear (Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/priest/shadow/bis-gear (Nov 17, 2026)
https://foreverwow.gg/shaman/enhancement/pre-raid/ (Nov 23, 2026)
https://foreverwow.gg/mage/frost/pre-raid/ (Nov 23, 2026)
https://www.wowhead.com/forever/gear-planner/warrior (Classic Era weights disclosed)
서버별 드롭 검증이 없는 경우 '검증'으로 표기하지 않습니다.

[참고] QuestieDB ItemDB.GetAllIds가 사용 가능하면 74개 후보의 아이템 ID를 읽기 전용으로 순차 탐색합니다.
이 과정에서 확인된 ID로 인게임 한글명/툴팁을 표시할 수 있으나 데이터 미발견 또는 미캐시 때는 보류합니다.

[BiS data automatic update]
External web access is not available to the WoW Lua runtime. A scheduled GitHub Action checks independent public pre-raid rankings. Only unambiguous matching items with a legitimate slot and source can enter the automatically compiled archive. Pending discrepancies remain unchanged, including PvP/raid/locked items. The installed addon never downloads external code. Forever Addon Manager shows the new ZIP when a verified data change is published, and updates only after the user presses Install. The current 74 curated candidates are NOT declared official in-game BiS. Personal Library mirrors the version at last assistant-run and is not directly writable from GitHub Actions.
/fbis data: print the installed data version and evidence policy.

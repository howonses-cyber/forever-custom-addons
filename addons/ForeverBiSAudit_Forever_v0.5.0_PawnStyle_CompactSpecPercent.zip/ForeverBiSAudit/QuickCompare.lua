local _, B = ...
-- Compact, equipped-item-relative ROLE SCORE estimates. These are not a combat
-- simulator or measured DPS/HPS. Every displayed change has a real equipped
-- baseline; an item with no effective stats can legitimately be 0.0%.
local slots={
 INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},INVTYPE_CLOAK={15},
 INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WRIST={9},INVTYPE_HAND={10},
 INVTYPE_WAIST={6},INVTYPE_LEGS={7},INVTYPE_FEET={8},INVTYPE_FINGER={11,12},
 INVTYPE_TRINKET={13,14},INVTYPE_RANGED={18},INVTYPE_RANGEDRIGHT={18},
 INVTYPE_THROWN={18},INVTYPE_RELIC={18},INVTYPE_WEAPONMAINHAND={16},
 INVTYPE_WEAPONOFFHAND={17},INVTYPE_SHIELD={17},INVTYPE_HOLDABLE={17},
 INVTYPE_2HWEAPON={16,17},INVTYPE_WEAPON={16},
}
local function number(x) return type(x)=='number' and x==x and x>-10000000 and x<10000000 end
local function inventory(i)
 if type(GetInventoryItemLink)~='function' then return nil end
 local ok,v=pcall(GetInventoryItemLink,'player',i)
 return ok and type(v)=='string' and v or nil
end
local function identity(a,b)
 return a and b and (a==b or (a:match('item:(%d+)') and a:match('item:(%d+)')==b:match('item:(%d+)')))
end
local function statsFor(link)
 if not link then return {},true end
 local get=C_Item and C_Item.GetItemStats or GetItemStats
 if type(get)~='function' then return {},false end
 local ok,x=pcall(get,link)
 if not ok or type(x)~='table' then
  local id=type(link)=='string' and tonumber(link:match('item:(%d+)'))
  if id and C_Item and C_Item.RequestLoadItemDataByID then
   pcall(C_Item.RequestLoadItemDataByID,id)
  end
  return {},false
 end
 return x,true
end
local function getRole(spec,class)
 if class=='SHAMAN' then
  if spec=='elemental' then return 'elemental' end
  if spec=='restoration' then return 'restoration' end
  if spec=='enhancement' then return 'enhancement' end
 end
 return 'generic'
end
local allowed={
 elemental={int=true,spi=true,sp=true,spellhit=true,spellcrit=true,crit=true,haste=true,nature=true,mp5=true},
 restoration={int=true,spi=true,sp=true,heal=true,spellcrit=true,crit=true,haste=true,mp5=true},
 enhancement={str=true,agi=true,int=true,ap=true,hit=true,crit=true,haste=true,expertise=true,sp=true,nature=true,mp5=true},
}
local function statsPoints(self,tableStats,class,spec)
 local role=getRole(spec,class)
 local weights=self:GetWeights(class,spec) or {}
 local total=0
 for k,v in pairs(tableStats or {}) do
  local stat=self.statByAPI and self.statByAPI[k]
  local w=stat and weights[stat]
  if number(v) and number(w) and (not allowed[role] or allowed[role][stat]) then
   total=total+v*w
  end
 end
 return total
end
local function unitInt()
 if type(UnitStat)~='function' then return 0 end
 local ok,base,effective=pcall(UnitStat,'player',4)
 if not ok then return 0 end
 return number(effective) and math.max(0,effective) or (number(base) and math.max(0,base) or 0)
end
local function attackPower()
 if type(UnitAttackPower)~='function' then return 0 end
 local ok,a,b,c=pcall(UnitAttackPower,'player')
 if not ok then return 0 end
 return math.max(0,(number(a) and a or 0)+(number(b) and b or 0)+(number(c) and c or 0))
end
local function bonus(fn,index)
 if type(fn)~='function' then return 0 end
 local ok,v=pcall(fn,index)
 return ok and number(v) and math.max(0,v) or 0
end
function B:RoleBaseline(class,spec)
 local role=getRole(spec,class)
 if role=='elemental' then
  -- Normalization against currently active character power, not against the
  -- new item's EP (which can be zero on purely physical weapons).
  return 160 + bonus(GetSpellBonusDamage,4) + unitInt()*.3
 elseif role=='restoration' then
  return 180 + bonus(GetSpellBonusHealing) + unitInt()*.7
 elseif role=='enhancement' then
  return 170 + attackPower()*.5
 end
 return 200 + attackPower()*.35 + unitInt()*.2
end
local function nameOf(self,link)
 if not link then return '미착용' end
 return (self.GetEquippedName and self.GetEquippedName(link)) or '현재 장비'
end
local function pickEquipped(self,link,class,spec,loc)
 local ids=slots[loc]
 if not ids then return nil,'장비 부위 확인 불가' end
 if loc=='INVTYPE_2HWEAPON' then
  local main=inventory(16);if not main then return nil,'현재 무기 미착용' end
  local off=inventory(17)
  return {main,off},nil,nameOf(self,main)..(off and (' + '..nameOf(self,off)) or '')
 end
 if loc=='INVTYPE_WEAPONOFFHAND' or loc=='INVTYPE_HOLDABLE' or loc=='INVTYPE_SHIELD' then
  local main=inventory(16)
  if main and self:ResolveEquipLocation(main)=='INVTYPE_2HWEAPON' then
   return nil,'양손 무기와는 단독 비교 불가'
  end
 end
 if loc=='INVTYPE_WEAPONMAINHAND' or loc=='INVTYPE_WEAPON' then
  local main=inventory(16)
  if main and self:ResolveEquipLocation(main)=='INVTYPE_2HWEAPON' and loc~='INVTYPE_2HWEAPON' then
   return nil,'양손 무기와는 단독 비교 불가'
  end
 end
 if #ids==1 then
  local x=inventory(ids[1]);if not x then return nil,'현재 장비 미착용' end
  return {x},nil,nameOf(self,x)
 end
 -- Rings/trinkets: report 0% for an item the player already wears; otherwise
 -- choose the occupied slot with the lowest role score (best replacement).
 local options={}
 for _,id in ipairs(ids) do
  local x=inventory(id)
  if not x then return nil,'비어 있는 장착 슬롯: 기준 % 없음' end
  if identity(x,link) then return {x},nil,nameOf(self,x) end
  local s,good=statsFor(x)
  if not good then return nil,'착용 장비 데이터 조회 중' end
  options[#options+1]={link=x,points=statsPoints(self,s,class,spec),id=id}
 end
 table.sort(options,function(a,b)if a.points==b.points then return a.id<b.id end return a.points<b.points end)
 return {options[1].link},nil,nameOf(self,options[1].link)
end
local function merge(arr)
 local combined={}
 for _,r in ipairs(arr) do
  local s,good=statsFor(r)
  if not good then return nil end
  for k,v in pairs(s) do
   if number(v) then combined[k]=(combined[k] or 0)+v end
  end
 end
 return combined
end
-- Known *damage values* are taken from the Forever item tooltip, not from
-- Classic. Proc frequency is NOT published by the client: assume 1 PPM solely
-- for a rough, clearly labelled estimate, never a verified DPS claim.
local knownProcs={
 [870]={direct=262,dot=60,armor=false}, -- Fiery War Axe (231-293 +60)
 [17766]={direct=168,dot=0,armor=true}, -- Princess Theradras' Scepter
}
local function tooltipStrings(link)
 local out={}
 if C_TooltipInfo and type(C_TooltipInfo.GetHyperlink)=='function' then
  local ok,data=pcall(C_TooltipInfo.GetHyperlink,link)
  if ok and type(data)=='table' and type(data.lines)=='table' then
   for _,line in ipairs(data.lines) do
    if type(line.leftText)=='string' then out[#out+1]=line.leftText end
    if type(line.rightText)=='string' then out[#out+1]=line.rightText end
   end
  end
 end
 return out
end
local function parseEffect(lines)
 local hasChance=false
 for _,s in ipairs(lines) do
  local t=s:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r',''):gsub(',','')
  if t:find('Chance on hit',1,true) or t:find('발동 효과',1,true) or
    t:find('공격 시',1,true) then
   hasChance=true
   local a,b=t:match('(%d+)%s+to%s+(%d+)%s+[Ff]ire')
   if not a then a,b=t:match('(%d+)%s*[~%-]%s*(%d+)%s*화염') end
   if not a then a,b=t:match('(%d+)%s*에서%s*(%d+)') end
   local dmg=(a and b) and ((tonumber(a)+tonumber(b))/2) or nil
   if not dmg then
    dmg=tonumber(t:match('for%s+(%d+)%s+damage')) or
       tonumber(t:match('(%d+)의%s*피해'))
   end
   if dmg then
    local dot=tonumber(t:match('additional%s+(%d+)%s+damage')) or
        tonumber(t:match('추가%s*(%d+)의%s*피해')) or 0
    return (dmg+dot)/60,true
   end
  end
 end
 return 0,hasChance
end
function B:ProcDPS(link)
 if not link then return 0,false end
 local id=tonumber(type(link)=='string' and link:match('item:(%d+)') or nil)
 local value,recognized=parseEffect(tooltipStrings(link))
 if recognized and value>0 then return value,true,knownProcs[id] and knownProcs[id].armor or false end
 local data=knownProcs[id]
 if data then return (data.direct+data.dot)/60,true,not not data.armor end
 -- Do not invent a proc rate/damage for unrecognized on-hit or use effects.
 return 0,false
end
local function validPercent(x)
 return number(x) and x>=-100 and x<=2000
end
function B:SimpleEquipPercent(link,class,spec,loc)
 local current,reason,baselineName=pickEquipped(self,link,class,spec,loc)
 if not current then return nil,reason end
 local cur=current[1]
 if identity(link,cur) and #current==1 then
  return {pct=0,comparedName=baselineName,method='same'}
 end
 local incoming,good=statsFor(link)
 if not good then return nil,'후보 장비 스탯 로딩 중' end
 local existing=merge(current)
 if not existing then return nil,'착용 장비 스탯 로딩 중' end
 local role=getRole(spec,class)
 local baseScore=statsPoints(self,existing,class,spec)
 local newScore=statsPoints(self,incoming,class,spec)
 local delta=newScore-baseScore
 local flag=false
 -- Keep the preexisting melee weapon comparison for other physical classes.
 -- Casters and feral druids must not be graded by weapon swing DPS.
 local meleeOthers=(class=='WARRIOR' or class=='ROGUE' or
  (class=='PALADIN' and spec=='retribution'))
 if meleeOthers and (loc=='INVTYPE_2HWEAPON' or loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND') then
  local c,why=self:CompareWeapon(link,class,spec,loc=='INVTYPE_2HWEAPON' and 'TwoHand' or 'MainHand',loc)
  if not c or not c.modelPct then return nil,why or '무기 데이터 조회 중' end
  return {pct=c.modelPct,comparedName=baselineName,method='melee',partial=c.procWarning or not c.modelAPKnown}
 end
 if role=='enhancement' and (loc=='INVTYPE_2HWEAPON' or loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND') then
  -- The existing 0.4 weapon model already uses actual equipped AP and the
  -- physical damage range and normalized Stormstrike. Add a small maximum-hit
  -- preference (windfury burst), relevant other stats and estimated procs.
  local c,why=self:CompareWeapon(link,class,spec,loc=='INVTYPE_2HWEAPON' and 'TwoHand' or 'MainHand',loc)
  if not c or not c.modelBase or not c.weaponCandidate or not c.weaponEquipped then
   return nil,why or '무기 피해량 조회 중'
  end
  local a,b=c.weaponCandidate,c.weaponEquipped
  local newProc,knownNew,incompleteNew=self:ProcDPS(link)
  local oldProc,knownOld,incompleteOld=self:ProcDPS(cur)
  local burstNew=a.max*0.02
  local burstOld=b.max*0.02
  local weights=self:GetWeights(class,spec) or {}
  local strDiff=(incoming.ITEM_MOD_STRENGTH_SHORT or 0)-(existing.ITEM_MOD_STRENGTH_SHORT or 0)
  local apDiff=(incoming.ITEM_MOD_ATTACK_POWER_SHORT or 0)-(existing.ITEM_MOD_ATTACK_POWER_SHORT or 0)
  -- Strength and AP are already reflected in the model's recalculated AP.
  local extra=delta-strDiff*(weights.str or 0)-apDiff*(weights.ap or 0)
  local before=c.modelBase+oldProc+burstOld
  local after=c.modelCandidate+newProc+burstNew+extra*.13
  if before<=0 then return nil,'현재 장비 기준 공격력 확인 불가' end
  local pct=100*(after-before)/before
  if not validPercent(pct) then return nil,'무기 비교값 이상' end
  flag=((a.special or b.special) and not (knownNew and knownOld)) or incompleteNew or incompleteOld
  return {pct=pct,comparedName=baselineName,method='melee',procAssumed=(knownNew or knownOld),partial=flag or not c.modelAPKnown}
 end
 -- Elemental / Restoration: weapon speed and melee procs MUST NOT produce
 -- imaginary spell/healing DPS. 0 relevant stats => exactly 0.0%.
 local denom=self:RoleBaseline(class,spec)
 if not number(denom) or denom<=0 then return nil,'기준 캐릭터 수치 없음' end
 local pct=100*delta/denom
 if not validPercent(pct) then return nil,'비교값 이상' end
 return {pct=pct,comparedName=baselineName,method='role',partial=false}
end

local _, B = ...
-- Default is a compact one-line-per-spec estimate, not a debug report.
local initialized=false
local valid={
 INVTYPE_HEAD=true,INVTYPE_NECK=true,INVTYPE_SHOULDER=true,INVTYPE_CLOAK=true,
 INVTYPE_CHEST=true,INVTYPE_ROBE=true,INVTYPE_WRIST=true,INVTYPE_HAND=true,
 INVTYPE_WAIST=true,INVTYPE_LEGS=true,INVTYPE_FEET=true,INVTYPE_FINGER=true,
 INVTYPE_TRINKET=true,INVTYPE_WEAPON=true,INVTYPE_WEAPONMAINHAND=true,
 INVTYPE_WEAPONOFFHAND=true,INVTYPE_2HWEAPON=true,INVTYPE_SHIELD=true,
 INVTYPE_HOLDABLE=true,INVTYPE_RANGED=true,INVTYPE_RANGEDRIGHT=true,
 INVTYPE_RELIC=true,INVTYPE_THROWN=true
}
local function signature()
 if type(GetInventoryItemLink)~='function' then return '' end
 local p={}
 for _,id in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
  p[#p+1]=tostring(GetInventoryItemLink('player',id) or '')
 end
 return table.concat(p,':')
end
local function itemFrom(t,data)
 if t and type(t.GetItem)=='function' then
  local ok,_,link=pcall(t.GetItem,t)
  if ok and type(link)=='string' then return link end
 end
 if type(data)=='table' then
  if type(data.hyperlink)=='string' then return data.hyperlink end
  if type(data.id)=='number' and data.id>0 then return 'item:'..data.id end
 end
end
local function AddInfo(tooltip,data)
 if not B.db or not B.db.showTooltip or not tooltip then return end
 if tooltip~=GameTooltip and tooltip~=ItemRefTooltip then return end
 if tooltip._fbisBusy then return end
 local link=itemFrom(tooltip,data)
 if type(link)~='string' or not link:find('item:',1,true) then return end
 local loc=B:ResolveEquipLocation(link)
 if not valid[loc] then return end
 local cl=UnitClass and select(2,UnitClass('player')) or B.db.class
 if not B.specs[cl] then return end
 local key=link..'|'..cl..'|'..signature()
 if tooltip._fbisSignature==key then return end
 tooltip._fbisSignature=key
 tooltip._fbisBusy=true
 local ok,err=pcall(function()
  tooltip:AddLine('Forever BiS |cffb9e4ff착용 대비 특성별 점수 변화|r',1,.76,.25)
  local selected=B.db.class==cl and B.db.spec or nil
  local arranged={}
  for _,sp in ipairs(B.specs[cl]) do
   if sp.key==selected then arranged[#arranged+1]=sp end
  end
  for _,sp in ipairs(B.specs[cl]) do
   if sp.key~=selected then arranged[#arranged+1]=sp end
  end
  local compared,hasAssumption,hasPartial=nil,false,false
  for _,sp in ipairs(arranged) do
   local res,why=B:SimpleEquipPercent(link,cl,sp.key,loc)
   if res and res.pct~=nil then
    local pct=res.pct
    local rounded=tonumber(string.format('%.1f',pct)) or 0
    if math.abs(rounded)<0.05 then rounded=0 end
    local tiny=rounded==0 and pct~=0
    local shown=tiny and ((pct>0 and '+' or '')..string.format('%.2f%%',pct)) or
     ((rounded>0 and '+' or '')..string.format('%.1f%%',rounded))
    local r,g,b=.76,.82,.86
    if pct>0 then r,g,b=.35,1,.52
    elseif pct<0 then r,g,b=1,.36,.35 end
    local short=cl=='SHAMAN' and ({enhancement='고술',elemental='정술',restoration='복술'})[sp.key] or sp.label
    tooltip:AddDoubleLine(short,shown,1,1,1,r,g,b)
    compared=compared or res.comparedName
    hasAssumption=hasAssumption or res.procAssumed
    hasPartial=hasPartial or res.partial
   else
    tooltip:AddDoubleLine(sp.label,'계산 불가',1,1,1,.97,.69,.4)
   end
  end
  if compared then tooltip:AddLine('기준: '..tostring(compared),.67,.78,.91,true) end
  -- One compact disclaimer only. Proc frequency is a scenario, not a known
  -- Forever server rate. Unsupported effects are not silently awarded points.
  if hasAssumption and hasPartial then
   tooltip:AddLine('※ 추정 점수 · 발동 1회/분 가정 · 일부 효과 제외',.85,.73,.48,true)
  elseif hasAssumption then
   tooltip:AddLine('※ 추정 점수 · 발동 1회/분 가정 · 실전 DPS 아님',.85,.73,.48,true)
  elseif hasPartial then
   tooltip:AddLine('※ 추정 점수 · 일부 효과 미반영 · 실전 DPS 아님',.85,.73,.48,true)
  else
   tooltip:AddLine('※ 특성별 추정 점수 · 실제 DPS/HPS 변화율 아님',.73,.74,.79,true)
  end
 end)
 tooltip._fbisBusy=false
 if not ok and B.Print then B.Print('툴팁 계산 오류: '..tostring(err)) end
end
function B:SetupTooltips()
 if initialized then return end
 initialized=true
 local modern=TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall)=='function'
  and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item~=nil
 if modern then
  local ok=pcall(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,function(tip,data)
   AddInfo(tip,data)
  end)
  if ok then
   for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
    if tip and tip.HookScript then
     pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
    end
   end
   return
  end
 end
 for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
  if tip and tip.HookScript then
   pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
   pcall(tip.HookScript,tip,'OnTooltipSetItem',function(self)AddInfo(self)end)
  end
 end
end

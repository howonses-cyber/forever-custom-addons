-- Walkable route network built from Forever Dungeon Routes' recorded path vertices.
-- No wall-crossing direct lines; cross-floor edges only between consecutively recorded main paths.
local _, N = ...
local A = 668/1002
local MAX_NODES = 1600
local POINT_EPS = 0.007
local MAX_ATTACH = 0.065
local function dist(x1,y1,x2,y2)
    local dx,dy=x2-x1,(y2-y1)*A
    return math.sqrt(dx*dx+dy*dy)
end
local function clamp(t) return N.Clamp(t,0,1) end
local function isCoord(a) return type(a)=="number" and a==a and a>=-0.08 and a<=1.08 end

function N.BuildGraph(route)
    local G={nodes={},edges={},adj={},route=route,mainFirst=nil}
    local function node(floor,x,y)
        if type(floor)~="number" or not isCoord(x) or not isCoord(y) then return nil end
        for i,n in ipairs(G.nodes) do
            if n.floor==floor and dist(n.x,n.y,x,y)<POINT_EPS then return i end
        end
        if #G.nodes>=MAX_NODES then return nil end
        local index=#G.nodes+1
        G.nodes[index]={floor=floor,x=x,y=y}
        G.adj[index]={}
        return index
    end
    local function edge(a,b,kind,penalty)
        if not a or not b or a==b then return end
        local u,v=G.nodes[a],G.nodes[b]
        local d=dist(u.x,u.y,v.x,v.y)
        local cost=penalty or d
        if cost<0.00001 then cost=0.00001 end
        local e={a=a,b=b,cost=cost,len=d,kind=kind or "walk",floor=(u.floor==v.floor) and u.floor or nil}
        local id=#G.edges+1;G.edges[id]=e
        G.adj[a][#G.adj[a]+1]={n=b,id=id,cost=cost}
        G.adj[b][#G.adj[b]+1]={n=a,id=id,cost=cost}
        return id
    end
    local paths={}
    for _,p in ipairs(route.paths or {}) do
        if (p.kind=="main" or p.kind=="side") and type(p.pts)=="table" then
            local points={}
            for j=1,#p.pts-1,2 do
                local id=node(p.floor,p.pts[j],p.pts[j+1])
                if id then
                    if #points==0 or points[#points]~=id then points[#points+1]=id end
                end
            end
            if #points>1 then
                for j=1,#points-1 do edge(points[j],points[j+1],p.kind) end
                paths[#paths+1]={kind=p.kind,first=points[1],last=points[#points],floor=p.floor}
                if p.kind=="main" and not G.mainFirst then G.mainFirst=points[1] end
            end
        end
    end
    -- Explicit sequential main path floor transitions recorded by the route author.
    local previousMain=nil
    for _,p in ipairs(paths) do
        if p.kind=="main" then
            if previousMain then
                local v,w=G.nodes[previousMain.last],G.nodes[p.first]
                if v and w and v.floor~=w.floor then
                    edge(previousMain.last,p.first,"floor",0.055)
                elseif v and w and dist(v.x,v.y,w.x,w.y)<0.014 then
                    edge(previousMain.last,p.first,"join")
                end
            end
            previousMain=p
        end
    end
    -- Attach branch endpoints only when truly at the drawn main route vertices.
    for _,p in ipairs(paths) do
        if p.kind=="side" then
            for _,id in ipairs({p.first,p.last}) do
                local a=G.nodes[id]
                local best,bestD=nil,0.012
                for _,m in ipairs(paths) do
                    if m.kind=="main" then
                        for _,other in ipairs({m.first,m.last}) do
                            local b=G.nodes[other]
                            if b.floor==a.floor and other~=id then
                                local d=dist(a.x,a.y,b.x,b.y)
                                if d<bestD then best,bestD=other,d end
                            end
                        end
                    end
                end
                if best then edge(id,best,"join") end
            end
        end
    end
    -- A branch can join the middle of a recorded main segment, not only its vertices.
    -- Connect it only at a very short physical map distance; never invent long shortcuts.
    local originalEdges=#G.edges
    for _,p in ipairs(paths) do
        if p.kind=="side" then
            for _,id in ipairs({p.first,p.last}) do
                local q=G.nodes[id]
                local best,bestDist=nil,0.014
                for eid=1,originalEdges do
                    local e=G.edges[eid]
                    if e.kind=="main" and e.floor==q.floor then
                        local a,b=G.nodes[e.a],G.nodes[e.b]
                        local vx,vy=b.x-a.x,(b.y-a.y)*A
                        local wx,wy=q.x-a.x,(q.y-a.y)*A
                        local len2=vx*vx+vy*vy
                        if len2>0.0000001 then
                            local t=math.max(0,math.min(1,(vx*wx+vy*wy)/len2))
                            local px,py=a.x+t*(b.x-a.x),a.y+t*(b.y-a.y)
                            local delta=dist(q.x,q.y,px,py)
                            if delta<bestDist then
                                bestDist=delta;best={edge=e,t=t,x=px,y=py}
                            end
                        end
                    end
                end
                if best then
                    local m=node(q.floor,best.x,best.y)
                    if m and m~=id then edge(id,m,"join",bestDist) end
                    if m then
                        edge(m,best.edge.a,"main",best.t*best.edge.len)
                        edge(m,best.edge.b,"main",(1-best.t)*best.edge.len)
                    end
                end
            end
        end
    end
    return G
end

local function project(G,floor,x,y)
    if not G or not isCoord(x) or not isCoord(y) then return nil end
    local best,lowest=nil,MAX_ATTACH
    for i,e in ipairs(G.edges) do
        if e.floor==floor and e.kind~="floor" and e.len>0.00001 then
            local a,b=G.nodes[e.a],G.nodes[e.b]
            local vx,vy=b.x-a.x,(b.y-a.y)*A
            local wx,wy=x-a.x,(y-a.y)*A
            local len2=vx*vx+vy*vy
            local t=clamp((vx*wx+vy*wy)/len2)
            local qx,qy=a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t
            local d=dist(x,y,qx,qy)
            if d<lowest then lowest=d;best={edge=i,t=t,x=qx,y=qy,floor=floor,offset=d} end
        end
    end
    return best
end
N.Project=project

local function push(heap,n,score)
    local i=#heap+1
    heap[i]={n=n,score=score}
    while i>1 do
        local parent=math.floor(i/2)
        if heap[parent].score<=score then break end
        heap[i]=heap[parent];i=parent
    end
    heap[i]={n=n,score=score}
end
local function pop(heap)
    local n=#heap
    if n==0 then return nil end
    local value=heap[1]
    local tail=heap[n];heap[n]=nil
    if n==1 then return value end
    local i=1
    while i*2<=n-1 do
        local child=i*2
        if child+1<=n-1 and heap[child+1].score<heap[child].score then child=child+1 end
        if heap[child].score>=tail.score then break end
        heap[i]=heap[child];i=child
    end
    heap[i]=tail
    return value
end

-- Source and destination become virtual vertices ON the recorded path, not direct lines through walls.
function N.Shortest(G,source,target)
    if not G or #G.edges==0 then return nil,"no_route" end
    local s=project(G,source.floor,source.x,source.y)
    local t=project(G,target.floor,target.x,target.y)
    if not s then return nil,"source_off_route" end
    if not t then return nil,"target_off_route" end
    local n=#G.nodes
    local start,finish=n+1,n+2
    local coords={}
    for i,p in ipairs(G.nodes) do coords[i]=p end
    coords[start]={floor=s.floor,x=s.x,y=s.y}
    coords[finish]={floor=t.floor,x=t.x,y=t.y}
    local temporary={}
    local function connect(a,b,c,kind)
        temporary[a]=temporary[a] or {}
        temporary[b]=temporary[b] or {}
        local z={a=a,b=b,cost=c,kind=kind,floor=(coords[a].floor==coords[b].floor) and coords[a].floor or nil}
        temporary[a][#temporary[a]+1]={n=b,e=z,cost=c}
        temporary[b][#temporary[b]+1]={n=a,e=z,cost=c}
    end
    local function attach(index,p)
        local e=G.edges[p.edge]
        connect(index,e.a,math.max(.00001,p.t*e.len),"walk")
        connect(index,e.b,math.max(.00001,(1-p.t)*e.len),"walk")
    end
    attach(start,s);attach(finish,t)
    if s.edge==t.edge then
        local e=G.edges[s.edge]
        connect(start,finish,math.max(.00001,math.abs(s.t-t.t)*e.len),"walk")
    end
    local cost={[start]=0};local prev={};local visited={};local heap={}
    push(heap,start,0)
    while #heap>0 do
        local value=pop(heap)
        local a=value.n
        if not visited[a] then
            visited[a]=true
            if a==finish then break end
            for _,ent in ipairs(G.adj[a] or {}) do
                local next=ent.n
                local weight=ent.cost
                local nc=cost[a]+weight
                if (not cost[next]) or nc<cost[next]-0.0000001 then
                    cost[next]=nc;prev[next]={from=a,kind=G.edges[ent.id].kind}
                    push(heap,next,nc)
                end
            end
            for _,ent in ipairs(temporary[a] or {}) do
                local next=ent.n
                local nc=cost[a]+ent.cost
                if (not cost[next]) or nc<cost[next]-0.0000001 then
                    cost[next]=nc;prev[next]={from=a,kind=ent.e.kind}
                    push(heap,next,nc)
                end
            end
        end
    end
    if not cost[finish] then return nil,"disconnected" end
    local order={finish};local kinds={};local cur=finish;local guard=0
    while cur~=start and prev[cur] and guard<=MAX_NODES+8 do
        kinds[#kinds+1]=prev[cur].kind
        cur=prev[cur].from
        order[#order+1]=cur
        guard=guard+1
    end
    if cur~=start then return nil,"disconnected" end
    local points={}
    for i=#order,1,-1 do
        local p=coords[order[i]]
        points[#points+1]={floor=p.floor,x=p.x,y=p.y}
    end
    local steps={}
    for i=#kinds,1,-1 do
        local a,b=points[#kinds-i+1],points[#kinds-i+2]
        steps[#steps+1]={floor=(a.floor==b.floor) and a.floor or nil,x1=a.x,y1=a.y,x2=b.x,y2=b.y,
            kind=kinds[i]}
    end
    return {points=points,edges=steps,cost=cost[finish],source=s,target=t},nil
end

local function turnInfo(a,b,c)
    if not a or not b or not c or a.floor~=b.floor or b.floor~=c.floor then return nil end
    local vx,vy=b.x-a.x,(b.y-a.y)*A
    local wx,wy=c.x-b.x,(c.y-b.y)*A
    local la,lb=math.sqrt(vx*vx+vy*vy),math.sqrt(wx*wx+wy*wy)
    if la<0.0005 or lb<0.0005 then return nil end
    local cross=vx*wy-vy*wx
    local cosine=(vx*wx+vy*wy)/(la*lb)
    if cosine>0.819 then return nil end -- <35 degrees: no instruction needed
    if cosine< -0.6 then return "뒤로 돌아가기","↶" end
    return cross>0 and "오른쪽으로" or "왼쪽으로",cross>0 and "↱" or "↰"
end
function N.BuildInstructions(solution,targetName)
    if not solution then return {} end
    local points=solution.points
    local steps={}
    local lastStep=0
    for i=2,#points-1 do
        local a,b,c=points[i-1],points[i],points[i+1]
        if b.floor~=c.floor then
            steps[#steps+1]={floor=b.floor,x=b.x,y=b.y,icon="↕",title="층 이동 지점",detail="목적지와 연결된 다른 층으로 이동",index=i}
            lastStep=i
        elseif a.floor~=b.floor then
            steps[#steps+1]={floor=b.floor,x=b.x,y=b.y,icon="↑",title="새 층 진입",detail="현재 층의 경로를 계속 따라가기",index=i}
            lastStep=i
        else
            local text,icon=turnInfo(a,b,c)
            local gap=(lastStep==0) or dist(points[lastStep].x,points[lastStep].y,b.x,b.y)>0.021 or
                points[lastStep].floor~=b.floor
            if text and gap then
                steps[#steps+1]={floor=b.floor,x=b.x,y=b.y,icon=icon,title="갈림길에서 "..text,
                    detail="지도 점선에 표시된 다음 통로로 이동",index=i}
                lastStep=i
            end
        end
    end
    local last=points[#points]
    if last then
        steps[#steps+1]={floor=last.floor,x=last.x,y=last.y,icon="◎",title=targetName or "목적지",
            detail="목표 위치 도착(지도 기준)",index=#points,arrival=true}
    end
    return steps
end

function N.Compute()
    N.dirty=false
    local route,key,d=N.Route()
    N.solution=nil;N.position=nil
    if not route or not d then N.problem="no_dungeon";return end
    if not N.graph or N.graph.route~=route then N.graph=N.BuildGraph(route) end
    if not N.graph or #N.graph.edges==0 then N.problem="no_route";return end
    local source,reason=N.PositionSource()
    N.position=source
    if not source then N.problem=reason;return end
    local entry,kind=N.TargetEntry()
    if not entry or type(entry.floor)~="number" or type(entry.x)~="number" or type(entry.y)~="number" then
        N.problem="target_missing";return
    end
    local result,err=N.Shortest(N.graph,source,{floor=entry.floor,x=entry.x,y=entry.y})
    if not result then N.problem=err;return end
    N.problem=nil
    result.instructions=N.BuildInstructions(result,N.EntryName(entry,kind,d))
    N.solution=result
end
function N.NextInstruction()
    if N.dirty then N.Compute() end
    return N.solution and N.solution.instructions and N.solution.instructions[1] or nil
end

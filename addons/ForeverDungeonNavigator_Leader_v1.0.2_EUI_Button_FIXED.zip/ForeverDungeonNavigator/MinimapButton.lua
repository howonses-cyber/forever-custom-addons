-- Floating launcher for EUI/OpenMap: intentionally parented to UIParent, not Minimap.
-- The default (Blizzard) Minimap frame can be hidden/replaced by UI packages.
local _, N = ...
local launcher
local lastDragAt = -100
local DEFAULT_X, DEFAULT_Y = -242, -110

local function config()
    if type(N.db) ~= "table" then return nil end
    N.db.launcher = N.db.launcher or {}
    return N.db.launcher
end

local function place(x, y, save)
    if not launcher then return end
    x, y = tonumber(x) or DEFAULT_X, tonumber(y) or DEFAULT_Y
    -- Keep the launcher visible if a user switches display resolution or UI scale.
    local width = UIParent:GetWidth() or 1024
    local height = UIParent:GetHeight() or 768
    x = math.max(-width + 145, math.min(-4, x))
    y = math.max(-height + 55, math.min(-4, y))
    launcher:ClearAllPoints()
    launcher:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", x, y)
    if save then
        local db = config()
        if db then db.x, db.y = x, y end
    end
end

local function openNavigator()
    if type(N.ToggleLeader) == "function" then
        N.ToggleLeader()
    elseif type(N.ShowLeader) == "function" then
        N.ShowLeader(true)
    elseif N.Print then
        N.Print("내비게이션 UI 로딩 중")
    end
end

local function toggleHud()
    if not N.db then return end
    N.db.autoHud = not N.db.autoHud
    if N.ShowHUD then N.ShowHUD(N.db.autoHud) end
end

local function makeLauncher()
    if launcher then return launcher end
    launcher = CreateFrame("Button", "ForeverDungeonNavigatorLauncher", UIParent)
    launcher:SetSize(137, 38)
    launcher:SetFrameStrata("DIALOG")
    launcher:SetFrameLevel(160)
    launcher:SetClampedToScreen(true)
    launcher:SetMovable(true)
    launcher:EnableMouse(true)
    launcher:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    launcher:RegisterForDrag("LeftButton")

    local bg = launcher:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(launcher)
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.03, 0.13, 0.17, 0.96)

    local rim = launcher:CreateTexture(nil, "BORDER")
    rim:SetPoint("TOPLEFT", launcher, "TOPLEFT", -1, 1)
    rim:SetPoint("BOTTOMRIGHT", launcher, "BOTTOMRIGHT", 1, -1)
    rim:SetTexture("Interface\\Buttons\\WHITE8X8")
    rim:SetVertexColor(0.10, 0.68, 0.60, 0.8)
    -- Render background above the rim while retaining the coloured border.
    bg:SetDrawLayer("BORDER", 1)
    rim:SetDrawLayer("BORDER", 0)
    bg:ClearAllPoints()
    bg:SetPoint("TOPLEFT", launcher, "TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", launcher, "BOTTOMRIGHT", -1, 1)

    local icon = launcher:CreateTexture(nil, "ARTWORK")
    icon:SetSize(26, 26)
    icon:SetPoint("LEFT", launcher, "LEFT", 7, 0)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")

    local caption = launcher:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    caption:SetPoint("LEFT", icon, "RIGHT", 6, 0)
    caption:SetText("던전 길찾기")
    caption:SetTextColor(0.95, 0.98, 0.95)

    local glow = launcher:CreateTexture(nil, "HIGHLIGHT")
    glow:SetAllPoints(launcher)
    glow:SetTexture("Interface\\Buttons\\WHITE8X8")
    glow:SetVertexColor(0.1, 0.8, 0.7, 0.20)
    glow:SetBlendMode("ADD")

    launcher:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("던전 길찾기", 0.24, 0.94, 0.72)
        GameTooltip:AddLine("왼쪽 클릭: 리딩창 열기/닫기", 1, 1, 1)
        GameTooltip:AddLine("Shift + 왼쪽 클릭: 원본 던전 지도", 1, 1, 1)
        GameTooltip:AddLine("오른쪽 클릭: 길찾기 HUD 켜기/끄기", 1, 1, 1)
        GameTooltip:AddLine("드래그: 버튼 이동 (위치 저장)", 0.75, 0.75, 0.75)
        GameTooltip:Show()
    end)
    launcher:SetScript("OnLeave", function()
        if GameTooltip then GameTooltip:Hide() end
    end)
    launcher:SetScript("OnClick", function(_, key)
        if GetTime and GetTime() - lastDragAt < 0.25 then return end
        if key == "RightButton" then
            toggleHud()
        elseif IsShiftKeyDown and IsShiftKeyDown() then
            if N.ShowMap then N.ShowMap() else openNavigator() end
        else
            openNavigator()
        end
    end)
    launcher:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    launcher:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        lastDragAt = GetTime and GetTime() or 0
        local pRight = UIParent:GetRight() or UIParent:GetWidth() or 1024
        local pTop = UIParent:GetTop() or UIParent:GetHeight() or 768
        local x = (self:GetRight() or (pRight + DEFAULT_X)) - pRight
        local y = (self:GetTop() or (pTop + DEFAULT_Y)) - pTop
        place(x, y, true)
    end)
    local db = config()
    place(db and db.x or DEFAULT_X, db and db.y or DEFAULT_Y, false)
    launcher:Show()
    return launcher
end

function N.ShowLauncher()
    makeLauncher():Show()
end

function N.ResetLauncher()
    makeLauncher()
    place(DEFAULT_X, DEFAULT_Y, true)
    launcher:Show()
end

-- Supports the old function name used in earlier revisions.
function N.ShowMinimapButton(visible)
    if visible == false then
        if launcher then launcher:Hide() end
    else
        N.ShowLauncher()
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:SetScript("OnEvent", function()
    -- Create on login; reinforce visibility on world entry after UI reloads.
    N.ShowLauncher()
end)

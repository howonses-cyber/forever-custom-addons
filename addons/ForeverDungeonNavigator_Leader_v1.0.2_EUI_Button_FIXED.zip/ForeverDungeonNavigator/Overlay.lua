-- Draws ONLY the computed remaining route on the upstream dungeon map canvas.
-- Never intercepts clicks; the upstream Shift-click marker and zoom keep working.
local _, N = ...
local W,H=1002,668
local cover,parent,lines,used,lastSignature=nil,nil,{},0,nil
local MAX_DASHES=700
local function hide()
    if cover then cover:Hide() end
    for i=1,used do if lines[i] then lines[i]:Hide() end end
    used=0
end
local function ensure(view)
    if cover and parent==view.layer then return end
    if cover then cover:Hide() end
    parent=view.layer
    cover=CreateFrame("Frame",nil,parent)
    cover:SetAllPoints(parent)
    cover:EnableMouse(false)
    cover:SetFrameLevel(parent:GetFrameLevel()+3)
    lines={};used=0;lastSignature=nil
end
local function line(a,b,view,r,g,c,alpha)
    if used>=MAX_DASHES then return end
    if not a or not b then return end
    used=used+1
    local l=lines[used]
    if not l then l=cover:CreateLine(nil,"OVERLAY");lines[used]=l end
    l:SetStartPoint("TOPLEFT",cover,a.x*W,-a.y*H)
    l:SetEndPoint("TOPLEFT",cover,b.x*W,-b.y*H)
    l:SetThickness(math.max(1.5,3.6/(view.scale or 1)))
    l:SetColorTexture(r,g,c,alpha)
    l:Show()
end
local function drawDashes(edge,view)
    if not edge.floor or edge.kind=="floor" then return end
    local dx,dy=(edge.x2-edge.x1)*W,(edge.y2-edge.y1)*H
    local total=math.sqrt(dx*dx+dy*dy)
    if total<0.01 then return end
    local scale=math.max(0.2,view.scale or 1)
    local dash=9/scale
    local gap=5/scale
    local pos=0
    while pos<total and used<MAX_DASHES do
        local hi=math.min(pos+dash,total)
        local t1,t2=pos/total,hi/total
        line({x=edge.x1+(edge.x2-edge.x1)*t1,y=edge.y1+(edge.y2-edge.y1)*t1},
            {x=edge.x1+(edge.x2-edge.x1)*t2,y=edge.y1+(edge.y2-edge.y1)*t2},
            view,0.19,0.95,0.77,0.97)
        pos=hi+gap
    end
end
function N.IsMapVisible()
    local d=N.FDR()
    local f=d and d.Window and d.Window.GetFrame and d.Window:GetFrame()
    return f and f:IsShown()
end
function N.RefreshOverlay()
    local d=N.FDR()
    local view=d and d.MapView
    if not view or not view.layer or not view.frame or not view.frame:IsShown() or
       not N.db or not N.db.showOverlay then hide();return end
    ensure(view)
    if N.dirty then N.Compute() end
    local sol=N.solution
    local _,key=N.Route()
    if not sol or view.key~=key or not view.floor then hide();return end
    local scale=view.scale or 1
    local sig=table.concat({tostring(sol),tostring(view.floor),string.format("%.3f",scale),tostring(N.db.showOverlay)},"|")
    cover:Show()
    if lastSignature==sig then return end
    lastSignature=sig
    for i=1,used do lines[i]:Hide() end
    used=0
    for _,e in ipairs(sol.edges) do
        if e.floor==view.floor then drawDashes(e,view) end
    end
end

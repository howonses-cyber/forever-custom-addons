-- Explicit, opt-in target sharing. Does not share guessed positions or auto-overwrite a route.
local _, N = ...
local PREFIX="FDNAV1"
local lastSend=0
local frame=CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("CHAT_MSG_ADDON")
local function isGroup()
    return type(IsInGroup)=="function" and N.Safe(IsInGroup())==true
end
local function inRaid()
    return type(IsInRaid)=="function" and N.Safe(IsInRaid())==true
end
local function groupCount()
    local count=type(GetNumGroupMembers)=="function" and N.Safe(GetNumGroupMembers()) or 0
    return type(count)=="number" and math.max(0,math.min(40,count)) or 0
end
local function send(prefix,message,channel)
    if C_ChatInfo and type(C_ChatInfo.SendAddonMessage)=="function" then
        return C_ChatInfo.SendAddonMessage(prefix,message,channel)
    elseif type(SendAddonMessage)=="function" then
        return SendAddonMessage(prefix,message,channel)
    end
end
function N.SendGoal()
    if not isGroup() then N.Print("파티 상태에서만 목적지를 공유할 수 있어요.");return end
    local route,key=N.Route()
    local entry,kind,index=N.TargetEntry()
    if not key or not entry or type(index)~="number" or not kind then
        N.Print("공유할 목적지를 선택해 주세요.");return
    end
    local now=GetTime and GetTime() or 0
    if now-lastSend<3 then N.Print("목적지 전송은 3초 간격으로 가능합니다.");return end
    lastSend=now
    local message=table.concat({"1",tostring(key),tostring(route.id or "default"),kind,tostring(index)},";")
    send(PREFIX,message,inRaid() and "RAID" or "PARTY")
    N.Print("파티에 목적지를 보냈어. 같은 애드온을 쓰는 파티원은 수락해야 적용돼.")
end
local function isTrustedSender(sender)
    if type(sender)~="string" or #sender>90 or not isGroup() then return false end
    for i=1,groupCount() do
        local unit=inRaid() and ("raid"..i) or ("party"..i)
        local name=(UnitName and N.Safe(UnitName(unit))) or nil
        if type(name)=="string" and
           (name==sender or sender:sub(1,#name+1)==name.."-") then return true end
    end
    return false
end
frame:SetScript("OnEvent",function(_,event,prefix,message,channel,sender)
    if event=="PLAYER_LOGIN" then
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
        elseif RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(PREFIX) end
        return
    end
    if event~="CHAT_MSG_ADDON" or prefix~=PREFIX or type(message)~="string" or #message>120 then return end
    if channel~="PARTY" and channel~="RAID" then return end
    if not isTrustedSender(sender) then return end
    local version,key,routeId,kind,n=message:match("^(%d+);([^;]+);([^;]+);([%a]+);(%d+)$")
    n=tonumber(n)
    local d=N.FDR()
    if version~="1" or not d or not d:GetDungeon(key) or (kind~="boss" and kind~="note" and kind~="link" and kind~="exit") or
       not n or n>300 or (kind=="exit" and n~=0) or (kind~="exit" and n<1) then return end
    local route=d:GetActiveRoute(key)
    if not route or tostring(route.id)~=routeId then
        N.Print("공유된 목표의 경로 버전이 내 경로와 달라서 적용하지 않았어. 같은 경로를 선택해야 해.")
        return
    end
    local list=(kind=="note") and route.notes or (kind=="link") and route.links or route.stops
    if kind~="exit" and (not list or not list[n]) then return end
    N.incoming={key=key,kind=kind,index=n,sender=sender}
    N.Print(sender.." 님이 목적지를 보냈어. /dnav 를 열어 '공유 목표 수락'을 눌러.")
    if N.RefreshUI then N.RefreshUI() end
end)
function N.AcceptGoal()
    local t=N.incoming
    if not t then return end
    N.incoming=nil
    N.SetTarget(t.kind,t.index,t.key)
    N.Print("공유 목적지를 적용했어.")
end

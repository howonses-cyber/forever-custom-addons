-- Forever Dungeon Navigator: controlled integration, no replacement of existing map addons.
local ADDON, N = ...
_G.ForeverDungeonNavigator = N
N.addon = ADDON
N.version = "1.0.2-beta"
N.activeKey = nil
N.target = nil
N.graph = nil
N.solution = nil
N.position = nil
N.uiReady = false
N.connected = false
N.dirty = true
N.searchPage = 1
N.searchText = ""
N.cdb = nil
N.db = nil

local function safe(v)
    if type(issecretvalue) == "function" and issecretvalue(v) then return nil end
    return v
end
N.Safe = safe
N.Normal = function(v) return tostring(v or ""):lower():gsub("[%s%p%c]", "") end
N.Clamp = function(n,lo,hi) return math.max(lo,math.min(hi,n)) end
function N.Print(s)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff4bd5bf[던전 내비]|r " .. tostring(s))
    end
end
function N.FDR()
    local d = _G.ForeverDungeonRoutes
    if type(d) == "table" and type(d.GetActiveRoute) == "function" and
        type(d.GetDungeon) == "function" and type(d.GetMarker) == "function" and
        type(d.Window) == "table" and type(d.MapView) == "table" then return d end
end
function N.Route()
    local d = N.FDR()
    local key = N.activeKey or (d and d.currentKey)
    local route = d and key and d:GetActiveRoute(key)
    return route,key,d
end
function N.EntryName(entry,kind,d)
    if not entry then return "미선택" end
    if kind == "note" then return (d and d.LocText and d.LocText(entry,"text")) or entry.textKO or entry.text or "메모" end
    if kind == "link" then return entry.label or "층 이동" end
    if kind == "exit" then return "던전 입구(복귀용)" end
    return (d and d.GetStopName and d:GetStopName(entry)) or entry.nameKO or entry.name or "보스"
end
function N.TargetEntry()
    local route,key,d=N.Route()
    if not route or not d then return nil end
    if N.target and N.target.key==key then
        if N.target.kind=="boss" and d.IsStopDone and
            d:IsStopDone(key,route,N.target.index) then
            N.target=nil
            if N.cdb and N.cdb.targets then N.cdb.targets[key]=nil end
        end
    end
    if N.target and N.target.key==key and N.target.kind=="exit" then
        for _,path in ipairs(route.paths or {}) do
            if path.kind=="main" and path.pts and #path.pts>=2 then
                return {floor=path.floor,x=path.pts[1],y=path.pts[2],name="던전 입구(복귀용)"},"exit",0
            end
        end
    end
    if N.target and N.target.key==key then
        local list=(N.target.kind=="note") and route.notes or
            (N.target.kind=="link") and route.links or route.stops
        local entry=list and list[N.target.index]
        if entry then return entry,N.target.kind,N.target.index end
    end
    if type(d.GetNextStopIndex)=="function" then
        local index=d:GetNextStopIndex(key,route)
        if index and route.stops and route.stops[index] then
            return route.stops[index],"boss",index
        end
        local hadBoss=false
        for _,s in ipairs(route.stops or {}) do if s.kind=="boss" then hadBoss=true end end
        if hadBoss then
            for _,path in ipairs(route.paths or {}) do
                if path.kind=="main" and path.pts and #path.pts>=2 then
                    return {floor=path.floor,x=path.pts[1],y=path.pts[2],name="던전 입구(복귀용)"},"exit",0
                end
            end
        end
    end
    for i,s in ipairs(route.stops or {}) do
        if s.kind=="boss" then return s,"boss",i end
    end
    return (route.stops or {})[1],"boss",1
end
function N.SetDungeon(key)
    local d=N.FDR()
    if not d or not key or not d:GetDungeon(key) then return false end
    if key~=N.activeKey then
        N.activeKey=key
        N.target=nil
        local old=N.cdb and N.cdb.targets and N.cdb.targets[key]
        local route=d:GetActiveRoute(key)
        if old and route and old.routeId==route.id then
            local list=old.kind=="note" and route.notes or old.kind=="link" and route.links or route.stops
            if old.kind=="exit" or (list and list[old.index]) then
                N.target={kind=old.kind,index=old.index,key=key}
            end
        end
        N.graph=nil
        N.solution=nil
        if N.db then N.db.lastDungeon=key end
        N.dirty=true
        N.RefreshAll()
    end
    return true
end
function N.SetTarget(kind,index,key)
    if key and N.activeKey~=key and not N.SetDungeon(key) then return false end
    local route,k=N.Route()
    if not route then return false end
    local list=(kind=="note") and route.notes or (kind=="link") and route.links or route.stops
    if kind~="exit" and (not list or not list[index]) then return false end
    if kind=="exit" then index=0 end
    N.target={kind=kind,index=index,key=k}
    if N.cdb then
        N.cdb.targets=N.cdb.targets or {}
        N.cdb.targets[k]={kind=kind,index=index,routeId=route.id}
    end
    N.dirty=true
    N.RefreshAll()
    N.FocusTarget()
    return true
end
function N.FocusTarget()
    local entry,kind,index=N.TargetEntry()
    local _,key,d=N.Route()
    if not entry or not d or not d.Window or not key then return end
    d.Window:Open(key,entry.floor)
    if entry.floor and d.Window.SelectFloor then d.Window:SelectFloor(entry.floor,true) end
    if kind=="boss" and d.Window.FocusStop then
        d.Window:FocusStop(index)
    elseif entry.x and entry.y and d.MapView.CenterOn then
        d.MapView:CenterOn(entry.x,entry.y,1.6)
    end
end
function N.ShowMap()
    local _,key,d=N.Route()
    if not d then N.Print("Forever Dungeon Routes 1.3.2 이상을 설치·활성화해 주세요.");return end
    if not key then N.Print("검색창에서 던전을 선택해 주세요.");return end
    d.Window:Open(key)
    if d.Window.GetFrame then
        local f=d.Window:GetFrame()
        if f then f:Raise() end
    end
end
function N.Mode()
    return N.db and N.db.mode or "boss"
end
function N.CycleMode()
    if not N.db then return end
    local old=N.Mode()
    N.db.mode=(old=="boss") and "quest" or (old=="quest") and "all" or "boss"
    N.searchPage=1
    N.RefreshAll()
end
function N.PositionSource()
    local route,key,d=N.Route()
    if not route or not d then return nil,"route_unavailable" end
    -- When the client really exposes a world position, use it; inside most dungeons it is nil.
    if key==d.currentKey and type(d.LocatePlayer)=="function" then
        local known,floor,x,y=d:LocatePlayer()
        if known==key and type(floor)=="number" and type(x)=="number" and type(y)=="number" then
            return {floor=floor,x=x,y=y,source="world",label="게임 제공 실시간 좌표"},"world"
        end
    end
    local marker=d:GetMarker(key)
    if marker and type(marker.floor)=="number" and type(marker.x)=="number" and type(marker.y)=="number" then
        local a=N.cdb and N.cdb.assumed and N.cdb.assumed[key]
        local label="지도 수동 마커"
        if a and a.floor==marker.floor and math.abs(a.x-marker.x)<0.0005 and math.abs(a.y-marker.y)<0.0005 then
            label=a.label or "수동 위치(추정)"
        end
        return {floor=marker.floor,x=marker.x,y=marker.y,source="marker",label=label},"marker"
    end
    local manual=N.cdb and N.cdb.manual and N.cdb.manual[key]
    if manual and type(manual.floor)=="number" and type(manual.x)=="number" and type(manual.y)=="number" then
        return {floor=manual.floor,x=manual.x,y=manual.y,source="manual",label="수동 지정 위치"},"manual"
    end
    if N.db and N.db.followRoom and key==d.currentKey and d.Room and d.Room.Get then
        local room=d.Room:Get()
        if room and d.Room.MainFloor and d.Room.Center then
            local floor=d.Room:MainFloor(room)
            local x,y=floor and d.Room:Center(room,floor)
            if x and y then return {floor=floor,x=x,y=y,source="room",label="방 이름 기준 대략 위치"},"room" end
        end
    end
    if d.IsStopDone then
        for i=#(route.stops or {}),1,-1 do
            local s=route.stops[i]
            if s and s.kind=="boss" and d:IsStopDone(key,route,i) and s.floor and s.x and s.y then
                return {floor=s.floor,x=s.x,y=s.y,source="boss",label="마지막 보스 처치 지점(추정)"},"boss"
            end
        end
    end
    local main
    for _,p in ipairs(route.paths or {}) do if p.kind=="main" and #p.pts>=2 then main=p; break end end
    if main then
        return {floor=main.floor,x=main.pts[1],y=main.pts[2],source="start",label="입구 가정(현재 위치 미확인)"},"start"
    end
    return nil,"missing"
end
function N.MarkAt(floor,x,y,label)
    local _,key,d=N.Route()
    if not d or not key or type(floor)~="number" or type(x)~="number" or type(y)~="number" then return false end
    x,y=N.Clamp(x,0,1),N.Clamp(y,0,1)
    N.cdb.assumed=N.cdb.assumed or {}
    N.cdb.assumed[key]={floor=floor,x=x,y=y,label=label or "내가 지정한 위치"}
    if d.SetMarker then
        d:SetMarker(key,floor,x,y)
    else
        N.cdb.manual[key]={floor=floor,x=x,y=y}
    end
    N.dirty=true
    N.RefreshAll()
    return true
end
function N.ResetPosition()
    local _,key,d=N.Route()
    if not key or not d then return end
    if d.ClearMarker then d:ClearMarker(key) end
    if N.cdb then
        if N.cdb.manual then N.cdb.manual[key]=nil end
        if N.cdb.assumed then N.cdb.assumed[key]=nil end
    end
    N.dirty=true
    N.RefreshAll()
end
function N.Step(delta)
    local _,key=N.Route()
    if not key or not N.cdb then return end
    N.cdb.history=N.cdb.history or {}
    N.cdb.history[key]=N.cdb.history[key] or {}
    local h=N.cdb.history[key]
    if delta and delta<0 then
        local before=h[#h]
        if not before then N.Print("되돌릴 수동 이동 기록이 없습니다.");return end
        h[#h]=nil
        N.MarkAt(before.floor,before.x,before.y,"이전 확인 위치(수동)")
        return
    end
    if N.dirty then N.Compute() end
    local steps=N.solution and N.solution.instructions or {}
    if #steps==0 then N.Print("경로를 먼저 선택해 주세요.");return end
    local s=steps[1]
    if not s then N.Print("다음 이동 지점이 없습니다.");return end
    local current=N.position
    if current then
        h[#h+1]={floor=current.floor,x=current.x,y=current.y}
        if #h>30 then table.remove(h,1) end
    end
    N.MarkAt(s.floor,s.x,s.y,"단계 이동 버튼으로 지정(추정)")
    N.Print("'"..tostring(s.title).."' 지점에 도착했다고 수동 지정했어. 실제 위치와 일치하는지 확인해.")
end
function N.RefreshAll()
    N.dirty=true
    if N.RefreshUI then N.RefreshUI() end
    if N.RefreshHUD then N.RefreshHUD() end
    if N.RefreshOverlay then N.RefreshOverlay() end
end
local registered=false
function N.Connect()
    local d=N.FDR()
    if not d then return false end
    if not registered and d.On then
        registered=true
        d:On("DUNGEON_CHANGED",function(key)
            if key then
                N.SetDungeon(key)
                if N.db and N.db.autoHud and N.ShowHUD then N.ShowHUD(true) end
                if N.db and N.db.autoPanel and N.ShowLeader then N.ShowLeader(true) end
            else
                if N.db and N.db.autoHud and N.ShowHUD then N.ShowHUD(false) end
                N.RefreshAll()
            end
        end)
        for _,event in ipairs({"MARKER_CHANGED","PROGRESS_CHANGED","ROOM_CHANGED","ROUTE_CHANGED","GROUP_ROOMS_CHANGED"}) do
            d:On(event,function(changed)
                if event=="ROUTE_CHANGED" then
                    N.graph=nil
                    N.target=nil
                    if N.cdb and N.cdb.targets and type(changed)=="string" then
                        N.cdb.targets[changed]=nil
                    end
                end
                if not changed or type(changed)~="string" or changed==N.activeKey then
                    N.RefreshAll()
                end
            end)
        end
    end
    N.connected=true
    if d.currentKey then N.SetDungeon(d.currentKey)
    elseif not N.activeKey and N.db and N.db.lastDungeon then N.SetDungeon(N.db.lastDungeon) end
    return true
end
local function init()
    ForeverDungeonNavigatorGlobalDB=ForeverDungeonNavigatorGlobalDB or {}
    ForeverDungeonNavigatorDB=ForeverDungeonNavigatorDB or {}
    N.db=ForeverDungeonNavigatorGlobalDB
    N.cdb=ForeverDungeonNavigatorDB
    if N.db.mode~="boss" and N.db.mode~="quest" and N.db.mode~="all" then N.db.mode="boss" end
    if N.db.followRoom==nil then N.db.followRoom=true end
    if N.db.showOverlay==nil then N.db.showOverlay=true end
    if N.db.autoHud==nil then N.db.autoHud=true end
    if N.db.autoPanel==nil then N.db.autoPanel=false end
    N.cdb.manual=N.cdb.manual or {}
    N.cdb.targets=N.cdb.targets or {}
end
local evt=CreateFrame("Frame")
evt:RegisterEvent("ADDON_LOADED")
evt:RegisterEvent("PLAYER_LOGIN")
evt:RegisterEvent("PLAYER_ENTERING_WORLD")
evt:SetScript("OnEvent",function(_,event,addon)
    if event=="ADDON_LOADED" and addon==ADDON then init() end
    if (event=="PLAYER_LOGIN" or event=="PLAYER_ENTERING_WORLD" or
        (event=="ADDON_LOADED" and addon=="ForeverDungeonRoutes")) and N.db then
        N.Connect()
        N.RefreshAll()
    end
end)
local elapsed=0
local watcher=CreateFrame("Frame")
watcher:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt
    if elapsed<0.8 then return end
    elapsed=0
    if N.db and N.FDR() then
        local _,key,d=N.Route()
        if d.currentKey and d.currentKey~=N.activeKey then N.SetDungeon(d.currentKey) end
        if (N.IsVisible and N.IsVisible()) or (N.IsMapVisible and N.IsMapVisible()) then
            if d.currentKey and type(d.LocatePlayer)=="function" then
                local known,floor,x,y=d:LocatePlayer()
                local old=N.position
                if known==d.currentKey and type(x)=="number" and type(y)=="number" and
                   type(floor)=="number" and (not old or old.source~="world" or old.floor~=floor or
                   math.abs(old.x-x)+math.abs(old.y-y)>0.003) then
                    N.dirty=true
                end
            end
            N.RefreshUI()
            N.RefreshHUD()
            N.RefreshOverlay()
        end
    end
end)
SLASH_FOREVERDUNGEONNAVIGATOR1="/dnav"
SLASH_FOREVERDUNGEONNAVIGATOR2="/던전길"
SlashCmdList.FOREVERDUNGEONNAVIGATOR=function(raw)
    local cmd=tostring(raw or ""):gsub("^%s+",""):gsub("%s+$","")
    if cmd=="button" or cmd=="버튼" then
        if N.ResetLauncher then N.ResetLauncher() end
        N.Print("화면 오른쪽 상단에 '던전 길찾기' 버튼을 표시했습니다.")
    elseif cmd=="hud" then
        N.db.autoHud=not N.db.autoHud
        if N.ShowHUD then N.ShowHUD(N.db.autoHud) end
    elseif cmd=="reset" then
        N.ResetPosition()
    elseif cmd=="auto" then
        N.db.autoPanel=not N.db.autoPanel
        N.Print(N.db.autoPanel and "입장 시 큰 지도+리딩 자동 열기 ON" or "입장 시 자동 열기 OFF")
    elseif cmd=="next" then N.Step(1)
    elseif cmd=="prev" then N.Step(-1)
    elseif cmd=="map" then N.ShowMap()
    elseif cmd=="line" then
        N.db.showOverlay=not N.db.showOverlay
        N.Print(N.db.showOverlay and "남은 경로 점선 ON" or "남은 경로 점선 OFF")
        N.RefreshAll()
    elseif cmd=="status" then
        local _,key,d=N.Route()
        N.Print(d and ("경로 엔진 연결 / 던전="..tostring(key or "미선택")) or "경로 엔진 미설치")
    else
        if N.ShowLeader then N.ShowLeader(true) else N.Print("로딩 중입니다.") end
    end
end

-- Optional keyboard shortcuts under Key Bindings > AddOns.
BINDING_HEADER_FOREVERDUNGEONNAVIGATOR = "포에버 던전 내비게이션"
BINDING_NAME_FDNAV_TOGGLE = "던전 리딩 지도 열기"
BINDING_NAME_FDNAV_NEXT = "다음 이동 지점 수동 확인"
BINDING_NAME_FDNAV_HUD = "던전 방향 안내 켜기/끄기"
function ForeverDungeonNavigator_Toggle() if N.ShowLeader then N.ShowLeader(true) end end
function ForeverDungeonNavigator_Next() N.Step(1) end
function ForeverDungeonNavigator_HUD()
    if N.db then N.db.autoHud=not N.db.autoHud end
    if N.ShowHUD then N.ShowHUD(N.db and N.db.autoHud) end
end

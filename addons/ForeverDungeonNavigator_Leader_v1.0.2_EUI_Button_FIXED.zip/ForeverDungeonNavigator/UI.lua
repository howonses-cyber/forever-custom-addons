-- Leader-oriented controls. Original map and marker stay owned by Forever Dungeon Routes.
local _, N = ...
local panel,hud
local title,subzone,bossLine,positionLine,guideTitle,guideDetail,noteText,statusText,modeButton
local search,results={},{}
local rows={}
local resultPage=1
local suppress=false
local listSignature=nil
local prompt="보스, 던전, 방 이름 검색"
local WHITE="Interface\\Buttons\\WHITE8X8"
local function style(frame)
    if frame.SetBackdrop then
        frame:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
           edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=13,
           insets={left=4,right=4,top=4,bottom=4}})
        frame:SetBackdropColor(.025,.038,.050,.97)
        frame:SetBackdropBorderColor(.27,.59,.60,1)
    end
end
local function text(parent,font,x,y,w,h,content)
    local t=parent:CreateFontString(nil,"OVERLAY",font)
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,-y)
    t:SetSize(w,h)
    t:SetJustifyH("LEFT")
    t:SetJustifyV("TOP")
    t:SetWordWrap(true)
    if content then t:SetText(content) end
    return t
end
local function btn(parent,label,x,y,w,h,click)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,-y)
    b:SetSize(w,h)
    b:SetText(label)
    if click then b:SetScript("OnClick",click) end
    return b
end
local function bar(parent,y,h,r,g,b,a)
    local f=CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",8,-y)
    f:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-8,-y)
    f:SetHeight(h)
    local bg=f:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(r,g,b,a or .65)
    return f
end
local function savePosition(f,prefix)
    if not N.db then return end
    N.db[prefix.."X"]=f:GetLeft()
    N.db[prefix.."Y"]=f:GetTop()
end
local function locate(f,prefix,point,x,y)
    f:ClearAllPoints()
    if N.db and type(N.db[prefix.."X"])=="number" and type(N.db[prefix.."Y"])=="number" then
        f:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",N.db[prefix.."X"],N.db[prefix.."Y"])
    else
        f:SetPoint(point,UIParent,point,x,y)
    end
end
local function dragHead(f,prefix,width)
    local d=CreateFrame("Frame",nil,f)
    d:SetPoint("TOPLEFT",f,"TOPLEFT",5,-4)
    d:SetSize(width,28)
    d:EnableMouse(true)
    d:RegisterForDrag("LeftButton")
    d:SetScript("OnDragStart",function()f:StartMoving()end)
    d:SetScript("OnDragStop",function()f:StopMovingOrSizing();savePosition(f,prefix)end)
end
local function currentTitle()
    local _,key,d=N.Route()
    if d and key then return d:GetKeyName(key) end
    return "던전을 검색해 선택하세요"
end
local function targetTitle()
    local entry,kind=N.TargetEntry()
    local _,_,d=N.Route()
    return N.EntryName(entry,kind,d)
end
local function currentRoom()
    local _,key,d=N.Route()
    if not d or not key or key~=d.currentKey then return "던전 밖 / 미확인" end
    if d.Room and d.Room.Get then
        local room=d.Room:Get()
        if room then return (d.LocText and d.LocText(room,"name")) or room.name or "현재 방" end
    end
    return "방 이름을 제공하지 않음"
end
local function warningText()
    local t={
        no_dungeon="경로 엔진 또는 던전 선택 없음",
        no_route="이 던전에는 추적 가능한 경로선이 없음",
        source_off_route="현재 위치가 기록된 통로와 멀리 떨어짐. 지도에서 마커를 옮겨 줘.",
        target_off_route="선택한 목표가 기록된 통로 밖에 있어. 지도 핀은 확인할 수 있지만 자동 경로는 없음.",
        disconnected="기록된 통로가 서로 연결되지 않아 경로를 계산할 수 없음. 다른 층/갈림길을 확인해 줘.",
        target_missing="선택한 목표의 지도 좌표가 없음",
        missing="현재 위치와 입구 경로가 없음",
        route_unavailable="데이터 로딩 중"
    }
    return t[N.problem] or "위치를 수동 마커로 지정해야 정확히 안내할 수 있어."
end
local function currentNote()
    local entry,kind=N.TargetEntry()
    local _,_,d=N.Route()
    local v=entry and kind=="boss" and ((d and d.LocText and d.LocText(entry,"note")) or entry.noteKO or entry.note) or nil
    if type(v)=="string" and v~="" then return v end
    if kind=="note" then return "해당 위치의 메모를 목적지로 선택함. 원본 던전 지도에서 내용을 확인해." end
    if kind=="exit" then return "경로 첫 지점(입구)으로 돌아가는 참고 안내야. 실제 출구가 다른 던전도 있어." end
    return "보스 이름을 눌러 목표로 지정. 정예·보스 전투 전에는 원본 지도 핀의 설명을 확인해."
end
local function modeName()
    return ({boss="필수 보스",quest="퀘스트·메모",all="전체 지점"})[N.Mode()] or "필수 보스"
end
local function prefix(kind)
    return ({dungeon="[던전] ",boss="[보스] ",note="[메모] ",link="[층] ",room="[방] ",exit="[입구] "})[kind] or ""
end
local function searchAdd(kind,key,index,label,extra)
    if #results>=240 then return end
    results[#results+1]={kind=kind,key=key,index=index,label=label,entry=extra}
end
local function isMatch(s,w)
    return N.Normal(s):find(w,1,true)~=nil
end
local function findResults()
    results={}
    local d=N.FDR()
    if not d then return end
    local term=N.Normal(N.searchText)
    local key=N.activeKey or d.currentKey
    if key and N.db and N.db.recovery then
        for i,room in ipairs((d.Rooms and d.Rooms[key]) or {}) do
            local label=(d.LocText and d.LocText(room,"name")) or room.name
            if label and (term=="" or isMatch(label,term)) then
                searchAdd("room",key,i,label,room)
            end
        end
        resultPage=N.Clamp(resultPage,1,math.max(1,math.ceil(#results/6)))
        return
    end
    local scanAll=term~=""
    local function scan(k)
        local r=d:GetActiveRoute(k)
        if not r then return end
        if term=="" or isMatch("던전 입구 돌아가기 출구 복귀",term) then
            searchAdd("exit",k,0,"던전 입구(복귀용)")
        end
        local mode=N.Mode()
        for i,entry in ipairs(r.stops or {}) do
            local label=N.EntryName(entry,"boss",d)
            if (mode=="all" or entry.kind=="boss" or (mode=="quest" and entry.kind=="boss")) and
                (term=="" or isMatch(label,term) or isMatch(entry.name,term) or isMatch(entry.nameKO,term)) then
                searchAdd("boss",k,i,label,entry)
            end
        end
        if mode~="boss" then
            for i,entry in ipairs(r.notes or {}) do
                local label=N.EntryName(entry,"note",d)
                if term=="" or isMatch(label,term) or isMatch(entry.textKO,term) then
                    searchAdd("note",k,i,label,entry)
                end
            end
        end
        if mode=="all" then
            for i,entry in ipairs(r.links or {}) do
                local label=N.EntryName(entry,"link",d)
                if term=="" or isMatch(label,term) then searchAdd("link",k,i,label,entry) end
            end
        end
    end
    if scanAll then
        for _,dungeon in ipairs(d.Dungeons or {}) do
            local k=dungeon.key
            if isMatch(d:GetKeyName(k),term) or isMatch(k,term) then
                searchAdd("dungeon",k,0,d:GetKeyName(k))
            end
            scan(k)
        end
    elseif key then scan(key) end
    local pages=math.max(1,math.ceil(#results/6))
    resultPage=N.Clamp(resultPage,1,pages)
end
local function choose(r)
    if not r then return end
    if r.kind=="dungeon" then
        N.SetDungeon(r.key)
        N.searchText=""
        if search then suppress=true;search:SetText("");suppress=false end
        resultPage=1
        N.ShowMap()
    elseif r.kind=="room" then
        local d=N.FDR()
        local room=r.entry
        local floor=d and d.Room and d.Room.MainFloor and d.Room:MainFloor(room)
        local x,y=floor and d.Room:Center(room,floor)
        if floor and x and y then
            N.MarkAt(floor,x,y,"선택한 방의 대략적 중심")
            if N.db then N.db.recovery=false end
            N.searchText=""
            if search then suppress=true;search:SetText("");suppress=false end
            N.Print("방의 중앙으로 수동 위치를 지정했어. 실제 통로와 다르면 지도에서 Shift+클릭으로 고쳐 줘.")
        end
    else
        N.SetTarget(r.kind,r.index,r.key)
    end
    N.RefreshAll()
end
local function rebuildResults()
    local _,key=N.Route()
    listSignature=table.concat({key or "",N.searchText or "",N.Mode(),N.db and tostring(N.db.recovery) or ""},"|")
    findResults()
    local offset=(resultPage-1)*6
    for i=1,6 do
        local b=rows[i]
        local r=results[offset+i]
        if r then
            b:SetText(prefix(r.kind)..r.label)
            b:Show()
        else b:Hide() end
    end
end
local function makeHUD()
    hud=CreateFrame("Frame","ForeverDungeonLeaderHUD",UIParent,"BackdropTemplate")
    hud:SetFrameStrata("HIGH")
    hud:SetSize(360,104)
    hud:SetMovable(true);hud:EnableMouse(true);hud:SetClampedToScreen(true)
    style(hud)
    locate(hud,"hud","TOP",0,-115)
    dragHead(hud,"hud",307)
    text(hud,"GameFontNormalSmall",10,7,294,18,"|cff55dec3던전 길찾기 - 다음 행동|r")
    btn(hud,"X",326,5,25,23,function()
        if N.db then N.db.autoHud=false end
        N.ShowHUD(false)
    end)
    hud.icon=text(hud,"GameFontNormalHuge",12,32,54,42,"◎")
    hud.icon:SetTextColor(.35,1,.79)
    hud.main=text(hud,"GameFontHighlight",76,30,270,35,"현재 위치 확인 필요")
    hud.small=text(hud,"GameFontDisableSmall",76,73,275,25,"GPS 아님 · 지정 위치 기준")
    hud:Hide()
end
function N.ShowHUD(value)
    if not hud then return end
    if value then hud:Show() else hud:Hide() end
    N.RefreshHUD()
end
function N.RefreshHUD()
    if not hud or not hud:IsShown() then return end
    local inst=N.NextInstruction()
    local label=inst and inst.title or warningText()
    hud.icon:SetText(inst and inst.icon or "?")
    hud.main:SetText(label)
    local p=N.position
    hud.small:SetText((p and p.label or "위치 미확인").." · 자동 GPS 아님")
end
local function showMarkerHelp()
    N.ShowMap()
    N.Print("원본 큰 던전 지도에서 Shift + 왼쪽 클릭으로 현재 위치에 초록색 마커를 찍어. 옮기면 남은 점선 경로가 다시 계산돼.")
end
function N.DockMap()
    N.ShowMap()
    if not panel then return end
    local d=N.FDR();local map=d and d.Window and d.Window.GetFrame and d.Window:GetFrame()
    if not map then return end
    if type(InCombatLockdown)=="function" and InCombatLockdown() then
        N.Print("전투 중에는 창 재배치를 하지 않아. 전투가 끝난 뒤 다시 눌러.")
        return
    end
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if type(w)~="number" or w<980 then return end
    local panelW=464
    local mw=math.min(930,math.max(520,w-panelW-65))
    local gap=10
    local total=mw+panelW+gap
    local left=(w-total)/2
    local mh=math.min(610,h-75)
    if map.SetSize then map:SetSize(mw,mh) end
    map:ClearAllPoints()
    map:SetPoint("CENTER",UIParent,"CENTER",left+mw/2-w/2,4)
    panel:ClearAllPoints()
    panel:SetPoint("CENTER",UIParent,"CENTER",left+mw+gap+panelW/2-w/2,4)
    savePosition(panel,"panel")
    if d.MapView and d.MapView.Layout then d.MapView:Layout() end
    N.RefreshOverlay()
end
local function makePanel()
    panel=CreateFrame("Frame","ForeverDungeonLeaderPanel",UIParent,"BackdropTemplate")
    panel:SetFrameStrata("HIGH")
    panel:SetSize(464,646)
    panel:SetMovable(true);panel:EnableMouse(true);panel:SetClampedToScreen(true)
    style(panel)
    locate(panel,"panel","CENTER",300,0)
    dragHead(panel,"panel",408)
    text(panel,"GameFontNormalLarge",13,9,380,23,"|cff53d9bd던전 리딩 내비게이션|r")
    btn(panel,"X",431,7,25,22,function()panel:Hide()end)
    title=text(panel,"GameFontNormal",14,43,418,23,"던전 선택")
    subzone=text(panel,"GameFontHighlightSmall",14,67,430,22,"현재 방: 미확인")
    bossLine=text(panel,"GameFontHighlightSmall",14,89,430,25,"목표: 선택 없음")
    positionLine=text(panel,"GameFontDisableSmall",14,111,430,22,"지도 좌표 없음")
    btn(panel,"큰 지도 + 리딩",12,139,137,27,function()N.DockMap()end)
    btn(panel,"현재 위치 찍기",154,139,130,27,showMarkerHelp)
    btn(panel,"위치 초기화",289,139,88,27,function()N.ResetPosition()end)
    btn(panel,"HUD",382,139,67,27,function()
        if hud:IsShown() then N.db.autoHud=false;N.ShowHUD(false)
        else N.db.autoHud=true;N.ShowHUD(true) end
    end)
    local g=bar(panel,177,112,.07,.15,.18,.9)
    guideTitle=text(panel,"GameFontHighlightLarge",22,184,413,48,"현재 위치를 지도에서 지정하세요")
    guideTitle:SetTextColor(.40,1,.83)
    guideDetail=text(panel,"GameFontHighlightSmall",22,237,415,42,"통로의 갈림길, 계단, 층 이동을 안내합니다.")
    local b1=btn(panel,"이전 위치",12,299,104,25,function()N.Step(-1)end)
    btn(panel,"다음 구간 도착",121,299,123,25,function()N.Step(1)end)
    modeButton=btn(panel,"필수 보스",249,299,114,25,function()
        N.CycleMode();resultPage=1;rebuildResults()
    end)
    btn(panel,"파티 공유",368,299,81,25,function()N.SendGoal()end)
    local n=bar(panel,332,61,.14,.13,.09,.62)
    noteText=text(panel,"GameFontHighlightSmall",19,339,423,49,"보스·퀘스트 메모를 선택하세요.")
    text(panel,"GameFontNormalSmall",15,399,250,19,"|cff55dec3던전 · 보스 · 퀘스트 메모 · 방 검색|r")
    search=CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
    search:SetAutoFocus(false)
    search:SetMaxLetters(80)
    search:SetSize(420,25)
    search:SetPoint("TOPLEFT",panel,"TOPLEFT",21,-418)
    search:SetFontObject("GameFontHighlightSmall")
    search:SetScript("OnTextChanged",function(self)
        if suppress then return end
        N.searchText=self:GetText() or ""
        resultPage=1
        rebuildResults()
    end)
    search:SetScript("OnEnterPressed",function(self)
        self:ClearFocus()
        choose(results[(resultPage-1)*6+1])
    end)
    search:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    for i=1,6 do
        local ix=i
        local row=btn(panel,"",14,452+(i-1)*25,435,23,function()
            choose(results[(resultPage-1)*6+ix])
        end)
        local font=row:GetFontString()
        if font then font:SetFontObject(GameFontHighlightSmall) end
        rows[i]=row
    end
    btn(panel,"◀ 이전",14,606,86,26,function()
        resultPage=math.max(1,resultPage-1);rebuildResults()
    end)
    btn(panel,"다음 ▶",105,606,86,26,function()
        resultPage=math.min(math.max(1,math.ceil(#results/6)),resultPage+1);rebuildResults()
    end)
    btn(panel,"길 잃음: 방 검색",198,606,142,26,function()
        N.db.recovery=not N.db.recovery
        resultPage=1
        rebuildResults()
        N.Print(N.db.recovery and "방 이름 검색이 켜졌어. 실제 있는 방을 선택하거나 지도 Shift+클릭으로 지정해." or "방 검색을 종료했어.")
    end)
    btn(panel,"목표 수락",346,606,103,26,function()
        if N.incoming then N.AcceptGoal();N.RefreshAll()
        else N.Print("파티에서 공유받은 목표가 없어.") end
    end)
    statusText=text(panel,"GameFontDisableSmall",15,635,430,15,"Ctrl 없이 Shift+클릭: 현재 위치 표시 · 자동 GPS 아님")
    panel:Hide()
    rebuildResults()
end
function N.IsVisible()
    return panel and panel:IsShown() or hud and hud:IsShown()
end
function N.ShowLeader(alsoMap)
    if not panel then return end
    panel:Show()
    if alsoMap then N.DockMap() end
    N.RefreshUI()
end
function N.ToggleLeader()
    if not panel then
        N.Print("리딩창을 불러오는 중이야. 잠시 후 다시 눌러 줘.")
        return
    end
    if panel:IsShown() then
        panel:Hide()
    else
        N.ShowLeader(true)
    end
end
function N.RefreshUI()
    if not N.uiReady then return end
    if N.dirty then N.Compute() end
    if not panel then return end
    local _,key,d=N.Route()
    local sig=table.concat({key or "",N.searchText or "",N.Mode(),N.db and tostring(N.db.recovery) or ""},"|")
    if sig~=listSignature then resultPage=1;rebuildResults() end
    title:SetText(currentTitle())
    subzone:SetText("현재 구역: "..currentRoom())
    bossLine:SetText("목적지: "..targetTitle())
    local count,done=0,0
    local route=N.Route()
    if route and d then
        for i,entry in ipairs(route.stops or {}) do
            if entry.kind=="boss" then
                count=count+1
                if d.IsStopDone and d:IsStopDone(key,route,i) then done=done+1 end
            end
        end
    end
    local source=N.position and N.position.label or "현재 위치 미확인"
    positionLine:SetText("위치: "..source.."  |  보스 "..done.."/"..count)
    local inst=N.NextInstruction()
    if inst then
        guideTitle:SetText(inst.icon.."  "..inst.title)
        guideDetail:SetText(inst.detail or "남은 점선을 따라 진행하세요.")
    else
        guideTitle:SetText("?  "..warningText())
        guideDetail:SetText("정확한 GPS가 없어. 원본 지도 Shift+클릭으로 위치를 지정하면 경로를 계산해.")
    end
    noteText:SetText(currentNote())
    modeButton:SetText(modeName())
    local pageCount=math.max(1,math.ceil(#results/6))
    statusText:SetText("검색 "..#results.."건 · "..resultPage.."/"..pageCount.." 페이지"
       ..(N.incoming and "  |cff53ffa0공유받은 목표 있음|r" or "")
       ..(N.db and N.db.recovery and "  |cffd4bd60방 검색 ON|r" or ""))
end
local loader=CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent",function()
    makeHUD()
    makePanel()
    N.uiReady=true
    N.Connect()
    N.RefreshUI()
end)

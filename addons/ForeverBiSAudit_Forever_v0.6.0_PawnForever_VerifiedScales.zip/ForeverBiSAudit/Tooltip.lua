local _, B = ...
-- Compact *Pawn stat score* comparison; NOT a guessed total DPS percentage.
local initialized=false
local valid={
 INVTYPE_HEAD=true,INVTYPE_NECK=true,INVTYPE_SHOULDER=true,INVTYPE_CLOAK=true,
 INVTYPE_CHEST=true,INVTYPE_ROBE=true,INVTYPE_WRIST=true,INVTYPE_HAND=true,
 INVTYPE_WAIST=true,INVTYPE_LEGS=true,INVTYPE_FEET=true,INVTYPE_FINGER=true,
 INVTYPE_TRINKET=true,INVTYPE_WEAPON=true,INVTYPE_WEAPONMAINHAND=true,
 INVTYPE_WEAPONOFFHAND=true,INVTYPE_2HWEAPON=true,INVTYPE_SHIELD=true,
 INVTYPE_HOLDABLE=true,INVTYPE_RANGED=true,INVTYPE_RANGEDRIGHT=true,
 INVTYPE_RELIC=true,INVTYPE_THROWN=true,
}
local function equipmentSignature()
 if type(GetInventoryItemLink)~='function' then return '' end
 local out={}
 for _,i in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
  out[#out+1]=GetInventoryItemLink('player',i) or ''
 end
 return table.concat(out,'|')
end
local function tooltipItem(t,data)
 if t and type(t.GetItem)=='function' then
  local ok,_,link=pcall(t.GetItem,t)
  if ok and type(link)=='string' then return link end
 end
 if type(data)=='table' then
  if type(data.hyperlink)=='string' then return data.hyperlink end
  if type(data.id)=='number' and data.id>0 then return 'item:'..tostring(data.id) end
 end
end
local function shortSpec(cl,sp)
 if cl=='SHAMAN' then
  return ({enhancement='고술',elemental='정술',restoration='복술'})[sp.key] or sp.label
 end
 return sp.label
end
local function prettyPct(n)
 if math.abs(n)<.005 then return '0.0%' end
 local digits=math.abs(n)<.05 and 2 or 1
 return (n>0 and '+' or '')..string.format('%.'..digits..'f%%',n)
end
local function addToTooltip(tooltip,data)
 if not B.db or not B.db.showTooltip or not tooltip then return end
 if tooltip~=GameTooltip and tooltip~=ItemRefTooltip then return end
 if tooltip._fbisBusy then return end
 local link=tooltipItem(tooltip,data)
 if not link or not link:find('item:',1,true) then return end
 local loc=B:ResolveEquipLocation(link)
 if not valid[loc] then return end
 local cl=UnitClass and select(2,UnitClass('player')) or B.db.class
 if not B.specs[cl] then return end
 local key=link..'|'..cl..'|'..equipmentSignature()
 if tooltip._fbisSignature==key then return end
 tooltip._fbisSignature=key
 tooltip._fbisBusy=true
 local ok,err=pcall(function()
  tooltip:AddLine('Forever BiS |cffb9e4ffPawn 스탯 점수 교체 비교|r',1,.76,.25)
  if not B:PawnReady() then
   tooltip:AddLine('Pawn 2.14.8+ 필요 (CurseForge에서 직접 설치)',1,.62,.35,true)
   tooltip:AddLine('권장: Pawn Forever 가중치 애드온',.75,.8,.95,true)
   tooltip:AddLine('임의 DPS % 표시 중단: 스탯만으로 실제 DPS 알 수 없음',.8,.77,.67,true)
   return
  end
  local selected=B.db.class==cl and B.db.spec or nil
  local ordered={}
  for _,sp in ipairs(B.specs[cl]) do if sp.key==selected then ordered[#ordered+1]=sp end end
  for _,sp in ipairs(B.specs[cl]) do if sp.key~=selected then ordered[#ordered+1]=sp end end
  local baseline,hasProc,hasAny=nil,false,false
  local source='Pawn'
  for _,sp in ipairs(ordered) do
   local result,why=B:VerifiedEquipPercent(link,cl,sp.key,loc)
   local label=shortSpec(cl,sp)
   if result then
    hasAny=true
    baseline=baseline or result.comparedName
    hasProc=hasProc or result.proc
    source=result.source or source
    if result.pct~=nil then
     local n=result.pct
     local r,g,b=.77,.8,.85
     if n>0 then r,g,b=.25,1,.46 elseif n<0 then r,g,b=1,.36,.35 end
     tooltip:AddDoubleLine(label,prettyPct(n),1,1,1,r,g,b)
    else
     tooltip:AddDoubleLine(label,'기준 점수 0 · % 불가',1,1,1,1,.69,.36)
    end
   else
    tooltip:AddDoubleLine(label,why or '평가 불가',1,1,1,.98,.73,.42)
   end
  end
  if baseline then tooltip:AddLine('착용 기준: '..baseline,.62,.76,.9,true) end
  if hasProc then
   tooltip:AddLine('※ 발동 무기: 위 %는 스탯만. 실전 DPS 비교는 별도 시뮬 필요',.97,.7,.38,true)
  elseif hasAny then
   tooltip:AddLine('※ '..source..' 스탯 점수 % · 실전 DPS/HPS 변화율 아님',.74,.77,.81,true)
  end
 end)
 tooltip._fbisBusy=false
 if not ok and B.Print then B.Print('툴팁 계산 오류: '..tostring(err)) end
end
function B:SetupTooltips()
 if initialized then return end
 initialized=true
 local modern=TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall)=='function'
  and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item~=nil
 if modern then
  local ok=pcall(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,function(tip,data)
   addToTooltip(tip,data)
  end)
  if ok then
   for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
    if tip and tip.HookScript then
     pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
    end
   end
   return
  end
 end
 for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
  if tip and tip.HookScript then
   pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
   pcall(tip.HookScript,tip,'OnTooltipSetItem',function(self)addToTooltip(self)end)
  end
 end
end

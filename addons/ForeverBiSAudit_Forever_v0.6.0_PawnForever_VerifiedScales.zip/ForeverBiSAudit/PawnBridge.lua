local _, B = ...
-- Optional integration only. We DO NOT redistribute or modify Pawn/Pawn Forever.
-- All scores are obtained at runtime from Pawn's published functions and the
-- user's installed Pawn scales. This file contains no third-party addon code.
local equippedSlots = {
 INVTYPE_HEAD={1}, INVTYPE_NECK={2}, INVTYPE_SHOULDER={3},
 INVTYPE_CLOAK={15}, INVTYPE_CHEST={5}, INVTYPE_ROBE={5},
 INVTYPE_WRIST={9}, INVTYPE_HAND={10}, INVTYPE_WAIST={6},
 INVTYPE_LEGS={7}, INVTYPE_FEET={8}, INVTYPE_FINGER={11,12},
 INVTYPE_TRINKET={13,14}, INVTYPE_RELIC={18}, INVTYPE_RANGED={18},
 INVTYPE_RANGEDRIGHT={18}, INVTYPE_THROWN={18},
 INVTYPE_WEAPONMAINHAND={16}, INVTYPE_WEAPONOFFHAND={17},
 INVTYPE_HOLDABLE={17}, INVTYPE_SHIELD={17}, INVTYPE_WEAPON={16},
 INVTYPE_2HWEAPON={16,17},
}
local classIds={WARRIOR=1,PALADIN=2,HUNTER=3,ROGUE=4,PRIEST=5,
 SHAMAN=7,MAGE=8,WARLOCK=9,DRUID=11}
local specsForKey={
 DRUID={balance=1,['feral-cat']=2,['feral-bear']=2,restoration=3},
}
local function isNum(v) return type(v)=='number' and v==v and v<1e9 and v>-1e9 end
local function getLink(slot)
 if type(GetInventoryItemLink)~='function' then return nil end
 local ok,link=pcall(GetInventoryItemLink,'player',slot)
 return ok and type(link)=='string' and link or nil
end
local function itemId(link)
 return type(link)=='string' and link:match('item:(%d+)') or nil
end
local function sameItem(a,b)
 if not a or not b then return false end
 if a==b then return true end
 local ai,bi=itemId(a),itemId(b)
 return ai~=nil and ai==bi
end
local function itemName(link)
 if not link then return '미착용' end
 if type(B.GetEquippedName)=='function' then return B.GetEquippedName(link) end
 return link:match('|h%[(.-)%]|h') or '현재 장비'
end
local function scaleInfo(class,spec)
 local specs=B.specs[class]
 if not specs then return end
 local index=specsForKey[class] and specsForKey[class][spec] or nil
 if not index then
  for i,sp in ipairs(specs) do if sp.key==spec then index=i;break end end
 end
 return classIds[class],index
end
function B:PawnReady()
 return type(PawnGetItemData)=='function' and type(PawnGetItemValue)=='function' and
  type(PawnCommon)=='table' and type(PawnCommon.Scales)=='table'
end
function B:PawnScale(class,spec)
 if not self:PawnReady() then return nil,'Pawn 미설치 또는 아직 준비되지 않음' end
 local classID,index=scaleInfo(class,spec)
 if not classID or not index then return nil,'특성 미지원' end
 local best,bestPriority=nil,-1
 for name,scale in pairs(PawnCommon.Scales) do
  if type(name)=='string' and type(scale)=='table' and type(scale.Values)=='table' and
    scale.ClassID==classID and scale.SpecID==index then
   local pri=1
   -- Prefer Forever-aware scales. Then stock Pawn; never silently use an
   -- arbitrary custom scale belonging to a different character or role.
   local provider=scale.Provider
   if provider=='PawnForever' or name:find('PawnForever',1,true) then pri=3
   elseif provider=='Classic' or name:find('Classic',1,true) then pri=2 end
   if pri>bestPriority or (pri==bestPriority and best and name<best) then
    best,bestPriority=name,pri
   end
  end
 end
 if not best then return nil,'이 특성에 맞는 Pawn 척도 없음 (Pawn Forever 권장)' end
 return best,(bestPriority==3 and 'Pawn Forever' or 'Pawn')
end
local function pawnScore(link,scale)
 if not link then return nil,'장비 링크 없음' end
 -- PawnGetItemData parses tooltip weapon DPS, stats, and all supported native
 -- Forever stats. It is not a damage simulation and ignores most procs.
 local ok,item=pcall(PawnGetItemData,link)
 if not ok or type(item)~='table' or type(item.Stats)~='table' then
  return nil,'Pawn 아이템 캐시 로딩 중'
 end
 local ok2,value=pcall(PawnGetItemValue,item.Stats,item.Level or 0,
   item.SocketBonusStats,scale,false,true,true)
 if not ok2 or not isNum(value) then return nil,'Pawn 점수 계산 불가' end
 return value
end
function B:PawnScoreLink(link,scale) return pawnScore(link,scale) end
local function possibleProc(link)
 if not link then return false end
 -- These two item IDs were reported by the owner. Do not assign any guessed
 -- damage, proc probability or uptime from them.
 local id=tonumber(itemId(link))
 if id==870 or id==17766 then return true end
 if not (C_TooltipInfo and type(C_TooltipInfo.GetHyperlink)=='function') then return false end
 local ok,info=pcall(C_TooltipInfo.GetHyperlink,link)
 if not ok or type(info)~='table' or type(info.lines)~='table' then return false end
 for _,line in ipairs(info.lines) do
  for _,part in ipairs({line.leftText,line.rightText}) do
   if type(part)=='string' then
    local t=part:lower()
    if t:find('chance on hit',1,true) or t:find('공격 시',1,true) or
      t:find('발동 효과',1,true) or t:find('사용 효과',1,true) or
      t:find('use:',1,true) or t:find('proc',1,true) then return true end
   end
  end
 end
 return false
end
B.PawnHasUnscoredProc=possibleProc
local function isHandSlot(loc) return loc=='INVTYPE_2HWEAPON' or loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND' or loc=='INVTYPE_WEAPONOFFHAND' or loc=='INVTYPE_SHIELD' or loc=='INVTYPE_HOLDABLE' end
local function pickEquipped(self,link,loc,scale)
 local ids=equippedSlots[loc]
 if not ids then return nil,'장착 부위 확인 불가' end
 if type(GetInventoryItemLink)~='function' then return nil,'현재 착용 장비 조회 불가' end
 if isHandSlot(loc) and loc~='INVTYPE_2HWEAPON' then
  local main=getLink(16)
  local mloc=main and self:ResolveEquipLocation(main)
  if mloc=='INVTYPE_2HWEAPON' then
   return nil,'양손 무기 착용 중: 한손 단독 비교 불가'
  end
 end
 local options={}
 if loc=='INVTYPE_2HWEAPON' then
  local main=getLink(16)
  if not main then return nil,'현재 주무기 미착용' end
  local off=getLink(17)
  local all={main}
  if off then all[#all+1]=off end
  return all,nil,itemName(main)..(off and ' + '..itemName(off) or '')
 end
 local idSlots=ids
 if loc=='INVTYPE_WEAPON' then idSlots={16} end
 if loc=='INVTYPE_WEAPONOFFHAND' then idSlots={17} end
 for _,slot in ipairs(idSlots) do
  local current=getLink(slot)
  if not current then return nil,'현재 해당 슬롯 미착용' end
  if sameItem(link,current) then return {current},nil,itemName(current) end
  local sc,why=pawnScore(current,scale)
  if sc==nil then return nil,why end
  options[#options+1]={link=current,score=sc,slot=slot}
 end
 table.sort(options,function(a,b)
  if a.score==b.score then return a.slot<b.slot end
  return a.score<b.score
 end)
 local opt=options[1]
 if not opt then return nil,'현재 장비 미확인' end
 return {opt.link},nil,itemName(opt.link)
end
function B:VerifiedEquipPercent(link,class,spec,loc)
 local scale,source=self:PawnScale(class,spec)
 if not scale then return nil,source end
 local current,reason,currentName=pickEquipped(self,link,loc,scale)
 if not current then return nil,reason end
 local incoming,why=pawnScore(link,scale)
 if incoming==nil then return nil,why end
 local baseline=0
 local proc=possibleProc(link)
 local identical=false
 for _,wear in ipairs(current) do
  local points,err=pawnScore(wear,scale)
  if points==nil then return nil,err end
  baseline=baseline+points
  proc=proc or possibleProc(wear)
  if sameItem(wear,link) then identical=true end
 end
 if identical and #current==1 then
  return {pct=0,rawCandidate=incoming,rawEquipped=baseline,source=source,
   comparedName=currentName,proc=proc,mode='same',scale=scale}
 end
 if baseline==0 then
  if incoming==0 then
   return {pct=0,rawCandidate=0,rawEquipped=0,source=source,
    comparedName=currentName,proc=proc,mode='bothZero',scale=scale}
  end
  return {pct=nil,reason='착용템 점수가 0이라 % 계산 불가',delta=incoming,
   source=source,comparedName=currentName,proc=proc,mode='zeroBaseline',scale=scale}
 end
 local percent=(incoming-baseline)/baseline*100
 if not isNum(percent) or math.abs(percent)>10000 then return nil,'점수 이상치' end
 return {pct=percent,rawCandidate=incoming,rawEquipped=baseline,
  source=source,comparedName=currentName,proc=proc,mode='statScore',scale=scale}
end

-- Forever Nameplate Distance v1.0.0
-- Independent of EllesmereUI. Only writes the native client CVar
-- 'nameplateMaxDistance' on a deliberate user change or once at login
-- if the user previously saved a preference.
local ADDON = ...
local CVAR = "nameplateMaxDistance"
local DEFAULT = 45
local MINIMUM = 10
local MAXIMUM = 60

local db
local panel
local selected = DEFAULT
local queued
local loginScheduled = false
local internalSet = false

local function say(message)
    local text = "|cff71d5ffForever Nameplate Distance|r: " .. tostring(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    elseif print then
        print(text)
    end
end

local function cvarGet()
    local ok, value
    if C_CVar and type(C_CVar.GetCVar) == "function" then
        ok, value = pcall(C_CVar.GetCVar, CVAR)
    elseif type(GetCVar) == "function" then
        ok, value = pcall(GetCVar, CVAR)
    end
    if ok and value ~= nil and tostring(value) ~= "" then
        return tonumber(value)
    end
    return nil
end

local function cvarSet(value)
    if C_CVar and type(C_CVar.SetCVar) == "function" then
        return pcall(C_CVar.SetCVar, CVAR, tostring(value))
    elseif type(SetCVar) == "function" then
        return pcall(SetCVar, CVAR, tostring(value))
    end
    return false, "SetCVar API unavailable"
end

local function normalize(value)
    local n = tonumber(value)
    if not n or n ~= n or n == math.huge or n == -math.huge then return nil end
    n = math.floor(n + 0.5)
    if n < MINIMUM or n > MAXIMUM then return nil end
    return n
end

local function present()
    if not panel then return end
    local actual = cvarGet()
    panel.actual:SetText("현재 클라이언트 설정값: " .. (actual and (tostring(actual) .. "야드") or "조회 불가"))
    if not panel.edit:HasFocus() then panel.edit:SetText(tostring(selected)) end
    panel.slider:SetValue(selected)
    if queued then
        panel.status:SetText("전투 종료 후 " .. queued .. "야드 적용 대기")
        panel.status:SetTextColor(1, .78, .28)
    end
end

local function setStatus(message, red)
    if panel then
        panel.status:SetText(message)
        if red then panel.status:SetTextColor(1, .36, .32)
        else panel.status:SetTextColor(.68, .92, .72) end
    end
end

local function apply(value, source)
    local n = normalize(value)
    if not n then
        setStatus("10~60 사이의 정수 거리를 입력해 주세요.", true)
        if source == "chat" then say("10~60 사이 야드를 입력하세요. 예: /fnd 30") end
        return false
    end

    selected = n
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        queued = n
        setStatus("전투 중 변경은 보류됩니다. 전투 종료 후 적용합니다.")
        say("전투가 끝나면 " .. n .. "야드로 설정합니다.")
        present()
        return false
    end
    queued = nil
    internalSet = true
    local ok, result = cvarSet(n)
    internalSet = false
    if not ok or result == false then
        local reason = not ok and tostring(result) or "클라이언트 거부"
        setStatus("설정 변경 실패: 클라이언트가 요청을 거부했습니다.", true)
        say("거리 변경이 차단됐습니다 (" .. reason .. "). /console " .. CVAR .. " " .. n .. " 을 시도해 주세요.")
        present()
        return false
    end
    local actual = cvarGet()
    if not actual then
        setStatus("명령 전달됨. 클라이언트가 CVar 조회를 지원하지 않습니다.", true)
        say("명령을 전달했지만 설정값 재조회는 실패했습니다.")
        present()
        return false
    end
    if math.abs(actual - n) > .1 then
        setStatus("요청 " .. n .. "야드 / 현재 CVar " .. actual .. "야드 (제한 여부 확인)", true)
        say("요청: " .. n .. "야드, 현재 CVar: " .. actual .. "야드. 클라이언트가 값을 제한했을 수 있습니다.")
        selected = math.floor(actual + .5)
        if selected < MINIMUM then selected = MINIMUM end
        if selected > MAXIMUM then selected = MAXIMUM end
        present()
        return false
    end
    db = db or {}
    db.distance = n
    setStatus("설정값 저장됨: " .. n .. "야드. 게임에서 실제 표시 거리를 확인해 주세요.")
    if source ~= "login" then say("이름표 최대 표시 거리 CVar를 " .. n .. "야드로 설정했습니다.") end
    present()
    return true
end

local function label(parent, text, size, x, y)
    local f = parent:CreateFontString(nil, "OVERLAY", size or "GameFontNormal")
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    f:SetText(text)
    return f
end

local function button(parent, text, x, y, w, h, click)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, h)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", click)
    return b
end

local function createUI()
    if panel then return panel end
    local f = CreateFrame("Frame", "ForeverNameplateDistanceSettings", UIParent)
    f:SetSize(470, 310)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 55)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    if f.SetClampedToScreen then f:SetClampedToScreen(true) end
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(f)
    bg:SetColorTexture(.055, .071, .092, .96)
    local borderTop = f:CreateTexture(nil, "BORDER")
    borderTop:SetColorTexture(.75, .55, .24, 1)
    borderTop:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
    borderTop:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    borderTop:SetHeight(2)
    local borderBottom = f:CreateTexture(nil, "BORDER")
    borderBottom:SetColorTexture(.75, .55, .24, 1)
    borderBottom:SetPoint("BOTTOMLEFT", f)
    borderBottom:SetPoint("BOTTOMRIGHT", f)
    borderBottom:SetHeight(2)
    label(f, "이름표 최대 표시 거리", "GameFontNormalLarge", 22, -21)
    local desc = label(f, "투명도/사거리 검사가 아닌 실제 표시 거리 설정", "GameFontHighlightSmall", 23, -50)
    desc:SetTextColor(.70, .81, .90)

    local close = button(f, "X", 428, -11, 27, 26, function() f:Hide() end)
    close:SetFrameLevel(f:GetFrameLevel()+1)

    local slider = CreateFrame("Slider", "ForeverNameplateDistanceSlider", f, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", f, "TOPLEFT", 42, -103)
    slider:SetSize(306, 18)
    slider:SetMinMaxValues(MINIMUM, MAXIMUM)
    slider:SetValueStep(1)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    if _G[slider:GetName() .. "Low"] then _G[slider:GetName() .. "Low"]:SetText("10") end
    if _G[slider:GetName() .. "High"] then _G[slider:GetName() .. "High"]:SetText("60") end
    if _G[slider:GetName() .. "Text"] then _G[slider:GetName() .. "Text"]:SetText("야드 (10~60)") end

    local edit = CreateFrame("EditBox", "ForeverNameplateDistanceInput", f, "InputBoxTemplate")
    edit:SetSize(64, 24)
    edit:SetPoint("TOPLEFT", f, "TOPLEFT", 369, -97)
    edit:SetAutoFocus(false)
    edit:SetMaxLetters(3)
    edit:SetNumeric(true)
    edit:SetText(tostring(selected))
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEnterPressed", function(self)
        local n = normalize(self:GetText())
        if n then selected = n; slider:SetValue(n) end
        self:ClearFocus()
        apply(self:GetText(), "edit")
    end)
    slider:SetScript("OnValueChanged", function(_, v)
        selected = math.floor(v + .5)
        if not edit:HasFocus() then edit:SetText(tostring(selected)) end
    end)

    local actual = label(f, "현재 클라이언트 설정값: 조회 중", "GameFontHighlight", 30, -150)
    local status = label(f, "", "GameFontHighlightSmall", 30, -177)
    status:SetWidth(415)
    status:SetJustifyH("LEFT")
    status:SetTextColor(.68, .92, .72)

    button(f, "적용", 28, -210, 120, 31, function()
        local n = normalize(edit:GetText())
        if not n then setStatus("10~60 사이의 숫자를 입력해 주세요.", true); return end
        apply(n, "ui")
    end)
    button(f, "기본값 45", 164, -210, 125, 31, function()
        selected = DEFAULT
        edit:SetText(tostring(DEFAULT))
        slider:SetValue(DEFAULT)
        apply(DEFAULT, "ui")
    end)
    button(f, "현재값 확인", 304, -210, 139, 31, function()
        present()
        setStatus("클라이언트 CVar 값을 다시 읽었습니다.")
    end)
    local notice = label(f, "※ 게임/서버의 표시 한계를 넘길 수 없으며, 전투 중 변경은 보류됩니다.", "GameFontDisableSmall", 28, -272)
    notice:SetTextColor(.75, .78, .84)

    f.slider, f.edit, f.actual, f.status = slider, edit, actual, status
    f:SetScript("OnShow", function()
        local value = cvarGet()
        selected = normalize(value) or (db and normalize(db.distance)) or DEFAULT
        present()
    end)
    f:Hide()
    panel = f
    return f
end

local function openUI()
    local f = createUI()
    if f:IsShown() then f:Hide() else f:Show() end
end

SLASH_FOREVERNAMEPLATEDISTANCE1 = "/fnd"
SLASH_FOREVERNAMEPLATEDISTANCE2 = "/nameplatedistance"
SlashCmdList["FOREVERNAMEPLATEDISTANCE"] = function(msg)
    local trimmed = tostring(msg or ""):match("^%s*(.-)%s*$")
    local command = trimmed:lower()
    if trimmed == "" then openUI(); return end
    if command == "status" or command == "check" then
        local v = cvarGet()
        say("현재 이름표 최대 표시 거리 CVar: " .. (v and (v .. "야드") or "조회 실패") .. ".")
        return
    end
    if command == "reset" then apply(DEFAULT, "chat"); return end
    if normalize(trimmed) then apply(trimmed, "chat"); return end
    say("명령: /fnd (설정창), /fnd 30 (거리), /fnd status, /fnd reset")
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("CVAR_UPDATE")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= "ForeverNameplateDistance" then return end
        ForeverNameplateDistanceCharDB = type(ForeverNameplateDistanceCharDB) == "table" and ForeverNameplateDistanceCharDB or {}
        db = ForeverNameplateDistanceCharDB
        return
    end
    if event == "PLAYER_ENTERING_WORLD" then
        if loginScheduled then return end
        loginScheduled = true
        -- Other nameplate addons may apply their settings at login. Reassert
        -- only an explicit preference the user already saved, once per login.
        local function restore()
            if db and normalize(db.distance) then apply(db.distance, "login") end
        end
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(2, restore)
        else
            restore()
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if queued then
            local value = queued
            queued = nil
            apply(value, "combat")
        end
    elseif event == "CVAR_UPDATE" and arg1 and tostring(arg1):lower() == CVAR:lower() then
        if not internalSet then present() end
    end
end)

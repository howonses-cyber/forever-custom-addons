Forever Nameplate Distance v1.0.0
================================
Purpose: configure the actual native nameplateMaxDistance CVar. Not range fading, range check, nameplate alpha or camera distance.
Install: extract the ForeverNameplateDistance folder to World of Warcraft/_forever_/Interface/AddOns/ or the AddOns directory for your client.
Usage: /fnd opens the Korean settings window. /fnd 30 sets 30 yards. /fnd status reads back the CVar. /fnd reset selects default 45 yards.
Distance slider accepts 10-60 yards. The game/server may clamp this further; the addon cannot bypass client/server limits.
Only writes the distance CVar after user choice or re-applies the user's saved per-character preference at login.
The client may refuse CVar changes during combat; changes are queued until combat ends.
Does not change EllesmereUI, nameplates' visual style, WoW WTF files directly, or other addons.

local addon,G=...
-- v1.9.8: concise original Korean walkthroughs. The installed Forever DB and
-- the live quest log remain authoritative for eligibility and completion.
-- A verified walkthrough never changes the player's quest flags or uses items.
local records={}
local function rec(id,entry) records[id]=entry end
local function wp(x,y,name,approx) return {map=1449,x=x/100,y=y/100,name=name,approx=approx or nil} end
local function same(id,x,y,name)
 G.pickupOverrides[id]=wp(x,y,name); G.turninOverrides[id]=wp(x,y,name)
end
local function obj(id,item,title,p)
 G.verifiedObjectives[id]={{kind="item",id=item,title=title,point=p}}
end
local function needs(id,items) G.verifiedItemRequirements[id]=items end
local function location(id,kind,zone,site,target,instruction,approach)
 local meta=G.specialQuestMeta[id] or {};G.specialQuestMeta[id]=meta
 meta.stageLandmarks=meta.stageLandmarks or {}
 meta.stageLandmarks[kind]={zone=zone,site=site,target=target,instruction=instruction,approach=approach,verified=true}
end
local torwa="토르와 패스파인더"
local un="운고로 분화구"
local refuge="마샬의 야영지"
for _,id in ipairs({4290,4291,4292}) do same(id,71.64,75.96,torwa) end
G.koQuestNames[4291]="라르코르위의 냄새"
G.koQuestNames[4292]="라르코르위를 위한 미끼"
-- The carcass is a ground object, not an animal the player has to kill.
obj(4290,11504,"트레샤돈 시체 덩이",wp(68.74,56.71,"신선한 트레샤돈 시체"))
needs(4290,{[11504]=1})
rec(4290,{source="와우헤드 클래식 원문 · 포에버 퀘스티 자료 오브젝트 · 퀘스팅 위키 포에버",urls={"https://www.wowhead.com/classic/quest=4290/the-fare-of-larkorwi","https://questing.wiki/wow-forever/quests/4290/"},
 accept={"토르와에게 수락한 뒤 분화구 동쪽의 공룡 활동 구역으로 향하세요. 별도 미끼를 사용할 단계는 아닙니다."},
 objective={"동쪽 늪지대 (68.7, 56.7)의 신선한 트레샤돈 시체 오브젝트를 찾으세요.","주변 공룡을 피하거나 처치한 뒤 시체와 상호작용하세요. 새로 공룡을 잡아 시체를 만드는 것이 아닙니다.","시체 조각 1개를 전리품 창에서 획득하세요."},
 turnin={"토르와에게 시체 조각을 전달하고 다음 연계 [라르코르위의 냄새]를 수락하세요."},items={{11504,1,"트레샤돈 시체 덩이"}}})
-- Reported mate locations are search areas; no exact egg coordinate is claimed.
obj(4291,11509,"라바사우루스 페로몬샘",wp(58.2,78.2,"라바사우루스 알 둥지 탐색 구역",true))
needs(4291,{[11509]=2})
rec(4291,{source="와우헤드 포에버 원문 · 와우헤드 한글 · 퀘스팅 위키 포에버",urls={"https://www.wowhead.com/forever/quest=4291/the-scent-of-larkorwi","https://questing.wiki/wow-forever/quests/4291/"},
 accept={"토르와에게 수락하세요. 별도의 지급 미끼나 사용 아이템은 필요하지 않습니다."},
 objective={"분화구 남동쪽의 라바사우루스 알 둥지를 찾으세요. 표시된 지점(58.2, 78.2)은 암컷 출현이 기록된 탐색 구역입니다.","바닥의 공룡 알 바로 가까이 걸어가세요. 알을 줍거나 가방 아이템을 사용할 필요는 없습니다.","알을 지키는 라르코르위의 짝이 나타나면 처치하고 시체에서 라바사우루스 페로몬샘을 획득하세요.","이미 사용한 둥지에서 나타나지 않으면 다른 둥지를 찾으세요. 추가 탐색 후보: (60.8, 72.2), (63.2, 77.2), (67.0, 73.6).", "페로몬샘을 총 2개 모으면 수행 완료입니다."},
 turnin={"페로몬샘 2개를 토르와에게 보고하세요. 다음 [라르코르위를 위한 미끼]를 수락할 때 주머니를 받습니다."},items={{11509,2,"라바사우루스 페로몬샘"}}})
obj(4292,11510,"라르코르위의 머리",wp(79.6,49.8,"동쪽 수정탑 뒤 미끼 바위 (부근)",true))
needs(4292,{[11510]=1})
rec(4292,{source="와우헤드 포에버 원문 및 공략 댓글 · 퀘스팅 위키 포에버 · 아이템 사용 설명",urls={"https://www.wowhead.com/forever/quest=4292/the-bait-for-larkorwi","https://questing.wiki/wow-forever/quests/4292/","https://www.wowhead.com/classic/item=11569/preserved-threshadon-meat"},
 accept={"수락하면 토르와의 주머니를 받습니다. 가방에서 우클릭하여 미끼 재료 두 개를 꺼내세요.","보존된 트레샤돈 고기와 페로몬 혼합물이 가방에 있는지 확인하세요."},
 objective={"토르와의 주머니(11568)를 열어 고기(11569)와 페로몬 혼합물(11570)을 꺼내세요. 이미 열었다면 이 단계는 생략하세요.","동쪽 수정탑(약 77, 49)의 동쪽 산길을 따라 올라가 큰 뼈무더기와 평평한 검은 바위 부근(79.6, 49.8)을 찾으세요.","바위에 가까이 서서 가방의 보존된 트레샤돈 고기를 먼저 우클릭해 놓으세요.","이어 보존된 페로몬 혼합물을 우클릭해 고기에 바르세요. 순서를 바꾸지 마세요.","소환된 라르코르위(56레벨)와 전투해 처치한 뒤 시체에서 라르코르위의 머리 1개를 획득하세요.","주머니와 두 재료가 모두 없다면 먼저 퀘스트 상태와 지급 아이템을 확인하세요. 자동 포기나 재수락은 하지 않습니다."},
 turnin={"라르코르위의 머리를 토르와에게 가져가 보고하고 보상을 선택하세요."},items={{11510,1,"라르코르위의 머리"}},bag={{11568,"토르와의 주머니"},{11569,"보존된 트레샤돈 고기"},{11570,"보존된 페로몬 혼합물"}}})
-- Other Un'Goro interactions where a generic kill/loot instruction is misleading.
rec(4492,{source="와우헤드 포에버 · 공략 댓글",urls={"https://www.wowhead.com/forever/quest=4492/lost"},
 accept={"스프래글에게 실종된 링고를 찾는 퀘스트를 받으세요. 지급 물품이 있다면 가방에 보관하세요."},
 objective={"불기둥 마루의 작은 동굴에서 링고를 찾으세요. 일반 사냥 목표가 아니라 인물에게 직접 대화하는 퀘스트입니다."},
 turnin={"링고와 대화해 보고하고 호위 연계 퀘스트를 확인하세요."}})
rec(4491,{source="와우헤드 포에버 원문",urls={"https://www.wowhead.com/forever/quest=4491/a-little-help-from-my-friends"},
 accept={"링고의 호위를 시작하기 전에 가방의 스프래글의 수통을 확인하세요. 호위 중 링고에게 물을 사용해야 할 수 있습니다."},
 objective={"링고를 두고 멀리 이동하지 말고 마샬의 야영지 방향으로 함께 이동하세요.","링고가 더위로 쓰러지면 링고를 대상으로 지정하고 스프래글의 수통을 사용해 일으켜 세우세요.","주변 적으로부터 링고를 보호하며 스프래글에게 도착할 때까지 호위를 마치세요."},
 turnin={"링고가 도착하고 퀘스트 로그에 호위 완료가 표시되면 스프래글에게 보고하세요."},bag={{11804,"스프래글의 수통"}}})
rec(4243,{source="와우헤드 포에버 원문 · 퀘스팅 위키 포에버 연계",urls={"https://www.wowhead.com/forever/quest=4243/chasing-a-me-01","https://questing.wiki/wow-forever/quests/series/4243/"},
 accept={"카르나 렘트레블에게 수락하세요. 후속 수리 퀘스트에 미스릴 형틀 1개가 필요하므로 미리 준비하면 왕복을 줄일 수 있습니다."},
 objective={"마샬의 야영지 동쪽 버섯 바위굴의 유인원 동굴로 들어가 기계 유인원 에이미 01을 찾으세요."},
 turnin={"고장 난 에이미 01에게 직접 보고한 후 수리 퀘스트를 받으세요."}})
-- This material is craftable/tradable; do not navigate to incidental loot sources.
G.verifiedObjectives[4244]={{kind="item",id=10561,title="미스릴 형틀",landmark={zone="재료 준비",site="경매장·기계공학 제작",target="미스릴 형틀",instruction="기계공학 제작품 또는 거래로 1개를 준비하세요. 이미 보유 중이라면 추가 획득할 필요가 없습니다.",verified=true}}}
needs(4244,{[10561]=1})
rec(4244,{source="와우헤드 포에버 원문 및 제작 공략 · 퀘스팅 위키 포에버 연계",urls={"https://www.wowhead.com/forever/quest=4244/chasing-a-me-01","https://questing.wiki/wow-forever/quests/series/4243/"},
 accept={"에이미 01에게 수리 퀘스트를 수락하세요. 미스릴 형틀 1개가 필요합니다."},
 objective={"경매장이나 기계공학 제작자를 통해 미스릴 형틀 1개를 준비하세요. 기계공학을 직접 배울 필요는 없습니다.","형틀이 가방에 있으면 동굴의 에이미 01에게 돌아가세요."},
 turnin={"형틀을 에이미 01에게 제출하여 수리하세요. 별도 호위 퀘스트를 수락하기 전 주변 적을 정리하는 것이 좋습니다."},items={{10561,1,"미스릴 형틀"}}})
rec(4245,{source="퀘스팅 위키 포에버 연계 · 포에버 자료실 관측 기록",urls={"https://questing.wiki/wow-forever/quests/series/4243/","https://foreverdb.net/ko/quest/4245-chasing-a-me-01"},
 accept={"수리를 완료한 뒤 에이미 01에게 별도의 호위 퀘스트를 수락하세요. 바로 출발할 수 있으니 주변 적을 확인하세요."},
 objective={"에이미 01을 따라 동굴 밖으로 나가세요. 이동하는 동안 가까이에서 호위하고 공격하는 적을 처치하세요.","마샬의 야영지에 있는 카르나 렘트레블에게 도착할 때까지 호위를 계속하세요."},
 turnin={"호위 완료 표시를 확인한 뒤 카르나에게 보고하세요."}})
rec(3844,{source="와우헤드 포에버 원문",urls={"https://www.wowhead.com/forever/quest=3844/its-a-secret-to-everybody"},
 accept={"운고로 남동쪽 작은 연못 가장자리의 부서진 뗏목과 상호작용해 퀘스트를 받으세요."},
 objective={"뗏목 근처 연못 속으로 들어가 물에 잠긴 작은 배낭 오브젝트를 찾으세요."},
 turnin={"연못 바닥의 가방과 상호작용해 보고하고 후속 퀘스트를 받으세요."}})
-- All three objectives are inside the supplied pack, not three separate drop sites.
-- Preserve original objective IDs so saved route identities remain valid.
G.verifiedObjectives[3845]={}
for _,v in ipairs({{11104,"큰 나침반"},{11105,"두루마리 지도"},{11106,"사자머리 열쇠"}}) do
 G.verifiedObjectives[3845][#G.verifiedObjectives[3845]+1]={kind="item",id=v[1],title=v[2],landmark={zone="가방 확인",site="수락 시 지급된 작은 배낭",target=v[2],instruction="가방 속 퀘스트 지급품을 열어 필요한 내용물을 꺼내세요.",verified=true}}
end
needs(3845,{[11104]=1,[11105]=1,[11106]=1})
rec(3845,{source="와우헤드 포에버 원문 · 공개 포에버 퀘스트 자료",urls={"https://www.wowhead.com/forever/quest=3845/its-a-secret-to-everybody","https://www.60.tools/quests/3845-its-a-secret-to-everybody"},
 accept={"연못 속 작은 배낭에서 후속 퀘스트를 수락하고 가방에 지급된 작은 배낭을 확인하세요."},
 objective={"인벤토리에 들어온 작은 배낭(아이템 번호 11107)을 우클릭하여 여세요.","전리품 창의 나침반, 지도, 사자머리 열쇠를 각각 1개씩 모두 꺼내세요. 이 물품을 얻기 위해 별도 몬스터를 사냥할 필요는 없습니다.","세 가지 내용물을 모두 챙겨 마샬의 야영지의 링쿠에게 이동하세요."},
 turnin={"나침반·지도·열쇠를 링쿠에게 전달하세요. 다음 퀘스트는 링쿠의 검을 여명의 설원으로 운반하는 연계입니다."},bag={{11107,"작은 배낭"}},items={{11104,1,"큰 나침반"},{11105,1,"두루마리 지도"},{11106,1,"사자머리 열쇠"}}})
rec(3908,{source="와우헤드 포에버 원문",urls={"https://www.wowhead.com/forever/quest=3908/its-a-secret-to-everybody"},
 accept={"링쿠에게 수락하고 지급된 링쿠의 훈련용 검을 가방에 보관하세요."},
 objective={"검을 가지고 여명의 설원 온천 부근의 도노바 스노우덴에게 가세요. 별도 사냥이나 검 사용은 필요하지 않습니다."},
 turnin={"도노바에게 검을 전달하여 다음 연계를 받으세요."},bag={{11133,"링쿠의 훈련용 검"}}})
-- Alien Ecology: the sample is collected by using the provided vial, not looting mobs.
-- Map marker is the documented hive search area; not an exact chamber coordinate.
G.koQuestNames[3883]="외래 생태계"
same(3883,43.9,7.2,"홀라니에 마샬")
obj(3883,11131,"고리쉬집 벽면 견본",wp(48.7,85.3,"고리쉬 지하 부화장 탐색 구역",true))
needs(3883,{[11131]=1})
rec(3883,{source="와우헤드 포에버 · 워크래프트 위키 · 포에버 자료실 · 포에버 엑스피 · 와우 인벤",urls={"https://www.wowhead.com/forever/quest=3883/alien-ecology","https://foreverdb.net/ko/quest/3883-alien-ecology","https://forever-xp.com/quests/3883/","https://wow.inven.co.kr/dataninfo/wdb/edb_quest/detail.php?id=3883"},
 accept={"홀라니에 마샬에게 퀘스트를 받고 가방에 지급된 빈 채집 약병을 확인하세요."},
 objective={"운고로 분화구 남부 갈래굽이 구렁의 고리쉬 서식지, 약 (48.7, 85.3) 부근의 지하 통로로 이동하세요. 이 좌표는 부화장 탐색 구역입니다.","고리쉬가 있는 동굴 내부로 들어가 천장에 유충알이 매달려 있는 부화장 방을 찾으세요.","부화장 벽 가까이에 서서 가방의 빈 채집 약병을 사용하세요. 벌레를 사냥해 전리품으로 얻는 퀘스트가 아닙니다.","고리쉬집 벽면 견본 1개가 가방에 들어왔고 퀘스트 목표가 완료되었는지 확인하세요."},
 turnin={"운고로 북쪽 마샬의 야영지에 있는 홀라니에 마샬(43.9, 7.2)에게 견본을 보고하세요."},bag={{11132,"빈 채집 약병"}},items={{11131,1,"고리쉬집 벽면 견본"}}})
-- Generic read-only quest instruction engine. Never infer exact actions from
-- the mere presence of a quest item, or invent a kill/cast sequence.
local function dbget(db,id,field) return G.DBGet and G.DBGet(db,id,field) end
local function clean(s)
 if type(s)~="string" then return nil end
 s=s:gsub("^%s+",""):gsub("%s+$","")
 return G.KoreanText and G.KoreanText(s) or s
end
local function name(id,fallback)
 local n=G.SafeCall(C_Item and C_Item.GetItemNameByID,id) or G.SafeCall(GetItemInfo,id) or dbget(ItemDB,id,"name")
 if G.KoreanName then
  local localized=G.KoreanName("item",id,n,fallback)
  if type(localized)=="string" and localized~="" then return localized end
 end
 if type(n)=="string" and n~="" then
  if fallback and GetLocale and GetLocale()=="koKR" and not n:find("[\128-\255]") then return fallback end
  return n
 end
 return fallback or ("아이템 #"..tostring(id))
end
local function count(id)
 local n=G.SafeCall(C_Item and C_Item.GetItemCount or GetItemCount,id,false)
 return type(n)=="number" and math.max(0,n) or nil
end
local cache,cacheDB={},nil
local function static(id)
 if cacheDB~=QuestDB then cache={};cacheDB=QuestDB end
 if cache[id] then return cache[id] end
 local r={texts={},extra={},items={},targets={},provided=tonumber(dbget(QuestDB,id,"sourceItemId")),required={}}
 local seen={}
 local function add(dst,v)
  v=clean(v);if v and v~="" and not seen[v] then seen[v]=true;dst[#dst+1]=v end
 end
 local t=dbget(QuestDB,id,"objectivesText")
 if type(t)=="table" then for _,v in ipairs(t) do add(r.texts,v) end else add(r.texts,t) end
 local trigger=dbget(QuestDB,id,"triggerEnd")
 if type(trigger)=="table" then add(r.extra,trigger[1]) end
 local extras=dbget(QuestDB,id,"extraObjectives")
 if type(extras)=="table" then for _,v in ipairs(extras) do if type(v)=="table" then add(r.extra,v[3]) end end end
 local objectives=dbget(QuestDB,id,"objectives")
 if type(objectives)=="table" then
  for _,spec in ipairs({{index=1,db=NpcDB,prefix="처치·수행 대상: "},{index=2,db=ObjectDB,prefix="상호작용 대상: "}}) do
   for _,entry in ipairs(type(objectives[spec.index])=="table" and objectives[spec.index] or {}) do
    local eid=tonumber(type(entry)=="table" and entry[1] or entry)
    local label=eid and dbget(spec.db,eid,"name")
    local instruction=type(entry)=="table" and clean(entry[2])
    if label then add(r.targets,spec.prefix..label..(instruction and instruction~="" and (" · "..instruction) or "")) elseif instruction then add(r.targets,instruction) end
   end
  end
  for _,entry in ipairs(type(objectives[5])=="table" and objectives[5] or {}) do
   if type(entry)=="table" then add(r.extra,entry[3]) end
  end
  for _,entry in ipairs(type(objectives[6])=="table" and objectives[6] or {}) do
   if type(entry)=="table" then add(r.extra,entry[2]) end
  end
  for _,entry in ipairs(type(objectives[3])=="table" and objectives[3] or {}) do
   local iid=tonumber(type(entry)=="table" and entry[1] or entry)
   if iid and iid>0 then
    local it={id=iid,sources={}}
    for _,spec in ipairs({{db=NpcDB,key="npcDrops",label="몬스터 전리품"},{db=ObjectDB,key="objectDrops",label="오브젝트 획득처"}}) do
     local list=dbget(ItemDB,iid,spec.key)
     if type(list)=="table" then
      for _,v in ipairs(list) do
       local eid=tonumber(v);local n=eid and dbget(spec.db,math.abs(eid),"name")
       if n and #it.sources<5 then
        local label=G.KoreanName and G.KoreanName(spec.db==NpcDB and "npc" or "object",math.abs(eid),n) or n
        it.sources[#it.sources+1]=spec.label..": "..label
       end
      end
     end
    end
    r.items[#r.items+1]=it
   end
  end
 end
 local required=dbget(QuestDB,id,"requiredSourceItems")
 if type(required)=="table" then for _,v in ipairs(required) do local iid=tonumber(v);if iid and iid>0 then r.required[#r.required+1]=iid end end end
 if G.Ready and G.Ready() then cache[id]=r end
 return r
end
-- The Forever EUI tracker also uses GetQuestLogQuestText(logIndex).
-- Read by exact quest ID; do not select another quest in Blizzard's log.
function G.LiveQuestNarrative(id)
 id=tonumber(id)
 if not id or not G.IsInLog(id) or type(GetQuestLogQuestText)~="function" then return nil end
 local index=tonumber(G.SafeCall(C_QuestLog and C_QuestLog.GetLogIndexForQuestID,id))
 if not index or index<=0 then return nil end
 local info=G.SafeCall(C_QuestLog and C_QuestLog.GetInfo,index)
 if type(info)=="table" and info.questID and tonumber(info.questID)~=id then return nil end
 local ok,description,objective=pcall(GetQuestLogQuestText,index)
 if not ok then return nil end
 description=clean(description)
 if G.KoreanQuestObjectives then objective=G.KoreanQuestObjectives(id,objective) end
 objective=clean(objective)
 if description=="" then description=nil end;if objective=="" then objective=nil end
 if not objective and not description then return nil end
 return {description=description,objective=objective}
end
local function live(id)
 if not (G.IsInLog and G.IsInLog(id)) then return {} end
 local result={}
 local list=G.SafeCall(C_QuestLog and C_QuestLog.GetQuestObjectives,id)
 if type(list)=="table" then
  for _,o in ipairs(list) do
   if type(o)=="table" then
    local raw=o.text or o.description
    if G.KoreanQuestObjectives then raw=G.KoreanQuestObjectives(id,raw) end
    local t=clean(raw)
    if t and t~="" then
     local suffix=""
     local n,m=tonumber(o.numFulfilled),tonumber(o.numRequired)
     if n and m and m>0 then suffix=" ("..n.."/"..m..")" end
     result[#result+1]=t..suffix..((o.finished==true or o.finished==1) and " [완료]" or "")
    end
   end
  end
 end
 return result
end
local function append(out,items,heading,numbered)
 if #items==0 then return end
 if heading then out[#out+1]=heading end
 for i,s in ipairs(items) do out[#out+1]=(numbered and (i..". ") or "• ")..(G.KoreanText and G.KoreanText(s) or s) end
end
local function stock(out,items,active,required)
 if not items or #items==0 then return end
 local rows={}
 for _,v in ipairs(items) do
  local id,label,n
  if required then id,n,label=v[1],v[2],v[3] else id,label=v[1],v[2] end
  local owned=active and count(id) or nil
  rows[#rows+1]=name(id,label)..(n and (owned~=nil and " · 가방 "..owned.."/"..n or " × "..n) or (owned~=nil and " · 가방 "..owned.."개" or ""))
 end
 append(out,rows,required and "|cffffdc88필요 아이템|r" or "|cffffdc88지급·사용 아이템 확인 (이미 사용한 물품은 없을 수 있음)|r",false)
end
function G.StepWalkthrough(step,hasExistingAction,detailMode)
 if not step or not step.quest then return nil end
 local id=tonumber(step.quest);if not id then return nil end
 local kind=step.kind=="inside" and "objective" or step.kind
 if kind~="accept" and kind~="objective" and kind~="turnin" then return nil end
 local info=static(id);local curated=records[id];local out={}
 local active=G.IsInLog and G.IsInLog(id)
 if curated and curated[kind] then
  local phaseLines=kind=="objective" and curated.byObjective and curated.byObjective[step.objectiveId] or curated[kind]
  append(out,phaseLines,"|cffffdc88"..(kind=="accept" and "수락 및 준비" or kind=="turnin" and "보고 방법" or "상세 수행 방법").."|r",true)
  if kind~="turnin" then stock(out,curated.bag,active,false) end
  stock(out,curated.items,active,true)
  if kind=="objective" and not detailMode then append(out,live(id),"|cff88d7e9실제 퀘스트 로그|r",false) end
  if curated.evidence then out[#out+1]="|cff9baab5검증 범위: "..curated.evidence.."|r" end
  out[#out+1]="|cff9baab5근거: "..curated.source.."|r"
  return out,true
 end
 -- Existing hand-authored indoor/landmark instructions are preserved; append
 -- actual objective text instead of replacing it with an ambiguous verb.
 if kind=="objective" then
  local goal=clean(step.goalText or (G.QuestObjectiveText and G.QuestObjectiveText(id)))
  local texts={}
  local journal=G.LiveQuestNarrative(id)
  if journal and journal.objective then
   append(out,{journal.objective},"|cffffdc88실제 수행 목표 (게임 내 원문)|r",false)
   if journal.description and journal.description~=journal.objective then append(out,{journal.description},"|cffffdc88퀘스트 상세 내용 (게임 내 원문)|r",false) end
  else
   if G.verifiedQuestGoals and G.verifiedQuestGoals[id] and goal and goal~="" then texts[1]=goal elseif #info.texts>0 then texts=info.texts elseif goal and goal~="" then texts[1]=goal end
   if #texts>0 then append(out,texts,"|cffffdc88실제 수행 목표 (자료)|r",false) end
   if journal and journal.description then append(out,{journal.description},"|cffffdc88퀘스트 상세 내용 (게임 내 원문)|r",false) end
  end
  append(out,info.targets,"|cffffdc88확인된 목표 대상 (자료)|r",false)
  append(out,info.extra,"|cffffdc88추가 행동 정보 (자료)|r",false)
  local items={}
  for _,it in ipairs(info.items) do
   if not step.objectiveId or step.objectiveKind~="item" or step.objectiveId==it.id then
    local n=active and count(it.id) or nil
    local line=name(it.id)..(n~=nil and " · 가방 "..n.."개" or "")
    local source=table.concat(it.sources," / ")
    if source~="" then line=line.."\n  자료상 "..source end
    items[#items+1]=line
   end
  end
  append(out,items,"|cffffdc88목표 아이템 및 확인된 획득처|r",false)
  if not detailMode then append(out,live(id),"|cff88d7e9실제 퀘스트 로그 (필요 수량)|r",false) end
  if not hasExistingAction and #out==0 then
   if step.objectiveKind=="creature" and step.objectiveTitle then out[#out+1]=step.objectiveTitle.." 처치 목표를 확인하세요."
   elseif step.objectiveKind=="object" and step.objectiveTitle then out[#out+1]=step.objectiveTitle.." 오브젝트와 상호작용하세요."
   elseif step.objectiveTitle then out[#out+1]=step.objectiveTitle.." 획득 목표를 확인하세요. 정확한 사용 절차는 자료에서 확인되지 않았습니다."
   else out[#out+1]="세부 수행 방법이 자료에 없습니다. 퀘스트 원문을 확인하세요." end
  end
 end
 if kind=="turnin" then
  local journal=G.LiveQuestNarrative(id)
  if journal and journal.objective then append(out,{journal.objective},"|cffffdc88게임 내 목표 및 보고 정보|r",false) end
 end
 if kind~="turnin" then
  local issued=info.provided
  if issued and issued>0 then
   local n=active and count(issued) or nil
   out[#out+1]="|cffffdc88퀘스트 관련 아이템(시작/지급):|r "..name(issued)..(n~=nil and " · 현재 가방 "..n.."개" or " · 수락 전후 가방 확인")
   if kind=="objective" then out[#out+1]="지급품의 사용 여부와 순서는 위 목표 설명을 따르세요. 자료에서 확인되지 않은 사용법은 추정하지 않습니다." end
  end
  local req={};for _,iid in ipairs(info.required) do req[#req+1]={iid} end
  stock(out,req,active,false)
 end
 if #out>0 then
  out[#out+1]="|cff9baab5근거: 설치된 퀘스티 자료 / 실제 퀘스트 로그 · 별도 공략 미검증|r"
  return out,kind=="objective"
 end
end
-- Compact HUD model: omit story prose, but never discard authored procedures.
-- Live progress is authoritative; match quantities by a unique named target,
-- never by list position or an assumed one-item requirement.
function G.CompactStepWalkthrough(step)
 local id=step and tonumber(step.quest)
 if not id then return {} end
 local kind=step.kind=="inside" and "objective" or step.kind
 local info=static(id);local curated=records[id]
 local active=G.IsInLog and G.IsInLog(id)
 local model={action={},goals={},items={},supplies={},extra={},source=curated and curated.source or "퀘스티 자료 / 게임 퀘스트 로그"}
 local seen={}
 local function add(dst,value)
  value=clean(value)
  if value and value~="" and not seen[value] then seen[value]=true;dst[#dst+1]=value end
 end
 local function normalized(s)
  if type(s)~="string" then return "" end
  s=s:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
  return s:lower():gsub("[%s%p]","")
 end
 local progress=active and G.QuestObjectiveProgress and G.QuestObjectiveProgress(id)
 local objectives=type(progress)=="table" and progress.objectives or {}
 local used={}
 local function matchGoal(label)
  local needle=normalized(label);if needle=="" then return nil end
  local found
  for i,o in ipairs(objectives or {}) do
   local raw=type(o)=="table" and (o.text or o.display)
   -- Exact name after stripping the terminal count. A partial name match can
   -- attach another item's progress to this item (e.g. material vs large material).
   local label=type(raw)=="string" and raw:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("%s*%(?%d+%s*/%s*%d+%)?%s*$","")
   if label and normalized(label)==needle then
    if found then return nil end
    found=i
   end
  end
  return found
 end
 if curated and curated[kind] then
  local rows=kind=="objective" and curated.byObjective and curated.byObjective[step.objectiveId] or curated[kind]
  for _,line in ipairs(rows or {}) do add(model.action,line) end
 elseif kind=="objective" then
  local journal=G.LiveQuestNarrative(id)
  local goal=clean(journal and journal.objective or step.goalText or (G.QuestObjectiveText and G.QuestObjectiveText(id)))
  if step.objectiveTitle then
   local verb="목표 수행"
   if step.objectiveKind=="item" then verb="획득 조건 확인"
   elseif step.objectiveKind=="object" then verb="상호작용 조건 확인" end
   add(model.action,step.objectiveTitle.." · "..verb)
  end
  if goal and goal~="" then add(model.goals,goal)
  else for _,line in ipairs(info.texts) do add(model.goals,line) end end
  -- A description may contain a critical condition. Keep it in the full view;
  -- if no actionable evidence exists, explicitly direct the player to it.
  if #model.action==0 and #model.goals==0 then
   add(model.action,"세부 목표 미확인 · 원문·상세에서 확인하세요.")
  end
 end
 if kind=="objective" then
  local items={};local ids={}
  local function put(iid,qty,label,sources)
   if not iid then return end
   if step.objectiveKind=="item" and step.objectiveId and step.objectiveId~=iid then return end
   if ids[iid] then
    local old=ids[iid];old.qty=old.qty or qty;old.label=old.label or label
    return
   end
   local row={id=iid,qty=qty,label=label,sources=sources or {}}
   ids[iid]=row;items[#items+1]=row
  end
  local known=G.verifiedItemRequirements and G.verifiedItemRequirements[id] or {}
  for _,it in ipairs(info.items) do put(it.id,known[it.id],nil,it.sources) end
  for _,v in ipairs(curated and curated.items or {}) do put(v[1],v[2],v[3]) end
  local knownIds={};for iid in pairs(known) do knownIds[#knownIds+1]=iid end;table.sort(knownIds)
  for _,iid in ipairs(knownIds) do put(iid,known[iid]) end
  if step.objectiveKind=="item" and step.objectiveId then put(step.objectiveId,known[step.objectiveId],step.objectiveTitle) end
  for _,it in ipairs(items) do
   local label=name(it.id,it.label)
   local i=matchGoal(label);local goal=i and objectives[i]
   local owned=active and count(it.id)
   local parts={"|cffdce7ed"..label.."|r"}
   if goal and goal.quantity then parts[#parts+1]="진행 "..goal.quantity
   elseif it.qty then parts[#parts+1]="필요 "..it.qty.."개" end
   if type(owned)=="number" then parts[#parts+1]="가방 "..owned.."개" end
   if goal and goal.finished==true then parts[#parts+1]="|cff84dba0완료|r" end
   if i and (goal.quantity or goal.finished==true) then used[i]=true end
   local line=table.concat(parts," · ")
   if #it.sources>0 then line=line.."\n  자료상 획득처: "..table.concat(it.sources," / ")
   elseif not curated then line=line.."\n  획득처 자료 미확인 · 수행 목표와 원문 확인" end
   add(model.items,line)
  end
  for i,o in ipairs(objectives or {}) do
   if not used[i] then add(model.goals,(o.finished==true and "|cff84dba0[완료]|r " or "")..(o.display or o.text or "목표 확인 필요")) end
  end
  -- Generic targets and special triggers are useful when the route has no
  -- selected entity. Do not repeat unrelated targets for a named sub-step.
  if not step.objectiveId then for _,line in ipairs(info.targets) do add(model.extra,line) end end
  for _,line in ipairs(info.extra) do add(model.extra,line) end
 end
 if kind~="turnin" then
  local stocked={}
  local function supply(iid,label)
   if not iid or iid<=0 or stocked[iid] then return end
   stocked[iid]=true;local owned=active and count(iid)
   add(model.supplies,name(iid,label)..(type(owned)=="number" and " · 가방 "..owned.."개" or " · 가방 확인"))
  end
  for _,v in ipairs(curated and curated.bag or {}) do supply(v[1],v[2]) end
  supply(info.provided)
  for _,iid in ipairs(info.required) do supply(iid) end
 end
 return model
end
function G.WalkthroughDetails(id)
 local curated=records[id]
 if curated then
  local out={}
  for _,kind in ipairs({"accept","objective","turnin"}) do
   local rows=G.StepWalkthrough({quest=id,kind=kind},false,true)
   for _,row in ipairs(rows or {}) do if not row:find("근거: ",1,true) then out[#out+1]=row end end
  end
  out[#out+1]="|cff9baab5공략 근거: "..curated.source.."|r"
  -- Source URLs stay in the records and source documentation. The player's
  -- walkthrough shows the readable Korean source label rather than raw URLs.
  return table.concat(out,"\n")
 end
 local rows=G.StepWalkthrough({quest=id,kind="objective"},false,true)
 return rows and table.concat(rows,"\n") or nil
end
G.walkthroughRecords=records

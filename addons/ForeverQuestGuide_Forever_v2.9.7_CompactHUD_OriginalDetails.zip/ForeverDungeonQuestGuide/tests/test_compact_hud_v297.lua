-- Test production compact/full HUD models and widget wiring; no live client.
local base=arg[1] or './'
local Mock=assert(loadfile(base..'tests/mock_wow.lua'))().install()
GetLocale=function()return 'koKR'end
GetTime=function()return 100 end
UnitRace=function()return '드워프','Dwarf',3 end
Minimap=CreateFrame('Frame','Minimap',UIParent);Minimap:SetSize(140,140)
local G={}
for line in io.lines(base..'ForeverDungeonQuestGuide.toc') do
 local f=line:match('^([^#].-%.lua)%s*$');if f then assert(loadfile(base..f))('ForeverDungeonQuestGuide',G)end
end
local controller=assert(Mock.find(function(o)return o.scripts.OnEvent and o.scripts.OnUpdate end))
controller.scripts.OnEvent(controller,'ADDON_LOADED','ForeverDungeonQuestGuide')
local N=0
local function check(ok,msg) N=N+1;assert(ok,msg or 'failed')end
local function has(s,x) check(type(s)=='string' and s:find(x,1,true),'missing: '..x..' in '..tostring(s))end
local function no(s,x) check(not s:find(x,1,true),'unexpected: '..x)end
local function eq(a,b,msg)check(a==b,(msg or 'mismatch')..': '..tostring(a)..' vs '..tostring(b))end
-- Fixture uses the actual quest/item names in the packaged localization table.
-- Simulated quantities, contacts, and coordinates are test inputs, not server verification.
local id=5065
local third=G.KoreanName('item',12411,nil);local fourth=G.KoreanName('item',12412,nil)
local name=G.KoreanName('quest',id,nil)
local reporter='발굴조사단장 아이언부트'
local story='스토리 원문 고유 문장: '..string.rep('이전 조사 기록입니다. ',30)
local goal='세 번째와 네 번째 모쉬아루 서판을 찾아 타나리스에 있는 발굴조사단장 아이언부트에게 갖다주어야 합니다.'
local data={[id]={name=name,objectivesText={goal},objectives={[3]={{12411},{12412}}}},[4292]={name='라르코르위를 위한 미끼'},[99001]={objectives={[3]={{900101}}},objectivesText={'정확한 수량은 확인되지 않음'}},[99002]={}}
QuestDB={Get=function(q,k)return data[q] and data[q][k] end}
ItemDB={Get=function(i,k)
 if k=='name' then return i==12411 and third or i==12412 and fourth or i==900101 and '미확인 재료' or nil end
 if k=='npcDrops' and i==12411 then return {99} end
 if k=='objectDrops' and i==12412 then return {100} end
end}
NpcDB={Get=function(i,k)if i==99 and k=='name'then return '검사 몬스터' end end}
ObjectDB={Get=function(i,k)if i==100 and k=='name'then return '검사 서판 오브젝트' end end}
G.DBGet=function(db,i,k)return db and db.Get(i,k)end
G.Ready=function()return true end
G.IsInLog=function(q)return q==id or q==4292 or q==99001 end
G.LiveQuestNarrative=function(q)if q==id or q==4292 then return{objective=goal,description=story}end end
G.QuestObjectiveText=function(q)return data[q] and data[q].objectivesText and data[q].objectivesText[1] end
G.QuestContactName=function(q,k)if q==id then return reporter end end
G.QuestPoint=function(q,k)if q==id and k=='turnin'then return{map=1446,x=.5,y=.5,name=reporter}end end
G.QuestInsideInfo=function()return nil end
G.QuestStageLandmark=function()return nil end
G.QuestContactLandmark=function()return nil end
G.QuestSpecialInstruction=function()return nil end
G.QuestFollowupHint=function()return nil end
G.PlayerLocation=function()return{map=1426,x=.5,y=.5}end
G.IsInGuideDungeon=function()return false end
C_Map={GetMapInfo=function(m)
 local names={[1426]='던 모로',[1423]='동부 역병지대',[1446]='타나리스',[1414]='칼림도어',[1415]='동부 왕국'}
 return names[m] and {name=names[m],mapType=(m==1414 or m==1415) and 2 or 3,parentMapID=m==1446 and 1414 or 1415}
end}
C_Item={GetItemNameByID=function(i)return ItemDB.Get(i,'name')end,GetItemCount=function(i)return i==12411 and 0 or i==12412 and 1 or 3 end}
C_QuestLog={GetQuestObjectives=function(q)
 if q==id then return{{text=third..' 0/1',type='item',numFulfilled=0,numRequired=1,finished=false},{text=fourth..' 1/1',type='item',numFulfilled=1,numRequired=1,finished=true}} end
end}
local step={key='test1',kind='objective',quest=id,questName=name,title=name..' - 수행',point={map=1423,x=.4,y=.5,name='검사 활동 지역'}}
local step2={key='test2',kind='objective',quest=id,questName=name,title=name..' - 수행',objectiveTitle=fourth,objectiveId=12412,objectiveKind='item',point=step.point}
local report={key='test3',kind='turnin',quest=id,questName=name,title=name..' - 보고',contactName=reporter,point=G.QuestPoint(id,'turnin')}
local function text(s,full)
 local builder=full and G.BuildFullStepDirections or G.BuildCompactStepDirections
 return table.concat(builder(s,G.PlayerLocation()).lines,'\n')
end
local compact=text(step)
has(compact,'① 지금 할 일');has(compact,'② 이동 위치');has(compact,'동부 왕국');has(compact,'동부 역병지대');has(compact,third);has(compact,fourth);has(compact,'진행 0/1');has(compact,'진행 1/1');has(compact,'가방 0개');has(compact,'검사 몬스터');has(compact,'검사 서판 오브젝트');has(compact,'타나리스');has(compact,reporter);no(compact,'스토리 원문 고유 문장');has(text(step,true),'스토리 원문 고유 문장')
local nextTitle=G.StepBriefTitle(step2);has(nextTitle,fourth);has(G.StepBriefTitle(report),reporter);check(nextTitle~=G.StepBriefTitle(report),'preview titles collapse to same quest')
local single=text(step2);has(single,fourth);has(single,'진행 1/1');no(single,'검사 몬스터');has(single,third) -- other live goal is not silently lost
-- Similar names cannot steal each other's progress or invent a quantity.
local realProgress=G.QuestObjectiveProgress
G.QuestObjectiveProgress=function()return {objectives={{text='대형 미확인 재료 2/5',display='대형 미확인 재료 2/5',quantity='2/5',current=2,required=5,finished=false}}}end
local model=G.CompactStepWalkthrough({quest=99001,kind='objective',objectiveKind='item',objectiveId=900101,objectiveTitle='미확인 재료'})
no(table.concat(model.items,'\n'),'2/5');has(table.concat(model.goals,'\n'),'2/5')
G.QuestObjectiveProgress=realProgress
local reportText=text(report);has(reportText,reporter);has(reportText,'보고 및 보상 수령');no(reportText,'목표 아이템');no(reportText,'스토리 원문 고유 문장')
local accept={kind='accept',quest=id,questName=name,contactName=reporter,point=report.point};has(text(accept),'수락');no(text(accept),'진행 1/1')
local itemStart={kind='accept',quest=99002,questName='시작 아이템 시험',prepInventory=true,contactType='item',contactName='검사 시작품',note='가방에서 우클릭'};has(text(itemStart),'가방에서 우클릭');has(text(itemStart),'가방 · 시작 아이템');no(text(itemStart),'방문 위치 미확인')
local unknown=text({kind='objective',quest=99001,questName='미확인 시험',objectiveId=900101,objectiveKind='item',objectiveTitle='미확인 재료',regionHint='관련 지역 시험'})
has(unknown,'미확인 재료');has(unknown,'가방 3개');has(unknown,'획득처 자료 미확인');has(unknown,'실제 위치 미확인');no(unknown,'필요 1개');no(unknown,'진행 3/1')
local curated={kind='objective',quest=4292,questName='라르코르위를 위한 미끼'};local authored=text(curated)
has(authored,'먼저 우클릭');has(authored,'순서를 바꾸지 마세요');has(authored,'페로몬 혼합물');no(authored,'스토리 원문 고유 문장');has(text(curated,true),'스토리 원문 고유 문장')
local history=G.BuildCompactStepDirections(step,nil,'기록 완료');check(history.review,'history mode lost');has(table.concat(history.lines,'\n'),'기록 열람 전용')
-- HUD widget callbacks: actual code, unchanged route identity and index.
G.GuideProgress=function()return 0,3 end
G.GuideViewIndex=function()return G.db.guide.index end
G.GuideViewingHistory=function()return false end
G.DisplayGuideStep=function()return G.db.guide.steps[G.db.guide.index]end
G.GuideNavigationInfo=function()return '여정 동기화' end
G.RouteScopeLabel=function()return '검은바위 첨탑 · 출발 전 준비' end
G.HasSuspendedGuide=function()return false end
G.db.guide={mode='selected',index=1,steps={step,step2,report},excluded={},admittedCount=1}
local route=G.db.guide;G.db.hudHidden=false;G.db.hudCollapsed=false
G.HUDRefresh()
local hud=assert(_G.ForeverDungeonQuestGuideHUD)
local function contents()return Mock.visibleText(hud)end
local function hudButton(label)return assert(Mock.find(function(o)return o.parent==hud and o.kind=='Button' and o:GetText()==label end),label)end
has(contents(),'목적지: 동부 왕국 → 동부 역병지대');has(contents(),fourth);has(contents(),reporter);no(contents(),'스토리 원문 고유 문장')
local toggle=hudButton('원문·상세');check(toggle:Click(),'toggle not clickable');has(contents(),'스토리 원문 고유 문장');eq(G.db.guide,route);eq(route.index,1);eq(#route.steps,3)
G.HUDRefresh();has(contents(),'스토리 원문 고유 문장');check(hudButton('핵심 안내'):Click());no(contents(),'스토리 원문 고유 문장')
check(hudButton('원문·상세'):Click());route.index=2;G.HUDRefresh();no(contents(),'스토리 원문 고유 문장');check(hudButton('원문·상세'):IsEnabled());eq(route.index,2)
check(G.HUDSetSize(420,360));check(G.HUDSetOpacity(30));eq(route.index,2)
G.db.hudCollapsed=true;G.HUDRefresh();check(not toggle:IsShown(),'toggle shown in collapsed HUD')
G.db.hudCollapsed=false;G.HUDRefresh();check(toggle:IsShown(),'toggle lost after expand')
print('PASS V2.9.7 compact and original HUD, objective quantities, source and report labels, safe toggle: '..N..' assertions (mock only)')

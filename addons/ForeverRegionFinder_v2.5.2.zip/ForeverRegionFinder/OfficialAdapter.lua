-- Exact 0.64.1 adapter for the optional ForeverDB/FRFBridge.lua module.
-- No guessing global table layouts, no collision with the unrelated forever-db.
local _, FRF = ...
local A = {}
FRF.OfficialAdapter = A
local function validId(v)
    local n = tonumber(v)
    if n and n > 0 and n == math.floor(n) then return n end
end
local function loaded(name)
    if C_AddOns and type(C_AddOns.IsAddOnLoaded) == 'function' then
        local ok,v=pcall(C_AddOns.IsAddOnLoaded,name)
        if ok then return not not v end
    end
    if type(IsAddOnLoaded) == 'function' then
        local ok,v=pcall(IsAddOnLoaded,name)
        if ok then return not not v end
    end
    return false
end
function A.IsInstalled()
    return loaded('ForeverDB')
end
function A.LoadDiagnostic()
    local diag = _G.FRF_ForeverDB_BridgeLoad
    if type(diag) ~= 'table' then return '브리지 파일이 실행되지 않음 (ForeverDB TOC 로딩 확인 필요)' end
    if diag.active then return '브리지 실행 정상' end
    return '브리지 시작됨 / 초기화 실패: '..tostring(diag.error or diag.namespaceType or 'unknown')
end
function A.IsLinked()
    local b=_G.ForeverDB_FRF_Bridge
    return type(b)=='table' and b.version==1 and type(b.Query)=='function'
end
function A.Read(npcId, npcName)
    npcId=validId(npcId)
    if not npcId then return nil,'잘못된 NPC ID' end
    if not A.IsLinked() then
        return nil, A.IsInstalled() and ('ForeverDB 설치됨 / '..A.LoadDiagnostic())
            or 'ForeverDB.net 미설치'
    end
    local ok, data, desc=pcall(_G.ForeverDB_FRF_Bridge.Query,npcId,npcName)
    if not ok then return nil,'ForeverDB 연결 오류: '..tostring(data) end
    if type(data)~='table' then return nil,desc or 'ForeverDB 데이터 조회 실패' end
    return data, desc or '공식 ForeverDB 데이터 확인'
end
function A.Open()
    if not A.IsInstalled() then return false end
    if type(SlashCmdList)=='table' then
        for key,fn in pairs(SlashCmdList) do
            if type(fn)=='function' then
                for i=1,20 do
                    local slash=_G['SLASH_'..tostring(key)..i]
                    if not slash then break end
                    if type(slash)=='string' and slash:lower()=='/fdb' then
                        return pcall(fn,'')
                    end
                end
            end
        end
    end
    return false
end

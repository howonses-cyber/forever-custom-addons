local addonName, ns = ...
local roots = {947, 946, 1414, 1415, 1413, 12, 13, 14}
local fallbackAreas = {
    [1]=1426,[3]=1418,[8]=1435,[10]=1431,[11]=1437,[12]=1429,
    [14]=1411,[15]=1445,[16]=1447,[17]=1413,[28]=1422,[33]=1434,
    [36]=1416,[38]=1432,[40]=1436,[41]=1430,[44]=1433,[45]=1417,
    [46]=1428,[47]=1425,[51]=1427,[85]=1420,[130]=1421,[139]=1423,
    [141]=1438,[148]=1439,[188]=1438,[215]=1412,[267]=1424,[331]=1440,
    [357]=1444,[361]=1448,[400]=1441,[405]=1443,[406]=1442,
    [440]=1446,[490]=1449,[618]=1452,[1377]=1451,[1519]=1453,
    [1537]=1455,[1637]=1454,[1657]=1457
}
local areaMaps = nil

-- Public QuestieDB support map, with a conservative fallback if that addon is missing.
local function LoadAreaMap()
    areaMaps = {}
    for area, map in pairs(fallbackAreas) do areaMaps[area] = map end
    local lib = LibQuestieDB
    local root = lib and lib.Support and lib.Support.Get and lib.Support.Get("ZoneDB")
    local priv = root and root.private
    if priv then
        for _, field in ipairs({"areaIdToUiMapId", "areaIdToUiMapIdOverride"}) do
            local source = priv[field]
            if type(source) == "string" and loadstring then
                local fn = loadstring(source)
                if fn then
                    local ok, data = pcall(fn)
                    if ok and type(data) == "table" then
                        for area, map in pairs(data) do
                            if type(area) == "number" and type(map) == "number" then
                                areaMaps[area] = map
                            end
                        end
                    end
                end
            elseif type(source) == "table" then
                for area, map in pairs(source) do areaMaps[area] = map end
            end
        end
    end
    ns.allAreaMaps = areaMaps
end

function ns.AreaToMap(areaId)
    if not areaMaps then LoadAreaMap() end
    local id = areaMaps[tonumber(areaId)]
    if id and ns.SafeMap(id) then return id end
    if ns.SafeMap(areaId) then return areaId end
    return nil
end

local dungeonData = {
    {"죽음의 폐광", "Deadmines", 40,42.5,71.7},
    {"스톰윈드 지하감옥", "The Stockade",1519,52.41,70.01},
    {"통곡의 동굴", "Wailing Caverns",17,46,36.5},
    {"그림자송곳니 성채", "Shadowfang Keep",130,44.8,67.8},
    {"검은심연의 나락", "Blackfathom Deeps",331,14.5,14.2},
    {"놈리건", "Gnomeregan",1,24.3,39.8},
    {"가시덩굴 우리", "Razorfen Kraul",17,42.9,90.2},
    {"가시덩굴 구릉", "Razorfen Downs",17,49,93.9},
    {"붉은십자군 수도원", "Scarlet Monastery",85,82.6,33.8},
    {"줄파락", "Zul'Farrak",440,38.7,20.1},
    {"울다만", "Uldaman",3,44.6,12.1},
    {"마라우돈", "Maraudon",405,29.1,62.5},
    {"아탈학카르 신전", "Sunken Temple",8,69.9,53.5},
    {"검은바위 나락", "Blackrock Depths",46,29.4,38.3},
    {"검은바위 첨탑", "Blackrock Spire",46,29.4,38.3},
    {"혈투의 전장", "Dire Maul",357,59.2,45.1},
    {"스트라솔름", "Stratholme",139,26.52,10.36},
    {"스칼로맨스", "Scholomance",28,69.7,73.2},
    {"오닉시아의 둥지", "Onyxia's Lair",15,52.6,76.8},
    {"화산 심장부", "Molten Core",46,29.4,38.3},
    {"검은날개 둥지", "Blackwing Lair",46,29.4,38.3},
    {"줄구룹", "Zul'Gurub",33,53.89,17.6},
    {"카라잔", "Karazhan",41,46.7,70.2},
    {"낙스라마스", "Naxxramas",139,34.25,19.45},
    {"안퀴라즈 사원", "Temple of Ahn'Qiraj",1377,28.6,92.3},
    {"안퀴라즈 폐허", "Ruins of Ahn'Qiraj",1377,28.6,92.3}
}

local function MakeEntry(kind, name, mapId, x, y, extra)
    local item = {kind=kind, name=name, norm=ns.Norm(name), map=mapId,
        x=x and x/100, y=y and y/100, extra=extra}
    ns.mapEntries[#ns.mapEntries + 1] = item
    return item
end

function ns.IndexMaps()
    ns.mapEntries = {}
    local seen = {}
    local queue = {}
    local function Add(info)
        if type(info) ~= "table" then return end
        local id = info.mapID
        if type(id) ~= "number" or seen[id] or type(info.name) ~= "string" or info.name == "" then return end
        seen[id] = true
        local mt = info.mapType
        if mt == 1 or mt == 2 or mt == 3 or mt == 4 or mt == 5 then
            MakeEntry("map",info.name,id,nil,nil,info.parentMapID)
        end
        if mt == 1 or mt == 2 or mt == 3 or mt == 4 then queue[#queue+1] = id end
    end
    for _, root in ipairs(roots) do Add(ns.SafeMap(root)) end
    local cursor = 1
    while cursor <= #queue and cursor <= 2400 do
        local id = queue[cursor]; cursor = cursor + 1
        if C_Map and C_Map.GetMapChildrenInfo then
            local ok, child = pcall(C_Map.GetMapChildrenInfo, id, nil, false)
            if ok and type(child) == "table" then
                for _, info in ipairs(child) do Add(info) end
            end
        end
    end
    -- Dungeon entries name the OUTDOOR entrance, not a fictional dungeon-floor map.
    for _, row in ipairs(dungeonData) do
        local mapId = ns.AreaToMap(row[3])
        if mapId then
            local e = MakeEntry("dungeon",row[1],mapId,row[4],row[5],row[2])
            e.alias = ns.Norm(row[2])
        end
    end
    -- Fine-grained area names can open their parent map. No invented center point.
    if C_Map and type(C_Map.GetAreaInfo) == "function" then
        local inMap = {}
        for _, e in ipairs(ns.mapEntries) do inMap[e.norm] = true end
        if not areaMaps then LoadAreaMap() end
        for areaId, mapId in pairs(areaMaps) do
            if type(mapId) == "number" and ns.SafeMap(mapId) then
                local ok, name = pcall(C_Map.GetAreaInfo, areaId)
                if ok and type(name) == "string" and name ~= "" then
                    local key = ns.Norm(name)
                    if not inMap[key] then
                        local e = MakeEntry("subzone",name,mapId,nil,nil,areaId)
                        inMap[key] = true
                    end
                end
            end
        end
    end
end

local indexFrame = CreateFrame("Frame")
local phase, cursor, npcIds, questIds = "idle", 1, nil, nil

local function DbGet(db, field, id)
    if db and type(db.Get) == "function" then
        local ok, result = pcall(db.Get, id, field)
        if ok then return result end
    end
end

local function AddDBEntry(kind, id, name, sub)
    if type(name) ~= "string" or name == "" then return end
    local entry = {kind=kind, id=id, name=name,
        norm=ns.Norm(name), extra=sub, alias=ns.Norm(sub or "")}
    ns.dbIndex[#ns.dbIndex + 1] = entry
end

function ns.BeginDB()
    if ns.dbStarted then return end
    if not (NpcDB and QuestDB and type(NpcDB.GetAllIds) == "function"
        and type(QuestDB.GetAllIds) == "function") then
        ns.dbFinished = true
        ns.dbProgress = "QuestieDB 없음: 지역·던전·좌표 검색 사용 가능"
        if ns.Refresh then ns.Refresh() end
        return
    end
    ns.dbStarted, ns.dbFinished = true, false
    ns.dbIndex = {}
    local ok1, nids = pcall(NpcDB.GetAllIds)
    local ok2, qids = pcall(QuestDB.GetAllIds)
    npcIds = ok1 and type(nids) == "table" and nids or {}
    questIds = ok2 and type(qids) == "table" and qids or {}
    phase, cursor = "npc", 1
    ns.dbProgress = "NPC/몬스터/퀘스트 색인 생성 중..."
    indexFrame:Show()
end

function ns.BeginIndex(reset)
    if reset then
        ns.dbStarted, ns.dbFinished = false, false
        ns.dbIndex = {}
        areaMaps = nil
        phase, cursor = "idle", 1
    end
    LoadAreaMap()
    ns.IndexMaps()
    ns.BeginDB()
    if ns.Refresh then ns.Refresh() end
end

indexFrame:SetScript("OnUpdate", function(self)
    if phase == "idle" or phase == "done" then self:Hide(); return end
    local budget = 110
    for _ = 1, budget do
        if phase == "npc" then
            if cursor > #npcIds then phase, cursor = "quest", 1
            else
                local id = npcIds[cursor]; cursor = cursor + 1
                AddDBEntry("npc", id, DbGet(NpcDB,"name",id), DbGet(NpcDB,"subName",id))
            end
        elseif phase == "quest" then
            if cursor > #questIds then phase = "done"; break
            else
                local id = questIds[cursor]; cursor = cursor + 1
                AddDBEntry("quest",id,DbGet(QuestDB,"name",id))
            end
        end
    end
    if phase == "done" then
        ns.dbFinished = true
        ns.dbProgress = "NPC/몬스터/퀘스트 검색 준비 완료"
        self:Hide()
    else
        ns.dbProgress = "DB 색인: " .. tostring(#ns.dbIndex) .. "개"
    end
    if ns.Refresh then ns.Refresh() end
end)
indexFrame:Hide()

function ns.Search(text)
    local query = ns.Norm(text)
    local out = {}
    if query == "" then return out end
    local coord = ns.FindCoordinate(text)
    if coord then out[#out + 1] = coord; return out end
    local function Test(row)
        local n = row.norm or ""
        local pos = string.find(n, query, 1, true)
        if not pos and row.alias and row.alias ~= "" then
            pos = string.find(row.alias, query, 1, true)
        end
        if pos then
            row._rank = (n == query and -3) or (pos == 1 and 0) or 2
            out[#out + 1] = row
        end
    end
    for _, entry in ipairs(ns.mapEntries) do Test(entry) end
    if #query >= 2 then
        for _, entry in ipairs(ns.dbIndex) do Test(entry) end
    end
    local typeOrder = {coord=0,map=1,subzone=2,dungeon=3,npc=4,quest=5}
    table.sort(out, function(a,b)
        if a._rank ~= b._rank then return a._rank < b._rank end
        local k1,k2 = typeOrder[a.kind] or 9,typeOrder[b.kind] or 9
        if k1~=k2 then return k1<k2 end
        if #a.norm~=#b.norm then return #a.norm<#b.norm end
        return a.name < b.name
    end)
    return out
end

local function AddSpawns(out, name, entityId, role, seen, provider)
    provider = provider or NpcDB
    local spawns = DbGet(provider,"spawns",entityId)
    if type(spawns) ~= "table" then return end
    for area, points in pairs(spawns) do
        local mapId = ns.AreaToMap(area)
        if mapId and type(points) == "table" then
            local count = 0
            for _, pt in ipairs(points) do
                if type(pt) == "table" then
                    local x,y=tonumber(pt[1]),tonumber(pt[2])
                    if x and y and x>=0 and x<=100 and y>=0 and y<=100 then
                        local key=string.format("%d:%.1f:%.1f",mapId,x,y)
                        if not seen[key] then
                            seen[key]=true
                            out[#out + 1] = {kind="place",name=name,map=mapId,x=x/100,y=y/100,
                                extra=role, entityId=entityId}
                            count = count+1
                        end
                        if count>=10 then break end
                    end
                end
            end
        end
    end
end

function ns.Resolve(entry)
    if not entry then return {} end
    if entry.map then return {entry} end
    local result,seen={},{}
    if entry.kind == "npc" then
        AddSpawns(result,entry.name,entry.id,"NPC 출현 기록",seen)
    elseif entry.kind == "quest" then
        local starters = DbGet(QuestDB,"startedBy",entry.id)
        local finishers = DbGet(QuestDB,"finishedBy",entry.id)
        local function AddQuestStarters(info,role)
            if type(info) ~= "table" then return end
            for _, row in ipairs({
                {ids=info.npc or info.NPC or info[1], db=NpcDB, label="NPC"},
                {ids=info.object or info.Object or info[2], db=ObjectDB, label="사물"},
            }) do
                if type(row.ids) == "table" and row.db then
                    for _, id in ipairs(row.ids) do
                        local name=DbGet(row.db,"name",id)
                        if name then
                            AddSpawns(result,entry.name .. " - " .. name,id,role.." "..row.label,seen,row.db)
                        end
                    end
                end
            end
        end
        AddQuestStarters(starters,"퀘스트 수락")
        if #result == 0 then AddQuestStarters(finishers,"퀘스트 보고 (수락 위치 없음)") end
    end
    table.sort(result,function(a,b)
        local am=ns.MapName(a.map);local bm=ns.MapName(b.map)
        if am ~= bm then return am < bm end
        if a.x~=b.x then return a.x<b.x end
        return a.y<b.y
    end)
    return result
end

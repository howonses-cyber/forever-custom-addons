-- Forever Region Finder: NPC loot providers, without inventing item chances.
-- Provider order: NorgannonDB 1.x (published schema), a structurally verified
-- forever-db library, individually sourced Classic reference rows, then
-- QuestieDB (drop source only, normally no chance). No HTTP or file I/O.
local _, FRF = ...
local bridge = {}
FRF.LootBridge = bridge
local active = nil
local serial = 0
local cache = {}
local cacheOrder = {}
local MAX_CACHE = 6
local rowsPerTick = 320

local function NumericId(value)
    local n = tonumber(value)
    if n and n > 0 and n == math.floor(n) then return n end
end

local function SafeCall(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b = pcall(fn, ...)
    if ok then return a, b end
end

local function GetNorgannon()
    local d = _G.NorgannonDB
    if type(d) ~= "table" or type(d.RequireSchema) ~= "function" then return nil end
    if SafeCall(d.RequireSchema, d, 1, 1) then return d end
    return nil
end

local function GetFlatDB()
    -- There are TWO unrelated products with near-identical names. The official
    -- ForeverDB.net 0.64.x app has no verified public drop table contract.
    local d = _G.ForeverDB
    if type(d) ~= "table" or type(d.drop) ~= "table" then return nil end
    -- Only accept the separate library if the table is actually shaped like
    -- itemId => {npcId, chanceBasisPoints, ...}. Never trust the name alone.
    local checked = 0
    for k, value in pairs(d.drop) do
        if type(k) ~= "number" or type(value) ~= "table" then return nil end
        if #value > 0 and #value % 2 == 0 then
            local a = value[1]
            if (type(a) ~= "number" and (type(a) ~= "string" or not a:match("^c%d+$")))
                or tonumber(value[2]) == nil then return nil end
            checked = checked + 1
        end
        if checked >= 3 then return d end
    end
    if checked > 0 then return d end
    return nil
end

local function GetQuestie()
    local d = _G.ItemDB
    if type(d) == "table" and type(d.GetAllIds) == "function"
       and (type(d.npcDrops) == "function" or type(d.Get) == "function") then
        return d
    end
    local lib = _G.LibQuestieDB
    if type(lib) == "table" then
        local item = lib.Item
        if type(item) == "table" and type(item.GetAllIds) == "function" then
            return item
        end
    end
    return nil
end

local function LocalItemName(id, norg, fallback)
    if GetItemInfo then
        local a = SafeCall(GetItemInfo, id)
        if type(a) == "string" and a ~= "" then return a end
    end
    if norg and type(norg.L) == "function" then
        local a = SafeCall(norg.L, norg, "items", id)
        if type(a) == "string" and a ~= "" then return a end
    end
    local qb = GetQuestie()
    if qb then
        local a = type(qb.name) == "function" and SafeCall(qb.name, id)
            or type(qb.Get) == "function" and SafeCall(qb.Get, id, "name")
        if type(a) == "string" and a ~= "" then return a end
    end
    return fallback or ("아이템 #" .. tostring(id))
end

local function ItemVisuals(id)
    local name, _, quality, _, _, _, _, _, _, icon
    if GetItemInfo then name, _, quality, _, _, _, _, _, _, icon = GetItemInfo(id) end
    if (not icon or icon == 0) and GetItemIcon then icon = SafeCall(GetItemIcon, id) end
    return name, quality, icon
end

local rank = {NorgannonDB = 100, ["ForeverDB.net"] = 110, ["forever-db"] = 85,
    ["클래식 참조"] = 50, QuestieDB = 10}

local function Insert(job, itemId, chancePercent, source, rawName, rawQuality, rawIcon, detail)
    itemId = NumericId(itemId)
    if not itemId then return end
    local chance = tonumber(chancePercent)
    if chance and (chance < 0 or chance > 100) then chance = nil end
    if chance == 0 then chance = nil end  -- zero is unknown, not a 0% drop
    local stableKey = source .. ":" .. itemId
    local old = job.byItem[stableKey]
    local score = rank[source] or 1
    if old then
        local previous = rank[old.source] or 1
        -- The more trusted source wins for naming; a real number is preferable
        -- to an unknown chance, with chance provenance stored independently.
        if score > previous then
            old.source = source
            if rawName then old.fallback = rawName end
            if rawQuality then old.quality = rawQuality end
            if rawIcon then old.icon = rawIcon end
        end
        if chance and (not old.chance or score >= (rank[old.chanceSource] or 1)) then
            old.chance = chance
            old.chanceSource = source
        end
        if detail and not old.origin then old.origin=detail.origin; old.observations=detail.observations; old.kills=detail.kills end
        return
    end
    local r = {itemId = itemId, chance = chance, chanceSource = chance and source or nil,
        source = source, fallback = rawName, quality = rawQuality or 0,
        icon = rawIcon, origin=detail and detail.origin,
        observations=detail and detail.observations, kills=detail and detail.kills}
    job.byItem[stableKey] = r
    job.rows[#job.rows + 1] = r
end

local function Notify(job)
    if active == job and type(job.onChange) == "function" then
        job.onChange(job)
    end
end

local function PutKnown(job)
    local entry = FRF.KnownLoot and FRF.KnownLoot[job.npcId]
    if not entry or type(entry.rows) ~= "table" then return end
    for _, a in ipairs(entry.rows) do
        Insert(job, a[1], a[2], "클래식 참조", a[3])
    end
end

local function PutNorg(job)
    local d = GetNorgannon()
    if not d then return end
    job.providers[#job.providers + 1] = "NorgannonDB"
    local npc = type(d.Get) == "function" and SafeCall(d.Get, d, "npcs", job.npcId)
    if npc and type(npc.drops) == "table" then
        for itemId, chance in pairs(npc.drops) do
            local item = type(d.Get) == "function" and SafeCall(d.Get, d, "items", NumericId(itemId))
            local label = type(d.L) == "function" and SafeCall(d.L, d, "items", NumericId(itemId))
            Insert(job, itemId, chance, "NorgannonDB", label,
                item and item.quality, item and item.icon)
        end
    end
    if npc then
        job.npcLevel = npc.minLevel
        job.npcMaxLevel = npc.maxLevel
    end
end

local function GetNextID(job)
    if job.phase == "flat" then
        local key, value = next(job.flat.drop, job.flatCursor)
        if key then job.flatCursor = key end
        return key, value
    end
    if job.phase == "questie" then
        job.questPos = job.questPos + 1
        local id = job.questIds and job.questIds[job.questPos]
        return id, nil
    end
    return nil
end

local function IsNpcSource(npcDrops, npcId)
    if type(npcDrops) ~= "table" then return false end
    -- Questie stores item.npcDrops as an ID list. A keyed id map is also safe.
    for key, value in pairs(npcDrops) do
        if NumericId(value) == npcId then return true end
        if NumericId(key) == npcId and (value == true or type(value) == "table") then return true end
    end
    return false
end

local function BeginQuestie(job)
    job.phase = "questie"
    local q = GetQuestie()
    if q then
        job.providers[#job.providers + 1] = "QuestieDB"
        job.questDB = q
        local ids = SafeCall(q.GetAllIds)
        if type(ids) == "table" then job.questIds = ids end
    end
    job.questPos = 0
    if not job.questIds then job.phase = "done" end
end

local function ProcessOne(job)
    local itemId, data = GetNextID(job)
    if itemId == nil then
        if job.phase == "flat" then BeginQuestie(job)
        else job.phase = "done" end
        return
    end
    job.examined = job.examined + 1
    if job.phase == "flat" and type(data) == "table" then
        for index = 1, #data-1, 2 do
            local source = data[index]
            if NumericId(source) == job.npcId or source == "c"..job.npcId then
                local chance = (tonumber(data[index+1]) or 0) / 100
                local item = job.flat.item and job.flat.item[itemId]
                Insert(job, itemId, chance, "forever-db",
                    item and item[1], item and item[2], item and item[8])
                break
            end
        end
    elseif job.phase == "questie" and job.questDB then
        local q = job.questDB
        local drops = type(q.npcDrops) == "function" and SafeCall(q.npcDrops, itemId)
            or type(q.Get) == "function" and SafeCall(q.Get, itemId, "npcDrops")
        if IsNpcSource(drops, job.npcId) then
            local label = type(q.name) == "function" and SafeCall(q.name, itemId)
                or type(q.Get) == "function" and SafeCall(q.Get, itemId, "name")
            Insert(job, itemId, nil, "QuestieDB", label)
        end
    end
end

local scanner = CreateFrame("Frame")
scanner:Hide()
scanner:SetScript("OnUpdate", function(frame)
    local job = active
    if not job or job.phase == "done" then frame:Hide(); return end
    local previousCount = #job.rows
    for _ = 1, rowsPerTick do
        if job.phase == "done" then break end
        ProcessOne(job)
    end
    if job.phase == "done" then
        job.complete = true
        cache[job.npcId] = { rows = job.rows, npcLevel = job.npcLevel,
            npcMaxLevel = job.npcMaxLevel, providers = job.providers,
            officialStatus = job.officialStatus }
        cacheOrder[#cacheOrder + 1] = job.npcId
        if #cacheOrder > MAX_CACHE then cache[table.remove(cacheOrder, 1)] = nil end
        frame:Hide()
    end
    if #job.rows ~= previousCount or job.phase == "done" or job.examined % (rowsPerTick*4) == 0 then
        Notify(job)
    end
end)

function bridge.Begin(npcId, onChange, force, npcName)
    npcId = NumericId(npcId)
    if not npcId then return nil end
    serial = serial + 1
    if force then cache[npcId] = nil end
    local c = cache[npcId]
    local job = {npcId = npcId, rows = c and c.rows or {}, byItem = {},
        onChange = onChange, providers = c and c.providers or {},
        npcLevel = c and c.npcLevel, npcMaxLevel = c and c.npcMaxLevel,
        complete = c ~= nil, phase = c and "done" or "initial",
        officialStatus = c and c.officialStatus or nil,
        examined = 0, serial = serial}
    for _, row in ipairs(job.rows) do job.byItem[row.source..":"..row.itemId] = row end
    active = job
    if c then scanner:Hide(); Notify(job); return job end
    PutKnown(job)
    PutNorg(job)
    -- The official ForeverDB.net is a separate product. Never treat the
    -- unrelated 'forever-db' library as though it were the installed app.
    local rawOfficial, officialMessage = FRF.OfficialAdapter.Read(npcId, npcName)
    job.officialStatus=officialMessage
    if type(rawOfficial)=='table' then
        job.providers[#job.providers + 1] = 'ForeverDB.net'
        for _, r in ipairs(rawOfficial) do
            Insert(job,r.itemId,r.chance,'ForeverDB.net',r.name,r.quality,r.icon,r)
        end
    end
    BeginQuestie(job)
    if job.phase == "done" then job.complete = true
    else scanner:Show() end
    Notify(job)
    return job
end

function bridge.Cancel()
    active = nil
    scanner:Hide()
end

function bridge.Sort(job, qualityOnly, provider)
    local out = {}
    if not job then return out end
    local icons = FRF.ItemVisuals
    for _, row in ipairs(job.rows) do
        local included = provider == nil or (provider == 'reference'
            and (row.source == '클래식 참조' or row.source == 'QuestieDB'))
            or row.source == provider
        if included then
            local name,qual,icon = icons and icons.Get(row.itemId, row.icon)
            if name then row.name=name end
            if type(qual)=='number' then row.quality=qual end
            if icon then row.icon=icon end
            if not row.name then row.name=LocalItemName(row.itemId,GetNorgannon(),row.fallback) end
            if icons and not icon then icons.Request(row.itemId) end
            if not qualityOnly or (tonumber(row.quality) or 0)>=2 then
                out[#out+1]=row
            end
        end
    end
    table.sort(out,function(a,b)
        if (a.chance~=nil)~=(b.chance~=nil) then return a.chance~=nil end
        if a.chance and b.chance and a.chance~=b.chance then return a.chance>b.chance end
        if a.quality~=b.quality then return (a.quality or 0)>(b.quality or 0) end
        return a.itemId<b.itemId
    end)
    return out
end

function bridge.Status(job, provider)
    if not job then return '전리품 조회 준비 중' end
    local filtered = bridge.Sort(job,false,provider)
    local suffix = not job.complete and ' (Questie 정보 추가 조사 중)' or ''
    if provider=='ForeverDB.net' then
        if #filtered==0 then return job.officialStatus or '공식 ForeverDB 자료 없음' end
        return tostring(#filtered)..'종 | ForeverDB 0.64.1 직접 조회 (출처별 표본은 아이템 툴팁)'
    end
    if provider=='NorgannonDB' and #filtered==0 then
        return GetNorgannon() and '이 몬스터의 NorgannonDB 드롭 목록 없음' or 'NorgannonDB 설치/로드 필요'
    end
    if #filtered==0 then return '이 출처의 전리품 자료 없음'..suffix end
    return tostring(#filtered)..'종 | '..tostring(provider or '전체')..suffix
end

function bridge.Diagnose()
    return "NPC드롭 DB: NorgannonDB="..(GetNorgannon() and "연결" or "없음")
        .." / forever-db 라이브러리="..(GetFlatDB() and "연결" or "없음")
        .." / QuestieDB="..(GetQuestie() and "연결" or "없음")
        ..' / 공식 ForeverDB.net='..((FRF.OfficialAdapter and FRF.OfficialAdapter.IsLinked()) and '직접 연결됨' or
          (FRF.OfficialAdapter and FRF.OfficialAdapter.IsInstalled()) and ('설치됨/'..(FRF.OfficialAdapter and FRF.OfficialAdapter.LoadDiagnostic() or '상태 미확인')) or '없음')
end

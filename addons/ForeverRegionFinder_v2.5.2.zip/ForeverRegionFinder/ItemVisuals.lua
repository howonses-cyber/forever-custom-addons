-- Resolve *real* Blizzard item icons by item ID, even when item details are not
-- cached yet. An unknown icon is never fabricated or rendered as '?'.
local _, FRF = ...
local M = {}
FRF.ItemVisuals = M
local subscribers = {}
local requested = {}
local cache = {}

local function Safe(fn, ...)
    if type(fn) ~= 'function' then return nil end
    local ok, a,b,c,d,e,f,g,h,i,j,k = pcall(fn,...)
    if ok then return a,b,c,d,e,f,g,h,i,j,k end
end

local function ValidIcon(icon)
    if type(icon)=='number' then return icon > 0 and icon ~= 134400 end
    if type(icon)=='string' then
        if icon=='' or icon=='134400' or icon:lower():find('questionmark',1,true) then return false end
        return true
    end
    return false
end
M.ValidIcon = ValidIcon
local function ItemInstantIcon(id)
    if type(GetItemInfoInstant)=='function' then
        local _,_,_,_, icon=Safe(GetItemInfoInstant, id)
        if ValidIcon(icon) then return icon end
    end
end

function M.Get(id, fallbackIcon)
    id=tonumber(id)
    if not id or id<1 then return nil,nil,nil,false end
    local name,_,quality,_,_,_,_,_,_,icon
    if type(GetItemInfo)=='function' then
        name,_,quality,_,_,_,_,_,_,icon=Safe(GetItemInfo,id)
    end
    if not ValidIcon(icon) and type(GetItemIcon)=='function' then icon=Safe(GetItemIcon,id) end
    if not ValidIcon(icon) then icon=ItemInstantIcon(id) end
    if not ValidIcon(icon) and type(C_Item)=='table' and type(C_Item.GetItemIconByID)=='function' then
        icon=Safe(C_Item.GetItemIconByID,id)
    end
    if not ValidIcon(icon) and ValidIcon(fallbackIcon) then icon=fallbackIcon end
    if not ValidIcon(icon) then icon=nil end
    if name or icon or quality then
        local c=cache[id] or {}
        if name then c.name=name end
        if type(quality)=='number' then c.quality=quality end
        if icon then c.icon=icon end
        cache[id]=c
    end
    local cached=cache[id]
    if cached then
        name=name or cached.name
        quality=quality or cached.quality
        icon=icon or cached.icon
    end
    return name,quality,icon,not not icon
end

function M.Request(id)
    id=tonumber(id)
    if not id or id<1 or requested[id] then return end
    requested[id]=true
    -- Only request, never invent an icon. Blizzard eventually sends item data
    -- through GET_ITEM_INFO_RECEIVED or ITEM_DATA_LOAD_RESULT.
    if type(C_Item)=='table' and type(C_Item.RequestLoadItemDataByID)=='function' then
        Safe(C_Item.RequestLoadItemDataByID,id)
    end
    if type(Item)=='table' and type(Item.CreateFromItemID)=='function' then
        local obj=Safe(Item.CreateFromItemID,Item,id)
        if not obj then obj=Safe(Item.CreateFromItemID, id) end
        if obj and type(obj.ContinueOnItemLoad)=='function' then
            Safe(obj.ContinueOnItemLoad,obj,function()
                M.Get(id)
                for callback in pairs(subscribers) do pcall(callback,id) end
            end)
        end
    end
end

function M.Subscribe(callback)
    if type(callback)=='function' then subscribers[callback]=true end
end
local event=CreateFrame('Frame')
pcall(event.RegisterEvent,event,'GET_ITEM_INFO_RECEIVED')
pcall(event.RegisterEvent,event,'ITEM_DATA_LOAD_RESULT')
event:SetScript('OnEvent',function(_,eventName,itemId,success)
    itemId=tonumber(itemId)
    if not itemId then return end
    -- False indicates the server cannot supply this item; don't fabricate an icon.
    M.Get(itemId)
    for callback in pairs(subscribers) do pcall(callback,itemId,success) end
end)

function M.ClearRequests()
    requested={}
end

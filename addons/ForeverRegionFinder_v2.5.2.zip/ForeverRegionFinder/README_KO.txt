Forever Region Finder v2.5.0 — ForeverDB.net 0.64.1 직접 연동 패치
=====================================================================

이 패치는 사용자가 제공한 ForeverDB.net 0.64.1 실제 배포 소스의
LootBrowser.parseLoot, Data/Loot.lua, Rares.info, SavedVariables 구조를
확인하고 이에 맞춰 개발했습니다. 존재하지 않는 API를 추정하지 않습니다.

[지원 기능]
- 기존 지역/NPC/보스/던전/퀘스트/좌표 검색 유지
- 몬스터 3D 모델 및 아이템 실제 아이콘 표시 유지
- ForeverDB 탭: 설치된 공식 DB의 던전 보스, 희귀 NPC,
  본인 획득 기록을 직접 읽어 아이템 ID·확률을 표시
- NorgannonDB 탭: 원래처럼 완전히 독립된 전리품·확률
- 클래식 참고: 별도 표시. 각 DB 확률을 서로 섞지 않음
- ForeverDB 탭 클릭 시 /fdb 설정 창을 자동으로 열던 동작 제거
- 클릭한 아이템의 툴팁에 Forever 관측/클래식/본인 획득 출처 표기
- 공식 자료에 없는 NPC는 연동 오류 대신 '자료 없음' 표시

[중요: 공식 데이터 범위]
ForeverDB.net 0.64.1 내장 데이터는 모든 일반 야외 몬스터의
전리품을 보장하지 않습니다. 예: NPC #5328은 공식 보스/희귀
드롭 테이블에 항목이 없어서 NorgannonDB의 자료만 보일 수 있습니다.
이건 연동 오류가 아니라 원본 자료의 범위입니다.
도안 확률은 Forever 서버 관측(f) 또는 클래식 참고(c)입니다.
공식 0.64.1 내장 데이터에 출처 표기가 있고, 실제 서버 확률 보장은 아닙니다.

[필요 파일과 설치]
- ForeverDB (0.64.1): 필요. 기존 설정(Data collection only 포함) 유지 가능
- NorgannonDB: Norgannon 탭의 선택 사항
- QuestieDB: 기존 NPC 위치/퀘스트 조회용
- ForeverDB_Helper: 별도 변경 불필요

게임을 완전히 종료하고 기존 폴더를 백업한 뒤
패치 ZIP의 ForeverDB와 ForeverRegionFinder 두 폴더를
월드 오브 워크래프트 포에버\Interface\AddOns\ 에 병합합니다.
폴더 병합 시 ForeverDB.toc 파일 덮어쓰기 필요.
다른 공식 DB 소스/설정/WTF는 수정하지 않습니다.
반드시 ForeverDB 0.64.1에서만 이 .toc 교체 패치를 사용하세요.
향후 ForeverDB 공식 업데이트 시 연동 모듈이 덮어써질 수 있습니다.

[확인 방법]
1. 게임 재시작(캐릭터 선택 화면부터)
2. M -> NPC / 보스 검색 -> ForeverDB 탭 선택
3. /rfind db : 공식 ForeverDB=직접 연결됨 확인
4. '자료 없음'은 해당 NPC의 공식 DB 드롭 항목 부재 의미

[검증 범위]
Lua 5.4 컴파일, 실제 0.64.1 Data/Loot.lua 보스 데이터,
Data/Rares.lua 기반 희귀 NPC, 본인 관측 데이터,
NorgannonDB 탭 분리와 상태 표시까지 로컬 테스트 통과.
WoW Forever 클라이언트에서 직접 실행 검증은 하지 못했습니다.

[출처 및 라이선스]
Data from ForeverDB.net (https://foreverdb.net).
ForeverDB original: GPL-3.0 with extra attribution, original NOTICE.txt.
CMaNGOS classic-db (Classic 참고 데이터): GPL-3.0.
이 패치는 원본 데이터 파일을 변경하거나 복사하지 않고
기존 ForeverDB 설치의 로드된 namespace를 읽는 선택적 연결 모듈입니다.

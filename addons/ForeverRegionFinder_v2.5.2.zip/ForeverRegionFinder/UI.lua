local addonName, ns = ...
local panel, toggle, edit, dropdown, status, selectedInfo, pin
local navButton, mapButton, rows = nil,nil,{}
local mapFrame, attached, searchRows, page = nil,false,{},0
local currentChoices = nil
local currentQuery = ""

local category = {map="지역",subzone="세부 지역",dungeon="던전 입구",npc="NPC/몬스터",
    quest="퀘스트",coord="좌표",place="기록된 위치"}

local function Backdrop(frame)
    if not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
        tile=true,tileSize=12,edgeSize=12,
        insets={left=3,right=3,top=3,bottom=3}
    })
    frame:SetBackdropColor(0.02,0.035,0.052,0.97)
    frame:SetBackdropBorderColor(0.23,0.53,0.62,0.96)
end

local function Text(parent, font, x, y, value)
    local fs = parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    if value then fs:SetText(value) end
    return fs
end

local function Button(parent, label, width, height)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(width,height)
    if b.SetText then b:SetText(label) end
    return b
end

local function HideResults()
    if dropdown then dropdown:Hide() end
end

local function SetPanelPos()
    if not panel or not mapFrame then return end
    panel:ClearAllPoints()
    local x=ns.settings.x or 70
    local y=ns.settings.y or -142
    panel:SetPoint("TOPLEFT",mapFrame,"TOPLEFT",x,y)
end

ns.ResetPanel = function()
    SetPanelPos()
    if panel then panel:Show() end
    ns.settings.open = true
end

local function Status(message)
    if status then status:SetText(message or "") end
end

local function SelectTarget(entry)
    ns.SetTarget(entry)
    HideResults()
    if edit then
        edit:SetText(entry.name)
        edit:ClearFocus()
    end
    currentQuery = entry.name
    local info = entry.x and string.format("%s %.1f, %.1f",ns.MapName(entry.map),entry.x*100,entry.y*100)
        or ns.MapName(entry.map)
    Status((category[entry.kind] or "목적지").." | "..info)
end

local function SortLocations(list)
    local map = _G.WorldMapFrame
    local current = map and map.GetMapID and map:GetMapID()
    local best = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    table.sort(list,function(a,b)
        local aa=(a.map==best and 0 or a.map==current and 1 or 2)
        local bb=(b.map==best and 0 or b.map==current and 1 or 2)
        if aa~=bb then return aa<bb end
        if a.map~=b.map then return ns.MapName(a.map)<ns.MapName(b.map) end
        if a.x~=b.x then return a.x<b.x end
        return a.y<b.y
    end)
end

local function OnEntry(entry)
    if not entry then return end
    -- Show the creature page even if QuestieDB has no spawn points for this NPC.
    if entry.kind == "npc" and ns.ShowCreatureDetails then ns.ShowCreatureDetails(entry) end
    if entry.map then
        SelectTarget(entry)
        return
    end
    local points = ns.Resolve(entry)
    if not points or #points==0 then
        Status((category[entry.kind] or "대상").." 위치 자료가 없습니다. QuestieDB 내용을 확인하세요.")
        ns.Print("위치를 찾지 못했습니다: "..entry.name)
        return
    end
    SortLocations(points)
    if #points == 1 then SelectTarget(points[1]); return end
    currentChoices = points
    page=0
    if ns.Refresh then ns.Refresh() end
    Status("같은 대상의 출현 위치 "..tostring(#points).."개. 하나를 선택하세요.")
end

local function BuildRows()
    if not dropdown then return end
    searchRows = currentChoices or ns.Search(currentQuery)
    if not currentChoices then page=math.max(0,math.min(page,math.max(0,#searchRows-ns.maxRows))) end
    if ns.Norm(currentQuery)=="" and not currentChoices then HideResults();return end
    dropdown:Show()
    local showing=math.min(ns.maxRows,#searchRows)
    dropdown:SetHeight(29+math.max(showing,1)*32)
    dropdown.title:SetText(currentChoices and "위치 선택 (위/아래 스크롤)" or "검색 결과 (Enter/클릭 선택)")
    dropdown.count:SetText(tostring(#searchRows).."개")
    dropdown.empty:Hide()
    if #searchRows==0 then
        dropdown.empty:SetText(ns.dbStarted and not ns.dbFinished and
            "NPC/퀘스트 목록 읽는 중..." or "일치하는 검색 결과가 없습니다.")
        dropdown.empty:Show()
    end
    for i=1,ns.maxRows do
        local b=rows[i]
        local item=searchRows[page+i]
        if item then
            b.entry=item
            b.main:SetText(item.name)
            local detail=category[item.kind] or ""
            if item.map then detail=detail.." | "..ns.MapName(item.map) end
            if item.x and item.y then detail=string.format("%s %.1f,%.1f",detail,item.x*100,item.y*100) end
            b.detail:SetText(detail)
            b:Show()
        else
            b.entry=nil;b:Hide()
        end
    end
end

ns.Refresh = function()
    if not panel or not panel:IsShown() then return end
    if status and not ns.selected then Status(ns.dbProgress) end
    BuildRows()
end

local function OnTextChanged(self)
    currentChoices=nil
    currentQuery=self:GetText() or ""
    page=0
    if self.placeholder then self.placeholder:SetShown(currentQuery=="") end
    if dropdown then BuildRows() end
end

local function OnSearchEnter()
    if #searchRows==0 then return end
    local e=searchRows[page+1]
    if e then OnEntry(e) end
end

local function MakeRow(parent,index)
    local b=CreateFrame("Button",nil,parent)
    b:SetHeight(32)
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",8,-26-(index-1)*32)
    b:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-8,-26-(index-1)*32)
    b.main=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    b.main:SetPoint("TOPLEFT",b,"TOPLEFT",7,-3)
    b.main:SetPoint("TOPRIGHT",b,"TOPRIGHT",-5,-3)
    b.main:SetJustifyH("LEFT")
    b.main:SetWordWrap(false)
    b.detail=b:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    b.detail:SetPoint("TOPLEFT",b,"TOPLEFT",7,-17)
    b.detail:SetPoint("TOPRIGHT",b,"TOPRIGHT",-5,-17)
    b.detail:SetJustifyH("LEFT")
    b.detail:SetWordWrap(false)
    local hi=b:CreateTexture(nil,"BACKGROUND")
    hi:SetAllPoints(b)
    hi:SetColorTexture(0.13,0.27,0.33,0.9)
    b:SetScript("OnEnter",function() hi:Show() end)
    b:SetScript("OnLeave",function() hi:Hide() end)
    b:SetScript("OnClick",function(self) OnEntry(self.entry) end)
    hi:Hide()
    b:Hide()
    return b
end

ns.UpdateTarget = function()
    if not selectedInfo then return end
    local t=ns.selected
    if not t then
        selectedInfo:SetText("선택된 목적지 없음")
        return
    end
    if t.x and t.y then
        selectedInfo:SetText(string.format("선택: %s  |  %s (%.1f, %.1f)",t.name,ns.MapName(t.map),t.x*100,t.y*100))
    else
        selectedInfo:SetText("선택: "..t.name.." (지도 중심 경로)")
    end
end

ns.UpdatePin = function()
    if not pin or not mapFrame then return end
    pin:Hide()
    local t=ns.selected
    if not t or not t.map or not t.x or not t.y then return end
    local shown=mapFrame.GetMapID and mapFrame:GetMapID()
    if shown~=t.map then return end
    local scroll=mapFrame.ScrollContainer
    local child=scroll and scroll.Child
    if not child or not child.GetWidth or not child.GetHeight then return end
    local w,h=child:GetWidth(),child:GetHeight()
    if not w or not h or w<=0 or h<=0 then return end
    pin:SetParent(child)
    pin:ClearAllPoints()
    pin:SetPoint("CENTER",child,"TOPLEFT",w*t.x,-h*t.y)
    pin:Show()
end

local function MakeUI(map)
    mapFrame=map
    toggle=Button(map,"찾기",52,24)
    toggle:SetPoint("TOPLEFT",map,"TOPLEFT",70,-108)
    toggle:SetFrameLevel(map:GetFrameLevel()+80)
    toggle:SetScript("OnClick",function()
        if panel:IsShown() then
            panel:Hide();ns.settings.open=false
        else
            panel:Show();ns.settings.open=true
            if edit then edit:SetFocus() end
        end
    end)

    panel=CreateFrame("Frame","ForeverRegionFinderPanel",map,"BackdropTemplate")
    panel:SetSize(415,119)
    panel:SetFrameLevel(map:GetFrameLevel()+85)
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    Backdrop(panel)
    SetPanelPos()

    local handle=CreateFrame("Frame",nil,panel)
    handle:SetPoint("TOPLEFT",panel,"TOPLEFT",5,-3)
    handle:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-36,-3)
    handle:SetHeight(22)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart",function() panel:StartMoving() end)
    handle:SetScript("OnDragStop",function()
        panel:StopMovingOrSizing()
        if ns.settings and map.GetLeft and map.GetTop and panel.GetLeft and panel.GetTop then
            local l,t,pl,pt=map:GetLeft(),map:GetTop(),panel:GetLeft(),panel:GetTop()
            if l and t and pl and pt then
                ns.settings.x,ns.settings.y=pl-l,pt-t
            end
        end
    end)
    Text(panel,"GameFontNormalSmall",12,-9,"|cff62ddd1포에버 통합 검색|r  |cff9ab0ba(제목 드래그 이동)|r")
    local close=Button(panel,"X",25,22)
    close:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-5,-4)
    close:SetScript("OnClick",function() panel:Hide();ns.settings.open=false end)

    edit=CreateFrame("EditBox","ForeverRegionFinderEditBox",panel,"InputBoxTemplate")
    edit:SetAutoFocus(false)
    edit:SetHeight(25)
    edit:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-27)
    edit:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-16,-27)
    edit:SetMaxLetters(100)
    edit:SetFontObject("GameFontHighlightSmall")
    edit.placeholder=edit:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    edit.placeholder:SetPoint("LEFT",edit,"LEFT",7,0)
    edit.placeholder:SetText("지역 / NPC / 몬스터 / 퀘스트 / 던전 / 좌표")
    edit:SetScript("OnTextChanged",OnTextChanged)
    edit:SetScript("OnEnterPressed",OnSearchEnter)
    edit:SetScript("OnEscapePressed",function(self) HideResults();self:ClearFocus() end)
    edit:SetScript("OnEditFocusGained",function() if currentQuery~="" then BuildRows() end end)
    edit:SetScript("OnKeyDown",function(self,key)
        if key=="DOWN" then
            page=math.min(math.max(0,#searchRows-ns.maxRows),page+1)
            BuildRows()
        elseif key=="UP" then
            page=math.max(0,page-1)
            BuildRows()
        end
    end)

    mapButton=Button(panel,"지도 표시",88,24)
    mapButton:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-117,13)
    mapButton:SetScript("OnClick",function()
        local t=ns.selected
        if t then ns.OpenMap(t.map);ns.UpdatePin()
        else ns.Print("먼저 검색 결과를 선택하세요.") end
    end)
    navButton=Button(panel,"길찾기",101,24)
    navButton:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-10,13)
    navButton:SetScript("OnClick",function() ns.StartNavigation() end)

    status=panel:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    status:SetPoint("TOPLEFT",panel,"TOPLEFT",14,-61)
    status:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-9,-61)
    status:SetJustifyH("LEFT")
    status:SetWordWrap(false)
    selectedInfo=panel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    selectedInfo:SetPoint("BOTTOMLEFT",panel,"BOTTOMLEFT",14,17)
    selectedInfo:SetWidth(169)
    selectedInfo:SetJustifyH("LEFT")
    selectedInfo:SetWordWrap(false)
    selectedInfo:SetText("선택된 목적지 없음")
    Status(ns.dbProgress)

    dropdown=CreateFrame("Frame","ForeverRegionFinderResults",panel,"BackdropTemplate")
    dropdown:SetWidth(panel:GetWidth())
    dropdown:SetHeight(60)
    dropdown:SetPoint("TOPLEFT",panel,"BOTTOMLEFT",0,-4)
    dropdown:SetFrameLevel(panel:GetFrameLevel()+2)
    dropdown:EnableMouse(true)
    dropdown:EnableMouseWheel(true)
    Backdrop(dropdown)
    dropdown.title=Text(dropdown,"GameFontDisableSmall",12,-8,"검색 결과")
    dropdown.count=dropdown:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    dropdown.count:SetPoint("TOPRIGHT",dropdown,"TOPRIGHT",-13,-8)
    dropdown.empty=dropdown:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    dropdown.empty:SetPoint("CENTER",dropdown,"CENTER",0,-8)
    dropdown.empty:Hide()
    for i=1,ns.maxRows do rows[i]=MakeRow(dropdown,i) end
    dropdown:SetScript("OnMouseWheel",function(_,wheel)
        page=math.max(0,math.min(math.max(0,#searchRows-ns.maxRows),page-(wheel*2)))
        BuildRows()
    end)
    dropdown:Hide()

    pin=CreateFrame("Frame","ForeverRegionFinderTargetPin",map)
    pin:SetSize(22,22)
    pin:SetFrameStrata("TOOLTIP")
    local dot=pin:CreateTexture(nil,"OVERLAY")
    dot:SetAllPoints(pin)
    dot:SetColorTexture(1,0.75,0.15,0.8)
    local point=pin:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    point:SetPoint("CENTER",pin,"CENTER",0,1)
    point:SetText("+")
    pin:EnableMouse(true)
    pin:SetScript("OnEnter",function(self)
        if not ns.selected then return end
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:SetText(ns.selected.name)
        GameTooltip:Show()
    end)
    pin:SetScript("OnLeave",function() GameTooltip:Hide() end)
    pin:Hide()

    map:HookScript("OnShow",function()
        toggle:Show()
        if ns.settings.open then panel:Show() else panel:Hide() end
        ns.UpdatePin()
    end)
    map:HookScript("OnHide",function()
        HideResults()
        edit:ClearFocus()
        if pin then pin:Hide() end
    end)
    if map.HookScript then
        local timePassed, lastMap, lastW, lastH = 0, nil, nil, nil
        map:HookScript("OnUpdate",function(_,elapsed)
            timePassed = timePassed + (elapsed or 0)
            if timePassed < 0.25 then return end
            timePassed = 0
            local mapId = map.GetMapID and map:GetMapID()
            local child = map.ScrollContainer and map.ScrollContainer.Child
            local w = child and child.GetWidth and child:GetWidth()
            local h = child and child.GetHeight and child:GetHeight()
            if mapId ~= lastMap or w ~= lastW or h ~= lastH then
                lastMap,lastW,lastH = mapId,w,h
                ns.UpdatePin()
            elseif ns.selected and pin and not pin:IsShown() and mapId == ns.selected.map then
                ns.UpdatePin()
            end
        end)
    end
    if not ns.settings.open then panel:Hide() end
    if ns.pending and ns.pending~="" then
        edit:SetText(ns.pending); ns.pending=nil
    end
end

ns.TryAttach = function()
    if attached then return true end
    local map=_G.WorldMapFrame
    if not map or type(map.HookScript)~="function" then return false end
    MakeUI(map)
    attached=true
    return true
end

ns.ShowSearch=function(text)
    if not ns.TryAttach() then ns.pending=text;return end
    if not mapFrame:IsShown() then ns.OpenMap() end
    ns.settings.open=true
    panel:Show()
    if text and text~="" then edit:SetText(text) end
    edit:SetFocus()
    if currentQuery~="" then BuildRows() end
end

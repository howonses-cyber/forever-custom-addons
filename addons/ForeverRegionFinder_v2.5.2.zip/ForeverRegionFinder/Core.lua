local addonName, ns = ...
ns = ns or {}
_G.ForeverRegionFinder = ns
ns.name = addonName or "ForeverRegionFinder"
ns.maxRows = 7
ns.mapEntries = {}
ns.entries = {}
ns.selected = nil
ns.dbIndex = {}
ns.dbProgress = ""
ns.dbFinished = false
ns.dbStarted = false
ns.allAreaMaps = nil
ns.settings = {}

function ns.Print(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff58cdd0[FRF]|r " .. tostring(message))
    end
end

function ns.Norm(text)
    return string.lower(tostring(text or "")):gsub("[%s%p%c]", "")
end

function ns.SafeMap(mapId)
    if not (C_Map and C_Map.GetMapInfo and type(mapId) == "number") then return nil end
    local ok, info = pcall(C_Map.GetMapInfo, mapId)
    if ok and type(info) == "table" then return info end
end

function ns.MapName(mapId)
    local m = ns.SafeMap(mapId)
    return m and m.name or ("Map #" .. tostring(mapId))
end

local function SaveDefault()
    if type(ForeverRegionFinderDB) ~= "table" then ForeverRegionFinderDB = {} end
    ns.settings = ForeverRegionFinderDB
    if ns.settings.open == nil then ns.settings.open = true end
end

function ns.CanAct()
    return not (InCombatLockdown and InCombatLockdown())
end

function ns.OpenMap(mapId)
    if not ns.CanAct() then ns.Print("전투 중에는 지도 전환이 제한될 수 있습니다."); return false end
    local map = _G.WorldMapFrame
    local ok = false
    if C_Map and C_Map.OpenWorldMap then
        ok = pcall(C_Map.OpenWorldMap, mapId)
    end
    if map and not map:IsShown() and ToggleWorldMap and not ok then
        ok = pcall(ToggleWorldMap)
    end
    if map and map.SetMapID and mapId then
        ok = pcall(map.SetMapID, map, mapId) or ok
    end
    return ok
end

function ns.SetNativeWaypoint(target)
    if not (target and target.map and target.x and target.y) then return false end
    if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.Create then
        local good, p = pcall(UiMapPoint.Create, target.map, target.x, target.y)
        if good and p then
            local set, accepted = pcall(C_Map.SetUserWaypoint, p)
            if set and accepted ~= false then
                if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
                    pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
                end
                return true
            end
        end
    end
    if TomTom and type(TomTom.AddWaypoint) == "function" then
        local ok = pcall(TomTom.AddWaypoint, TomTom, target.map, target.x, target.y,
            {title = target.name or "FRF", persistent = false})
        if ok then return true end
    end
    return false
end

function ns.SetTarget(item)
    ns.selected = item
    if not item then return end
    if item.map then ns.OpenMap(item.map) end
    if item.x and item.y then
        ns.SetNativeWaypoint(item)
    end
    if ns.UpdatePin then ns.UpdatePin() end
    if ns.UpdateTarget then ns.UpdateTarget() end
    if ns.ShowCreatureDetails then ns.ShowCreatureDetails(item) end
end

function ns.StartNavigation()
    local t = ns.selected
    if not t then ns.Print("먼저 검색 결과를 선택하세요."); return false end
    if not t.map then ns.Print("선택한 결과의 지도 좌표가 없습니다."); return false end
    local x, y = t.x, t.y
    if not x or not y then
        -- The map center is only a fallback target, never an asserted entrance point.
        x, y = 0.5, 0.5
        ns.Print("세부 좌표가 없어 해당 지역 지도 중앙을 목적지로 사용합니다.")
    end
    if not ns.CanAct() then ns.Print("전투 종료 후 길찾기를 시작하세요."); return false end
    local api = ShortestPathForever and ShortestPathForever.API
    if api and type(api.Navigate) == "function" and (api.version == 1 or api.version == 2) then
        local ok, started = pcall(api.Navigate, ns.name, t.map, x, y, t.name)
        if ok and started then
            ns.Print("최적 경로 안내 시작: " .. t.name .. " (Shortest Path Forever)")
            return true
        end
        ns.Print("최단 경로를 계산하지 못했습니다. 경로 엔진의 지도 데이터/전투 상태를 확인하세요.")
        return false
    end
    local fake = {map=t.map, x=x, y=y, name=t.name}
    local pinned = ns.SetNativeWaypoint(fake)
    if pinned then
        ns.Print("목적지 표시만 했습니다. 배·비행경로를 계산하려면 Shortest Path Forever를 설치하세요.")
    else
        ns.Print("최단 경로 엔진(Shortest Path Forever)이 없습니다. 지도를 열어 위치를 확인하세요.")
    end
    return false
end

function ns.FindCoordinate(text)
    local prefix, sx, sy = tostring(text or ""):match("^(.-)%s*(%d+%.?%d*)%s*[,， ]+%s*(%d+%.?%d*)%s*$")
    if not sx then return nil end
    local x, y = tonumber(sx), tonumber(sy)
    if not x or not y or x < 0 or x > 100 or y < 0 or y > 100 then return nil end
    local mapId
    local needle = ns.Norm(prefix)
    if needle ~= "" then
        mapId = tonumber(needle)
        if not mapId then
            local shortest = 999
            for _, item in ipairs(ns.mapEntries) do
                local s = item.norm or ns.Norm(item.name)
                if s == needle then
                    mapId = item.map
                    break
                elseif string.find(s, needle, 1, true) and #s < shortest then
                    shortest, mapId = #s, item.map
                end
            end
        end
        if not ns.SafeMap(mapId) then return nil end
    else
        local map = _G.WorldMapFrame
        local shown = map and map.GetMapID and map:GetMapID()
        local inf = ns.SafeMap(shown)
        if inf and inf.mapType == 3 then mapId = shown end
        if not mapId and C_Map and C_Map.GetBestMapForUnit then
            local ok, id = pcall(C_Map.GetBestMapForUnit, "player")
            if ok then mapId = id end
        end
    end
    if not ns.SafeMap(mapId) then return nil end
    return {name=string.format("%s (%.1f, %.1f)", ns.MapName(mapId), x, y),
        map=mapId, x=x/100, y=y/100, kind="coord"}
end

function ns.ResetUI()
    ns.settings.x, ns.settings.y = nil, nil
    if ns.ResetPanel then ns.ResetPanel() end
end

SLASH_FOREVERREGIONFINDER1 = "/rfind"
SLASH_FOREVERREGIONFINDER2 = "/지역검색"
SlashCmdList.FOREVERREGIONFINDER = function(message)
    local arg = tostring(message or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if arg == "db" then
        if ns.DiagnoseForeverDB then ns.DiagnoseForeverDB()
        else ns.Print("몬스터 정보 모듈 로딩 실패") end
        return
    end
    if arg == "reset" then ns.ResetUI(); ns.Print("검색창 위치를 초기화했습니다."); return end
    if arg == "refresh" then
        if ns.BeginIndex then ns.BeginIndex(true) end
        ns.Print("지도 및 DB 목록을 다시 읽습니다.")
        return
    end
    if ns.ShowSearch then ns.ShowSearch(arg) else ns.pending = arg end
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(self, event, addon)
    if event == "PLAYER_LOGIN" then
        SaveDefault()
        if ns.BeginIndex then ns.BeginIndex() end
        if ns.TryAttach then ns.TryAttach() end
    elseif addon == "Blizzard_WorldMap" or addon == "QuestieDB" then
        if ns.TryAttach then ns.TryAttach() end
        if addon == "QuestieDB" and ns.BeginDB then ns.BeginDB() end
    end
end)

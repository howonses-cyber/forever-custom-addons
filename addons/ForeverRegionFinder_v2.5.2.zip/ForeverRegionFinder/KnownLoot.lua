-- Targeted, cited Classic-reference fallback for NPC #5328.
-- NOT a complete Forever loot table. Entries are direct chance values from
-- classic-db snapshot; shared reference-pool rolls are intentionally excluded.
-- Reference: https://www.wowforeverfriends.org/npcs/5328/
local _, FRF = ...
FRF.KnownLoot = {
    [5328] = {
        source = "클래식 참조 (포에버 미검증)",
        rows = {
            {7973, 28.6624, "큰입조개 (Big-mouth Clam)"},
            {1645, 3.1847, "달딸기 주스 (Moonberry Juice)"},
            {4603, 3.1847, "날것의 점박이놀래기 (Raw Spotted Yellowtail)"},
            {3928, 1.9108, "최상급 치유 물약 (Superior Healing Potion)"},
            {6149, 1.2739, "상급 마나 물약 (Greater Mana Potion)"},
            {8705, 1.0000, "OOX-22/FE 구조 요청 신호"},
            {4637, 0.6369, "강철 자물쇠 상자 (Steel Lockbox)"},
            {7909, 0.3200, "남옥 (Aquamarine)"},
            {3395, 0.1000, "조제법: 제한된 무적 물약"},
            {3864, 0.1000, "황수정 (Citrine)"},
            {10301, 0.0300, "도안: 흰색 산적 복면"},
            {10302, 0.0300, "도안: 붉은 마법매듭 바지"},
        },
    },
}

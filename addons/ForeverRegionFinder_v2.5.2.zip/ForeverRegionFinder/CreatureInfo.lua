-- NPC details: real client item icons, independent provider tabs, no fake icons.
local _, FRF = ...
local panel, model, title, sub, tip, countLabel, pageLabel, filterButton, reloadButton
local rows, tabs, note={},{},nil
local state={npcId=nil, name=nil, job=nil, filtered={}, page=0,
             qualityOnly=false, source='NorgannonDB'}
local PAGE_SIZE=8
local SOURCES={'ForeverDB.net','NorgannonDB','reference'}

local function FrameStyle(f)
    if not f.SetBackdrop then return end
    f:SetBackdrop({bgFile='Interface\\Tooltips\\UI-Tooltip-Background',
      edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',tile=true,tileSize=12,edgeSize=12,
      insets={left=4,right=4,top=4,bottom=4}})
    f:SetBackdropColor(0.018,0.028,0.04,0.98)
    f:SetBackdropBorderColor(0.25,0.55,0.60,1)
end
local function Button(parent,text,w,h)
    local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    b:SetSize(w,h)
    b:SetText(text)
    return b
end
local function Field(parent,font,anchor,x,y,value)
    local t=parent:CreateFontString(nil,'OVERLAY',font)
    t:SetPoint(anchor,parent,anchor,x,y)
    if value then t:SetText(value) end
    return t
end
local function OpenOfficial()
    local ok=FRF.OfficialAdapter and FRF.OfficialAdapter.Open()
    if not ok and FRF.Print then FRF.Print('공식 ForeverDB: 채팅창에 /fdb 를 입력하세요.') end
end
local Repaint
local function SelectSource(value)
    state.source=value
    state.page=0
    if FRF.settings then FRF.settings.lootSource=value end
    Repaint()
    -- Never open the official settings/window as a side effect of switching tabs.
end
Repaint=function()
    if not panel then return end
    local job=state.job
    state.filtered=FRF.LootBridge.Sort(job,state.qualityOnly,state.source)
    local officialEmpty = state.source=='ForeverDB.net' and
        #FRF.LootBridge.Sort(job,false,'ForeverDB.net')==0
    local fallbackRows = officialEmpty and FRF.LootBridge.Sort(job,state.qualityOnly,'NorgannonDB') or {}
    local usingFallback = officialEmpty and #fallbackRows>0
    if usingFallback then state.filtered=fallbackRows end
    local total=#state.filtered
    local pages=math.max(1,math.ceil(total/PAGE_SIZE))
    state.page=math.max(0,math.min(state.page,pages-1))
    pageLabel:SetText((state.page+1)..' / '..pages)
    if usingFallback then
        countLabel:SetText('ForeverDB 0종 | NorgannonDB 참고 전리품 '..#fallbackRows..'종')
    else
        countLabel:SetText(FRF.LootBridge.Status(job,state.source))
    end
    if job and job.npcLevel then
        local hi=job.npcMaxLevel
        sub:SetText('레벨 '..job.npcLevel..(hi and hi~=job.npcLevel and ('-'..hi) or ''))
    else sub:SetText('NPC # '..tostring(state.npcId or '?')) end
    for _,source in ipairs(SOURCES) do
        local b=tabs[source]
        if b then b:SetText((source=='ForeverDB.net' and 'ForeverDB' or
                source=='NorgannonDB' and 'NorgannonDB' or '클래식 참고')..
                (state.source==source and ' ●' or '')) end
    end
    local validIcon=FRF.ItemVisuals and FRF.ItemVisuals.ValidIcon
    for i=1,PAGE_SIZE do
        local r=rows[i]
        local data=state.filtered[state.page*PAGE_SIZE+i]
        if data then
            r.itemId=data.itemId
            r.data=data
            local icon=data.icon
            if not(validIcon and validIcon(icon)) then
                local _,_,fresh=FRF.ItemVisuals.Get(data.itemId,icon)
                icon=fresh
                if icon then data.icon=icon end
            end
            if validIcon and validIcon(icon) then
                r.icon:SetTexture(icon)
                r.icon:Show()
                r.noIcon:Hide()
            else
                r.icon:Hide()
                r.noIcon:Show()
            end
            r.name:SetText(data.name or data.fallback or ('아이템 #'..data.itemId))
            if data.chance then
                r.percent:SetText(string.format('%.2f%%',data.chance))
            else r.percent:SetText('미확인') end
            r:Show()
        else
            r.itemId=nil;r.data=nil;r:Hide()
        end
    end
    local noEntries=total==0
    if usingFallback then
        note:SetText('공식 ForeverDB에 이 몬스터의 기록이 없어 NorgannonDB를 표시합니다.\n현재 보이는 아이템과 확률은 ForeverDB 자료가 아닙니다.')
    elseif noEntries and state.qualityOnly and #FRF.LootBridge.Sort(job,false,state.source)>0 then
        note:SetText('해당 아이템은 존재하지만 고급 이상 필터로 숨겨졌습니다.\n아래 [전체 보기]를 누르세요.')
    elseif state.source=='ForeverDB.net' and noEntries then
        if FRF.OfficialAdapter and FRF.OfficialAdapter.IsLinked() then
            note:SetText('공식 ForeverDB에 이 NPC의 전리품 출처가 없습니다.\nNorgannonDB 탭에서 별도 참고자료를 확인할 수 있습니다.')
        else
            note:SetText('ForeverDB 연동 상태: '..(FRF.OfficialAdapter and FRF.OfficialAdapter.LoadDiagnostic() or '확인 불가')..'\n이 통합팩은 일반/Camelot TOC 양쪽에 연결 모듈을 등록합니다.')
        end
    elseif state.source=='NorgannonDB' and noEntries then
        note:SetText('NorgannonDB에 이 몬스터의 아이템 목록이 없거나\n데이터 연결이 완료되지 않았습니다.')
    elseif state.source=='reference' and noEntries then
        note:SetText('클래식/Questie 참고 데이터가 없습니다.')
    else note:SetText('') end
    filterButton:SetText(state.qualityOnly and '전체 보기' or '고급 이상')
end
local function ShowModel(npcId)
    if not model then return end
    if model.ClearModel then pcall(model.ClearModel,model) end
    local ok=false
    if type(model.SetCreature)=='function' then ok=pcall(model.SetCreature,model,npcId) end
    if model.SetPortraitZoom then pcall(model.SetPortraitZoom,model,0.85) end
    if model.SetCamDistanceScale then pcall(model.SetCamDistanceScale,model,1.15) end
    if model.SetRotation then pcall(model.SetRotation,model,0.35) end
    tip:SetText(ok and '몬스터 3D 미리보기' or '3D 모델을 지원하지 않는 NPC일 수 있음')
end
local function MakeUI()
    if panel then return end
    local parent=_G.WorldMapFrame or UIParent
    panel=CreateFrame('Frame','ForeverRegionFinderCreaturePanel',parent,'BackdropTemplate')
    panel:SetSize(438,610)
    panel:SetFrameStrata('HIGH')
    panel:SetClampedToScreen(true)
    panel:SetMovable(true)
    panel:EnableMouse(true)
    FrameStyle(panel)
    local cfg=FRF.settings or {}
    if cfg.creatureX and cfg.creatureY then
        panel:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',cfg.creatureX,cfg.creatureY)
    else panel:SetPoint('TOPRIGHT',parent,'TOPRIGHT',-15,-142) end
    local bar=CreateFrame('Frame',nil,panel)
    bar:SetPoint('TOPLEFT',panel,'TOPLEFT',6,-4)
    bar:SetPoint('TOPRIGHT',panel,'TOPRIGHT',-38,-4)
    bar:SetHeight(25)
    bar:EnableMouse(true)
    bar:RegisterForDrag('LeftButton')
    bar:SetScript('OnDragStart',function()panel:StartMoving()end)
    bar:SetScript('OnDragStop',function()
        panel:StopMovingOrSizing()
        local l,t=panel:GetLeft(),panel:GetTop()
        if l and t and FRF.settings then FRF.settings.creatureX=l;FRF.settings.creatureY=t end
    end)
    title=Field(panel,'GameFontNormal','TOPLEFT',13,-12,'몬스터 정보')
    title:SetWidth(390);title:SetJustifyH('LEFT')
    local close=Button(panel,'X',25,22)
    close:SetPoint('TOPRIGHT',panel,'TOPRIGHT',-5,-5)
    close:SetScript('OnClick',function()panel:Hide()end)
    sub=Field(panel,'GameFontHighlightSmall','TOPLEFT',14,-36,'')
    sub:SetWidth(404);sub:SetJustifyH('LEFT')
    model=CreateFrame('PlayerModel',nil,panel)
    model:SetPoint('TOPLEFT',panel,'TOPLEFT',12,-54)
    model:SetSize(414,156)
    local bg=panel:CreateTexture(nil,'BACKGROUND')
    bg:SetColorTexture(0.03,0.06,0.08,1)
    bg:SetPoint('TOPLEFT',model,'TOPLEFT',0,0)
    bg:SetPoint('BOTTOMRIGHT',model,'BOTTOMRIGHT',0,0)
    tip=Field(panel,'GameFontDisableSmall','TOPLEFT',13,-215,'몬스터 3D 미리보기')
    tip:SetWidth(408)
    local y=-236
    local def={{'ForeverDB.net','ForeverDB',125,12},{'NorgannonDB','NorgannonDB',125,145},
        {'reference','클래식 참고',125,278}}
    for _,t in ipairs(def) do
        local b=Button(panel,t[2],t[3],23)
        b:SetPoint('TOPLEFT',panel,'TOPLEFT',t[4],y)
        b:SetScript('OnClick',function()SelectSource(t[1])end)
        tabs[t[1]]=b
    end
    countLabel=Field(panel,'GameFontHighlightSmall','TOPLEFT',13,-264,'')
    countLabel:SetWidth(410);countLabel:SetJustifyH('LEFT')
    local legend=Field(panel,'GameFontDisableSmall','TOPLEFT',13,-284,
        '표시 확률은 데이터베이스 추정치이며 포에버 실제 서버 확률과 다를 수 있음')
    legend:SetWidth(409);legend:SetJustifyH('LEFT')
    for i=1,PAGE_SIZE do
        local r=CreateFrame('Button',nil,panel)
        r:SetHeight(29)
        r:SetPoint('TOPLEFT',panel,'TOPLEFT',12,-308-(i-1)*29)
        r:SetPoint('TOPRIGHT',panel,'TOPRIGHT',-11,-308-(i-1)*29)
        r.icon=r:CreateTexture(nil,'ARTWORK')
        r.icon:SetPoint('LEFT',r,'LEFT',3,0)
        r.icon:SetSize(24,24)
        r.noIcon=r:CreateTexture(nil,'BACKGROUND')
        r.noIcon:SetPoint('LEFT',r,'LEFT',3,0)
        r.noIcon:SetSize(24,24)
        if r.noIcon.SetColorTexture then r.noIcon:SetColorTexture(0.18,0.21,0.24,1) end
        r.name=r:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
        r.name:SetPoint('LEFT',r,'LEFT',34,0)
        r.name:SetWidth(276);r.name:SetJustifyH('LEFT');r.name:SetWordWrap(false)
        r.percent=r:CreateFontString(nil,'OVERLAY','GameFontDisableSmall')
        r.percent:SetPoint('RIGHT',r,'RIGHT',-2,0)
        r.percent:SetWidth(82);r.percent:SetJustifyH('RIGHT')
        r:SetScript('OnEnter',function(self)
            if not self.itemId or not GameTooltip then return end
            GameTooltip:SetOwner(self,'ANCHOR_LEFT')
            pcall(GameTooltip.SetHyperlink,GameTooltip,'item:'..self.itemId)
            if self.data and self.data.chance then
                GameTooltip:AddLine(string.format('참고 드롭률: %.2f%% | %s',self.data.chance,
                    self.data.chanceSource or self.data.source),0.4,0.85,0.88)
            end
            if self.data and self.data.origin then
                local labels={f='ForeverDB 서버 관측',s='ForeverDB 희귀 관측',i='ForeverDB 아이템 출처',c='클래식 참고',you='본인 획득 기록'}
                GameTooltip:AddLine('데이터: '..(labels[self.data.origin] or self.data.origin),0.55,0.85,0.9)
                if self.data.observations then GameTooltip:AddLine('관측 드롭: '..self.data.observations..'회',0.7,0.7,0.7) end
                if self.data.kills and self.data.kills > 0 then GameTooltip:AddLine('표본 처치: '..self.data.kills..'회',0.7,0.7,0.7) end
            end
            GameTooltip:Show()
        end)
        r:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
        rows[i]=r
    end
    note=Field(panel,'GameFontHighlightSmall','BOTTOMLEFT',14,45,'')
    note:SetWidth(408);note:SetJustifyH('LEFT')
    filterButton=Button(panel,'고급 이상',84,22)
    filterButton:SetPoint('BOTTOMLEFT',panel,'BOTTOMLEFT',11,8)
    filterButton:SetScript('OnClick',function()
        state.qualityOnly=not state.qualityOnly;state.page=0;Repaint()
    end)
    reloadButton=Button(panel,'다시 조회',77,22)
    reloadButton:SetPoint('BOTTOMLEFT',panel,'BOTTOMLEFT',98,8)
    reloadButton:SetScript('OnClick',function()
        if state.npcId then
            FRF.ItemVisuals.ClearRequests()
            state.job=FRF.LootBridge.Begin(state.npcId,Repaint,true,state.name)
            state.page=0;Repaint()
        end
    end)
    local official=Button(panel,'공식 DB 열기',112,22)
    official:SetPoint('BOTTOMLEFT',panel,'BOTTOMLEFT',179,8)
    official:SetScript('OnClick',OpenOfficial)
    local prev=Button(panel,'<',27,22)
    prev:SetPoint('BOTTOMRIGHT',panel,'BOTTOMRIGHT',-107,8)
    prev:SetScript('OnClick',function()state.page=math.max(0,state.page-1);Repaint()end)
    pageLabel=Field(panel,'GameFontHighlightSmall','BOTTOMRIGHT',-45,12,'1 / 1')
    pageLabel:SetWidth(50);pageLabel:SetJustifyH('CENTER')
    local nxt=Button(panel,'>',27,22)
    nxt:SetPoint('BOTTOMRIGHT',panel,'BOTTOMRIGHT',-10,8)
    nxt:SetScript('OnClick',function()
        state.page=math.min(math.ceil(#state.filtered/PAGE_SIZE)-1,state.page+1)
        state.page=math.max(0,state.page);Repaint()
    end)
    if FRF.ItemVisuals then
        FRF.ItemVisuals.Subscribe(function(id)
            if panel and panel.IsShown and panel:IsShown() then
                for _,r in ipairs(rows) do
                    if r.itemId==id then Repaint();break end
                end
            end
        end)
    end
    panel:Hide()
end
function FRF.DiagnoseForeverDB()
    if FRF.Print then FRF.Print(FRF.LootBridge.Diagnose()) end
end
function FRF.ShowCreatureDetails(entry)
    if not entry then return end
    local id=nil
    if entry.kind=='npc' then id=tonumber(entry.id)
    elseif entry.kind=='place' and entry.extra=='NPC 출현 기록' then id=tonumber(entry.entityId) end
    if not id then if panel then panel:Hide() end;return end
    MakeUI()
    if not FRF.settings then FRF.settings={} end
    local source=FRF.settings.lootSource
    if source=='ForeverDB.net' or source=='NorgannonDB' or source=='reference' then
        state.source=source
    end
    local newId=id~=state.npcId
    state.npcId=id;state.name=entry.name or 'NPC'
    title:SetText(state.name..' | #'..id)
    if newId or not state.job then
        state.page=0
        state.job=FRF.LootBridge.Begin(id,Repaint,false,state.name)
    end
    ShowModel(id)
    panel:Show()
    Repaint()
end

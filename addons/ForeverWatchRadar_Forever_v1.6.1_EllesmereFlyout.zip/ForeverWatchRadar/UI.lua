-- Forever Watch Radar UI | Standalone list window, Korean labels.
local WR = _G.ForeverWatchRadar
if not WR then return end

local FLAT = "Interface\\Buttons\\WHITE8X8"
local panel
local currentTab = "mob"
local rows = {}
local listChild, listScroll, input, countText, visibleText, messageText, partyStatusText
local tabs = {}
local styleButton, sizeButton, minimapToggle
local boxes = {}
local G = {0.98,0.73,0.19}
local R = {1.00,0.27,0.31}
local F = {0.27,0.88,1.00}
local function Paint(t, color)
    t:SetColorTexture(color[1],color[2],color[3],color[4] or 1)
end
local function Text(parent, text, template, x, y, anchor)
    local t = parent:CreateFontString(nil, "OVERLAY",template or "GameFontNormal")
    t:SetPoint(anchor or "TOPLEFT",parent,anchor or "TOPLEFT", x or 0, y or 0)
    t:SetText(text or "")
    return t
end
local function Button(parent, label, w, h, click)
    local b = CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h)
    b:SetText(label)
    b:SetScript("OnClick",click)
    return b
end
local function Note(msg, good)
    if messageText then
        messageText:SetText(msg or "")
        messageText:SetTextColor(good and 0.44 or 1,good and 0.9 or 0.36,good and 0.53 or 0.4)
    end
    WR.Notice(msg)
end
local function Row(parent)
    local b = CreateFrame("Frame",nil,parent)
    b:SetSize(439,29)
    b.back = b:CreateTexture(nil,"BACKGROUND")
    b.back:SetAllPoints()
    b.back:SetColorTexture(0.12,0.13,0.17,0.82)
    b.dot = b:CreateTexture(nil,"ARTWORK")
    b.dot:SetSize(3,22)
    b.dot:SetPoint("LEFT",b,"LEFT",3,0)
    b.name = b:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    b.name:SetPoint("LEFT",b,"LEFT",14,0)
    b.name:SetWidth(270)
    b.name:SetJustifyH("LEFT")
    b.status = b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    b.status:SetPoint("RIGHT",b,"RIGHT",-41,0)
    b.delete = Button(b,"X",26,23,function()
        if b.record then
            local ok, res = WR:Remove(b.record.kind,b.record.key)
            Note(ok and ("삭제: "..res) or res,ok)
        end
    end)
    b.delete:SetPoint("RIGHT",b,"RIGHT",-4,0)
    return b
end
local function Checkbox(parent, text, key, x, y)
    local check = CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    check:SetSize(24,24)
    check:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",x,y or 58)
    check.lbl = check:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    check.lbl:SetPoint("LEFT",check,"RIGHT",3,0)
    check.lbl:SetText(text)
    check:SetScript("OnClick",function(self)
        WR:SetOption(key,self:GetChecked())
    end)
    boxes[key] = check
end
local function Construct()
    if panel then return end
    panel = CreateFrame("Frame","ForeverWatchRadarOptions",UIParent,"BackdropTemplate")
    panel:SetSize(548,665)
    panel:SetPoint("CENTER",UIParent,"CENTER",0,20)
    panel:SetFrameStrata("DIALOG")
    panel:SetToplevel(true)
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)
        if not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
    end)
    panel:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    panel:SetBackdrop({bgFile=FLAT,edgeFile=FLAT,edgeSize=2,insets={left=2,right=2,top=2,bottom=2}})
    panel:SetBackdropColor(0.043,0.053,0.075,0.98)
    panel:SetBackdropBorderColor(0.63,0.45,0.20,1)
    local header = panel:CreateTexture(nil,"BACKGROUND")
    header:SetSize(542,73)
    header:SetPoint("TOP",panel,"TOP",0,-4)
    header:SetColorTexture(0.095,0.105,0.14,0.98)
    local gold = panel:CreateTexture(nil,"ARTWORK")
    gold:SetSize(542,2)
    gold:SetPoint("TOP",panel,"TOP",0,-75)
    Paint(gold,{0.98,0.71,0.19,1})
    local title = Text(panel,"FOREVER WATCH RADAR", "GameFontNormalLarge",21,-19)
    title:SetTextColor(1.0,0.81,0.36)
    local sub = Text(panel,"몬스터 수배 · 적 플레이어 경고 · 아군 친구 강조", "GameFontHighlightSmall",22,-47)
    sub:SetTextColor(0.72,0.75,0.80)
    local close = Button(panel,"X",28,26,function() panel:Hide() end)
    close:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-13,-14)
    minimapToggle = Button(panel,"미니맵 버튼: 켜짐",120,24,function()
        local settings = WR.db and WR.db.settings
        if settings then WR:SetOption("minimapButton", not settings.minimapButton) end
    end)
    minimapToggle:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-52,-15)
    if UISpecialFrames then table.insert(UISpecialFrames,"ForeverWatchRadarOptions") end

    -- Three independent persistent watchlists: monster, enemy, friendly.
    local function Tab(label,kind,x,w)
        local b = CreateFrame("Button",nil,panel)
        b:SetSize(w,35)
        b:SetPoint("TOPLEFT",panel,"TOPLEFT",x,-91)
        b.bg = b:CreateTexture(nil,"BACKGROUND")
        b.bg:SetAllPoints()
        b.text = b:CreateFontString(nil,"OVERLAY","GameFontNormal")
        b.text:SetPoint("CENTER",b,"CENTER",0,0)
        b.text:SetText(label)
        b:SetScript("OnClick",function()
            currentTab = kind
            WR:RefreshUI()
        end)
        tabs[kind] = b
    end
    Tab("몬스터 수배", "mob", 20, 158)
    Tab("적 플레이어", "player", 187, 158)
    Tab("아군 친구", "friend", 354, 171)

    local instruction = Text(panel,"현재 선택한 대상을 바로 등록하거나, 이름을 직접 입력하세요.","GameFontHighlightSmall",22,-143)
    instruction:SetTextColor(0.79,0.81,0.86)
    panel.instruction = instruction
    input = CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
    input:SetSize(244,28)
    input:SetPoint("TOPLEFT",panel,"TOPLEFT",32,-172)
    input:SetAutoFocus(false)
    input:SetMaxLetters(100)
    input:SetText("")
    input:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    local function AddManual()
        local ok, result = WR:Add(currentTab,input:GetText())
        Note(result,ok)
        if ok then input:SetText(""); input:ClearFocus() end
    end
    input:SetScript("OnEnterPressed",AddManual)
    local add = Button(panel,"이름 직접 등록",113,27,AddManual)
    add:SetPoint("LEFT",input,"RIGHT",12,0)
    local addTarget = Button(panel,"선택 대상 등록",117,27,function()
        local ok,result = WR:AddTarget(currentTab)
        Note(result,ok)
    end)
    addTarget:SetPoint("LEFT",add,"RIGHT",8,0)
    messageText = Text(panel,"", "GameFontHighlightSmall",22,-212)
    messageText:SetWidth(504)
    messageText:SetJustifyH("LEFT")
    messageText:SetTextColor(0.80,0.82,0.84)
    countText = Text(panel,"등록: 0명", "GameFontNormalSmall",23,-245)
    visibleText = Text(panel,"현재 감지: 0", "GameFontNormalSmall",389,-245)
    visibleText:SetTextColor(1,0.77,0.31)

    local area = CreateFrame("Frame",nil,panel,"BackdropTemplate")
    area:SetSize(510,198)
    area:SetPoint("TOPLEFT",panel,"TOPLEFT",19,-266)
    area:SetBackdrop({bgFile=FLAT,edgeFile=FLAT,edgeSize=1,insets={left=1,right=1,top=1,bottom=1}})
    area:SetBackdropColor(0.075,0.08,0.11,1)
    area:SetBackdropBorderColor(0.24,0.28,0.34,1)
    listScroll = CreateFrame("ScrollFrame","ForeverWatchRadarScroll",area,"UIPanelScrollFrameTemplate")
    listScroll:SetPoint("TOPLEFT",area,"TOPLEFT",8,-8)
    listScroll:SetPoint("BOTTOMRIGHT",area,"BOTTOMRIGHT",-29,8)
    listChild = CreateFrame("Frame",nil,listScroll)
    listChild:SetSize(445,180)
    listScroll:SetScrollChild(listChild)

    local tip = Text(panel,"※ 주변 이름표 자동 감지: 클릭 불필요. 타겟/마우스오버도 지원합니다.", "GameFontHighlightSmall",23,-472)
    tip:SetTextColor(0.66,0.72,0.79)
    local tip2 = Text(panel,"   EUI 체력바 전체 테두리·발광·징표. 이름표 최대 거리 밖의 대상은 탐지 불가.","GameFontHighlightSmall",23,-487)
    tip2:SetTextColor(0.66,0.72,0.79)
    local styleTitle = Text(panel,"이름표 효과", "GameFontHighlightSmall",23,-511)
    styleTitle:SetTextColor(0.88,0.80,0.60)
    styleButton = Button(panel,"효과: 강력",120,24,function()
        local s = WR.db and WR.db.settings.markStyle or "strong"
        local nextStyle = s == "strong" and "soft" or s == "soft" and "off" or "strong"
        local ok,result = WR:SetMarkStyle(nextStyle)
        Note(result,ok)
    end)
    styleButton:SetPoint("TOPLEFT",panel,"TOPLEFT",100,-504)
    local smaller = Button(panel,"-",27,24,function()
        local now = (WR.db and WR.db.settings.markSize) or 125
        local ok,result=WR:SetMarkSize(now-10)
        Note(result,ok)
    end)
    smaller:SetPoint("TOPLEFT",panel,"TOPLEFT",246,-504)
    sizeButton = Button(panel,"125%",64,24,function()
        local ok,result=WR:SetMarkSize(125)
        Note(result,ok)
    end)
    sizeButton:SetPoint("LEFT",smaller,"RIGHT",5,0)
    local larger = Button(panel,"+",27,24,function()
        local now = (WR.db and WR.db.settings.markSize) or 125
        local ok,result=WR:SetMarkSize(now+10)
        Note(result,ok)
    end)
    larger:SetPoint("LEFT",sizeButton,"RIGHT",5,0)
    local rangeButton = Button(panel,"거리 확인",93,24,function() WR:RangeStatus() end)
    rangeButton:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-20,-504)
    Checkbox(panel,"감지", "enabled",23,119)
    Checkbox(panel,"적/몹 작은 경고", "hud",107,119)
    Checkbox(panel,"적/몹 알림음", "sound",231,119)
    Checkbox(panel,"표식 반짝임", "pulse",383,119)
    Checkbox(panel,"파티 제보 공유", "partyShare",23,85)
    Checkbox(panel,"파티 제보창", "partyHUD",196,85)
    Checkbox(panel,"친구 알림음", "friendSound",357,85)
    partyStatusText = Text(panel,"파티 통신: 확인 중", "GameFontHighlightSmall",23,-607)
    partyStatusText:SetTextColor(0.55,0.78,1)
    local preview = Button(panel,"알림 테스트",100,24,function() WR:Test() end)
    preview:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-14,9)
    local sharedPreview = Button(panel,"제보 화면 테스트",125,24,function() WR:TestParty() end)
    sharedPreview:SetPoint("RIGHT",preview,"LEFT",-8,0)
    local pingButton = Button(panel,"파티 통신 테스트",122,24,function() WR:PingParty() end)
    pingButton:SetPoint("RIGHT",sharedPreview,"LEFT",-8,0)
    local friendPreview = Button(panel,"친구 징표 테스트",112,24,function() WR:TestFriend() end)
    friendPreview:SetPoint("RIGHT",pingButton,"LEFT",-8,0)
    panel:Hide()
end
function WR:RefreshDetectedUI()
    if not panel or not panel:IsShown() then return end
    local count = 0
    for _,rec in ipairs(self:GetEntries(currentTab)) do
        if self:IsDetected(rec) then count = count + 1 end
    end
    visibleText:SetText("현재 감지: "..count)
    for _,r in ipairs(rows) do
        if r.record then
            local isOn = self:IsDetected(r.record)
            r.status:SetText(isOn and "● 발견" or "대기")
            if isOn then
                if r.record.kind == "player" then r.status:SetTextColor(1,0.30,0.36)
                elseif r.record.kind == "friend" then r.status:SetTextColor(0.29,0.90,1)
                else r.status:SetTextColor(1,0.80,0.34) end
            else r.status:SetTextColor(0.54,0.59,0.66) end
            if isOn and r.record.kind == "friend" then
                r.back:SetColorTexture(0.07, 0.23, 0.29, 0.92)
            else
                r.back:SetColorTexture(isOn and 0.24 or 0.12,
                    isOn and 0.15 or 0.13, isOn and 0.16 or 0.17, 0.89)
            end
        end
    end
end
function WR:RefreshPartyStatus()
    if not partyStatusText then return end
    local status = self.GetPartyStatus and self:GetPartyStatus() or "확인 불가"
    partyStatusText:SetText("파티 통신: " .. status)
end
function WR:RefreshUI()
    if not panel then return end
    for kind,b in pairs(tabs) do
        local chosen = currentTab == kind
        local c = kind == "player" and R or kind == "friend" and F or G
        b.bg:SetColorTexture(chosen and 0.25 or 0.10, chosen and 0.19 or 0.12, chosen and 0.13 or 0.17,1)
        b.text:SetTextColor(chosen and c[1] or 0.65,chosen and c[2] or 0.68,chosen and c[3] or 0.71)
    end
    if panel.instruction then
        panel.instruction:SetText(currentTab == "friend" and
            "아군 플레이어를 선택해 등록하거나, 친구 이름을 직접 입력하세요." or
            "현재 선택한 대상을 등록하거나, 이름을 직접 입력하세요.")
    end
    local arr = self:GetEntries(currentTab)
    countText:SetText("등록: "..#arr.."명")
    listChild:SetHeight(math.max(180,#arr * 32))
    if #arr == 0 then
        if not self.emptyText then
            self.emptyText = listChild:CreateFontString(nil,"OVERLAY","GameFontDisable")
            self.emptyText:SetPoint("TOP",listChild,"TOP",0,-54)
        end
        local empty = currentTab == "player" and "적 플레이어를 등록하면 여기에 나타납니다."
            or currentTab == "friend" and "내 친구를 등록하면 여기에 나타납니다."
            or "수배할 몬스터를 등록하면 여기에 나타납니다."
        self.emptyText:SetText(empty)
        self.emptyText:Show()
    elseif self.emptyText then self.emptyText:Hide() end
    for i, rec in ipairs(arr) do
        local r = rows[i]
        if not r then r=Row(listChild); rows[i]=r end
        r:SetParent(listChild)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT",listChild,"TOPLEFT",0,-(i-1)*32)
        r.record = rec
        r.name:SetText(rec.name)
        local c = rec.kind=="player" and R or rec.kind=="friend" and F or G
        r.dot:SetColorTexture(c[1],c[2],c[3],1)
        r:Show()
    end
    for i=#arr+1,#rows do rows[i]:Hide(); rows[i].record=nil end
    if self.db then
        for key, box in pairs(boxes) do box:SetChecked(self.db.settings[key]) end
        local st = self.db.settings.markStyle
        if styleButton then
            styleButton:SetText("효과: " .. (st == "strong" and "강력" or st == "soft" and "기본" or "끄기"))
        end
        if sizeButton then sizeButton:SetText((self.db.settings.markSize or 125) .. "%") end
        if minimapToggle then minimapToggle:SetText("미니맵 버튼: " .. (self.db.settings.minimapButton ~= false and "켜짐" or "꺼짐")) end
    end
    self:RefreshDetectedUI()
    self:RefreshPartyStatus()
end
function WR:ToggleUI()
    Construct()
    if panel:IsShown() then panel:Hide()
    else panel:Show(); self:RefreshUI() end
end

-- Forever Watch Radar 1.2.0 - opt-out PARTY/RAID sighting share.
-- All network reports are explicit party-member sightings; NEVER imply exact range or position.
-- Uses the supported addon channel. Never uses global/custom channels or standard chat.
local WR = _G.ForeverWatchRadar
if not WR then return end

local PREFIX = "FWatchRadar11"        -- 13 bytes (WoW limit: 16)
local SEP = "\031"
local PROTOCOL = "1"
local EXPIRE = 24                  -- stale party report disappears after 24 sec
local RESEND = 12                  -- only one sighting per target every 12 sec
local ALERT_COOLDOWN = 45          -- no chat/sound repeat spam
local SEND_SPACING = 1.25          -- stays under 1 msg/sec refill with margin
local RETRY_SPACING = 4
local MAX_QUEUE = 24
local MAX_NAME_BYTES = 100
local nextSendTime = 0
local registered = false
local lastStatusCode = nil
local lastSendError = nil
local lastErrorNotice = -1000
local queue, queued = {}, {}
local localSent = {}
local remote, lastRemoteAlert = {}, {}
local lastAck = {}
local pingNonce, pingDeadline, pingResponses = nil, nil, {}
local connected = {}
local partyHUD
local lastPartySound = -1000
local frame = CreateFrame("Frame")

local function Now()
    return (GetTime and GetTime()) or 0
end
local function SafeCall(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b = pcall(fn, ...)
    if not ok then return nil end
    if issecretvalue and (issecretvalue(a) or issecretvalue(b)) then return nil end
    return a, b
end
local function SafePlain(s)
    if type(s) ~= "string" then return "" end
    s = s:gsub("[%c]", " "):gsub("|", "¦")
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    if #s > MAX_NAME_BYTES then s = s:sub(1, MAX_NAME_BYTES) end
    return s
end
local function IsShareEnabled()
    return WR.db and WR.db.settings and WR.db.settings.enabled and WR.db.settings.partyShare
end
local function Channel()
    local instanceCategory = _G.LE_PARTY_CATEGORY_INSTANCE
    if type(instanceCategory) == "number" and SafeCall(IsInGroup, instanceCategory) == true then
        return "INSTANCE_CHAT"
    end
    if SafeCall(IsInRaid) == true then return "RAID" end
    if SafeCall(IsInGroup) == true then return "PARTY" end
    return nil
end
local function RegisterPrefix()
    if not C_ChatInfo or type(C_ChatInfo.RegisterAddonMessagePrefix) ~= "function" then
        registered = false
        return false
    end
    -- 0 = success; 1 = duplicate prefix already registered by this client.
    local result = SafeCall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
    registered = (result == 0 or result == 1 or result == true)
    return registered
end
local function EmptyQueue()
    queue, queued, localSent = {}, {}, {}
end
local function EmptyRemote()
    remote, lastRemoteAlert = {}, {}
    if partyHUD then partyHUD:Hide() end
end
local function Enqueue(packet, token, first)
    if type(packet) ~= "string" or #packet > 255 or packet:find("\000", 1, true) then return false end
    if queued[token] or #queue >= MAX_QUEUE then return false end
    local obj = {packet=packet, token=token, queuedAt=Now()}
    if first then table.insert(queue, 1, obj) else table.insert(queue, obj) end
    queued[token] = true
    return true
end
local function ChattedError(code)
    -- Do not spam the user if the server restricts party addon communication.
    local now = Now()
    if now - lastErrorNotice < 45 then return end
    lastErrorNotice = now
    WR.Notice("파티 통신 전송 제한 (코드 " .. tostring(code) .. "). /wtr status로 확인하세요. 직접 감지는 계속 작동합니다.")
end
local function SendNext()
    local now = Now()
    if now < nextSendTime or #queue == 0 then return end
    if not IsShareEnabled() or not Channel() then
        EmptyQueue()
        return
    end
    if not registered and not RegisterPrefix() then
        lastSendError = "접두어 등록 실패"
        nextSendTime = now + RETRY_SPACING
        return
    end
    if not C_ChatInfo or type(C_ChatInfo.SendAddonMessage) ~= "function" then
        lastSendError = "통신 API 없음"
        EmptyQueue()
        return
    end
    local item = queue[1]
    -- A queued sighting must not go out long after the mob/player was seen.
    if item.token:sub(1,2) == "s:" and now - item.queuedAt > 8 then
        table.remove(queue, 1)
        queued[item.token] = nil
        nextSendTime = now + 0.1
        return
    end
    -- Enum.SendAddonMessageResult.Success is 0 in Forever 1.60.1.
    local code = SafeCall(C_ChatInfo.SendAddonMessage, PREFIX, item.packet, Channel())
    lastStatusCode = code
    local success = (code == 0 or code == true)
    if success then
        table.remove(queue, 1)
        queued[item.token] = nil
        lastSendError = nil
        nextSendTime = now + SEND_SPACING
    elseif code == 3 or code == 8 or code == 11 then
        lastSendError = "서버 제한 코드 " .. tostring(code)
        nextSendTime = now + RETRY_SPACING
        ChattedError(code)
    else
        -- Bad channel / not in group / restrictions: discard the bad item,
        -- keep the rest of the add-on usable; no unbounded retry loop.
        table.remove(queue, 1)
        queued[item.token] = nil
        lastSendError = "전송 실패 코드 " .. tostring(code)
        nextSendTime = now + RETRY_SPACING
        ChattedError(code or "API 오류")
    end
end

local function LocalPlayerName()
    return (WR.NameOfUnit and WR:NameOfUnit("player")) or SafeCall(UnitName, "player")
end
local function IsOwnSender(sender)
    if type(sender) ~= "string" then return false end
    local mine = LocalPlayerName()
    if type(mine) ~= "string" then return false end
    if WR.Key(sender) == WR.Key(mine) then return true end
    -- A realm suffix in CHAT_MSG_ADDON is separate from Forever's surname.
    local base = sender:match("^(.-)%-[^%-]+$")
    return base ~= nil and WR.Key(base) == WR.Key(mine)
end
local function ValidSighting(kind, name)
    if (kind ~= "p" and kind ~= "m") or type(name) ~= "string" then return nil end
    if #name == 0 or #name > MAX_NAME_BYTES or name:find("[%c|]") then return nil end
    local clean = name:gsub("^%s+", ""):gsub("%s+$", "")
    if #clean == 0 then return nil end
    local key = WR.Key(clean)
    if key == "" then return nil end
    return {name=clean, key=key, kind=kind == "p" and "player" or "mob"}
end
local function PlayPartySound(now)
    if not WR.db or not WR.db.settings.sound then return end
    if now - lastPartySound < 3 then return end
    lastPartySound = now
    pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959, "Master")
end
local function ReceiveSighting(sender, kind, name)
    local rec = ValidSighting(kind, name)
    if not rec then return end
    local now = Now()
    local id = WR:EntryID(rec.kind, rec.key)
    local info = remote[id]
    if not info then
        -- Bound remote-only data from a noisy/buggy group member.
        local total = 0
        for _ in pairs(remote) do total = total + 1 end
        if total >= 50 then return end
        info = {kind=rec.kind, name=rec.name, key=rec.key, sources={}}
        remote[id] = info
    end
    info.sources[sender] = now
    info.lastSeen = now
    info.reporter = sender
    -- The first and subsequent alert cooldowns are distinct from the 24s HUD TTL.
    if now - (lastRemoteAlert[id] or -1000) >= ALERT_COOLDOWN then
        lastRemoteAlert[id] = now
        WR.Notice("|cff7fcbff[파티원 제보]|r " .. SafePlain(sender) .. " → " ..
            (rec.kind == "player" and "[블랙리스트] " or "[수배 몹] ") .. SafePlain(rec.name) ..
            " (직접 감지가 아님)")
        PlayPartySound(now)
    end
end

local function DrawPartyHUD(now)
    local rows = {}
    for id, report in pairs(remote) do
        local newest, source = 0, nil
        for sender, seenAt in pairs(report.sources) do
            if now - seenAt > EXPIRE then report.sources[sender] = nil
            elseif seenAt >= newest then newest, source = seenAt, sender end
        end
        if source then
            report.lastSeen, report.reporter = newest, source
            table.insert(rows, report)
        else remote[id] = nil end
    end
    if not IsShareEnabled() or not WR.db.settings.partyHUD then
        if partyHUD then partyHUD:Hide() end
        return
    end
    table.sort(rows, function(a,b) return (a.lastSeen or 0) > (b.lastSeen or 0) end)
    if #rows == 0 and (not WR.partyPreviewUntil or now >= WR.partyPreviewUntil) then
        if partyHUD then partyHUD:Hide() end
        return
    end
    if not partyHUD then
        local f = CreateFrame("Frame", "ForeverWatchRadarPartyHUD", UIParent)
        -- Remote sightings have no visible local plate to attach to.
        -- Keep the report compact and away from the middle of the screen.
        f:SetSize(324, 82)
        f:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -22, -208)
        f:SetFrameStrata("MEDIUM")
        f:EnableMouse(false)
        local bg = f:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.05,0.08,0.13,0.78)
        local edge = f:CreateTexture(nil, "BORDER")
        edge:SetSize(324,2)
        edge:SetPoint("TOP", f, "TOP",0,0)
        edge:SetColorTexture(0.32,0.66,1,0.98)
        f.head = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
        f.head:SetPoint("TOP",f,"TOP",0,-6)
        f.head:SetTextColor(0.55,0.78,1)
        f.one = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        f.one:SetPoint("TOP",f.head,"BOTTOM",0,-4)
        f.one:SetSize(308,14)
        f.two = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        f.two:SetPoint("TOP",f.one,"BOTTOM",0,-2)
        f.two:SetSize(308,14)
        f.note = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        f.note:SetPoint("TOP",f.two,"BOTTOM",0,-2)
        f:Hide()
        partyHUD = f
    end
    local function Line(info)
        if not info then return "" end
        local color = info.kind == "player" and "ffff656b" or "ffffd067"
        local typeText = info.kind == "player" and "[적 플레이어] " or "[몬스터] "
        return "|c" .. color .. typeText .. SafePlain(info.name) .. "|r  ·  " .. SafePlain(info.reporter) ..
            " (" .. math.max(0, math.floor(now - (info.lastSeen or now))) .. "초 전)"
    end
    if #rows == 0 then
        partyHUD.head:SetText("[미리보기] 파티원 제보")
        partyHUD.one:SetText("|cffff656b[적 플레이어] 예시 대상|r  ·  파티원 A")
        partyHUD.two:SetText("")
        partyHUD.note:SetText("테스트 표시 · 실제 감지/통신 아님")
    else
        partyHUD.head:SetText("파티원 제보  (" .. #rows .. ")")
        partyHUD.one:SetText(Line(rows[1]))
        partyHUD.two:SetText(Line(rows[2]))
        partyHUD.note:SetText(#rows > 2 and ("외 " .. (#rows-2) .. "개 제보  ·  위치 확인 불가") or
            "직접 감지가 아닌 파티원 제보 · 24초 후 자동 해제")
    end
    partyHUD:Show()
end

function WR:RenderPartyHUD(now)
    DrawPartyHUD(now)
end
function WR:OnLocalDetected(found, now)
    if not IsShareEnabled() or not Channel() then return end
    for id, rec in pairs(found) do
        -- Friend sightings stay LOCAL: never broadcast the user's friend list
        -- or turn an allied player into a hostile monster report.
        -- If a threat stays visible, refresh the report at most every 12 sec.
        if (rec.kind == "player" or rec.kind == "mob") and
            type(rec.name) == "string" and #rec.name <= MAX_NAME_BYTES and
            not rec.name:find("[%c|]") and now - (localSent[id] or -1000) >= RESEND then
            local kind = rec.kind == "player" and "p" or "m"
            local packet = PROTOCOL .. SEP .. "S" .. SEP .. kind .. SEP .. rec.name
            if Enqueue(packet, "s:" .. id) then localSent[id] = now end
        end
    end
end
function WR:OnPartyToggle()
    EmptyQueue()
    EmptyRemote()
    if self.RefreshPartyStatus then self:RefreshPartyStatus() end
end
function WR:GetPartyRemoteCount()
    local n = 0
    for _ in pairs(remote) do n = n + 1 end
    return n
end
function WR:GetPartyStatus()
    if not self.db then return "시작 중" end
    if not self.db.settings.partyShare then return "공유 꺼짐" end
    local channel = Channel()
    if not channel then return "파티 없음" end
    if not registered then return "통신 등록 실패" end
    if lastSendError then return "전송 제한 가능" end
    return channel == "PARTY" and "파티 공유 준비" or "공격대 공유 준비"
end
function WR:PartyStatus()
    if not self.db then return end
    local inGroup = Channel() or "파티 없음"
    local outgoing = C_ChatInfo and SafeCall(C_ChatInfo.AreOutgoingAddonChatMessagesRestricted)
    WR.Notice("파티 공유 " .. (self.db.settings.partyShare and "켜짐" or "꺼짐") ..
        " / 채널: " .. inGroup .. " / 접두어 등록: " .. (registered and "성공" or "실패"))
    WR.Notice("최근 전송 결과: " .. (lastStatusCode == nil and "없음" or tostring(lastStatusCode)) ..
        " (0=API 수락, 실제 수신은 테스트 필요) / 최근 오류: " .. (lastSendError or "없음"))
    WR.Notice("클라이언트의 발신 제한 표시: " .. (outgoing == true and "있음" or outgoing == false and "없음" or "확인 불가") ..
        " / 파티 제보: " .. self:GetPartyRemoteCount() .. "건")
end
function WR:PingParty()
    if not self.db or not self.db.settings.partyShare then WR.Notice("파티 공유를 켜고 다시 시도하세요."); return end
    if not Channel() then WR.Notice("파티 또는 공격대에 들어간 뒤 테스트하세요."); return end
    if not registered and not RegisterPrefix() then WR.Notice("통신 접두어 등록 실패입니다."); return end
    pingNonce = tostring(math.floor(Now() * 1000))
    pingDeadline = Now() + 12
    pingResponses = {}
    if Enqueue(PROTOCOL .. SEP .. "H" .. SEP .. pingNonce, "ping:" .. pingNonce, true) then
        WR.Notice("통신 확인 요청을 전송 대기열에 추가했습니다. 파티원도 v1.1.0 이상을 설치해야 응답합니다.")
    else WR.Notice("통신 대기열이 가득 찼습니다. 잠시 후 다시 시도하세요.") end
end
function WR:TestParty()
    if not self.db then return end
    local now = Now()
    self.partyPreviewUntil = now + 5
    PlayPartySound(now)
    DrawPartyHUD(now)
end
local function HandleMessage(prefix, text, channel, sender)
    if prefix ~= PREFIX or not IsShareEnabled() then return end
    -- The WoW server restricts PARTY/RAID/INSTANCE_CHAT to group membership.
    -- Never process a whisper, general channel, or an out-of-group message.
    if channel ~= "PARTY" and channel ~= "RAID" and channel ~= "INSTANCE_CHAT" then return end
    if not Channel() or type(text) ~= "string" or #text > 255 or type(sender) ~= "string" then return end
    if IsOwnSender(sender) then return end
    sender = SafePlain(sender)
    if #sender == 0 then return end
    local version, action, rest = text:match("^(%d+)" .. SEP .. "([SHK])" .. SEP .. "(.*)$")
    if version ~= PROTOCOL or not action then return end
    local now = Now()
    if action == "S" then
        local kind, name = rest:match("^([pm])" .. SEP .. "(.+)$")
        if kind then ReceiveSighting(sender, kind, name) end
    elseif action == "H" then
        if rest:match("^%d+$") and #rest <= 20 and now - (lastAck[sender] or -1000) >= 3 then
            lastAck[sender] = now
            Enqueue(PROTOCOL .. SEP .. "K" .. SEP .. rest, "ack:" .. sender .. ":" .. rest, true)
        end
    elseif action == "K" then
        if pingNonce and rest == pingNonce and now < (pingDeadline or 0) and not pingResponses[sender] then
            pingResponses[sender] = true
            connected[sender] = now
            WR.Notice("파티 통신 응답 확인: " .. sender .. " (양쪽 애드온 메시지 수신됨)")
        end
    end
    DrawPartyHUD(now)
    if WR.RefreshDetectedUI then WR:RefreshDetectedUI() end
end
local lastGroup = nil
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("CHAT_MSG_ADDON")
frame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        RegisterPrefix()
        lastGroup = Channel()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "GROUP_ROSTER_UPDATE" then
        -- A roster change invalidates sighting provenance. Keep the stored personal lists.
        EmptyQueue()
        EmptyRemote()
        connected, pingResponses, pingNonce, pingDeadline = {}, {}, nil, nil
        lastGroup = Channel()
        if WR.RefreshPartyStatus then WR:RefreshPartyStatus() end
    elseif event == "CHAT_MSG_ADDON" then
        HandleMessage(...)
    end
end)
local t = 0
frame:SetScript("OnUpdate", function(_, elapsed)
    t = t + elapsed
    if t < 0.25 then return end
    t = 0
    local now = Now()
    local ch = Channel()
    if ch ~= lastGroup then
        EmptyQueue()
        EmptyRemote()
        lastGroup = ch
    end
    SendNext()
    DrawPartyHUD(now)
    if WR.RefreshPartyStatus then WR:RefreshPartyStatus() end
    if pingNonce and pingDeadline and now >= pingDeadline then
        local count = 0
        for _ in pairs(pingResponses) do count = count + 1 end
        if count == 0 then WR.Notice("파티 통신 응답 없음: 파티원 설치 여부 또는 서버 제한을 확인하세요.") end
        pingNonce, pingDeadline, pingResponses = nil, nil, {}
    end
end)

-- Forever Watch Radar 1.6.1 | EllesmereUI native addon-button flyout integration.
-- Keeps existing nameplates, watchlists, and party-sharing code untouched.
-- EllesmereUI scans *direct children* of Minimap for named Button frames.
-- Never force our own position once EllesmereUI has taken over the button.
local WR = _G.ForeverWatchRadar
if not WR then return end

local button
local cos, sin, rad, deg, atan = math.cos, math.sin, math.rad, math.deg, math.atan
local function Options()
    return WR.db and WR.db.settings
end

-- EllesmereUI's collector records buttons in this public compatibility cache.
-- The button's parent may later become its flyout panel, or it may stay on
-- the minimap if users select Ungroup Minimap Buttons.
local function IsEllesmereCollected()
    local list = _G._EBS_CachedAddonButtons
    if type(list) ~= "table" or not button then return false end
    for i = 1, #list do
        if list[i] == button then return true end
    end
    return false
end

local function Angle(y, x)
    if math.atan2 then return deg(math.atan2(y, x)) end
    if x == 0 then return y >= 0 and 90 or -90 end
    local a = deg(atan(y / x))
    if x < 0 then return a + 180 end
    return a
end

local function PositionButton()
    if not button then return end
    -- EUI owns the grouped/ungrouped layout once the button is collected.
    -- Relayout here would pop the icon back out of the user's button drawer.
    if IsEllesmereCollected() then return end
    local mapParent = _G.Minimap or UIParent
    if button:GetParent() ~= mapParent then return end
    local opts = Options()
    local angle = opts and tonumber(opts.minimapAngle) or 45
    if not angle then angle = 45 end
    button:ClearAllPoints()
    local map = _G.Minimap
    if map and map.GetWidth then
        local width = map:GetWidth()
        if not width or width < 40 then width = 140 end
        local radius = width * 0.5 + 10
        button:SetPoint("CENTER", map, "CENTER", cos(rad(angle)) * radius, sin(rad(angle)) * radius)
    else
        button:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -215, -95)
    end
end

local function UpdateDragPosition()
    local opts = Options()
    local map = _G.Minimap
    if not opts or not map or not map.GetCenter or not GetCursorPosition then return end
    local mx, my = map:GetCenter()
    local ok, cursorX, cursorY = pcall(GetCursorPosition)
    if not ok or type(mx) ~= "number" or type(my) ~= "number"
        or type(cursorX) ~= "number" or type(cursorY) ~= "number" then return end
    local scale = map.GetEffectiveScale and map:GetEffectiveScale() or 1
    if type(scale) ~= "number" or scale <= 0 then scale = 1 end
    local dx, dy = cursorX / scale - mx, cursorY / scale - my
    if dx * dx + dy * dy < 9 then return end
    opts.minimapAngle = Angle(dy, dx)
    PositionButton()
end

function WR:RefreshMinimapButton()
    if not button then return end
    if not Options() or Options().minimapButton ~= false then
        PositionButton()
        button:Show()
    else
        button:Hide()
    end
end

function WR:CreateMinimapButton()
    if button then self:RefreshMinimapButton(); return button end
    if not UIParent or not CreateFrame then return nil end
    -- Critical: EUI's GatherMinimapButtons only scans Minimap:GetChildren().
    -- UIParent as the parent (v1.6.0) leaves the icon outside the EUI drawer.
    button = CreateFrame("Button", "ForeverWatchRadarMinimapButton", _G.Minimap or UIParent)
    button:SetSize(32, 32)
    button:SetFrameStrata("HIGH")
    button:SetFrameLevel(8)
    button:EnableMouse(true)
    button:RegisterForClicks("LeftButtonUp")
    button:RegisterForDrag("LeftButton")

    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.035, 0.044, 0.063, 0.95)
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\Ability_Hunter_EagleEye")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    -- EUI can now identify and size the icon inside its 24px flyout cell.
    button.icon = icon
    -- Crisp gold edges without bundled images or external icon libraries.
    -- Anchored outlines stretch with the button: EUI resizes 32px buttons
    -- to its grid cell size, which made the old fixed 32px edges stick out.
    for side = 1, 4 do
        local t = button:CreateTexture(nil, "OVERLAY")
        t:SetColorTexture(1, 0.73, 0.24, 0.96)
        if side == 1 then
            t:SetHeight(2)
            t:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
            t:SetPoint("TOPRIGHT", button, "TOPRIGHT", 0, 0)
        elseif side == 2 then
            t:SetHeight(2)
            t:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 0, 0)
            t:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 0, 0)
        elseif side == 3 then
            t:SetWidth(2)
            t:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
            t:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 0, 0)
        else
            t:SetWidth(2)
            t:SetPoint("TOPRIGHT", button, "TOPRIGHT", 0, 0)
            t:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 0, 0)
        end
    end
    local glow = button:CreateTexture(nil, "HIGHLIGHT")
    glow:SetAllPoints(icon)
    glow:SetColorTexture(1, 0.85, 0.42, 0.20)
    button:SetScript("OnClick", function()
        if WR.ToggleUI then WR:ToggleUI() end
    end)
    button:SetScript("OnDragStart", function(self)
        -- EUI manages grouped buttons' size, position, and drag behavior.
        if IsEllesmereCollected() or self:GetParent() ~= (_G.Minimap or UIParent) then return end
        if InCombatLockdown and InCombatLockdown() then return end
        self:SetScript("OnUpdate", UpdateDragPosition)
    end)
    button:SetScript("OnDragStop", function(self)
        if not self:GetScript("OnUpdate") then return end
        self:SetScript("OnUpdate", nil)
        if not IsEllesmereCollected() and not (InCombatLockdown and InCombatLockdown()) then
            UpdateDragPosition()
        end
    end)
    button:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Forever Watch Radar", 1, 0.79, 0.35)
        GameTooltip:AddLine("좌클릭: 수배 · 블랙리스트 · 친구 등록창", 0.87, 0.91, 1)
        if IsEllesmereCollected() then
            GameTooltip:AddLine("엘스미어 UI 미니맵 버튼 모음집에서 관리", 0.65, 0.82, 1)
        else
            GameTooltip:AddLine("드래그: 미니맵 버튼 위치 이동", 0.65, 0.82, 1)
        end
        GameTooltip:AddLine("숨기기: /wtr minimap off", 0.72, 0.76, 0.81)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function()
        if GameTooltip then GameTooltip:Hide() end
    end)
    self.minimapButtonFrame = button
    self:RefreshMinimapButton()
    return button
end

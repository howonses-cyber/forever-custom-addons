-- Forever Watch Radar 1.6.1 | WoW Forever 1.60.1 (Interface 16001)
-- Glow + thick border attached to EllesmereUI health bar when exposed.
-- Standalone overlay: never edits or replaces EllesmereUI nameplates.
-- Automatic visible nameplate detection (no click), with target/mouseover fallback.
-- Does NOT scan invisible units or extend WoW nameplate range.

local ADDON_NAME = ...
local WR = {}
_G.ForeverWatchRadar = WR

local pairs, ipairs, type, tostring, tonumber, pcall = pairs, ipairs, type, tostring, tonumber, pcall
local tinsert, tremove, sort = table.insert, table.remove, table.sort
local lower, gsub, match, format = string.lower, string.gsub, string.match, string.format
local max, min, sin = math.max, math.min, math.sin
local DB
local overlays = setmetatable({}, { __mode = "k" })
-- Do not use plate.namePlateUnitToken as the only source. On Forever it may
-- not exist at all: C_NamePlate/GetNamePlateForUnit and the NAME_PLATE events
-- expose the canonical nameplate1..nameplate40 unit tokens instead.
local activeNameplateUnits = {} -- event token => true, for delayed population
local plateByUnit = {}         -- token => last shown plate, for removal cleanup
local NAMEPLATE_SWEEP_LIMIT = 40
local detected = {}
local lastAlert = {}
local lastGlobalSound = 0
local lastFriendSound = -9999
local pulseTime = 0
local nextScan = 0
local hud
local core = CreateFrame("Frame")
local clientForever = true -- Dedicated Forever package: surname is the second UnitName return.
local FLAT = "Interface\\Buttons\\WHITE8X8"
-- Small built-in raid-target icons, rendered ON the visible nameplate only.
-- 1=star (friend), 8=skull (enemy), 3=diamond (monster).
-- This never calls SetRaidTarget: it is a private visual overlay, not a real raid mark.
local ICON_ATLAS = "Interface\\TargetingFrame\\UI-RaidTargetingIcons"
local ICON_COORDS = {
    friend = {0.00, 0.25, 0.00, 0.25},
    player = {0.75, 1.00, 0.25, 0.50},
    mob = {0.50, 0.75, 0.00, 0.25},
}

local function SafeValue(v)
    if issecretvalue and issecretvalue(v) then return nil end
    return v
end
local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a, b, c = pcall(fn, ...)
    if not ok then return nil end
    return SafeValue(a), SafeValue(b), SafeValue(c)
end
local function Trim(s)
    if type(s) ~= "string" then return "" end
    return (gsub(gsub(s, "^%s+", ""), "%s+$", ""))
end
local function Key(s)
    s = lower(Trim(s or ""))
    -- Forever supports First Surname, and some UI shows First-Surname.
    s = gsub(s, "%s*%-%s*", " ")
    s = gsub(s, "%s+", " ")
    return s
end
local function Notice(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffcc33[Watch Radar]|r " .. tostring(msg))
    else
        print("[Watch Radar] " .. tostring(msg))
    end
end
WR.Notice = Notice
WR.Key = Key
local function NewDB()
    if type(ForeverWatchRadarDB) ~= "table" then ForeverWatchRadarDB = {} end
    DB = ForeverWatchRadarDB
    if type(DB.mobs) ~= "table" then DB.mobs = {} end
    if type(DB.players) ~= "table" then DB.players = {} end
    if type(DB.friends) ~= "table" then DB.friends = {} end
    if type(DB.settings) ~= "table" then DB.settings = {} end
    local s = DB.settings
    if s.enabled == nil then s.enabled = true end
    -- 1.3 migration: stop the old large central warning panels even for
    -- existing installations whose v1.2 settings had HUD enabled by default.
    -- Other user options and every registered name stay exactly as saved.
    if s.nameplateMarkerV13 == nil then
        s.hud = false
        s.friendHUD = false -- legacy option, no longer creates any frame
        s.nameplateMarkerV13 = true
    end
    if s.hud == nil then s.hud = false end
    if s.sound == nil then s.sound = true end
    if s.pulse == nil then s.pulse = true end
    if s.partyShare == nil then s.partyShare = true end
    if s.friendHUD == nil then s.friendHUD = false end
    if s.partyHUD == nil then s.partyHUD = true end
    if s.friendSound == nil then s.friendSound = false end
    -- v1.6: optional, draggable minimap button. Keep existing watchlists intact.
    if s.minimapButton == nil then s.minimapButton = true end
    if type(s.minimapAngle) ~= "number" then s.minimapAngle = 45 end
    -- New in v1.5: opt-in size/style controls, keeping previous lists/settings.
    if s.markStyle ~= "strong" and s.markStyle ~= "soft" and s.markStyle ~= "off" then
        s.markStyle = "strong"
    end
    if type(s.markSize) ~= "number" or s.markSize < 80 or s.markSize > 160 then
        s.markSize = 125
    end
    WR.db = DB
end
function WR:GetEntries(kind)
    if not DB then return {} end
    if kind == "player" then return DB.players end
    if kind == "friend" then return DB.friends end
    return DB.mobs
end
function WR:SetOption(key, value)
    if not DB or DB.settings[key] == nil then return end
    DB.settings[key] = value and true or false
    if key == "partyShare" and self.OnPartyToggle then self:OnPartyToggle() end
    if key == "minimapButton" and self.RefreshMinimapButton then self:RefreshMinimapButton() end
    self:Scan()
    if self.RefreshUI then self:RefreshUI() end
end
function WR:SetMarkStyle(style)
    if not DB then NewDB() end
    if style ~= "strong" and style ~= "soft" and style ~= "off" then
        return false, "강조 방식은 strong / soft / off 중에서 선택하세요."
    end
    DB.settings.markStyle = style
    self:Scan()
    if self.RefreshUI then self:RefreshUI() end
    return true, "이름표 강조: " .. (style == "strong" and "강력" or style == "soft" and "기본" or "끄기")
end
function WR:SetMarkSize(size)
    if not DB then NewDB() end
    size = tonumber(size)
    if not size then return false, "크기는 80~160(%) 사이의 숫자로 설정하세요." end
    size = max(80, min(160, math.floor(size + 0.5)))
    DB.settings.markSize = size
    self:Scan()
    if self.RefreshUI then self:RefreshUI() end
    return true, "징표 크기: " .. size .. "%"
end
function WR:NameOfUnit(unit)
    local first, second = SafeCall(UnitName, unit)
    if type(first) ~= "string" or first == "" then return nil end
    -- On Forever, UnitName's second result is *surname*, NOT realm.
    if clientForever and type(second) == "string" and second ~= "" then
        return first .. (CHARACTERNAME_SURNAME_SEPARATOR or " ") .. second
    end
    return first
end
function WR:UnitNPCID(unit)
    local guid = SafeCall(UnitGUID, unit)
    if type(guid) ~= "string" then return nil end
    -- Creature-0-...-NPCID-spawn. Do not force an ID on unrecognised GUIDs.
    return tonumber(match(guid, "^Creature%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)%-"))
        or tonumber(match(guid, "^Vehicle%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)%-"))
end
function WR:Identity(unit)
    if SafeCall(UnitExists, unit) ~= true then return nil end
    local name = self:NameOfUnit(unit)
    if not name then return nil end
    local player = SafeCall(UnitIsPlayer, unit)
    if type(player) ~= "boolean" then return nil end
    local canAttack = SafeCall(UnitCanAttack, "player", unit)
    local isEnemy = SafeCall(UnitIsEnemy, "player", unit)
    local hostile = (canAttack == true or isEnemy == true)
    if player and not hostile then
        -- Cross-faction enemies may be non-attackable in sanctuary/PvP-off zones.
        local theirs, ours = SafeCall(UnitFactionGroup, unit), SafeCall(UnitFactionGroup, "player")
        if type(theirs) == "string" and type(ours) == "string" and theirs ~= "" and ours ~= "" then
            hostile = theirs ~= ours
        elseif canAttack == nil and isEnemy == nil then
            -- Unknown secret faction/hostility => use an earlier safe nameplate cache.
            return nil
        end
    end
    -- A separate same-faction / friend test: never treat a merely non-attackable
    -- opposing player in a sanctuary as an allied friend.
    local friendly = false
    if player then
        local isFriend = SafeCall(UnitIsFriend, "player", unit)
        local theirs, ours = SafeCall(UnitFactionGroup, unit), SafeCall(UnitFactionGroup, "player")
        local sameFaction = type(theirs) == "string" and type(ours) == "string"
            and theirs ~= "" and ours ~= "" and theirs == ours
        friendly = (isFriend == true or sameFaction) and not hostile
        if SafeCall(UnitIsUnit, unit, "player") == true then friendly = false end
    end
    return {name=name, key=Key(name), player=player, hostile=hostile,
        friendly=friendly, npcId=(not player) and self:UnitNPCID(unit) or nil}
end
function WR:EntryID(kind, key)
    local prefix = kind == "player" and "p:" or kind == "friend" and "f:" or "m:"
    return prefix .. key
end
function WR:FindMatch(id)
    if not DB or not DB.settings.enabled or not id then return nil end
    local kind
    if id.player then
        if id.hostile then kind = "player"
        elseif id.friendly then kind = "friend"
        else return nil end
    else
        kind = "mob"
    end
    local arr = self:GetEntries(kind)
    for _, rec in ipairs(arr) do
        if rec.key == id.key then
            -- NPC ID is an extra disambiguator where the game exposes it.
            if kind ~= "mob" or not rec.npcId or not id.npcId or rec.npcId == id.npcId then
                return rec
            end
        end
    end
    return nil
end
function WR:Add(kind, name, npcId)
    if not DB then NewDB() end
    if kind ~= "player" and kind ~= "mob" and kind ~= "friend" then
        return false, "종류가 올바르지 않습니다."
    end
    local clean = Trim(name)
    local k = Key(clean)
    if k == "" then return false, "등록할 이름을 입력하세요." end
    if #clean > 100 then return false, "이름은 100바이트 이하로 입력하세요." end
    if clean:find("[%c|]") then return false, "이름에 제어문자나 | 문자는 사용할 수 없습니다." end
    local arr = self:GetEntries(kind)
    for _, rec in ipairs(arr) do
        if rec.key == k then return false, "이미 등록된 대상입니다: " .. rec.name end
    end
    local rec = {name=clean, key=k, kind=kind, npcId=(kind == "mob") and npcId or nil}
    tinsert(arr, rec)
    self:Scan()
    if self.RefreshUI then self:RefreshUI() end
    local suffix = kind == "player" and " — 적 플레이어 블랙리스트에 등록"
        or kind == "friend" and " — 아군 친구 목록에 등록"
        or " — 몬스터 수배 목록에 등록"
    return true, clean .. suffix
end
function WR:AddTarget(requestedKind)
    if SafeCall(UnitExists, "target") ~= true then
        return false, "먼저 등록할 몬스터 또는 플레이어를 선택하세요."
    end
    local id = self:Identity("target")
    if not id then return false, "대상 이름을 읽을 수 없습니다. 전투가 끝난 뒤 다시 시도하세요." end
    local actualKind
    if id.player then
        if id.hostile then actualKind = "player"
        elseif id.friendly then actualKind = "friend"
        else return false, "아군/적군을 확인할 수 없어 등록하지 않았습니다." end
    else actualKind = "mob" end
    if requestedKind and requestedKind ~= actualKind then
        if requestedKind == "friend" then return false, "아군 플레이어만 친구 목록에 등록할 수 있습니다." end
        if requestedKind == "player" then return false, "적 플레이어만 블랙리스트에 등록할 수 있습니다." end
        return false, "몬스터만 수배 목록에 등록할 수 있습니다."
    end
    return self:Add(actualKind, id.name, id.npcId)
end
function WR:Remove(kind, key)
    if not DB then return false end
    local arr = self:GetEntries(kind)
    local k = Key(key)
    for i = #arr, 1, -1 do
        if arr[i].key == k then
            local name = arr[i].name
            tremove(arr, i)
            self:Scan()
            if self.RefreshUI then self:RefreshUI() end
            return true, name
        end
    end
    return false, "등록되지 않은 이름입니다."
end
function WR:IsDetected(rec)
    return rec and detected[self:EntryID(rec.kind, rec.key)] ~= nil
end
function WR:CountDetected()
    local n = 0
    for _ in pairs(detected) do n = n + 1 end
    return n
end

-- v1.5 nameplate emphasis. Never changes or recolors the actual EUI plate.
-- The frame is a non-interactive visual overlay whose anchors follow EUI's
-- published "health" widget. A safe fallback is used with other nameplates.
local MARK_COLORS = {
    friend = {0.26, 0.91, 1.00},
    player = {1.00, 0.19, 0.27},
    mob = {1.00, 0.74, 0.16},
}
local MARK_LABELS = { friend="친구", player="주의", mob="수배" }

-- The EUI Forever source publishes both ns.plates (enemies) and
-- ns.friendlyPlates (friendly). The actual visible statusbar is .health.
-- We only READ these tables; we never write to or hook EUI widgets.
local function RealHealthBar(plate, unit)
    local ns = _G.EllesmereNameplates_NS
    if not ns and EllesmereUI and EllesmereUI._ModuleNS then
        ns = EllesmereUI._ModuleNS.EllesmereUINameplates
    end
    if ns then
        local containers = { ns.friendlyPlates or false, ns.plates or false }
        for _, group in ipairs(containers) do
            if type(group) == "table" then
                local item = type(unit) == "string" and group[unit] or nil
                if item and item.health and item.nameplate == plate then
                    return item.health, true
                end
                -- target/mouseover fallbacks and pools whose unit index changed:
                for _, candidate in pairs(group) do
                    if candidate and candidate.nameplate == plate and candidate.health then
                        return candidate.health, true
                    end
                end
            end
        end
    end
    local uf = plate and plate.UnitFrame
    if uf then
        local health = uf.healthBar or uf.healthbar or uf.health
        if health then return health, true end
    end
    -- Never assume an arbitrary nameplate root is exactly healthbar sized.
    return plate, false
end

local function EdgeTexture(parent)
    local t = parent:CreateTexture(nil, "OVERLAY")
    t:SetTexture(FLAT)
    return t
end
-- Create a complete four-sided border with *anchor-based* geometry. Its edges
-- change width automatically whenever EllesmereUI changes healthbar width.
local function BorderRing(parent, gap, thickness)
    local group = {}
    local top = EdgeTexture(parent)
    top:SetPoint("TOPLEFT", parent, "TOPLEFT", -gap, gap)
    top:SetPoint("TOPRIGHT", parent, "TOPRIGHT", gap, gap)
    top:SetHeight(thickness)
    local bottom = EdgeTexture(parent)
    bottom:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", -gap, -gap)
    bottom:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", gap, -gap)
    bottom:SetHeight(thickness)
    local left = EdgeTexture(parent)
    left:SetPoint("TOPLEFT", parent, "TOPLEFT", -gap, gap)
    left:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", -gap, -gap)
    left:SetWidth(thickness)
    local right = EdgeTexture(parent)
    right:SetPoint("TOPRIGHT", parent, "TOPRIGHT", gap, gap)
    right:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", gap, -gap)
    right:SetWidth(thickness)
    group[1],group[2],group[3],group[4] = top,bottom,left,right
    return group
end
local function TintRing(ring, r, g, b)
    for i=1,4 do ring[i]:SetVertexColor(r, g, b, 1) end
end
local function AlphaRing(ring, a)
    for i=1,4 do ring[i]:SetAlpha(a) end
end

local function Decor(plate)
    local f = overlays[plate]
    if f then return f end
    f = CreateFrame("Frame", nil, plate)
    f:SetSize(114, 10)
    f:SetPoint("CENTER", plate, "CENTER", 0, -4)
    f:EnableMouse(false)

    -- Three superposed borders, radiating out from the existing healthbar.
    -- Outer and middle layers pulse softly; inner 3px stays clearly visible.
    f.halo = BorderRing(f, 11, 10)
    f.glow = BorderRing(f, 7, 6)
    f.rim = BorderRing(f, 3, 3)

    -- Large raid-style marker ABOVE the plate. Never uses SetRaidTarget.
    f.crest = CreateFrame("Frame", nil, f)
    f.crest:SetSize(48, 48)
    f.crest:SetPoint("BOTTOM", f, "TOP", 0, 33)
    f.crest:EnableMouse(false)
    f.shadow = f.crest:CreateTexture(nil, "ARTWORK")
    f.shadow:SetSize(49, 49)
    f.shadow:SetPoint("CENTER", f.crest, "CENTER", 2, -2)
    f.shadow:SetTexture(ICON_ATLAS)
    f.shadow:SetVertexColor(0, 0, 0, 0.95)
    f.icon = f.crest:CreateTexture(nil, "OVERLAY")
    f.icon:SetSize(42, 42)
    f.icon:SetPoint("CENTER", f.crest, "CENTER", 0, 0)
    f.icon:SetTexture(ICON_ATLAS)

    local bigFont = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    f.friendShadow = f.crest:CreateFontString(nil, "ARTWORK", "GameFontNormalHuge")
    f.friendShadow:SetPoint("CENTER", f.crest, "CENTER", 2, -3)
    f.friendShadow:SetFont(bigFont, 41, "OUTLINE")
    f.friendShadow:SetText("★")
    f.friendShadow:SetTextColor(0, 0, 0, 1)
    f.friendStar = f.crest:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.friendStar:SetPoint("CENTER", f.crest, "CENTER", 0, 0)
    f.friendStar:SetFont(bigFont, 41, "OUTLINE")
    f.friendStar:SetText("★")
    f.friendStar:Hide()
    f.friendShadow:Hide()

    -- Strong contrasting inward arrows at both ends of the healthbar.
    f.leftWing = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.leftWing:SetPoint("RIGHT", f, "LEFT", -13, 1)
    f.leftWing:SetFont(bigFont, 23, "OUTLINE")
    f.leftWing:SetText("▶")
    f.rightWing = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.rightWing:SetPoint("LEFT", f, "RIGHT", 13, 1)
    f.rightWing:SetFont(bigFont, 23, "OUTLINE")
    f.rightWing:SetText("◀")
    -- Compact nameplate tag to distinguish the category at a glance.
    f.tagBox = CreateFrame("Frame", nil, f)
    f.tagBox:SetSize(43, 19)
    f.tagBox:SetPoint("BOTTOMLEFT", f, "TOPRIGHT", 12, 10)
    f.tagBox:EnableMouse(false)
    f.tagBg = f.tagBox:CreateTexture(nil, "BACKGROUND")
    f.tagBg:SetAllPoints()
    f.tagBg:SetTexture(FLAT)
    f.tagBg:SetVertexColor(0.0, 0.0, 0.02, 0.93)
    f.tagText = f.tagBox:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.tagText:SetPoint("CENTER", f.tagBox, "CENTER", 0, 0)

    f:Hide()
    overlays[plate] = f
    return f
end

local function AttachToHealth(f, plate, unit)
    local health, isBar = RealHealthBar(plate, unit)
    if health ~= f.health or isBar ~= f.attachedToBar then
        f:ClearAllPoints()
        if isBar then
            f:SetAllPoints(health) -- precise EUI bar geometry (no GetWidth)
        else
            -- fallback for other UIs; do not stretch over the whole plate.
            f:SetPoint("CENTER", plate, "CENTER", 0, -4)
            f:SetSize(114, 10)
        end
        f.health, f.attachedToBar = health, isBar
    end
    local lvl = health and SafeCall(health.GetFrameLevel, health)
    if type(lvl) ~= "number" then lvl = SafeCall(plate.GetFrameLevel, plate) end
    if type(lvl) ~= "number" then lvl = 10 end
    local newLevel = min(10000, lvl + 35)
    if f.level ~= newLevel then
        f:SetFrameStrata("MEDIUM")
        f:SetFrameLevel(newLevel)
        f.level = newLevel
    end
end

local function ShowMarker(plate, rec, now, unit)
    if not plate or not DB then return false end
    if DB.settings.markStyle == "off" then
        if overlays[plate] then overlays[plate]:Hide() end
        return true
    end
    local ok, f = pcall(Decor, plate)
    if not ok or not f then return false end
    AttachToHealth(f, plate, unit)
    local style = DB.settings.markStyle or "strong"
    local strong = style == "strong"
    local kind = rec.kind
    local c = MARK_COLORS[kind] or MARK_COLORS.mob
    local r, g, b = c[1],c[2],c[3]
    local coords = ICON_COORDS[kind] or ICON_COORDS.mob
    if f.kind ~= kind then
        TintRing(f.rim,r,g,b)
        TintRing(f.glow,r,g,b)
        TintRing(f.halo,r,g,b)
        f.leftWing:SetTextColor(r,g,b,1)
        f.rightWing:SetTextColor(r,g,b,1)
        f.tagText:SetTextColor(r,g,b,1)
        f.tagText:SetText(MARK_LABELS[kind] or "수배")
        f.icon:SetTexCoord(coords[1],coords[2],coords[3],coords[4])
        f.shadow:SetTexCoord(coords[1],coords[2],coords[3],coords[4])
        if kind == "friend" then
            f.friendStar:SetTextColor(r,g,b,1)
            f.friendStar:Show()
            f.friendShadow:Show()
            f.icon:Hide()
            f.shadow:Hide()
        else
            f.friendStar:Hide()
            f.friendShadow:Hide()
            f.icon:SetVertexColor(1,1,1,1)
            f.icon:Show()
            f.shadow:Show()
        end
        f.kind = kind
    end
    local size = (DB.settings.markSize or 125) / 100
    if f.lastSize ~= size then f.crest:SetScale(size); f.lastSize=size end
    if f.lastStrong ~= strong then
        f.leftWing:SetShown(strong)
        f.rightWing:SetShown(strong)
        f.tagBox:SetShown(strong)
        f.lastStrong = strong
    end
    local wave = DB.settings.pulse and ((sin(now * 5) + 1) * 0.5) or 0.75
    AlphaRing(f.rim, 1.0)
    AlphaRing(f.glow, strong and (0.34 + 0.22 * wave) or 0.18)
    AlphaRing(f.halo, strong and (0.11 + 0.17 * wave) or 0.0)
    f.crest:SetAlpha(DB.settings.pulse and (0.88 + 0.12 * wave) or 1)
    f:Show()
    return true
end
local function HideOldMarkers(marked)
    for plate, f in pairs(overlays) do
        if not marked[plate] then
            f:Hide()
            f.kind = nil
            f.health = nil -- EUI can recycle the same nameplate for another unit
            f.attachedToBar = nil
        end
    end
end

local function MakeHUD()
    if hud then return hud end
    local f = CreateFrame("Frame", "ForeverWatchRadarHUD", UIParent)
    f:SetSize(282, 76)
    f:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -22, -120)
    f:SetFrameStrata("MEDIUM")
    f:EnableMouse(false)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.06, 0.06, 0.09, 0.75)
    local edge = f:CreateTexture(nil, "BORDER")
    edge:SetColorTexture(1, 0.24, 0.22, 0.95)
    edge:SetSize(282, 2)
    edge:SetPoint("TOP", f, "TOP", 0, 0)
    f.title = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    f.title:SetPoint("TOP", f, "TOP",0,-6)
    f.title:SetTextColor(1,0.85,0.35)
    f.one = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f.one:SetPoint("TOP",f.title,"BOTTOM",0,-4)
    f.one:SetSize(268,14)
    f.two = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f.two:SetPoint("TOP",f.one,"BOTTOM",0,-2)
    f.two:SetSize(268,14)
    f.more = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    f.more:SetPoint("TOP",f.two,"BOTTOM",0,-2)
    f:Hide()
    hud = f
    return f
end
function WR:DrawHUD(now)
    local isPreview = self.previewUntil and now < self.previewUntil
    if not DB or not DB.settings.enabled or (not DB.settings.hud and not isPreview) then
        if hud then hud:Hide() end
        return
    end
    local found = {}
    for _, rec in pairs(detected) do
        if rec.kind ~= "friend" then tinsert(found, rec) end
    end
    sort(found, function(a,b)
        if a.kind ~= b.kind then return a.kind == "player" end
        return a.key < b.key
    end)
    if #found == 0 then
        if self.previewUntil and now < self.previewUntil then
            local h = MakeHUD()
            h.title:SetText("[미리보기] 감시 대상 발견")
            h.one:SetText("|cffff4444[블랙리스트] 적 플레이어 예시|r")
            h.two:SetText("|cffffb83c[수배 몹] 몬스터 예시|r")
            h.more:SetText("테스트 모드 — 실제 대상이 아닙니다")
            h:Show()
        elseif hud then hud:Hide() end
        return
    end
    local h = MakeHUD()
    h.title:SetText("감시 대상 발견  (" .. #found .. ")")
    local function ShowLine(rec)
        if not rec then return "" end
        local color = rec.kind == "player" and "ffff4b4b" or "ffffc24a"
        return "|c" .. color .. (rec.kind == "player" and "[블랙리스트] " or "[수배 몹] ") .. rec.name .. "|r"
    end
    h.one:SetText(ShowLine(found[1]))
    h.two:SetText(ShowLine(found[2]))
    h.more:SetText(#found > 2 and ("외 " .. (#found-2) .. "개 대상 감지 중") or "이름표에 표시된 대상을 확인하세요")
    h:Show()
end

-- Different Forever builds expose unitToken, GetUnit(), or only an event token.
-- namePlateUnitToken is NOT guaranteed to exist. Avoid cached identity guesses:
-- recycled nameplate frames must never inherit a previous unit's alert.
local function IsPlateToken(unit)
    return type(unit) == "string" and match(unit, "^nameplate%d+$") ~= nil
end
local function PlateIsVisible(plate)
    if not plate then return false end
    if plate.IsShown then return SafeCall(plate.IsShown, plate) == true end
    return true
end
local function PlateUnitToken(plate)
    if not plate then return nil end
    local token = SafeValue(plate.unitToken)
    if IsPlateToken(token) then return token end
    token = SafeValue(plate.namePlateUnitToken) -- compatible with older clients
    if IsPlateToken(token) then return token end
    if type(plate.GetUnit) == "function" then
        token = SafeCall(plate.GetUnit, plate)
        if IsPlateToken(token) then return token end
    end
    local unitFrame = plate.UnitFrame
    if type(unitFrame) == "table" or type(unitFrame) == "userdata" then
        token = SafeValue(unitFrame.unit)
        if IsPlateToken(token) then return token end
    end
    return nil
end
local function GetPlate(unit)
    if not IsPlateToken(unit) or not C_NamePlate or not C_NamePlate.GetNamePlateForUnit then
        return nil
    end
    local plate = SafeCall(C_NamePlate.GetNamePlateForUnit, unit)
    if PlateIsVisible(plate) then return plate end
    return nil
end
function WR:FindPlateForUnit(unit)
    if not unit then return nil end
    -- The Blizzard API wants a nameplate token; passing 'target' can be denied.
    if IsPlateToken(unit) then return GetPlate(unit) end
    if not C_NamePlate then return nil end
    local function TryCandidate(token, plate)
        if IsPlateToken(token) and PlateIsVisible(plate)
            and SafeCall(UnitIsUnit, unit, token) == true then
            return plate
        end
    end
    if C_NamePlate.GetNamePlates then
        local plates = SafeCall(C_NamePlate.GetNamePlates)
        if type(plates) == "table" then
            for _, plate in ipairs(plates) do
                local token = PlateUnitToken(plate)
                local matched = TryCandidate(token, plate)
                if matched then return matched end
            end
        end
    end
    for token in pairs(activeNameplateUnits) do
        local plate = GetPlate(token)
        local matched = TryCandidate(token, plate)
        if matched then return matched end
    end
    for i = 1, NAMEPLATE_SWEEP_LIMIT do
        local token = "nameplate" .. i
        local plate = GetPlate(token)
        local matched = TryCandidate(token, plate)
        if matched then return matched end
    end
    -- Last resort for clients which accept the selected-unit token directly.
    local plate = C_NamePlate.GetNamePlateForUnit
        and SafeCall(C_NamePlate.GetNamePlateForUnit, unit)
    if PlateIsVisible(plate) then return plate end
    return nil
end

-- Friend discovery is visually marked on the FRIEND'S nameplate only.
-- No full-screen/center notification is ever created, including during tests.
function WR:TestFriend()
    if not DB then NewDB() end
    if SafeCall(UnitExists, "target") ~= true then
        Notice("친구 징표 테스트: 가까운 아군 플레이어를 선택하세요.")
        return
    end
    local id = self:Identity("target")
    if not id or not id.player or not id.friendly then
        Notice("친구 징표 테스트는 아군 플레이어만 가능합니다.")
        return
    end
    local plate = self:FindPlateForUnit("target")
    if not plate then
        Notice("대상의 이름표가 보이지 않습니다. EUI 아군 이름표를 켜고 가까이에서 시도하세요.")
        return
    end
    self.friendMarkerPreview = {
        plate = plate,
        key = id.key,
        untilTime = ((GetTime and GetTime()) or 0) + 5,
        rec = {kind="friend", key=id.key, name=id.name},
    }
    self:Scan()
    Notice("대상 이름표에 하늘색 테두리·발광·징표를 5초 동안 미리 보여줍니다.")
end

function WR:Alert(rec, now)
    local id = self:EntryID(rec.kind,rec.key)
    local previous = lastAlert[id] or -9999
    -- Suppress repeat spam when plates momentarily hide/return.
    if now - previous < 40 then return end
    lastAlert[id] = now
    if rec.kind == "friend" then
        Notice("|cff55e7ff[아군 친구 발견]|r " .. rec.name)
        -- Friend sound is opt-in and separate from enemy/mob warning sounds.
        if DB.settings.friendSound and now - lastFriendSound > 3 then
            lastFriendSound = now
            pcall(PlaySound, (SOUNDKIT and SOUNDKIT.TELL_MESSAGE) or 3081, "Master")
        end
        return
    end
    local prefix = rec.kind == "player" and "|cffff4444[블랙리스트 발견]|r"
        or "|cffffbe39[수배 몹 발견]|r"
    Notice(prefix .. " " .. rec.name)
    if DB.settings.sound and now - lastGlobalSound > 3 then
        lastGlobalSound = now
        local soundID = (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959
        pcall(PlaySound, soundID, "Master")
    end
end
function WR:Scan()
    if not DB then return end
    local now = (GetTime and GetTime()) or 0
    local newFound, marked = {}, {}
    local visitedTokens = {}
    local stats = { visibleFrames=0, plateUnits=0, plateMatches=0,
        targetMatches=0, iconErrors=0, eventUnits=0 }
    if DB.settings.enabled then
        local function Check(unit, plate, fromNameplate)
            if type(unit) ~= "string" then return end
            if fromNameplate then
                if visitedTokens[unit] or not PlateIsVisible(plate) then return end
                visitedTokens[unit] = true
                stats.plateUnits = stats.plateUnits + 1
                plateByUnit[unit] = plate
            end
            local identity = WR:Identity(unit)
            -- Never reuse an identity saved on a previous nameplate frame. A
            -- cached identity can belong to a completely different unit after
            -- the client recycles the plate.
            local rec = WR:FindMatch(identity)
            if not rec then return end
            newFound[WR:EntryID(rec.kind, rec.key)] = rec
            if fromNameplate then
                stats.plateMatches = stats.plateMatches + 1
            else
                stats.targetMatches = stats.targetMatches + 1
            end
            if plate then
                marked[plate] = true
                local ok, applied = pcall(ShowMarker, plate, rec, now, unit)
                if not ok or not applied then stats.iconErrors = stats.iconErrors + 1 end
            end
        end
        -- First: direct tokens supplied by modern nameplate frames.
        if C_NamePlate and C_NamePlate.GetNamePlates then
            local plates = SafeCall(C_NamePlate.GetNamePlates)
            if type(plates) == "table" then
                for _, plate in ipairs(plates) do
                    if PlateIsVisible(plate) then
                        stats.visibleFrames = stats.visibleFrames + 1
                        local token = PlateUnitToken(plate)
                        if token then Check(token, plate, true) end
                    end
                end
            end
        end
        -- Second: tokens from NAME_PLATE_UNIT_ADDED. On Forever the event may
        -- fire before UnitName() or the frame is ready, so every scan retries.
        for token in pairs(activeNameplateUnits) do
            stats.eventUnits = stats.eventUnits + 1
            if not visitedTokens[token] then
                local plate = GetPlate(token)
                if plate then Check(token, plate, true) end
            end
        end
        -- Third: full visible nameplate token sweep. This is the critical
        -- fallback for Forever builds where nameplate frames have NO unit token
        -- field and the ADDED event occurred before this addon was ready.
        for i = 1, NAMEPLATE_SWEEP_LIMIT do
            local token = "nameplate" .. i
            if not visitedTokens[token] then
                local plate = GetPlate(token)
                if plate then Check(token, plate, true) end
            end
        end
        -- Selected targets are supplementary, never required for detection.
        for _, unit in ipairs({"target", "mouseover", "focus"}) do
            if SafeCall(UnitExists, unit) == true then
                Check(unit, WR:FindPlateForUnit(unit), false)
            end
        end
    end
    local preview = self.friendMarkerPreview
    if DB.settings.enabled and preview and now < preview.untilTime then
        local plate = preview.plate
        if PlateIsVisible(plate) and not marked[plate] then
            -- Verify current identity; a reused nameplate must not keep a preview.
            local token = PlateUnitToken(plate)
            if not token then
                for i = 1, NAMEPLATE_SWEEP_LIMIT do
                    local candidate = "nameplate" .. i
                    if GetPlate(candidate) == plate then token = candidate; break end
                end
            end
            local current = token and self:Identity(token) or nil
            if current and current.friendly and current.key == preview.key then
                marked[plate] = true
                pcall(ShowMarker, plate, preview.rec, now, token)
            end
        end
    elseif preview then
        self.friendMarkerPreview = nil
    end
    HideOldMarkers(marked)
    self.scanStats = stats
    detected = newFound
    for id, rec in pairs(newFound) do
        if not self.oldDetected or not self.oldDetected[id] then self:Alert(rec, now) end
    end
    self.oldDetected = newFound
    if self.OnLocalDetected then self:OnLocalDetected(newFound, now) end
    self:DrawHUD(now)
    if self.RenderPartyHUD then self:RenderPartyHUD(now) end
    if self.RefreshDetectedUI then self:RefreshDetectedUI() end
end
function WR:Test()
    if not DB then NewDB() end
    self.previewUntil = ((GetTime and GetTime()) or 0) + 5
    lastGlobalSound = -9999
    if DB.settings.sound then
        pcall(PlaySound,(SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959,"Master")
    end
    self:DrawHUD((GetTime and GetTime()) or 0)
end
function WR:Diag()
    self:Scan()
    local s = self.scanStats or {}
    Notice("자동 이름표 진단: 표시 " .. (s.visibleFrames or 0)
        .. " / 유닛 인식 " .. (s.plateUnits or 0)
        .. " / 목록 일치 " .. (s.plateMatches or 0)
        .. " / 선택 대상 일치 " .. (s.targetMatches or 0)
        .. " / 징표 오류 " .. (s.iconErrors or 0))
    Notice("강조: " .. (DB.settings.markStyle or "strong") .. " / 크기 " .. (DB.settings.markSize or 125) .. "%")
    Notice("이벤트 등록 토큰 " .. (s.eventUnits or 0)
        .. " / 감지 목록 " .. self:CountDetected()
        .. " / 이름표 탐색 한도 " .. NAMEPLATE_SWEEP_LIMIT)
end
function WR:RangeStatus()
    -- Read only. We never override EllesmereUI's configured CVars or bypass
    -- the game's nameplate discovery range and stealth visibility rules.
    local all = SafeCall(GetCVar, "nameplateMaxDistance")
    local players = SafeCall(GetCVar, "nameplatePlayerMaxDistance")
    Notice("게임 이름표 거리 설정: 전체=" .. tostring(all or "확인 불가")
        .. " / 플레이어=" .. tostring(players or "확인 불가"))
    Notice("표시 가능 거리 밖의 대상은 감지할 수 없습니다. EllesmereUI의 이름표 설정과 게임 제한을 확인하세요.")
end
function WR:Status()
    if not DB then NewDB() end
    Notice("몬스터 " .. #DB.mobs .. "명 / 적 플레이어 " .. #DB.players
        .. "명 / 아군 친구 " .. #DB.friends .. "명 등록 | 현재 " .. self:CountDetected() .. "개 감지")
    Notice("감지: " .. (DB.settings.enabled and "켜짐" or "꺼짐") .. " | 이름표 징표: "..(DB.settings.enabled and "켜짐" or "꺼짐").." | 작은 적/몹 경고: "..(DB.settings.hud and "켜짐" or "꺼짐"))
    if self.PartyStatus then self:PartyStatus() end
end
function WR:Commands(msg)
    if not DB then NewDB() end
    msg = Trim(msg or "")
    local cmd, rest = match(msg, "^(%S+)%s*(.-)%s*$")
    cmd = lower(cmd or "")
    if cmd == "add" or cmd == "target" then
        local ok, result = self:AddTarget()
        Notice(result)
    elseif cmd == "mob" or cmd == "npc" or cmd == "몬스터" then
        local ok, result = self:Add("mob", rest)
        Notice(result)
    elseif cmd == "player" or cmd == "black" or cmd == "블랙" then
        local ok, result = self:Add("player", rest)
        Notice(result)
    elseif cmd == "friend" or cmd == "ally" or cmd == "친구" then
        local ok, result = self:Add("friend", rest)
        Notice(result)
    elseif cmd == "friendtarget" or cmd == "allytarget" then
        local ok, result = self:AddTarget("friend")
        Notice(result)
    elseif cmd == "delmob" then
        local ok, result = self:Remove("mob",rest)
        Notice(ok and (result.." 삭제") or result)
    elseif cmd == "delplayer" then
        local ok, result = self:Remove("player",rest)
        Notice(ok and (result.." 삭제") or result)
    elseif cmd == "delfriend" then
        local ok, result = self:Remove("friend",rest)
        Notice(ok and (result.." 삭제") or result)
    elseif cmd == "test" then self:Test()
    elseif cmd == "testfriend" then self:TestFriend()
    elseif cmd == "testparty" then if self.TestParty then self:TestParty() end
    elseif cmd == "ping" then if self.PingParty then self:PingParty() end
    elseif cmd == "share" then
        local opt = lower(rest)
        if opt == "on" then self:SetOption("partyShare",true); Notice("파티 공유 켜짐")
        elseif opt == "off" then self:SetOption("partyShare",false); Notice("파티 공유 꺼짐")
        elseif self.PartyStatus then self:PartyStatus() end
    elseif cmd == "on" then self:SetOption("enabled",true); Notice("감지 켜짐")
    elseif cmd == "off" then self:SetOption("enabled",false); Notice("감지 꺼짐")
    elseif cmd == "style" then
        local ok, result = self:SetMarkStyle(lower(rest))
        Notice(result)
    elseif cmd == "size" then
        local ok, result = self:SetMarkSize(rest)
        Notice(result)
    elseif cmd == "minimap" or cmd == "button" or cmd == "icon" then
        local choice = lower(rest)
        if choice == "on" then self:SetOption("minimapButton",true); Notice("미니맵 버튼 표시")
        elseif choice == "off" then self:SetOption("minimapButton",false); Notice("미니맵 버튼 숨김. /wtr minimap on 으로 다시 표시")
        elseif choice == "reset" then
            DB.settings.minimapAngle = 45
            if self.RefreshMinimapButton then self:RefreshMinimapButton() end
            Notice("미니맵 버튼 위치 초기화")
        else Notice("미니맵 버튼: /wtr minimap on / off / reset") end
    elseif cmd == "range" then self:RangeStatus()
    elseif cmd == "status" then self:Status()
    elseif cmd == "diag" or cmd == "debug" then self:Diag()
    elseif cmd == "help" then
        Notice("/wtr 등록창 | /wtr add 현재 타겟 자동 등록 | /wtr mob 이름 | /wtr player 이름")
        Notice("/wtr friend 이름 | /wtr friendtarget 아군 타겟 등록 | /wtr delfriend 이름")
        Notice("/wtr delmob 이름 | /wtr delplayer 이름 | /wtr testfriend(아군 타겟 징표) | /wtr test")
        Notice("/wtr style strong/soft/off | /wtr size 80~160 | /wtr range | /wtr status | /wtr diag")
        Notice("/wtr on/off | /wtr share on/off | /wtr ping | /wtr testparty")
        Notice("/wtr minimap on/off/reset | 미니맵 버튼 좌클릭: 등록창 | 드래그: 위치 이동")
    else
        if self.ToggleUI then self:ToggleUI() else Notice("/wtr help 명령어") end
    end
end
SLASH_FOREVERWATCHRADAR1 = "/wtr"
SLASH_FOREVERWATCHRADAR2 = "/watchradar"
SlashCmdList.FOREVERWATCHRADAR = function(msg) WR:Commands(msg) end

core:RegisterEvent("PLAYER_LOGIN")
core:RegisterEvent("NAME_PLATE_UNIT_ADDED")
core:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
core:RegisterEvent("PLAYER_TARGET_CHANGED")
core:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
core:RegisterEvent("PLAYER_FOCUS_CHANGED")
core:RegisterEvent("PLAYER_ENTERING_WORLD")
core:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_LOGIN" then
        NewDB()
        if WR.CreateMinimapButton then WR:CreateMinimapButton() end
        WR:Scan()
        if WR.RefreshUI then WR:RefreshUI() end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        if IsPlateToken(unit) then
            -- The plate may already be inaccessible from the Blizzard API;
            -- remember the old frame from previous scans so it can be cleared.
            local plate = plateByUnit[unit] or GetPlate(unit)
            if plate and overlays[plate] then
                overlays[plate]:Hide()
                overlays[plate].kind = nil
            end
            activeNameplateUnits[unit] = nil
            plateByUnit[unit] = nil
        end
        if DB then WR:Scan() end
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        if IsPlateToken(unit) then
            activeNameplateUnits[unit] = true
            plateByUnit[unit] = nil
        end
        -- This event can precede unit population. OnUpdate will retry even
        -- when this first scan gets no UnitName or nameplate frame yet.
        if DB then WR:Scan() end
    else
        if event == "PLAYER_ENTERING_WORLD" then
            -- Drop stale event tokens after instances / zones / reloads.
            for token in pairs(activeNameplateUnits) do activeNameplateUnits[token] = nil end
            for token in pairs(plateByUnit) do plateByUnit[token] = nil end
        end
        if DB then WR:Scan() end
    end
end)
core:SetScript("OnUpdate", function(_, elapsed)
    if not DB then return end
    nextScan = nextScan + elapsed
    if nextScan < 0.25 then return end
    nextScan = 0
    WR:Scan()
end)

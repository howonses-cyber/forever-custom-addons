local addon,G=...
G.uiVersion="2.1.2"
local C={bg={.055,.065,.082,.98},panel={.085,.10,.13,.96},gold={.95,.77,.39},cyan={.41,.82,.91},dim={.64,.69,.74},green={.4,.85,.54},gray={.85,.86,.89}}
local frame,searchInput,dataInfo,headerInfo,detailHead,detailPrereqs,guideInfo,guideNow,guideNote,navStatus
local dungeonRows,questRows,hideToggle,incompleteToggle,selectedInfo,leftTitle,factionButtons
local dungeonScrollbar,questScrollbar
local chainToggle,contactStart,contactEnd
local nowTitle,nowAction,nowPlace,findNextButton,locationButton,emptyList,relationshipInfo
local versionButton
local titleInfo
local phaseButtons={}
local journeyPhase="all"
local visibleDisplay,visibleSummary,journeyCache={},{},{}
local stateCache={}
local chainFrames={}
local QUEST_ROW_HEIGHT,QUEST_ROW_STRIDE,QUEST_ROW_COUNT=40,47,8
local pendingReveal=false
local detailScroll,detailChild,detailQuest,lastDetailText,detailScrollbar
local planOffset,planBar,planProgress,planGuide=0,nil,nil,nil
local footerProgress,footerPrev,footerNext
local deferredListButton,resumeOneButton,resumeAllButton,resetButton,scopeStartButton,quickStartButton,characterInfo
local planPrev,planNext,planExclusionButton
local showExcluded=false
local dungeonMaxScroll,questMaxScroll=0,0
local modeButtons={}
local planFrame,planRows,planHeading,planCounter=nil,nil,nil,nil
local dungeonOffset,questOffset=0,0
local preserveCategoryScroll=false
local lastBrowseMode,lastBrowseSearch,lastBrowseCategory
local DASH_COLOR={deferred="|cffe6ab63",dependentDeferred="|cffe6ab63",superseded="|cff96d9ed",done="|cff7ccf84",active="|cff7dd1ed",ready="|cfff5da80",turnin="|cff56e28e",low="|cffa7a8aa",blocked="|cffbb7777",locked="|cffdbad62",unknown="|cffabb3b7"}
local function label(parent,text,x,y,w,h,size,color)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h)
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
 if color then f:SetTextColor(color[1],color[2],color[3]) end
 if text then f:SetText(text) end
 return f
end
local function panel(parent,x,y,w,h)
 local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h);f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(C.panel))
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=G.UIButton(parent,text,w,h,fn)
 b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 return b
end
local function row(parent,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent);b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=b:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.12,.15,.19,.54);b.fill=t
 local glow=b:CreateTexture(nil,"HIGHLIGHT");glow:SetAllPoints();glow:SetColorTexture(.35,.40,.43,.22)
 b.marker=b:CreateTexture(nil,"ARTWORK");b.marker:SetPoint("LEFT",b,"LEFT",0,0);b.marker:SetSize(3,h)
 b.marker:SetColorTexture(.31,.36,.39,.8)
 b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 b.text:SetPoint("LEFT",b,"LEFT",9,0);b.text:SetPoint("RIGHT",b,"RIGHT",-4,0)
 b.text:SetJustifyH("LEFT");b.text:SetHeight(h);if b.text.SetMaxLines then b.text:SetMaxLines(1) end
 b:SetScript("OnClick",fn)
 return b
end
-- Four explicit edges: a tinted background or a left stripe alone is not a
-- boundary. Cards are inset inside chain frames, with seven pixels between
-- rows. All edges are reset when recycled rows change their relationship.
local function makeBorder(parent,layer)
 local border={}
 for _,side in ipairs({"top","right","bottom","left"}) do border[side]=parent:CreateTexture(nil,layer or "BORDER");border[side]:Hide() end
 return border
end
local function hideBorder(border) for _,edge in pairs(border) do edge:Hide() end end
local function paintBorder(parent,border,inset,width,color)
 local left,right=inset or 0,inset or 0
 for _,edge in pairs(border) do edge:ClearAllPoints();edge:SetColorTexture(unpack(color));edge:Show() end
 border.top:SetPoint("TOPLEFT",parent,"TOPLEFT",left,0);border.top:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-right,0);border.top:SetHeight(width)
 border.bottom:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",left,0);border.bottom:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-right,0);border.bottom:SetHeight(width)
 border.left:SetPoint("TOPLEFT",parent,"TOPLEFT",left,0);border.left:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",left,0);border.left:SetWidth(width)
 border.right:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-right,0);border.right:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-right,0);border.right:SetWidth(width)
end
local function chainKey(entry)
 if not entry then return nil end
 return (entry.kind=="chain" or entry.kind=="chainEnd") and entry.key or (entry.kind=="quest" and entry.chainKey) or nil
end
local function refreshChainFrames(display,offset)
 for _,group in ipairs(chainFrames) do group:Hide();group.chainKey=nil end
 local i,used=1,0
 while i<=#questRows do
  local key=chainKey(display[offset+i])
  if not key then i=i+1 else
   local first,last=i,i
   while last<#questRows and chainKey(display[offset+last+1])==key do last=last+1 end
   used=used+1;local group=chainFrames[used]
   group.chainKey=key;group.firstRow=first;group.lastRow=last
   group.continuesBefore=chainKey(display[offset+first-1])==key
   group.continuesAfter=chainKey(display[offset+last+1])==key
   group:ClearAllPoints();group:SetPoint("TOPLEFT",frame.mid,"TOPLEFT",8,-95-(first-1)*QUEST_ROW_STRIDE)
   group:SetSize(389,(last-first)*QUEST_ROW_STRIDE+QUEST_ROW_HEIGHT)
   paintBorder(group,group.border,0,2,{.45,.75,.90,1});group:Show()
   i=last+1
  end
 end
end
-- Continuous scrolling by row, instead of jumping by entire pages.
local function clampOffset(value,total,visible)
 return math.max(0,math.min(value,math.max(0,total-visible)))
end
local function setScrollbar(bar,offset,maxOffset,visible)
 if not bar then return end
 bar.updating=true
 local high=math.max(1,maxOffset)
 local changed=bar._range~=high
 if changed then bar:SetMinMaxValues(0,high);bar._range=high end
 local value=math.max(0,math.min(maxOffset,offset))
 if changed or bar._value~=value then bar:SetValue(value);bar._value=value end
 local thumb=bar:GetThumbTexture()
 if thumb and visible then thumb:SetHeight(math.max(18,math.min(bar:GetHeight(),bar:GetHeight()*visible/(maxOffset+visible)))) end
 if maxOffset>0 then bar:Show() else bar:Hide() end
 bar.updating=false
end
local function setDungeonOffset(offset)
 local target=math.max(0,math.min(dungeonMaxScroll,math.floor(offset+.5)))
 if target~=dungeonOffset then dungeonOffset=target;G.UIRefresh() end
end
local function setQuestOffset(offset)
 local target=math.max(0,math.min(questMaxScroll,math.floor(offset+.5)))
 if target~=questOffset then questOffset=target;G.UIRefresh() end
end
local function scrollDungeon(delta) setDungeonOffset(dungeonOffset+delta) end
local function scrollQuest(delta) setQuestOffset(questOffset+delta) end
local function bindWheel(widget,fn)
 widget:EnableMouseWheel(true)
 widget:SetScript("OnMouseWheel",function(_,wheel)
  fn(-wheel*3)
 end)
end
local function makeScrollbar(parent,x,y,height,update)
 local bar=CreateFrame("Slider",nil,parent)
 bar:SetSize(13,height)
 bar:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 bar:SetOrientation("VERTICAL")
 bar:SetMinMaxValues(0,1)
 bar:SetValueStep(1)
 if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(true) end
 local background=bar:CreateTexture(nil,"BACKGROUND")
 background:SetAllPoints();background:SetColorTexture(.05,.065,.085,.95)
 bar:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
 local thumb=bar:GetThumbTexture()
 if thumb then thumb:SetSize(11,35);thumb:SetVertexColor(.84,.62,.28,.95) end
 bar:SetScript("OnValueChanged",function(self,value)
  if self.updating then return end
  self._value=value
  update(math.floor((tonumber(value) or 0)+.5))
 end)
 return bar
end
local function displayText(value)
 return G.KoreanText and G.KoreanText(value) or value
end
local function itemTooltip(self,lines)
 if not GameTooltip then return end
 GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
 for i,v in ipairs(lines) do
  if i==1 then GameTooltip:SetText(displayText(v)) else GameTooltip:AddLine(displayText(v),.84,.85,.89,true) end
 end
 GameTooltip:Show()
end
local function versionHeading()
 return (G.displayName or "포에버 퀘스트 가이드").." · "..tostring(G.version or "버전 확인 필요")
  ..(G.version~=G.uiVersion and " · 파일 버전 다름" or "").."  |  무엇부터 할까요?"
end
local function journey(id)
 if not id then return nil end
 if not journeyCache[id] then journeyCache[id]=G.QuestJourney(id,stateCache) end
 return journeyCache[id]
end
local function journeyFlow(code)
 if code=="active" then return "|cff7ccf84받기 완료|r → |cff7dd1ed목표 수행 중|r → 보고 남음" end
 if code=="turnin" then return "받기 완료 → 목표 완료 → |cff56e28e지금 보고하기|r" end
 if code=="done" then return "|cff7ccf84받기 완료 → 목표 완료 → 보고 완료|r" end
 if code=="ready" then return "|cfff5da80지금 받기|r → 목표 수행 → 완료 보고" end
 if code=="locked" then return "|cffdbad62선행부터 진행|r → 이 퀘스트 받기 → 수행 → 보고" end
 if code=="superseded" then return "후속 진행 확인 · 실제 보고 완료 기록과 구분" end
 if code=="deferred" or code=="dependentDeferred" then return "|cffe6ab63보류 해제|r → 남은 단계 이어서 진행" end
 return "|cffdbad62현재 조건 확인|r → 받기 → 목표 수행 → 완료 보고"
end
-- Filters keep an entire related group visible. A predecessor is never made
-- to look like an unrelated quest by removing only part of its chain.
local function phaseRows(rows,phase,candidateSet)
 if phase=="all" then return rows end
 local result,pendingHeader={},nil
 local function matches(id)
  if not candidateSet[id] then return false end
  local state=G.JourneyState(id,stateCache);return state and state.phase==phase
 end
 local function append(group)
  if pendingHeader then result[#result+1]=pendingHeader;pendingHeader=nil end
  for _,entry in ipairs(group) do result[#result+1]=entry end
 end
 local i=1
 while i<=#rows do
  local entry=rows[i]
  if entry.kind=="header" then pendingHeader=entry;i=i+1
  elseif entry.kind=="chain" then
   local group={entry};local include=false
   for _,id in ipairs(entry.memberIds or {}) do if matches(id) then include=true;break end end
   i=i+1
   while rows[i] and ((rows[i].kind=="quest" and rows[i].chainKey==entry.key) or (rows[i].kind=="chainEnd" and rows[i].key==entry.key)) do
    group[#group+1]=rows[i];i=i+1
   end
   if include then append(group) end
  else
   if entry.kind=="quest" and matches(entry.id) then append({entry}) end
   i=i+1
  end
 end
 return result
end
local function revealQuest(id)
 if not id then return end
 -- Opening a presentation group does not add/check/complete any quest.
 for _,entry in ipairs(visibleDisplay) do
  if entry.kind=="chain" then
   for _,member in ipairs(entry.memberIds or {}) do
    if member==id then G.db.chainCollapsed[entry.key]=false;break end
   end
  end
 end
 pendingReveal=true;G.SetQuest(id)
end
local function showQuestMap()
 local q=G.selection.quest
 local j=journey(q)
 if not j or not j.canGuide then G.Print("진행 조건을 확인한 뒤 위치를 표시하세요.");return end
 local target=j.actionQuestId or q
 local kind=j.actionPhase or j.phase
 if kind~="accept" and kind~="turnin" then kind="objective" end
 local p=not j.inside and G.QuestPoint(target,kind) or nil
 if not p and not j.inside and kind=="objective" then local obj=G.QuestObjectivePoints(target);p=obj[1] and obj[1].point end
 if p then G.OpenPointMap(p) else
  local st={quest=target,kind=kind};G.EnrichStepLocation(st);G.OpenGuideStepMap(st)
 end
end
local function filteredQuests(d)
 local ids={}
 if not d then return ids end
 for _,id in ipairs(d.ids) do
  if G.IsQuestBrowseVisible(id) then ids[#ids+1]=id end
 end
 table.sort(ids,function(a,b)
  local _,as=G.QuestState(a);local _,bs=G.QuestState(b)
  local w={ready=1,active=2,locked=3,low=4,done=5,blocked=6}
  if (w[as] or 9)~=(w[bs] or 9) then return (w[as] or 9)<(w[bs] or 9) end
  return a<b
 end)
 return ids
end
local function prereqString(ids)
 local names={}
 for _,id in ipairs(ids) do
  local abs=math.abs(id)
  local mark=G.IsCompleted(abs) and "|cff75cf86[완료]|r " or
   (G.RoutePrereqEvidence(abs) and "|cff96d9ed[후속 진행 확인]|r " or (G.db.deferredQuests[abs] and "|cffe6ab63[사용자 보류]|r " or (G.IsInLog(abs) and "|cff7dd1ed[진행 중]|r " or "|cffffd06c[미완료]|r ")))
  names[#names+1]=mark..G.GetQuestName(abs)
 end
 return #names>0 and table.concat(names,"\n") or "없음"
end
local function makeQuestCheckbox(r)
 local check=CreateFrame("CheckButton",nil,r,"UICheckButtonTemplate")
 check:SetSize(25,25)
 check:SetPoint("LEFT",r,"LEFT",5,0)
 check:SetScript("OnClick",function(self)
  if r.quest then
   if G.TryQuestChatClick(r.quest) then self:SetChecked(G.db.selectedQuests[r.quest]==true);return end
   G.ToggleQuestChecked(r.quest,self:GetChecked())
  end
 end)
 check:SetScript("OnEnter",function(self)
  itemTooltip(self,{"퀘스트 동선에 포함", "체크한 퀘스트는 하나의 동선으로 실시간 재계산됩니다."})
 end)
 check:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 r.text:ClearAllPoints()
 r.text:SetPoint("LEFT",r,"LEFT",35,0)
 r.text:SetPoint("RIGHT",r,"RIGHT",-4,0)
 r.checkbox=check
 r.statusText=r:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",35,1);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-6,1);r.statusText:SetHeight(13);r.statusText:SetJustifyH("LEFT")
 if r.statusText.SetWordWrap then r.statusText:SetWordWrap(false) end
 r.text:ClearAllPoints();r.text:SetPoint("TOPLEFT",r,"TOPLEFT",35,-1);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-6,-1);r.text:SetHeight(16)
end
local function setDetailOffset(offset)
 if not detailScroll or not detailChild then return end
 local visible=math.max(1,math.floor(detailScroll:GetHeight()))
 local maximum=math.max(0,math.ceil(detailChild:GetHeight()-visible))
 local value=math.max(0,math.min(maximum,math.floor(offset+.5)))
 detailScroll:SetVerticalScroll(value)
 setScrollbar(detailScrollbar,value,maximum,visible)
end
local function detailText(text,q)
 if not detailScroll then detailPrereqs:SetText(text);return end
 if text~=lastDetailText or q~=detailQuest then
  local old=detailScroll:GetVerticalScroll()
  detailPrereqs:SetHeight(0);detailPrereqs:SetText(text)
  local h=math.max(1,math.ceil((detailPrereqs:GetStringHeight() or 0)+12))
  detailPrereqs:SetHeight(h);detailChild:SetHeight(h)
  local max=math.max(0,h-detailScroll:GetHeight())
  setDetailOffset(q~=detailQuest and 0 or math.min(old,max))
  detailQuest=q;lastDetailText=text
 end
end
local function buildUI()
 if frame or not UIParent then return end
 frame=CreateFrame("Frame","ForeverDungeonQuestGuideFrame",UIParent)
 frame:SetSize(1200,844)
 frame:SetPoint("CENTER",UIParent,"CENTER",(G.db.position and G.db.position.x)or 0,(G.db.position and G.db.position.y)or 0)
 frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag("LeftButton")
 frame:SetFrameStrata("DIALOG");frame:SetToplevel(true)
 local base=frame:CreateTexture(nil,"BACKGROUND");base:SetAllPoints();base:SetColorTexture(unpack(C.bg))
 local top=frame:CreateTexture(nil,"BORDER");top:SetPoint("TOPLEFT",0,-1);top:SetPoint("TOPRIGHT",0,-1);top:SetHeight(2);top:SetColorTexture(.85,.63,.26)
 frame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 frame:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then
   local ratio=(self.GetEffectiveScale and UIParent.GetEffectiveScale and self:GetEffectiveScale()/UIParent:GetEffectiveScale()) or 1
   G.db.position={x=x-ux/ratio,y=y-uy/ratio}
  end
 end)
 titleInfo=label(frame,versionHeading(),19,-12,1014,28,"GameFontNormalLarge",C.gold)
 versionButton=button(frame,"버전 확인",1048,-14,94,26,function()
  G.Print(G.VersionReport and G.VersionReport() or ("현재 가이드 버전: "..tostring(G.version or "미확인").." · 화면 버전: "..tostring(G.uiVersion or "미확인")))
 end)
 versionButton:SetScript("OnEnter",function(self)itemTooltip(self,{"현재 불러온 버전 확인","게임이 실제로 불러온 애드온과 화면 파일의 버전을 채팅창에 표시합니다.","이전 화면이 계속 보일 때 설치된 파일과 불러온 파일의 차이를 확인하세요."})end)
 versionButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 characterInfo=label(frame,"",20,-44,690,18,"GameFontHighlightSmall",C.dim)
 dataInfo=label(frame,"",760,-42,409,19,"GameFontHighlightSmall",C.cyan);dataInfo:SetJustifyH("RIGHT")
 button(frame,"×",1155,-12,28,28,function()G.CloseContactPreview();frame:Hide()end)
 frame:HookScript("OnHide",function()G.CloseContactPreview()end)
 label(frame,"찾기",20,-80,45,22,"GameFontNormal",C.gold)
 searchInput=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
 searchInput:SetSize(337,25);searchInput:SetPoint("TOPLEFT",frame,"TOPLEFT",65,-77);searchInput:SetAutoFocus(false);searchInput:SetText("")
 local placeholder=label(searchInput,"퀘스트 이름 · 번호 · 지역",7,0,316,25,"GameFontDisableSmall",C.dim)
 button(frame,"×",410,-77,30,25,function()searchInput:SetText("");searchInput:ClearFocus()end)
 searchInput:SetScript("OnEditFocusGained",function()placeholder:Hide()end)
 searchInput:SetScript("OnEditFocusLost",function(self)if self:GetText()=="" then placeholder:Show() end end)
 searchInput:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnTextChanged",function(self)
  if self:GetText()~="" or (self.HasFocus and self:HasFocus()) then placeholder:Hide() else placeholder:Show() end
  if not preserveCategoryScroll then dungeonOffset=0 end
  questOffset=0
  if G.UIRefresh then G.UIRefresh() end
 end)
 local tabs={{"active","현재 퀘스트"},{"all","전체 검색"},{"zone","지역별"},{"dungeon","던전별"},{"turnin","보고 대기"},{"selected","체크 목록"}}
 for i,tab in ipairs(tabs) do modeButtons[tab[1]]=button(frame,tab[2],458+(i-1)*122,-77,116,27,function()
  questOffset=0;dungeonOffset=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.SetViewMode(tab[1])
 end) end
 local now=panel(frame,12,-116,1176,94)
 now:EnableMouse(true)
 now:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  if j then itemTooltip(self,{j.title,j.location,j.detail,j.nextText}) end
 end)
 now:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 local stripe=now:CreateTexture(nil,"ARTWORK");stripe:SetPoint("TOPLEFT",0,0);stripe:SetPoint("BOTTOMLEFT",0,0);stripe:SetWidth(4);stripe:SetColorTexture(.43,.77,.89,1)
 nowTitle=label(now,"지금 할 일",15,-6,724,22,"GameFontNormal",C.gold)
 nowAction=label(now,"",15,-30,724,25,"GameFontHighlight",C.gray)
 nowPlace=label(now,"",15,-57,724,31,"GameFontHighlightSmall",C.cyan)
 if nowAction.SetMaxLines then nowAction:SetMaxLines(1);nowTitle:SetMaxLines(1);nowPlace:SetMaxLines(2) end
 quickStartButton=button(now,"이 퀘스트 안내 시작",752,-10,204,32,function()
  local q=G.selection.quest;local j=journey(q)
  if j and j.canGuide then G.StartQuickGuide(q) end
 end)
 G.UIButtonState(quickStartButton,true)
 quickStartButton:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  itemTooltip(self,{"선택한 퀘스트를 따라 진행",j and j.detail or "목록에서 퀘스트를 고르세요.","필요한 선행부터 수락·수행·보고를 안내합니다.","기존 통합 동선은 보관하며 이동 안내창에서 복귀할 수 있습니다."})
 end)
 quickStartButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 locationButton=button(now,"지금 갈 곳 지도",752,-51,204,30,showQuestMap)
 locationButton:SetScript("OnEnter",function(self)
  local j=journey(G.selection.quest)
  itemTooltip(self,{"지금 할 행동의 위치",j and j.location or "퀘스트를 선택하세요.","선행이 필요하면 선행 퀘스트 위치를 표시합니다.","던전 내부 위치가 없으면 입구 접근용 지도와 내부 설명을 구분합니다."})
 end)
 locationButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 findNextButton=button(now,"우선 할 일 선택",967,-10,197,32,function()
  if visibleSummary.nextQuestId then revealQuest(visibleSummary.nextQuestId) end
 end)
 findNextButton:SetScript("OnEnter",function(self)itemTooltip(self,{"현재 목록에서 할 일 찾기","보고 대기 → 수행 중 → 받을 퀘스트 → 가능한 선행 순으로 고릅니다.","퀘스트를 완료 처리하거나 자동 수락하지 않습니다.","경험치나 이동 시간의 최적 순위를 뜻하지 않습니다."})end)
 findNextButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 label(now,"하나 고르기 → 안내 시작\n여러 개는 체크 후 통합 안내",974,-50,190,34,"GameFontHighlightSmall",C.dim)
 local left=panel(frame,12,-220,202,500)
 local mid=panel(frame,224,-220,432,500)
 local right=panel(frame,666,-220,522,500)
 leftTitle=label(left,"1  장소 고르기",10,-7,183,24,"GameFontNormal",C.gold)
 factionButtons={}
 local factionItems={{"auto","자동"},{"Alliance","얼라"},{"Horde","호드"},{"all","전체"}}
 for i,entry in ipairs(factionItems) do
  local x=({8,75,115,155})[i];local width=({64,37,37,39})[i]
  factionButtons[entry[1]]=button(left,entry[2],x,-36,width,23,function()questOffset=0;dungeonOffset=0;G.SetFactionFilter(entry[1])end)
  factionButtons[entry[1]]:SetScript("OnEnter",function(self)itemTooltip(self,{"표시 진영: "..entry[2],"자동은 현재 캐릭터의 실제 진영입니다.","다른 진영 보기는 검색용입니다. 수행 불가 퀘스트는 안내에 추가하지 않습니다."})end)
  factionButtons[entry[1]]:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 hideToggle=button(left,"제한 숨김",8,-65,90,23,function()G.db.hideUnavailable=not G.db.hideUnavailable;G.UIRefresh()end)
 incompleteToggle=button(left,"완료 제외",102,-65,92,23,function()G.db.onlyIncomplete=not G.db.onlyIncomplete;G.UIRefresh()end)
 dungeonRows={};bindWheel(left,scrollDungeon)
 for i=1,12 do
  local r=row(left,8,-98-(i-1)*30,165,28,function(self)
   if self.dungeon or self.zone then
    questOffset=0;local dungeon,zone=self.dungeon,self.zone;preserveCategoryScroll=true
    if searchInput:GetText()~="" then searchInput:SetText("") end
    if dungeon then G.SetDungeon(dungeon) else G.SetZone(zone) end
    preserveCategoryScroll=false
   end
  end)
  bindWheel(r,scrollDungeon);dungeonRows[i]=r
 end
 dungeonScrollbar=makeScrollbar(left,181,-98,358,setDungeonOffset);bindWheel(dungeonScrollbar,scrollDungeon)
 left.pagination=label(left,"",10,-469,182,20,"GameFontHighlightSmall",C.dim)
 label(mid,"2  할 퀘스트 고르기",12,-7,240,25,"GameFontNormal",C.gold)
 chainToggle=button(mid,"연계 묶기 켬",298,-9,121,23,function()G.db.groupChains=not G.db.groupChains;questOffset=0;G.UIRefresh()end)
 chainToggle:SetScript("OnEnter",function(self)itemTooltip(self,{"연계 묶기","실제 선행 관계로 연결된 퀘스트만 하나의 테두리 안에 표시합니다.","연계 끝 표시 뒤부터는 별개의 퀘스트입니다.","목록 번호는 분기가 있는 경우 수행 순서를 뜻하지 않습니다."})end)
 chainToggle:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 local phases={{"all","모두"},{"accept","받기"},{"objective","수행"},{"turnin","보고"},{"blocked","선행·조건"}}
 for i,entry in ipairs(phases) do
  phaseButtons[entry[1]]=button(mid,entry[2],8+(i-1)*83,-38,80,24,function()journeyPhase=entry[1];questOffset=0;G.selection.quest=nil;G.db.selectedQuest=nil;G.UIRefresh()end)
  phaseButtons[entry[1]]:SetScript("OnEnter",function(self)itemTooltip(self,{entry[2].." 단계 보기","해당 상태가 있는 연계는 앞뒤 관계를 함께 표시합니다.","필터로 퀘스트가 사라져도 체크와 진행 기록은 그대로입니다."})end)
  phaseButtons[entry[1]]:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 headerInfo=label(mid,"",12,-66,404,23,"GameFontHighlightSmall",C.dim)
 questRows={};bindWheel(mid,scrollQuest)
 for i=1,QUEST_ROW_COUNT do
  local r=row(mid,8,-95-(i-1)*QUEST_ROW_STRIDE,389,QUEST_ROW_HEIGHT,function(self)
   if self.quest then if not G.TryQuestChatClick(self.quest) then G.SetQuest(self.quest) end
   elseif self.chainKey then G.ToggleChainGroup(self.chainKey);G.UIRefresh() end
  end)
  makeQuestCheckbox(r)
  r.cardBorder=makeBorder(r,"BORDER")
  r.rail=r:CreateTexture(nil,"ARTWORK");r.rail:SetPoint("TOPLEFT",r,"TOPLEFT",9,0);r.rail:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",9,0);r.rail:SetWidth(2);r.rail:SetColorTexture(.28,.53,.67,.95);r.rail:Hide()
  r.edge=r:CreateTexture(nil,"ARTWORK");r.edge:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",9,0);r.edge:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-1,0);r.edge:SetHeight(2);r.edge:SetColorTexture(.28,.53,.67,.95);r.edge:Hide()
  bindWheel(r,scrollQuest);bindWheel(r.checkbox,scrollQuest);questRows[i]=r
 end
 for i=1,QUEST_ROW_COUNT do
  local group=CreateFrame("Frame",nil,mid);group:EnableMouse(false);group:SetFrameLevel(questRows[1]:GetFrameLevel()+1)
  group.border=makeBorder(group,"ARTWORK");group:Hide();chainFrames[i]=group
 end
 questScrollbar=makeScrollbar(mid,409,-95,376,setQuestOffset);bindWheel(questScrollbar,scrollQuest)
 mid.pagination=label(mid,"",12,-476,405,19,"GameFontHighlightSmall",C.dim)
 emptyList=label(mid,"",22,-141,374,154,"GameFontHighlight",C.dim);emptyList:SetJustifyV("TOP")
 label(right,"3  진행 방법 확인",12,-7,498,25,"GameFontNormal",C.gold)
 detailHead=label(right,"",12,-33,496,45,"GameFontHighlight",C.cyan)
 local titleClick=CreateFrame("Button",nil,right);titleClick:SetPoint("TOPLEFT",right,"TOPLEFT",12,-33);titleClick:SetSize(496,45)
 titleClick:SetScript("OnClick",function()G.TryQuestChatClick(G.selection.quest)end)
 titleClick:SetScript("OnEnter",function(self)if G.selection.quest then itemTooltip(self,{G.GetQuestName(G.selection.quest),"채팅창이 열린 상태에서 시프트 키를 누르고 클릭: 퀘스트 링크"}) end end)
 titleClick:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 contactStart=button(right,"받는 사람 / 물건",10,-84,248,26,function()G.ShowContactPreview(G.selection.quest,"accept",frame)end)
 contactEnd=button(right,"보고할 사람 / 물건",264,-84,248,26,function()G.ShowContactPreview(G.selection.quest,"turnin",frame)end)
 for _,v in ipairs({{contactStart,"accept"},{contactEnd,"turnin"}}) do
  local b,stage=v[1],v[2]
  b:SetScript("OnEnter",function(self)
   local q=G.selection.quest;local c=q and G.ContactPreview(q,stage)
   itemTooltip(self,{stage=="accept" and "퀘스트 받는 위치" or "퀘스트 보고 위치",c and c.name or "퀘스트를 선택하세요.",c and c.place or "","클릭하면 작은 지도를 엽니다."})
  end)
  b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 relationshipInfo=label(right,"",12,-116,495,34,"GameFontHighlightSmall",C.gold)
 detailScroll=CreateFrame("ScrollFrame",nil,right);detailScroll:SetPoint("TOPLEFT",right,"TOPLEFT",13,-158);detailScroll:SetSize(479,178)
 detailChild=CreateFrame("Frame",nil,detailScroll);detailChild:SetSize(479,1);detailScroll:SetScrollChild(detailChild)
 detailPrereqs=label(detailChild,"",0,0,473,1,"GameFontHighlightSmall",C.gray);detailPrereqs:SetJustifyV("TOP")
 if detailPrereqs.SetSpacing then detailPrereqs:SetSpacing(4) end
 detailScroll:EnableMouseWheel(true);detailScroll:SetScript("OnMouseWheel",function(self,delta)setDetailOffset(self:GetVerticalScroll()-delta*38)end)
 detailScrollbar=makeScrollbar(right,500,-158,178,setDetailOffset)
 detailScrollbar:EnableMouseWheel(true);detailScrollbar:SetScript("OnMouseWheel",function(_,delta)setDetailOffset(detailScroll:GetVerticalScroll()-delta*38)end)
 label(right,"아래로 스크롤: 전체 순서 · 조건 · 상세 목표",13,-337,496,16,"GameFontDisableSmall",C.dim)
 local start=button(right,"체크한 퀘스트 통합 안내",10,-360,248,30,function()G.StartSelectedGuide()end)
 start:SetScript("OnEnter",function(self)itemTooltip(self,{"체크한 퀘스트 함께 진행","필수 선행부터 수락·수행·보고 방문을 구성합니다.","현재 통합 동선이 새 동선으로 바뀝니다."})end)
 start:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 button(right,"체크한 퀘스트 보고 안내",264,-360,248,30,function()G.StartTurninGuide()end)
 scopeStartButton=button(right,"현재 목록 전체 안내",10,-398,502,28,function()
  local mode=G.selection.mode
  if mode=="active" then G.StartActiveGuide(false)
  elseif mode=="turnin" then G.StartActiveGuide(true)
  elseif mode=="dungeon" and G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil)
  else G.Print("현재 퀘스트·보고 대기·던전별 탭에서 사용하세요.") end
 end)
 scopeStartButton:SetScript("OnEnter",function(self)itemTooltip(self,{"현재 탭의 전체 범위","현재 퀘스트: 수락 중인 모든 퀘스트 / 보고 대기: 보고 가능한 모든 퀘스트","던전별: 선택 던전의 진행 가능한 퀘스트와 필요한 선행","검색·단계 필터·체크와 관계없이 탭 전체를 구성합니다."})end)
 scopeStartButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 selectedInfo=label(right,"",12,-432,196,24,"GameFontHighlightSmall",C.cyan)
 button(right,"체크만 해제",237,-434,126,24,function()G.ClearCheckedQuests()end)
 resetButton=button(right,"동선 초기화",370,-434,142,24,function()G.ResetRoutePlanning();questOffset=0;searchInput:SetText("");G.UIRefresh()end)
 resetButton:SetScript("OnEnter",function(self)itemTooltip(self,{"동선 초기화","체크·보류·이동 안내를 초기화합니다.","게임의 수락·완료 기록과 화면 설정은 유지됩니다."})end)
 resetButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 deferredListButton=button(right,"보류 목록 0",10,-466,162,24,function()questOffset=0;searchInput:SetText("");G.SetViewMode("deferred")end)
 resumeOneButton=button(right,"선택 보류 해제",180,-466,162,24,function()G.ResumeSelectedBlocker(G.selection.quest)end)
 resumeOneButton:SetScript("OnEnter",function(self)local blocker=G.DeferredBlocker(G.selection.quest);itemTooltip(self,{"선택 보류 해제",blocker and ("대상: "..G.GetQuestName(blocker)) or "보류된 퀘스트나 후속을 선택하세요."})end)
 resumeOneButton:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 resumeAllButton=button(right,"전체 보류 해제",350,-466,162,24,function()G.ResumeDeferredQuests("all")end)
 local foot=panel(frame,12,-730,1176,102)
 guideInfo=label(foot,"가이드 대기 중",11,-6,656,21,"GameFontNormal",C.gold)
 guideNow=label(foot,"",11,-34,1150,22,"GameFontHighlightSmall",C.gray)
 navStatus=label(foot,"",11,-57,1150,19,"GameFontHighlightSmall",C.cyan)
 guideNote=label(foot,"",11,-78,1150,19,"GameFontHighlightSmall",C.dim)
 button(foot,"이동 안내",710,-6,81,24,function()G.ToggleHUD()end)
 button(foot,"전체 순서",796,-6,75,24,function()G.TogglePlanWindow()end)
 footerPrev=button(foot,"이전",876,-6,75,24,function()G.NextGuide(-1,false)end)
 footerNext=button(foot,"다음 확인",956,-6,112,24,function()if G.GuideViewingHistory() then G.ReturnToActiveGuide() else G.NextGuide(1,true) end end)
 G.UIButtonState(footerNext,true)
 button(foot,"중지",1073,-6,89,24,function()G.StopGuide()end)
 footerProgress=G.UIProgress(foot);footerProgress:SetPoint("TOPLEFT",foot,"TOPLEFT",11,-30);footerProgress:SetPoint("TOPRIGHT",foot,"TOPRIGHT",-12,-30);footerProgress:SetHeight(3)
 frame.left=left;frame.mid=mid
 G.UIJourneyWidgets={titleInfo=titleInfo,versionButton=versionButton,chainFrames=chainFrames,rowHeight=QUEST_ROW_HEIGHT,rowStride=QUEST_ROW_STRIDE,scopeStartButton=scopeStartButton,contactStart=contactStart,contactEnd=contactEnd,frame=frame,questRows=questRows,questScrollbar=questScrollbar,phaseButtons=phaseButtons,nowTitle=nowTitle,nowAction=nowAction,nowPlace=nowPlace,quickStartButton=quickStartButton,findNextButton=findNextButton,locationButton=locationButton,detailHead=detailHead,detailText=detailPrereqs,detailScroll=detailScroll,relationshipInfo=relationshipInfo,emptyList=emptyList,search=searchInput}
 G.UIFit(frame);frame:Hide()
end
local function buildPlanUI()
 if planFrame or not UIParent then return end
 planFrame=CreateFrame("Frame","ForeverDungeonQuestGuidePlanFrame",UIParent)
 planFrame:SetSize(600,685);planFrame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 planFrame:SetClampedToScreen(true);planFrame:SetFrameStrata("FULLSCREEN_DIALOG")
 planFrame:SetMovable(true);planFrame:EnableMouse(true);planFrame:RegisterForDrag("LeftButton")
 planFrame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 planFrame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 local back=planFrame:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(unpack(C.bg))
 planHeading=label(planFrame,"전체 방문 동선",16,-10,480,31,"GameFontNormalLarge",C.gold)
 button(planFrame,"×",563,-11,26,27,function()planFrame:Hide()end)
 label(planFrame,"완료/예정 단계 열람 · 실제 경로 유지 | 휠 스크롤",16,-42,410,18,"GameFontHighlightSmall",C.dim)
 planProgress=G.UIProgress(planFrame);planProgress:SetPoint("TOPLEFT",planFrame,"TOPLEFT",14,-64);planProgress:SetPoint("TOPRIGHT",planFrame,"TOPRIGHT",-14,-64);planProgress:SetHeight(4)
 local function move(delta)planOffset=math.max(0,planOffset+delta);G.PlanRefresh()end
 bindWheel(planFrame,move)
 planRows={}
 for i=1,17 do
  planRows[i]=row(planFrame,11,-81-(i-1)*31,554,29,function(self)
   local gd=G.db and G.db.guide
   local id=self.exclusionQuest or (gd and gd.steps and self.guideIndex and gd.steps[self.guideIndex] and gd.steps[self.guideIndex].quest)
   if id and G.TryQuestChatClick(id) then return end
   if self.exclusionQuest then
    local id=self.exclusionQuest;planFrame:Hide();G.ShowUI(true);G.SetQuest(id)
   elseif gd and gd.steps and self.guideIndex then
    G.SelectGuideStep(self.guideIndex)
   end
  end)
  bindWheel(planRows[i],move)
 end
 planBar=makeScrollbar(planFrame,574,-81,525,function(offset)planOffset=offset;G.PlanRefresh()end)
 bindWheel(planBar,move)
 planCounter=label(planFrame,"",16,-616,282,26,"GameFontHighlightSmall",C.dim)
 planPrev=button(planFrame,"◀ 이전",301,-614,79,26,function()move(-#planRows)end)
 planNext=button(planFrame,"다음 ▶",385,-614,79,26,function()move(#planRows)end)
 planExclusionButton=button(planFrame,"제외 0",436,-42,147,20,function()
  showExcluded=not showExcluded;planOffset=0;G.PlanRefresh()
 end)
 local jump=button(planFrame,"현재 단계",469,-614,117,26,function()
  showExcluded=false
  local gd=G.db and G.db.guide
  if gd and gd.steps and #gd.steps>0 then
   G.ReturnToActiveGuide();planOffset=math.max(0,(gd.index or 1)-3)
  end
  G.PlanRefresh()
 end)
 G.UIButtonState(jump,true)
 label(planFrame,"지도 좌표는 참고용 · 실제 이동은 오른쪽 여정 또는 장소 설명",16,-645,566,20,"GameFontHighlightSmall",C.dim)
 G.UIFit(planFrame);planFrame:Hide()
end
function G.PlanRefresh()
 if not planFrame or not planFrame:IsShown() then return end
 local gd=G.db and G.db.guide
 local excluded=gd and gd.excluded or {}
 if planGuide~=gd then showExcluded=gd and gd.halted and #excluded>0 or false;planOffset=0 end
 if showExcluded and #excluded==0 and gd and gd.steps and #gd.steps>0 and not gd.halted then showExcluded=false;planOffset=0 end
 planExclusionButton:SetText(showExcluded and "동선 보기" or ("제외/보류 "..#excluded))
 if showExcluded then
  planGuide=gd;planHeading:SetText("제외/보류 퀘스트 · "..#excluded.."개")
  planOffset=clampOffset(planOffset,#excluded,#planRows)
  local maximum=math.max(0,#excluded-#planRows);setScrollbar(planBar,planOffset,maximum,#planRows)
  planProgress:SetProgress(0,0);planCounter:SetText("제외/보류 "..#excluded.."개 · 툴팁 상세")
  if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
  if planOffset<maximum then planNext:Enable() else planNext:Disable() end
  for i,r in ipairs(planRows) do
   local item=excluded[planOffset+i];r.guideIndex=nil;r.exclusionQuest=item and item.id or nil
   if item then
    r.text:SetText(displayText("|cffffc675[제외]|r "..item.name.." · "..item.reason))
    r.fill:SetColorTexture(.14,.12,.10,.95);r.marker:SetColorTexture(.78,.54,.21,1)
    r:SetScript("OnEnter",function(self)itemTooltip(self,{item.name.." (#"..item.id..")",item.reason,"클릭: 퀘스트 상세 및 보류 해제 · 실제 완료/체크 유지"})end);r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end);r:Show()
   else r:Hide() end
  end
  return
 end
 if not gd or not gd.steps or #gd.steps==0 then
  planGuide=gd
  planHeading:SetText(gd and gd.halted and "진행 가능한 동선 없음" or "진행 중인 동선 없음")
  for _,r in ipairs(planRows)do r.exclusionQuest=nil;r.guideIndex=nil;r:Hide()end
  planCounter:SetText("0 / 0");planProgress:SetProgress(0,0);setScrollbar(planBar,0,0);planPrev:Disable();planNext:Disable()
  return
 end
 local dungeon=G.GetDungeon(gd.dungeon)
 planHeading:SetText(displayText(G.RouteScopeLabel(gd)))
 local done,total=G.GuideProgress();planProgress:SetProgress(done,total)
 if planGuide~=gd then planGuide=gd;planOffset=math.max(0,(gd.index or 1)-3) end
 planOffset=clampOffset(planOffset,#gd.steps,#planRows)
 local maxOffset=math.max(0,#gd.steps-#planRows);setScrollbar(planBar,planOffset,maxOffset,#planRows)
 if planOffset>0 then planPrev:Enable() else planPrev:Disable() end
 if planOffset<maxOffset then planNext:Enable() else planNext:Disable() end
 for i,r in ipairs(planRows) do
  r.exclusionQuest=nil
  local ix=planOffset+i
  local st=gd.steps[ix]
  if st then
   r.guideIndex=ix
   local active=ix==(gd.index or 1);local viewed=G.GuideViewingHistory() and ix==G.GuideViewIndex()
   local prefix=active and ("|cff83d4fa"..ix..". 진행|r") or (tostring(ix)..".")
   local status=G.GuideViewStatus(st,ix)
   if status and ix<(gd.index or 1) then prefix=(G.StepIsDone(st,ix) and "|cff87dc98" or "|cff9daab6")..tostring(ix)..". 기록|r" end
   if viewed then prefix="|cffc4b1ff열람|r "..prefix end
   r.fill:SetColorTexture(active and .17 or viewed and .15 or .10,active and .29 or viewed and .20 or .13,active and .36 or viewed and .31 or .16,.95)
   local texts={accept="|cff74d7ff[수락]|r",turnin="|cff7cd18d[보고]|r",objective="|cffffd178[수행]|r",entrance="|cffffa36e[입구]|r",inside="|cffacaad4[던전]|r"}
   r.text:SetText(displayText(prefix.." "..(texts[st.kind] or "[단계]").." "..(st.questName or st.title or "")..(st.point and " |cff72ce98[지도]|r" or st.indoor and " |cffdaaaff[던전 내부]|r" or st.landmark and " |cff96d9ed[장소 안내]|r" or st.regionHint and " |cff96d9ed[지역 안내]|r" or (G.walkthroughRecords and G.walkthroughRecords[tonumber(st.quest)]) and " |cff96d9ed[행동 안내]|r" or " |cff9ba4aa[좌표 미확인]|r")))
   r.marker:SetColorTexture(active and .43 or viewed and .68 or .22,active and .77 or viewed and .56 or .31,active and .94 or viewed and .93 or .39,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{st.title,st.note or "","클릭하여 기록/예정 단계 열람 · 진행 위치 유지"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
   r:Show()
  else r.guideIndex=nil;r:Hide() end
 end
 planCounter:SetText("진행 "..done.."/"..total.." · "..(planOffset+1).."–"..math.min(total,planOffset+#planRows).." 표시")
end
function G.TogglePlanWindow()
 buildPlanUI()
 if not planFrame then return end
 if planFrame:IsShown() then planFrame:Hide() else G.UIFit(planFrame);planGuide=nil;planFrame:Show();G.PlanRefresh() end
end
function G.ShowRouteExclusions()
 buildPlanUI();if not planFrame then return end
 G.UIFit(planFrame);planGuide=G.db and G.db.guide;showExcluded=true;planOffset=0;planFrame:Show();G.PlanRefresh()
end
function G.IsUIShown() return frame and frame:IsShown() or false end
function G.UIRefresh()
 if not frame or not G.db then return end
 if titleInfo then titleInfo:SetText(versionHeading()) end
 journeyCache={};stateCache={}
 local mode=G.selection.mode or "all"
 if characterInfo then
  local n=G.SafeCall(UnitName,"player") or "현재 캐릭터"
  local f=G.player.faction=="Alliance" and "얼라이언스" or G.player.faction=="Horde" and "호드" or "진영 확인 중"
  local active,ready=0,0;for id in pairs(G.activeQuests or {}) do active=active+1;if G.IsReadyToTurnIn(id) then ready=ready+1 end end
  characterInfo:SetText(n.." · "..(G.player.level or 1).."레벨 · "..f.."   |   진행 "..active.." · 보고 "..ready.." · 캐릭터별 저장")
 end
 if scopeStartButton then
  local label=mode=="active" and "수락한 퀘스트 모두 안내" or mode=="turnin" and "보고 대기 모두 안내" or mode=="dungeon" and "선택 던전 전체 안내" or "현재 퀘스트 / 던전 탭에서 전체 안내"
  scopeStartButton:SetText(label)
  if mode=="active" or mode=="turnin" or mode=="dungeon" then scopeStartButton:Enable() else scopeStartButton:Disable() end
 end
 if quickStartButton then if G.selection.quest then quickStartButton:Enable() else quickStartButton:Disable() end end
 local search=searchInput and searchInput:GetText() or ""
 local category=mode=="zone" and G.selection.zone or mode=="dungeon" and G.selection.dungeon or nil
 if lastBrowseCategory~=category then questOffset=0;journeyPhase="all";lastBrowseCategory=category end
 if lastBrowseMode~=mode or lastBrowseSearch~=search then
  questOffset=0;journeyPhase="all"
  if not preserveCategoryScroll and lastBrowseMode and (lastBrowseMode=="dungeon")~=(mode=="dungeon") then dungeonOffset=0 end
  lastBrowseMode,lastBrowseSearch=mode,search
 end
 if dataInfo then
  dataInfo:SetText(G.Ready() and ("퀘스트 자료 연결 · "..G.QuestIndexStatus()) or "퀘스트 자료 미연결")
 end
 for key,b in pairs(modeButtons) do
  b:SetText(({all="전체 검색",active="현재 퀘스트",turnin="보고 대기",zone="지역별",dungeon="던전별",selected="체크 목록"})[key]);G.UIButtonState(b,key==mode)
 end
 -- The left category list is separate: region groups everywhere except
 -- dungeon mode. Clicking a category opens that region/dungeon tab.
 local dungeonMode=mode=="dungeon"
 leftTitle:SetText(dungeonMode and "1  던전 고르기" or "1  지역 고르기")
 local choices
 if dungeonMode then
  choices=G.SearchDungeons(search)
 else
  choices=G.SearchQuestZones(search)
  if #choices==0 and search~="" then choices=G.SearchQuestZones("") end
 end
 dungeonOffset=clampOffset(dungeonOffset,#choices,#dungeonRows)
 dungeonMaxScroll=math.max(0,#choices-#dungeonRows)
 setScrollbar(dungeonScrollbar,dungeonOffset,dungeonMaxScroll,#dungeonRows)
 for i,r in ipairs(dungeonRows) do
  local entry=choices[dungeonOffset+i]
  if entry then
   r:Show()
   r.dungeon=dungeonMode and entry.dungeon.id or nil
   r.zone=(not dungeonMode) and entry.key or nil
   local id=dungeonMode and entry.dungeon.id or entry.key
   local selected=dungeonMode and G.selection.dungeon==id or G.selection.zone==id
   local name=dungeonMode and entry.dungeon.name or ((entry.kind=="raid" and "[공격대] " or entry.kind=="dungeon" and "[던전] " or entry.kind=="pvp" and "[전장] " or "")..entry.name)
   local count=dungeonMode and #filteredQuests(entry.dungeon) or G.ZoneFactionCount(entry)
   r.text:SetText((selected and "|cffffd77b▶ |r" or "")..name.." |cff899aa3("..count..")|r")
   r.marker:SetColorTexture(selected and .43 or .25,selected and .77 or .39,selected and .94 or .45,1)
   r.fill:SetColorTexture(selected and .17 or .11,selected and .29 or .14,selected and .36 or .17,.92)
   if dungeonMode then
    local d=entry.dungeon
    r:SetScript("OnEnter",function(self)itemTooltip(self,{d.name,"레벨 "..(d.level or "미확인"),d.warning or ("관련 퀘스트 "..#d.ids.."건")})end)
   else
    local z=entry
    r:SetScript("OnEnter",function(self)itemTooltip(self,{z.name,(z.kind=="raid" and "공격대 퀘스트" or z.kind=="dungeon" and "던전 퀘스트" or "지역별 퀘스트 자료 분류"),z.count.."개 등록 (검색 인덱스 누적)","클릭하면 미수락·완료를 포함한 지역 퀘스트를 확인합니다."})end)
   end
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.dungeon=nil;r.zone=nil;r:Hide() end
 end
 frame.left.pagination:SetText(#choices==0 and "분류 없음" or ((dungeonOffset+1).."–"..math.min(#choices,dungeonOffset+#dungeonRows).." / "..#choices.." 분류"))
 local chosenFaction=G.db.factionFilter or "auto"
 for key,b in pairs(factionButtons or {}) do
  b:SetText(key=="auto" and ("자동"..(G.player.faction=="Alliance" and "(얼)" or G.player.faction=="Horde" and "(호)" or "(?)")) or
    ({Alliance="얼라",Horde="호드",all="전체"})[key])
  G.UIButtonState(b,key==chosenFaction)
 end
 hideToggle:SetText(G.db.hideUnavailable and "제한 숨김 켬" or "제한 숨김 끔");G.UIButtonState(hideToggle,G.db.hideUnavailable)
 incompleteToggle:SetText(G.db.onlyIncomplete and "완료 제외 켬" or "완료 제외 끔");G.UIButtonState(incompleteToggle,G.db.onlyIncomplete)
 local ids,total,building
 local d=G.GetDungeon(G.selection.dungeon)
 if mode=="dungeon" then
  ids=filteredQuests(d);total=#ids;building=false
  if search~="" then
   local match=G.Clean(search)
   local filtered={}
   for _,id in ipairs(ids) do
    if tostring(id)==match or string.find(G.Clean(G.GetQuestName(id)),match,1,true) or string.find(G.Clean((G.DBRawGet or G.DBGet)(QuestDB,id,"name")),match,1,true) or
       (d and (string.find(G.Clean(d.name),match,1,true) or string.find(G.Clean(d.aliases),match,1,true))) then
     filtered[#filtered+1]=id
    end
   end
   ids=filtered;total=#ids
  end
 else
  ids,total,building=G.SearchQuestIds(mode,search)
 end
 local grouped=mode=="active" or mode=="turnin" or mode=="selected" or mode=="deferred" or (mode=="all" and search=="")
 local display=G.QuestListRows(ids,grouped)
 local baseSummary=G.JourneySummary(ids,journeyCache,stateCache)
 local candidateSet,actionCandidates={},{}
 for _,id in ipairs(ids) do
  candidateSet[id]=true
  if journeyPhase=="all" or G.JourneyState(id,stateCache).phase==journeyPhase then actionCandidates[#actionCandidates+1]=id end
 end
 if chainToggle then chainToggle:SetText(G.db.groupChains~=false and "연계 묶기 켬" or "연계 묶기 끔");G.UIButtonState(chainToggle,G.db.groupChains~=false) end
 if G.QuestChainRows then display=G.QuestChainRows(display,mode..":"..tostring(category or ""),(mode=="dungeon" or mode=="zone") and search=="") end
 display=phaseRows(display,journeyPhase,candidateSet);visibleDisplay=display
 local shownIds,shownSet,chainByQuest={},{},{}
 for _,entry in ipairs(display) do
  local members=entry.kind=="chain" and entry.memberIds or (entry.kind=="quest" and {entry.id}) or {}
  for _,id in ipairs(members) do
   if not shownSet[id] then shownSet[id]=true;shownIds[#shownIds+1]=id end
   if entry.kind=="chain" then chainByQuest[id]=entry end
  end
 end
 visibleSummary=G.JourneySummary(actionCandidates,journeyCache,stateCache)
 if not G.selection.quest and #shownIds>0 then
  G.selection.quest=visibleSummary.nextQuestId or actionCandidates[1] or shownIds[1];G.db.selectedQuest=G.selection.quest;pendingReveal=true
 end
 if pendingReveal then
  local wanted=G.selection.quest
  for index,entry in ipairs(display) do
   local found=entry.kind=="quest" and entry.id==wanted
   if entry.kind=="chain" and entry.collapsed then for _,member in ipairs(entry.memberIds or {}) do if member==wanted then found=true;break end end end
   if found then
    if index<=questOffset or index>questOffset+#questRows then questOffset=index-2 end
    break
   end
  end
  pendingReveal=false
 end
 questOffset=clampOffset(questOffset,#display,#questRows);questMaxScroll=math.max(0,#display-#questRows)
 setScrollbar(questScrollbar,questOffset,questMaxScroll,#questRows)
 frame.mid.pagination:SetText(#display==0 and "표시할 항목 없음" or ((questOffset+1).."–"..math.min(#display,questOffset+#questRows).." / "..#display.."행 · 연계의 앞뒤 관계 함께 표시"))
 local counts=baseSummary.counts
 for key,b in pairs(phaseButtons) do
  local names={all="모두",accept="받기",objective="수행",turnin="보고",blocked="선행·조건"}
  b:SetText(names[key].." "..(key=="all" and #ids or counts[key] or 0));G.UIButtonState(b,key==journeyPhase)
 end
 local suffix=building and " · 목록 준비 중" or ""
 local scopeName=mode=="dungeon" and (d and d.name or "던전 선택") or mode=="zone" and "선택 지역" or ({active="수락한 퀘스트",turnin="보고 대기",selected="체크 목록",deferred="보류 목록",all="검색 결과"})[mode] or "퀘스트"
 if mode=="all" and search=="" then scopeName="현재 퀘스트 · 이름/지역 검색 가능" end
 headerInfo:SetText(scopeName.." · "..total.."개"..suffix)
 if #display==0 then
  emptyList:SetText(journeyPhase~="all" and "이 단계에 해당하는 퀘스트가 없습니다.\n\n[모두]를 누르면 다른 단계도 볼 수 있습니다."
   or not G.Ready() and "퀘스트 자료가 아직 연결되지 않았습니다.\n\n퀘스트 자료 불러오기 상태를 확인하세요. 이미 수락한 퀘스트는 [현재 퀘스트]에서 확인할 수 있습니다."
   or building and "검색 목록을 준비하고 있습니다.\n\n잠시 후 목록이 갱신됩니다."
   or mode=="active" and "아직 수락한 퀘스트가 없습니다.\n\n[지역별] 또는 [던전별]에서 장소를 고르고 [받기]를 눌러 시작할 퀘스트를 찾으세요."
   or "조건에 맞는 퀘스트가 없습니다.\n\n검색어·진영·완료 제외·제한 숨김 설정을 확인하세요.")
  emptyList:Show()
 else emptyList:Hide() end
 local groupNumbers,groupCount={},0
 for _,entry in ipairs(display) do
  if entry.kind=="chain" then groupCount=groupCount+1;groupNumbers[entry.key]=groupCount end
 end
 for i,r in ipairs(questRows) do
  local entry=display[questOffset+i];r.entry=entry;r.quest=nil;r.chainKey=nil;r.rail:Hide();r.edge:Hide()
  hideBorder(r.cardBorder);r.cardInset=0;r.fill:ClearAllPoints();r.fill:SetAllPoints(r)
  r.checkbox:Hide();r.statusText:Hide();r.marker:Show();r:SetScript("OnEnter",nil);r:SetScript("OnLeave",nil)
  r.text:ClearAllPoints();r.statusText:ClearAllPoints()
  if entry and entry.kind=="chain" then
   r.chainKey=entry.key;r:Show();r.statusText:Show();r.edge:Show()
   r.text:SetPoint("TOPLEFT",r,"TOPLEFT",12,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-7,-3);r.text:SetHeight(18)
   r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",12,4);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-7,4);r.statusText:SetHeight(14)
   r.fill:SetColorTexture(.15,.25,.32,.98);r.marker:SetColorTexture(.45,.76,.91,1)
   r.text:SetText("|cff9cddf2"..(entry.collapsed and "+ " or "− ").."[연계 "..groupNumbers[entry.key]..(entry.branch and "·분기] " or "] ")..entry.label.."|r")
   r.statusText:SetText("|cffb5c7d4"..entry.count.."개 · 보고 완료 "..entry.completed..(entry.superseded>0 and (" · 지난 단계 "..entry.superseded) or "")..(entry.extra>0 and (" · 외부 선행 "..entry.extra) or "").."|r")
   r:SetScript("OnEnter",function(self)
    local tips={entry.label.." 연계", "큰 파란 테두리 안의 퀘스트만 같은 연계입니다. 작은 네모는 각각의 퀘스트입니다.","클릭: 접기/펼치기",entry.linear and "앞 단계의 조건을 마쳐야 다음 퀘스트를 진행합니다." or "분기 또는 확인이 필요한 단계가 있습니다. 번호를 그대로 수행 순서로 해석하지 마세요."}
    if entry.nextQuestId then tips[#tips+1]="지금: "..entry.nextLabel.." · "..G.GetQuestName(entry.nextQuestId) end
    if entry.cycle then tips[#tips+1]="자료에서 선행 관계가 순환합니다. 실제 퀘스트 조건 확인이 필요합니다." end
    itemTooltip(self,tips)
   end)
  elseif entry and entry.kind=="chainEnd" then
   r:Show();r.marker:Hide()
   r.text:SetPoint("LEFT",r,"LEFT",21,0);r.text:SetPoint("RIGHT",r,"RIGHT",-7,0);r.text:SetHeight(36)
   r.fill:SetColorTexture(.075,.12,.16,.95)
   r.text:SetText("|cff91b5cb연계 "..tostring(groupNumbers[entry.key] or "").." 끝 · "..entry.label.."|r")
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label.." 연계는 여기까지", "아래에 표시되는 개별 퀘스트는 이 묶음에 속하지 않습니다."})end)
  elseif entry and entry.kind=="header" then
   r:Show();r.text:SetPoint("LEFT",r,"LEFT",10,0);r.text:SetPoint("RIGHT",r,"RIGHT",-6,0);r.text:SetHeight(36)
   r.fill:SetColorTexture(.19,.18,.14,.96);r.marker:SetColorTexture(.86,.65,.29,1)
   r.text:SetText("|cffffd486"..(entry.category=="raid" and "공격대 · " or entry.isDungeon and "던전 · " or "지역 · ")..entry.label.."|r")
   r:SetScript("OnEnter",function(self)itemTooltip(self,{entry.label,"장소별 분류입니다. 같은 장소라고 같은 연계 퀘스트는 아닙니다."})end)
  elseif entry and entry.kind=="quest" then
   local id=entry.id;local j=journey(id);local meta=entry.meta or G.QuestListMeta(id)
   r.quest=id;r:Show();r.checkbox:Show();r.statusText:Show()
   local cardInset=entry.chainKey and 12 or 0;r.cardInset=cardInset
   r.fill:ClearAllPoints();r.fill:SetPoint("TOPLEFT",r,"TOPLEFT",cardInset,0);r.fill:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-cardInset,0)
   local inset=entry.chainKey and 47 or 35
   r.checkbox:ClearAllPoints();r.checkbox:SetPoint("LEFT",r,"LEFT",entry.chainKey and 17 or 5,0)
   r.text:SetPoint("TOPLEFT",r,"TOPLEFT",inset,-3);r.text:SetPoint("TOPRIGHT",r,"TOPRIGHT",-cardInset-7,-3);r.text:SetHeight(18)
   r.statusText:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",inset,4);r.statusText:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-cardInset-7,4);r.statusText:SetHeight(14)
   local code=j.code;local name=G.GetQuestName(id);local col=DASH_COLOR[code] or "|cffffffff"
   r.checkbox:SetChecked(G.db.selectedQuests[id]==true)
   local canCheck=G.db.selectedQuests[id]==true or j.canGuide
   if r.checkbox.SetEnabled then r.checkbox:SetEnabled(canCheck) elseif canCheck then r.checkbox:Enable() else r.checkbox:Disable() end
   local factionTag=(mode=="all" or (G.db.factionFilter or "auto")~="auto") and G.QuestFactionTag(id) or ""
   local groupNumber=entry.chainKey and groupNumbers[entry.chainKey]
   local prefix=entry.chainIndex and (entry.chainLinear and ("|cff91c8e0[연계 "..tostring(groupNumber).." · "..entry.chainIndex.."/"..entry.chainCount.."]|r ") or ("|cff91c8e0[연계 "..tostring(groupNumber).." 항목]|r ")) or (entry.relationship=="ungrouped" and "|cffb5c1cd[관계 미표시]|r " or "|cffb5c1cd[개별]|r ")
   local displayName=entry.sameTitle and (name.." #"..id) or name
   r.text:SetText(prefix.."|cffefd398"..tostring(meta.level).."레벨|r "..factionTag..displayName)
   local place=(j.location or "위치 확인 필요"):gsub("\n"," / ")
   r.statusText:SetText((entry.chainContext and "|cff9fcce4외부 선행 · |r" or "")..col..j.verb.."|r · "..place)
   local selected=G.selection.quest==id
   r.marker:Hide()
   if selected then r.fill:SetColorTexture(.19,.31,.37,.98);paintBorder(r,r.cardBorder,cardInset,2,{1,.80,.34,1})
   elseif entry.chainKey then r.fill:SetColorTexture(.10,.17,.22,.98);paintBorder(r,r.cardBorder,cardInset,2,{.34,.55,.69,1})
   else r.fill:SetColorTexture(.14,.16,.19,.98);paintBorder(r,r.cardBorder,cardInset,2,{.47,.52,.57,1}) end
   r:SetScript("OnEnter",function(self)
    local tips={name.." (#"..id..")",entry.chainLabel and ("연계: "..entry.chainLabel..(entry.chainContext and " · 외부 선행" or "")) or entry.relationship=="ungrouped" and "연계 관계 미표시 · 아래 선행 조건 확인" or "개별 항목 · 앞 연계 묶음에 속하지 않음",
     "퀘스트 레벨 "..tostring(meta.level).." · 최소 수락 "..G.GetQuestMinLevel(id).."레벨",j.title,j.location,j.detail,j.nextText,
     "클릭: 오른쪽에서 진행 방법 확인 / 체크: 여러 퀘스트 함께 안내","채팅 입력창에서 시프트 키를 누르고 클릭: 퀘스트 링크"}
    itemTooltip(self,tips)
   end)
  else r:Hide() end
  r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 end
 refreshChainFrames(display,questOffset)
 if G.UIJourneyWidgets then G.UIJourneyWidgets.display=display;G.UIJourneyWidgets.summary=visibleSummary;G.UIJourneyWidgets.phase=journeyPhase end
 local current=journey(G.selection.quest)
 if current then
  nowTitle:SetText((shownSet[G.selection.quest] and "지금 할 일" or "목록 밖에서 선택한 퀘스트").." · "..current.title)
  nowAction:SetText((current.prerequisite and "먼저 · " or "")..((current.detail or current.title):match("[^\n]+") or current.title))
  nowPlace:SetText("장소 · "..(current.location or "확인 필요"))
  quickStartButton:SetText(current.prerequisite and "선행부터 안내 시작" or current.phase=="turnin" and "보고하러 가기 안내" or "이 퀘스트 안내 시작")
  if current.canGuide then quickStartButton:Enable();locationButton:Enable() else quickStartButton:Disable();locationButton:Disable() end
 else
  nowTitle:SetText("지금 할 일 · 퀘스트를 골라 주세요")
  nowAction:SetText("[현재 퀘스트]를 열거나 왼쪽에서 지역·던전을 선택하세요.")
  nowPlace:SetText("목록에서 퀘스트 클릭 → 진행 방법 확인 → [이 퀘스트 안내 시작]")
  quickStartButton:Disable();locationButton:Disable()
 end
 if visibleSummary.nextQuestId then findNextButton:Enable() else findNextButton:Disable() end
 local readyCount=0
 for id,yes in pairs(G.db.selectedQuests or {}) do
  if yes and G.IsReadyToTurnIn(tonumber(id)) then readyCount=readyCount+1 end
 end
 selectedInfo:SetText("체크 "..G.SelectedCount().." · 보고 "..readyCount)
 local count=G.DeferredCount()
 deferredListButton:SetText("보류 목록 "..count);G.UIButtonState(deferredListButton,mode=="deferred")
 if count>0 then resumeAllButton:Enable() else resumeAllButton:Disable() end
 if G.DeferredBlocker(G.selection.quest) then resumeOneButton:Enable() else resumeOneButton:Disable() end
 local q=G.selection.quest
 G.ContactPreviewSelectionChanged(q)
 if contactStart then
  if q then contactStart:Enable();contactEnd:Enable() else contactStart:Disable();contactEnd:Disable() end
 end
 if q then
  local desc=G.QuestDetails(q);local j=journey(q);local chain=chainByQuest[q]
  local lines=G.JourneyDetailLines(q)
  if chain then
   local position
   for ix,id in ipairs(chain.memberIds) do if id==q then position=ix;break end end
   relationshipInfo:SetText((chain.branch and "연계·분기 · " or "연계 · ")..chain.label.." · "..(chain.linear and ("현재 "..tostring(position or "?").."/"..chain.count) or ("구성 "..chain.count.."개")).."\n"..journeyFlow(j.code))
   lines[#lines+1]="\n|cff9cd9f0이 연계에 포함된 퀘스트|r"
   lines[#lines+1]=chain.linear and "앞 단계의 조건을 마친 뒤 다음 퀘스트를 진행합니다." or "갈라지거나 합쳐지는 관계가 포함될 수 있습니다. 이 번호는 수행 순서가 아닙니다."
   for ix,id in ipairs(chain.memberIds) do
    local member=journey(id)
    lines[#lines+1]=(id==q and "|cffffd787[선택] " or "")..ix..". "..G.GetQuestName(id).." (#"..id..") · "..member.verb..(id==q and "|r" or "")
   end
   if chain.nextQuestId then lines[#lines+1]="지금 가능한 일: "..G.GetQuestName(chain.nextQuestId).." · "..chain.nextLabel end
   if chain.incomplete then lines[#lines+1]="일부 선행이 현재 표시 범위 밖에 있습니다. 아래 조건도 확인하세요." end
  elseif G.db.groupChains==false then
   relationshipInfo:SetText("연계 묶기 끔 · 실제 관계는 아래 선행 조건 참고\n"..journeyFlow(j.code))
  elseif not G.Ready() then
   relationshipInfo:SetText("퀘스트 자료 미연결 · 연계 관계 확인 필요\n"..journeyFlow(j.code))
  elseif not shownSet[q] then
   relationshipInfo:SetText("현재 목록 밖에서 선택된 퀘스트\n"..journeyFlow(j.code))
  else
   relationshipInfo:SetText("개별 퀘스트 · 앞 연계 묶음과 별도 항목\n"..journeyFlow(j.code))
  end
  if j.prerequisite then
   lines[#lines+1]="\n|cffffd89b먼저 진행할 선행|r"
   lines[#lines+1]="‘"..G.GetQuestName(j.actionQuestId).."’부터 안내합니다. 위 [선행부터 안내 시작]을 누르세요."
  end
  local walkthrough=G.WalkthroughDetails and G.WalkthroughDetails(q)
  if walkthrough then lines[#lines+1]="\n|cffffdc88자세한 수행 방법|r\n"..walkthrough end
  if desc.requirements then lines[#lines+1]="\n|cffffdc88진행 조건|r\n"..desc.requirements end
  if #(desc.all or {})>0 then lines[#lines+1]="\n|cffffd89b모두 마쳐야 하는 선행 퀘스트|r\n"..prereqString(desc.all) end
  if #(desc.one or {})>0 then lines[#lines+1]="\n|cffffd89b이 중 하나를 마치면 되는 선행 퀘스트|r\n"..prereqString(desc.one) end
  if #(desc.all or {})==0 and #(desc.one or {})==0 then lines[#lines+1]="\n등록된 직접 선행 퀘스트: 없음" end
  if desc.reason then
   lines[#lines+1]="\n|cffffa173현재 막힌 이유|r\n"..desc.reason
   if desc.blocker and desc.blocker.path and #desc.blocker.path>1 then local path={};for _,qid in ipairs(desc.blocker.path) do path[#path+1]=G.GetQuestName(qid) end;lines[#lines+1]="필요한 선행: "..table.concat(path," → ") end
  end
  if desc.nameNote then lines[#lines+1]="\n|cff9fcce4명칭·서버 확인 사항|r\n"..desc.nameNote end
  if desc.note then lines[#lines+1]="\n|cffffa173주의할 점|r\n"..desc.note end
  detailHead:SetText(desc.name.."\n"..(DASH_COLOR[j.code] or "")..j.verb.."|r  ·  퀘스트 #"..q)
  detailText(table.concat(lines,"\n"),q)
 else
  detailHead:SetText("목록에서 퀘스트를 고르면\n받는 곳부터 보고할 곳까지 안내합니다.")
  relationshipInfo:SetText("연계 = 앞 퀘스트를 이어서 진행하는 묶음\n개별 = 앞 묶음과 분리된 퀘스트 항목")
  detailText("처음 사용하는 방법\n\n1. [현재 퀘스트]에서 이미 받은 퀘스트를 보세요. 새로 받을 퀘스트는 [지역별]·[던전별]에서 찾습니다.\n\n2. 퀘스트를 누르면 위쪽 ‘지금 할 일’에 행동과 장소가 나옵니다.\n\n3. [이 퀘스트 안내 시작]을 누르고 화면의 이동 안내를 따라가세요.\n\n여러 퀘스트를 함께 진행하려면 왼쪽 체크박스로 고른 뒤 [체크한 퀘스트 통합 안내]를 누르세요.\n\n받기 = 사람이나 물건에서 퀘스트 수락\n수행 = 퀘스트의 목표를 채우기\n보고 = 목표를 채운 뒤 보상을 받기\n선행 = 그보다 먼저 끝내야 하는 퀘스트",nil)
 end
 local guide=G.db.guide
 local done,total=G.GuideProgress();footerProgress:SetProgress(done,total)
 local reviewing=G.GuideViewingHistory();footerNext:SetText(reviewing and "현재 단계" or "다음 확인");if G.CurrentStep() or reviewing then footerNext:Enable() else footerNext:Disable() end
 if total>0 and G.GuideViewIndex()>1 then footerPrev:Enable() else footerPrev:Disable() end
 if guide and guide.halted then
  guideInfo:SetText(displayText("|cffffc675진행 가능한 동선 없음|r · "..G.RouteScopeLabel(guide)))
  guideNow:SetText(displayText(guide.statusReason or "수락 조건 확인 필요"))
  guideNote:SetText("제외/보류 목록에서 사유 확인 → 보류 해제 또는 동선 초기화 · 실제 완료 기록 유지")
 elseif guide and guide.completed then
  guideInfo:SetText("|cff8be19e동선 완료|r")
  guideNow:SetText("현재 방문 가능한 단계가 모두 처리되었습니다.")
  guideNote:SetText("체크 목록은 그대로 유지됩니다. 필요하면 다른 퀘스트를 추가하고 다시 시작하세요.")
 elseif guide and guide.steps and #guide.steps>0 then
  local done,count=G.GuideProgress();local step=G.CurrentStep()
  local guideDungeon=G.GetDungeon(guide.dungeon)
  local title=displayText(G.RouteScopeLabel(guide))
  local multi=guide.optimization and (" · 가능 "..(guide.admittedCount or guide.optimization.selectedQuestCount or 0).."개 · 제외 "..#(guide.excluded or {}).."개") or ""
  guideInfo:SetText("|cffffdc89진행 "..done.."/"..count.."|r  ·  "..title..multi)
  guideNow:SetText(displayText(step and ("|cff8adff1다음:|r "..(guide.index or 1)..". "..step.title) or "|cff86d695모든 단계 완료 · 퀘스트 창 확인|r"))
  local routeWarning=guide.optimization and guide.optimization.approximate and " · 여러 지역/좌표 미확인: 이동 시간 최적 보장 불가" or ""
  guideNote:SetText(displayText(step and ((step.note or "")..routeWarning) or ""))
 else
  guideInfo:SetText("가이드 대기 중")
  guideNow:SetText("처음이라면: [현재 퀘스트] → 퀘스트 하나 선택 → 위쪽 [이 퀘스트 안내 시작]")
  guideNote:SetText("받기 → 목표 수행 → 보고 대상에게 보고. 목표를 채운 뒤에도 보고와 보상을 받아야 퀘스트가 끝납니다.")
 end
 navStatus:SetText(displayText(G.guideFeedback or ("지도 길찾기: "..(G.navStatus or "대기"))))
end
function G.ShowUI(show)
 buildUI();if not frame then return end
 if show==false or (show==nil and frame:IsShown()) then frame:Hide();return end
 G.UIFit(frame);frame:Show();G.UIRefresh()
end
function G.ToggleUI() G.ShowUI(nil) end

"""Render recorded addon widgets, anchors and text. NOT an in-game screenshot.

The renderer approximates native font metrics/checkbox skin; data/state are the
explicit fixture. It is useful for inspecting grouping and geometry only.
"""
from __future__ import annotations
import json,re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'ui-preview.json').read_text())
items={o['id']:o for o in data['objects']}
children={}
for o in items.values():children.setdefault(o.get('parent'),[]).append(o['id'])
boxes={}
anchors={'TOPLEFT':(0,0),'TOP':(.5,0),'TOPRIGHT':(1,0),'LEFT':(0,.5),'CENTER':(.5,.5),'RIGHT':(1,.5),'BOTTOMLEFT':(0,1),'BOTTOM':(.5,1),'BOTTOMRIGHT':(1,1)}

def box(oid):
    if oid in boxes:return boxes[oid]
    o=items[oid]
    if oid==1:
        boxes[oid]=(0,0,data['width'],data['height']);return boxes[oid]
    par=o.get('parent',1);pb=box(par)
    if o.get('allPoints'):
        boxes[oid]=box(o['allPoints']);return boxes[oid]
    w,h=o.get('width',0),o.get('height',0)
    # Native FontStrings with LEFT/RIGHT anchors auto-size their text height.
    if o['kind']=='FontString'and h==0:h=(o.get('fontSize')or(16 if 'Large'in(o.get('font')or'')else 12))+3
    if items[par].get('thumb')==oid:
        p=items[par];value=(p.get('value',0)-p.get('low',0))/max(1,p.get('high',1)-p.get('low',0))
        boxes[oid]=(pb[0]+(pb[2]-w)/2,pb[1]+(pb[3]-h)*value,w,h);return boxes[oid]
    eqx,eqy=[],[]
    for p in o.get('points',[]):
        if not p:continue
        own=p[0];rel=par;rp=own;dx=dy=0
        if len(p)>1 and isinstance(p[1],dict):
            rel=p[1].get('ref') or par
            if len(p)>2 and isinstance(p[2],str):rp=p[2];dx=p[3] if len(p)>3 else 0;dy=p[4] if len(p)>4 else 0
        elif len(p)>1 and isinstance(p[1],(int,float)):
            dx=p[1];dy=p[2] if len(p)>2 else 0
        rb=box(rel);a=anchors.get(own,(0,0));r=anchors.get(rp,(0,0))
        eqx.append((a[0],rb[0]+rb[2]*r[0]+dx));eqy.append((a[1],rb[1]+rb[3]*r[1]-dy))
    def solve(eqs,size,fallback):
        for i,a in enumerate(eqs):
            for b in eqs[i+1:]:
                if a[0]!=b[0]:size=(b[1]-a[1])/(b[0]-a[0]);return a[1]-a[0]*size,size
        return (eqs[0][1]-eqs[0][0]*size if eqs else fallback),size
    x,w=solve(eqx,w,pb[0]);y,h=solve(eqy,h,pb[1])
    if items[par].get('scrollChild')==oid:y-=items[par].get('scroll',0)
    boxes[oid]=(x,y,max(0,w),max(0,h));return boxes[oid]

S=2
W,H=int(data['width']),int(data['height'])
canvas=Image.new('RGBA',(W*S,(H+40)*S),(11,15,20,255))
layer=Image.new('RGBA',(W*S,H*S),(0,0,0,0))
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
fonts={}
def font(size):
    if size not in fonts:fonts[size]=ImageFont.truetype(font_path,round(size*S),index=1)
    return fonts[size]
def rgb(a,default=(.91,.93,.95,1)):
    a=a or default;return tuple(round(max(0,min(1,x))*255)for x in (list(a)+[1])[:4])
def rect(im,coords,fill,outline=None,width=1):
    if coords[2]<=coords[0] or coords[3]<=coords[1]:return
    ImageDraw.Draw(im).rectangle(tuple(round(v*S)for v in coords),fill=fill,outline=outline,width=round(width*S))
def intersection(a,b):
    return(max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3]))
def composite(im,clip):
    x0,y0,x1,y1=[round(v*S)for v in clip]
    x0=max(0,x0);y0=max(0,y0);x1=min(layer.width,x1);y1=min(layer.height,y1)
    if x1>x0 and y1>y0:layer.alpha_composite(im.crop((x0,y0,x1,y1)),(x0,y0))

color_re=re.compile(r'\|c([0-9a-fA-F]{8})|\|r')
def glyphs(text,default):
    out=[];current=default;pos=0
    for m in color_re.finditer(text):
        out.extend((c,current)for c in text[pos:m.start()])
        if m.group(1):v=m.group(1);current=tuple(int(v[i:i+2],16)for i in (2,4,6,0))
        else:current=default
        pos=m.end()
    out.extend((c,current)for c in text[pos:]);return out
def draw_text(o,clip):
    x,y,w,h=box(o['id'])
    if w<=0 or h<=0 or not o.get('text'):return
    size=o.get('fontSize')or(16 if 'Large'in(o.get('font')or'')else 12)
    f=font(size);color=rgb(o.get('textColor'))
    if 'Disable'in(o.get('font')or''):color=(150,160,173,255)
    if o.get('parent')and items[o['parent']].get('enabled')is False:color=(129,139,149,255)
    gs=glyphs(o['text'],color);lines=[[]];lw=0
    wrapping=o.get('wordWrap')is not False
    for c,col in gs:
        if c=='\n':lines.append([]);lw=0;continue
        cw=f.getlength(c)/S
        if wrapping and lines[-1] and lw+cw>w:lines.append([]);lw=0
        lines[-1].append((c,col,cw));lw+=cw
    if o.get('maxLines'):lines=lines[:o['maxLines']]
    line_h=size+3+(o.get('spacing')or 0);total=len(lines)*line_h-(o.get('spacing')or 0)
    yy=y if o.get('justifyV')=='TOP' else y+max(0,(h-total)/2)
    im=Image.new('RGBA',layer.size,(0,0,0,0));dr=ImageDraw.Draw(im)
    for line in lines:
        width=sum(c[2]for c in line);xx=x
        if o.get('justifyH')=='CENTER':xx+=max(0,(w-width)/2)
        elif o.get('justifyH')=='RIGHT':xx+=max(0,w-width)
        for c,col,cw in line:
            dr.text((round(xx*S),round((yy+size)*S)),c,font=f,fill=col,anchor='ls');xx+=cw
        yy+=line_h
    composite(im,intersection(clip,(x,y,x+w,y+h)))

def draw_node(oid,clip):
    o=items[oid]
    if not o.get('shown',True):return
    x,y,w,h=box(oid);kind=o['kind'];par=items.get(o.get('parent'))
    if kind=='Texture':
        if par:
            if oid in (par.get('pushedTexture'),par.get('highlightTexture')):return
            if oid==par.get('disabledTexture')and par.get('enabled',True):return
            if oid==par.get('normalTexture')and par.get('enabled')is False and par.get('disabledTexture'):return
        col=o.get('color')or o.get('vertexColor')
        if col:
            im=Image.new('RGBA',layer.size,(0,0,0,0));rect(im,(x,y,x+w,y+h),rgb(col));composite(im,clip)
        return
    if kind=='FontString':draw_text(o,clip);return
    if kind=='ScrollFrame':clip=intersection(clip,(x,y,x+w,y+h))
    if kind=='CheckButton':
        im=Image.new('RGBA',layer.size,(0,0,0,0));pad=4
        rect(im,(x+pad,y+pad,x+w-pad,y+h-pad),(10,18,23,255),(113,123,130,255))
        if o.get('checked'):
            dr=ImageDraw.Draw(im);dr.line([(round((x+6)*S),round((y+h/2)*S)),(round((x+10)*S),round((y+h-7)*S)),(round((x+w-6)*S),round((y+7)*S))],fill=(139,216,242,255),width=2*S)
        composite(im,clip)
    if kind=='EditBox':
        im=Image.new('RGBA',layer.size,(0,0,0,0));rect(im,(x,y,x+w,y+h),(12,18,25,255),(75,87,99,255));composite(im,clip)
    kids=children.get(oid,[])
    regions=[i for i in kids if items[i]['kind']=='Texture']
    for i in sorted(regions,key=lambda i:({'BACKGROUND':0,'BORDER':1,'ARTWORK':2,'OVERLAY':3,'HIGHLIGHT':4}.get(items[i].get('layer'),2),i)):draw_node(i,clip)
    for i in kids:
        if items[i]['kind']not in('Texture','FontString'):draw_node(i,clip)
    for i in kids:
        if items[i]['kind']=='FontString':draw_node(i,clip)

draw_node(1,(0,0,W,H))
canvas.alpha_composite(layer,(0,40*S))
ImageDraw.Draw(canvas).text((18*S,10*S),'화면 구조 미리보기 · 모의 퀘스트 상태 · 게임 실행 화면 아님',font=font(12),fill=(175,195,209,255),anchor='lt')
canvas.convert('RGB').save(ROOT/'ui-preview.png')
(ROOT/'ui-preview-geometry.json').write_text(json.dumps({str(i):box(i)for i in items},ensure_ascii=False,indent=2))
print(ROOT/'ui-preview.png')

-- Export actual live Lua widget registry after UIRefresh. Fixture quest-log
-- states are illustrative; action text and indoor landmarks use bundled source.
return function(Mock,G,base,names,states,levels,dungeon)
 local function ko(value)return G.KoreanText and G.KoreanText(value)or value end
 local function displayRecord(record)
  if type(record)~="table"then return record end
  local out={};for key,value in pairs(record)do out[key]=(key=="name"or key=="target"or key=="zone"or key=="site"or key=="instruction"or key=="note")and ko(value)or value end
  return out
 end
 local data={}
 assert(loadfile(base.."Data.lua"))("ForeverDungeonQuestGuide",data)
 data.GetDungeon=function(id)return data.dungeonById[id]end;data.SafeCall=G.SafeCall
 assert(loadfile(base.."VerifiedRoutes.lua"))("ForeverDungeonQuestGuide",data)
 data.walkthroughRecords={}
 assert(loadfile(base.."DungeonWalkthrough.lua"))("ForeverDungeonQuestGuide",data)
 names[4123]="산의 정수";names[4126]="헐레이 블랙브레스";names[4136]="리블리 스크류스피곳"
 states[3801]="done";states[3802]="active";states[4123]="active";states[4126]="active";states[4136]="active"
 levels[4123]=55;levels[4126]=55;levels[4136]=53
 dungeon.ids={3801,3802,4123,4126,4136};G.dungeons={dungeon}
 G.QuestPoint=function(id,stage)
  local m=data.specialQuestMeta[id]
  if m and ((m.insideStages and m.insideStages[stage]) or (m.stageLandmarks and m.stageLandmarks[stage]))then return nil end
  local p=(stage=="accept" and data.pickupOverrides or stage=="turnin" and data.turninOverrides or {})[id]
  return displayRecord(p)
 end
 G.QuestInsideInfo=function(id,stage)
  local m=data.specialQuestMeta[id];local i=m and m.insideStages and m.insideStages[stage]
  if not i then return nil end
  local d=data.GetDungeon(i.dungeon)
  return{dungeon=ko(d.name),dungeonId=d.id,room=ko(i.room),npcName=ko(i.npcName),instruction=ko(i.instruction),contactType=i.contactType,entrance=d.entrance}
 end
 G.QuestStageLandmark=function(id,stage)local m=data.specialQuestMeta[id];return displayRecord(m and m.stageLandmarks and m.stageLandmarks[stage])end
 G.QuestContactName=function(id,stage)local i=G.QuestInsideInfo(id,stage);local l=G.QuestStageLandmark(id,stage);local p=G.QuestPoint(id,stage);return i and i.npcName or l and l.target or p and p.name,nil,nil,i and i.contactType or "npc"end
 G.QuestObjectiveText=function(id)local i=G.QuestInsideInfo(id,"objective");return i and i.instruction or "퀘스트 목표를 확인하세요."end
 G.QuestObjectivePoints=function()return{}end
 G.MapDisplayName=function(map)return ko(data.MapDisplayName(map))end
 G.WalkthroughDetails=function(id)local r=data.walkthroughRecords[id];return r and ko(table.concat(r.objective or {},"\n"))end
 G.QuestIndexStatus=function()return "예시 로그"end
 G.activeQuests={};for _,id in ipairs(dungeon.ids)do if states[id]=="active" then G.activeQuests[id]={title=names[id],level=levels[id] or 52,complete=false}end end
 G.db.selectedQuests={[3802]=true};G.db.deferredQuests={};G.db.chainCollapsed={};G.db.groupChains=true
 G.selection.mode="dungeon";G.selection.dungeon="brd";G.selection.quest=3802
 G.UIJourneyWidgets.search:SetText("");G.UIJourneyWidgets.phaseButtons.all:Click();G.ShowUI(true)
 local root=G.UIJourneyWidgets.frame
 local untranslated={}
 for _,widget in ipairs(Mock.objects)do
  if widget.kind=="FontString"and widget:IsVisible()then
   local visible=(widget:GetText()or""):gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
   if visible:find("[A-Za-z]")then untranslated[#untranslated+1]=visible end
  end
 end
 print("Preview visible English text count: "..#untranslated)
 for _,visible in ipairs(untranslated)do print("PREVIEW TEXT CHECK: "..visible)end
 local list={};local ids={}
 for _,o in ipairs(Mock.objects)do local p=o;while p and p~=root do p=p.parent end;if p==root then list[#list+1]=o;ids[o]=#list end end
 local function ref(o)return ids[o]end
 local function point(p)local r={};for i,v in ipairs(p)do r[i]=type(v)=="table" and {ref=ref(v) or 0} or v end;return r end
 local out={width=root.width,height=root.height,objects={}}
 for _,o in ipairs(list)do
  local p={id=ids[o],kind=o.kind,name=o.name,parent=ref(o.parent),width=o.width,height=o.height,shown=o.shown,enabled=o.enabled,text=type(o.text)=="string" and o.text or nil,font=o.font,fontSize=o.fontSize,textColor=o.textColor,color=o.color,vertexColor=o.vertexColor,texture=type(o.texture)=="string" and o.texture or nil,layer=o.layer,scale=o.scale,checked=o.checked,wordWrap=o.wordWrap,maxLines=o.maxLines,spacing=o.spacing,justifyH=o.justifyH,justifyV=o.justifyV,value=o.value,low=o.low,high=o.high,scroll=o.scroll,allPoints=ref(o.allPoints),normalTexture=ref(o.normalTexture),disabledTexture=ref(o.disabledTexture),highlightTexture=ref(o.highlightTexture),pushedTexture=ref(o.pushedTexture),fontString=ref(o.fontString),thumb=ref(o.thumb),scrollChild=ref(o.scrollChild),points={}}
  for _,v in ipairs(o.points)do p.points[#p.points+1]=point(v)end
  out.objects[#out.objects+1]=p
 end
 local function json(v)
  local t=type(v)
  if t=="nil" then return "null" elseif t=="boolean" or t=="number" then return tostring(v)
  elseif t=="string" then return '"'..v:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n'):gsub('\r','\\r'):gsub('\t','\\t')..'"'
  elseif t=="table" then
   local a={};if #v>0 then for _,x in ipairs(v)do a[#a+1]=json(x)end;return "["..table.concat(a,",").."]" end
   for k,x in pairs(v)do a[#a+1]=json(k)..":"..json(x)end;return "{"..table.concat(a,",").."}"
  else error("unsupported type "..t)end
 end
 local f=assert(io.open("tests/ui-preview.json","w"));f:write(json(out));f:close()
 print("Preview registry exported: tests/ui-preview.json")
end

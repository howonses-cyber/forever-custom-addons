local addon,G=...
-- QuestieDB provides the complete quest-ID set. Build a name index incrementally so
-- opening the guide never freezes the game while thousands of names are decoded.
local index={ids={},names={},normalized={},cursor=1,loaded=0,total=0,ready=false,available=false}
G.questIndex=index
local MAX_RESULTS=600
local nextRetryAt=0
local function queryIds()
 if type(QuestDB)~="table" then return nil end
 if type(QuestDB.GetAllIds)=="function" then
  local ok,result=pcall(QuestDB.GetAllIds)
  if ok and type(result)=="table" then return result end
 end
 -- Legacy Questie installations expose the same composed ID map via QuestPointers.
 local ptr=QuestieDB and QuestieDB.QuestPointers
 if type(ptr)=="table" then
  local ids={}
  for id,present in pairs(ptr) do
   if present and type(id)=="number" and id>0 then ids[#ids+1]=id end
  end
  table.sort(ids)
  return ids
 end
 return nil
end
function G.RestartQuestIndex()
 index.ids={};index.names={};index.normalized={}
 index.cursor=1;index.loaded=0;index.total=0;index.ready=false;index.available=false
 local ids=queryIds()
 if not ids then return false end
 -- GetAllIds is shared read-only. Never mutate it.
 index.ids=ids
 index.total=#ids
 index.available=true
 index.ready=(index.total==0)
 return true
end
function G.TickQuestIndex(budget)
 if not G.Ready() then return end
 if not index.available then
  local now=GetTime and GetTime() or 0
  if now<nextRetryAt then return end
  if not G.RestartQuestIndex() then nextRetryAt=now+3;return end
 end
 if index.ready then return end
 local count=0
 while index.cursor<=index.total and count<(budget or 150) do
  local id=index.ids[index.cursor]
  if type(id)=="number" and id>0 then
   local name=G.GetQuestName(id)
   index.names[id]=name
   index.normalized[id]=G.Clean(name)
  end
  index.cursor=index.cursor+1;count=count+1
 end
 index.loaded=index.cursor-1
 index.ready=index.cursor>index.total
 -- Refresh periodically while the user is actively searching.
 if (index.ready or (math.floor(index.loaded/600)~=math.floor((index.loaded-count)/600)))
     and G.IsUIShown and G.IsUIShown() and G.UIRefresh then
  G.UIRefresh()
 end
end
function G.QuestIndexStatus()
 if not index.available then return "QuestieDB 전체 목록 API 확인 필요" end
 if not index.ready then return string.format("검색 목록 준비 %d/%d",index.loaded,index.total) end
 return string.format("전체 %d개 검색 가능",index.total)
end
local function matches(id,needle)
 if needle=="" then return true end
 if tostring(id)==needle then return true end
 local name=index.normalized[id]
 if not name then
  name=G.Clean(G.GetQuestName(id))
  -- On-demand cache for accepted/dungeon quests while indexing is in progress.
  index.normalized[id]=name
 end
 return string.find(name,needle,1,true)~=nil
end
local function inResult(list,id,seen)
 id=tonumber(id)
 if id and id>0 and not seen[id] then list[#list+1]=id;seen[id]=true end
end
-- Returns { ids, totalMatches, stillIndexing }. Mode "all" searches the entire
-- database; an empty query displays active and checked quests instead of 20k rows.
function G.SearchQuestIds(mode,query)
 local text=G.Clean(query)
 local out,seen,total={}, {},0
 local function add(id)
  if id and matches(id,text) then
   total=total+1
   if #out<MAX_RESULTS then inResult(out,id,seen) end
  end
 end
 if mode=="active" or mode=="turnin" or mode=="selected" or (mode=="all" and text=="") then
  local ids={}
  if mode=="active" or mode=="turnin" or (mode=="all" and text=="") then
   for id in pairs(G.activeQuests or {}) do
    if mode~="turnin" or G.IsReadyToTurnIn(id) then ids[#ids+1]=id end
   end
  end
  if mode=="selected" or (mode=="all" and text=="") then
   for id,yes in pairs(G.db.selectedQuests or {}) do
    if yes then ids[#ids+1]=id end
   end
  end
  table.sort(ids)
  for _,id in ipairs(ids) do
   if not seen[id] and matches(id,text) then inResult(out,id,seen);total=total+1 end
  end
  return out,total,false
 end
 if mode~="all" then return out,0,false end
 if not index.available and G.Ready() then G.RestartQuestIndex() end
 local exact=tonumber(text)
 if exact and G.DBGet(QuestDB,exact,"name") then
  inResult(out,exact,seen);total=total+1
 end
 -- Search only indexed entries; refreshes add later matches in small batches.
 for i=1,index.loaded do
  local id=index.ids[i]
  if id~=exact and index.normalized[id] and matches(id,text) then
   total=total+1
   if #out<MAX_RESULTS then inResult(out,id,seen) end
  end
 end
 -- An incomplete index must not present its count as a final total.
 return out,total,not index.ready
end
function G.SelectedCount()
 local n=0
 for _,enabled in pairs(G.db.selectedQuests or {}) do if enabled then n=n+1 end end
 return n
end
function G.SelectedQuestIds()
 local ids={}
 for id,enabled in pairs(G.db.selectedQuests or {}) do
  if enabled then ids[#ids+1]=tonumber(id) end
 end
 table.sort(ids)
 return ids
end
function G.ToggleQuestChecked(id,enabled)
 id=tonumber(id)
 if not id or id<=0 then return false end
 G.db.selectedQuests=G.db.selectedQuests or {}
 if enabled==nil then enabled=not G.db.selectedQuests[id] end
 if enabled then G.db.selectedQuests[id]=true else G.db.selectedQuests[id]=nil end
 if G.db.guide and G.db.guide.mode=="selected" and G.ReplanSelectedGuide then
  G.ReplanSelectedGuide("체크 목록 변경")
 end
 if G.UIRefresh then G.UIRefresh() end
 return true
end
function G.ClearCheckedQuests()
 G.db.selectedQuests={}
 if G.db.guide and G.db.guide.mode=="selected" then G.StopGuide() end
 if G.UIRefresh then G.UIRefresh() end
end

포에버 통합 퀘스트 동선 가이드 v1.4.0
====================================

새 버전 주요 변경
- QuestieDB 전체 퀘스트 ID를 점진적으로 색인: 일반 필드 퀘스트, 퀘스트명/번호 검색
- 5가지 보기: 전체 퀘스트 / 진행 중 / 보고 대기 / 던전별 / 체크 목록
- 퀘스트 왼쪽 체크박스로 복수 선택, 체크한 여러 퀘스트의 통합 수락/수행/보고 동선 생성
- 빠진 선행 퀘스트 자동 포함, 선행 보고가 후속 퀘스트 수락보다 먼저 나오도록 제약
- 현재 위치 같은 지도 내 근접 우선 최적화, 퀘스트 상태/지역 이동/플레이어 이동에 따라 재정렬
- 지도 경유지 숫자와 같은 지도 안 직선 연결선 (도로 및 지형 경로가 아님)
- EllesmereUI 미니맵 애드온 모음집에 아이콘 제공 (네이티브 Minimap 자식 버튼)
- 기존 던전별 분류·던전 준비 가이드·HUD·수동 다음 단계·/fdq 명령 유지

설치
- ForeverDungeonQuestGuide 폴더를 Interface/AddOns/ 아래에 설치하세요.
- QuestieDB 필요: 없으면 전체 검색/선행 데이터가 나오지 않습니다.
- 선택 기능: TomTom, ShortestPathForever, ForeverDungeonNavigator, Questie.
- 월드 지도 포인트는 기본 지도 또는 TomTom으로 표시 가능; 실제 이동 가능한 경로 계산은
  ShortestPathForever가 별도 설치되어 해당 API를 제공할 때만 사용합니다.

사용법
1. 미니맵의 엘스미어UI '애드온 모음집'에서 황금 테두리 지도 아이콘을 클릭합니다.
   미니맵 모음집 미사용 환경에도 동일 버튼이 미니맵 주변에 표시됩니다.
2. '전체 퀘스트'에서 일반 퀘스트 이름이나 ID를 검색합니다.
3. 퀘스트 왼쪽 □를 여러 개 체크합니다. '체크 목록'에서 확인할 수 있습니다.
4. '체크한 퀘스트 동선 시작'을 누르고 HUD/동선표/지도에서 순서대로 따라갑니다.
5. 진행 중인 퀘스트 수락/진행/보고 변화 및 캐릭터 현재 위치 변화 시 동선을 다시 정렬합니다.
6. '던전별' 탭과 왼쪽 던전 목록에서는 기존처럼 던전 전용 퀘스트들을 볼 수 있습니다.
7. '선택 던전 전체 준비 가이드'로 기존 던전 준비 동선을 시작할 수도 있습니다.

명령어
/ fdq (띄어쓰기 없이 /fdq) : 창 열기/닫기
/fdq 전체         전체 퀘스트 보기
/fdq 던전         던전별 분류 보기
/fdq 진행         진행 중인 퀘스트 보기
/fdq 체크         내가 체크한 퀘스트 보기
/fdq quest 5001   퀘스트 ID 바로 선택
/fdq check 5001   퀘스트 ID를 체크 목록에 추가
/fdq 경로         체크 목록 통합 동선 시작
/fdq 동선         전체 동선표 열기/닫기
/fdq hud          HUD 표시/숨기기
/fdq next         현재 단계 수동 완료
/fdq stop         현재 가이드 중단

알려진 제한 (실게임 테스트 필요)
- QuestieDB에 없는 Forever 신규 퀘스트는 전체 검색 결과에 표시되지 않습니다.
- 퀘스트 좌표가 없는 DB 항목은 좌표를 생성하지 않고 '미확인'으로 표시합니다.
- 최적화는 같은 지도 내 단순 직선 거리 기반 휴리스틱이며 포탈, 비행, 산맥, 층수,
  던전 내부 통과 가능 경로를 계산하거나 최단 이동시간을 보장하지 않습니다.
- 던전 별도 목록의 신규 Forever 인던은 기존처럼 퀘스트 매핑 미검증으로 남습니다.
- 게임 내 실제 조작/서드파티 EUI 모음집 표시/다양한 QuestieDB 빌드는 이 환경에서 검증할 수 없습니다.
- 모음집에 안 뜨면 UI 로드 순서에 따라 /reload 후 재확인하세요.

데이터 보호
- 별도 애드온이나 WTF를 수정/삭제하지 않습니다.
- 기존 SavedVariablesPerCharacter 이름을 변경하지 않아 옛 가이드 설정을 유지합니다.
- 플레이어가 체크한 퀘스트 ID 목록은 캐릭터별로 저장합니다.


[v1.2.0 추가: 보고 NPC 동선]
- 퀘스트 목표를 완료했지만 아직 NPC 보상을 수령하지 않았다면 [보고 대기]로 표시됩니다.
- 이미 NPC에게 보고한 퀘스트는 [보고 완료]로 표시되며 경로에서 제외됩니다.
- 화면 상단 [보고 대기] 필터로 현재 보고 가능한 퀘스트를 모아 볼 수 있습니다.
- 여러 퀘스트를 체크하고 [보고 대기만 동선]을 누르면 체크한 항목 중 보고 대기만 NPC 방문 순서를 생성합니다.
- [전체 통합 동선]은 진행 중인 수행 퀘스트와 보고 대기 퀘스트를 같이 처리합니다.
- 보고/진행 상태와 위치가 바뀌면 동선이 자동 재계산되며, 보고 완료 시 이전 목적지를 제거합니다.
- 같은 지도 내부의 직선 거리 기반 정렬이며 실제 도로, 장애물, 비행경로, 대륙 이동 최단거리는 보장하지 않습니다.
- 보고 NPC 좌표가 없는 경우 경로에서 없애지 않고 '좌표 미확인'으로 표시합니다.
- 예전 [던전별] 화면과 미니맵/엘스미어 애드온 모음집의 지도 버튼은 그대로 이용할 수 있습니다.
- 명령어: /fdq 보고, /fdq 보고동선


[v1.3.0 추가: 전체 체크 퀘스트 동선 최적화 / 필드 이동 안내 HUD]
- 체크한 여러 퀘스트를 한 번에 묶어 수락·수행·보고 모든 경유지의 총 이동 비용을 최소화하는 순서를 계산합니다. 퀘스트마다 별개 길찾기를 연달아 붙이는 구조가 아닙니다.
- 선행 퀘스트 완료·보고 이전에 후속 수락을 배치하지 않습니다. 하나의 퀘스트에 목표 여러 개가 있으면 모두 보고 전에 처리합니다.
- 최대 11개의 남은 단계는 좌표 기반 비용의 전수 탐색에 준하는 동적 계획법으로 최적 순서를 구하고, 더 큰 목록은 여러 시작 후보와 2-opt / 순서 재배치로 비용을 줄입니다.
- 지역 간 도로/비행/포탈은 실제 경로 데이터를 확보하지 못하면 추정 경유 순서입니다. 실제 지형을 반영한 최단 이동시간을 보장하지 않습니다.
- 동선 시작 시 세계지도와 큰 목록 창은 자동으로 닫히고(지도 자동 열기 없음), 필드 화면에 작은 이동 가이드 HUD가 나타납니다.
- HUD는 마우스로 드래그해 위치 이동, 상단 -/+로 접기/펼치기, x로 숨기기, 전체 버튼으로 큰 창을 다시 열 수 있습니다. 위치와 접기 상태는 캐릭터 설정에 저장됩니다.
- HUD에 현재 목적지, 다음 2개 경유지, 좌표/방향/거리(추정), 이전/다음·지도·전체 동선표 버튼이 표시됩니다.
- 지도는 HUD의 지도 버튼을 눌러 필요할 때만 확인하고, 게임 화면에서 걸어가면서 HUD를 볼 수 있습니다.
- /fdq hud 명령어와 큰 창 하단 이동 안내 버튼으로 HUD 표시를 다시 전환할 수 있습니다.
- 기존 [보고 대기만 동선], 전체 퀘스트 검색, 던전별 분류, 엘스미어 애드온 모음집 아이콘을 보존합니다.
- 개발 환경의 Lua 구문/모의 검사는 게임 내 호환성 확인과 다릅니다. 게임에서 /reload 이후 테스트가 필요합니다.


[v1.4.0: Written zone and NPC directions, adjustable in-world HUD]
- The LEFT HUD shows numbered Korean directions: continent -> zone -> NPC/objective and coordinates -> accept/complete/turn in.
- Instructions use C_Map and QuestieDB waypoint locations; unknown coordinates remain unknown.
- Existing right-hand arrow/navigation add-on stays untouched and separate.
- HUD CFG settings: backdrop transparency 0-85%; numeric width and height fields.
- Drag the bottom-right corner to resize. Width 420-760, height 360-700.
- Scroll instructions with mouse wheel. Only backdrop opacity changes, never text legibility.
- HUD position, collapse state, backdrop opacity and expanded size persist per character across /reload.
- Fallback: /fdq hudcfg; /fdq opacity 40; /fdq size 520 430.
- This is route guidance, not a validated walking/flight/ferry shortest path.
- Real WoW Forever client tests remain pending.

local addon,G=...
local C={bg={.055,.065,.082,.98},panel={.085,.10,.13,.96},gold={.95,.77,.39},cyan={.41,.82,.91},dim={.64,.69,.74},green={.4,.85,.54},gray={.85,.86,.89}}
local frame,searchInput,dataInfo,headerInfo,detailHead,detailPrereqs,guideInfo,guideNow,guideNote,navStatus
local dungeonRows,questRows,hideToggle,incompleteToggle,selectedInfo
local modeButtons={}
local planFrame,planRows,planHeading,planCounter,planPage=nil,nil,nil,nil,0
local dungeonPage,questPage=0,0
local DASH_COLOR={done="|cff7ccf84",active="|cff7dd1ed",ready="|cfff5da80",turnin="|cff56e28e",low="|cffa7a8aa",blocked="|cffbb7777",locked="|cffdbad62",unknown="|cffabb3b7"}
local function label(parent,text,x,y,w,h,size,color)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h)
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
 if color then f:SetTextColor(color[1],color[2],color[3]) end
 if text then f:SetText(text) end
 return f
end
local function panel(parent,x,y,w,h)
 local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h);f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(C.panel))
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetText(text)
 if fn then b:SetScript("OnClick",fn) end
 return b
end
local function row(parent,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent);b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=b:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.12,.15,.19,.54)
 local glow=b:CreateTexture(nil,"HIGHLIGHT");glow:SetAllPoints();glow:SetColorTexture(.35,.40,.43,.22)
 b.marker=b:CreateTexture(nil,"ARTWORK");b.marker:SetPoint("LEFT",b,"LEFT",0,0);b.marker:SetSize(3,h)
 b.marker:SetColorTexture(.31,.36,.39,.8)
 b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 b.text:SetPoint("LEFT",b,"LEFT",9,0);b.text:SetPoint("RIGHT",b,"RIGHT",-4,0)
 b.text:SetJustifyH("LEFT");b.text:SetHeight(h)
 b:SetScript("OnClick",fn)
 return b
end
local function showPage(current,total,perPage)
 local max=math.max(0,math.ceil(total/perPage)-1)
 return math.max(0,math.min(current,max))
end
local function itemTooltip(self,lines)
 if not GameTooltip then return end
 GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
 for i,v in ipairs(lines) do
  if i==1 then GameTooltip:SetText(v) else GameTooltip:AddLine(v,.84,.85,.89,true) end
 end
 GameTooltip:Show()
end
local function filteredQuests(d)
 local ids={}
 if not d then return ids end
 for _,id in ipairs(d.ids) do
  if (G.IsEligibleQuest(id) or not G.db.hideUnavailable)
      and (not G.db.onlyIncomplete or not G.IsCompleted(id)) then ids[#ids+1]=id end
 end
 table.sort(ids,function(a,b)
  local _,as=G.QuestState(a);local _,bs=G.QuestState(b)
  local w={ready=1,active=2,locked=3,low=4,done=5,blocked=6}
  if (w[as] or 9)~=(w[bs] or 9) then return (w[as] or 9)<(w[bs] or 9) end
  return a<b
 end)
 return ids
end
local function prereqString(ids)
 local names={}
 for _,id in ipairs(ids) do
  local abs=math.abs(id)
  local mark=G.IsCompleted(abs) and "|cff75cf86[완료]|r " or "|cffffd06c[미완료]|r "
  names[#names+1]=mark..G.GetQuestName(abs)
 end
 return #names>0 and table.concat(names,"\n") or "없음"
end
local function makeQuestCheckbox(r)
 local check=CreateFrame("CheckButton",nil,r,"UICheckButtonTemplate")
 check:SetSize(25,25)
 check:SetPoint("LEFT",r,"LEFT",5,0)
 check:SetScript("OnClick",function(self)
  if r.quest then G.ToggleQuestChecked(r.quest,self:GetChecked()) end
 end)
 check:SetScript("OnEnter",function(self)
  itemTooltip(self,{"퀘스트 동선에 포함", "체크한 퀘스트는 하나의 동선으로 실시간 재계산됩니다."})
 end)
 check:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
 r.text:ClearAllPoints()
 r.text:SetPoint("LEFT",r,"LEFT",35,0)
 r.text:SetPoint("RIGHT",r,"RIGHT",-4,0)
 r.checkbox=check
end
local function buildUI()
 if frame or not UIParent then return end
 frame=CreateFrame("Frame","ForeverDungeonQuestGuideFrame",UIParent)
 frame:SetSize(1080,734)
 frame:SetPoint("CENTER",UIParent,"CENTER",(G.db.position and G.db.position.x)or 0,(G.db.position and G.db.position.y)or 0)
 frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag("LeftButton")
 frame:SetFrameStrata("DIALOG");frame:SetToplevel(true)
 local base=frame:CreateTexture(nil,"BACKGROUND");base:SetAllPoints();base:SetColorTexture(unpack(C.bg))
 local top=frame:CreateTexture(nil,"BORDER");top:SetPoint("TOPLEFT",0,-1);top:SetPoint("TOPRIGHT",0,-1)
 top:SetHeight(2);top:SetColorTexture(.85,.63,.26)
 frame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 frame:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then G.db.position={x=x-ux,y=y-uy} end
 end)
 label(frame,"FOREVER QUEST ROUTE GUIDE",19,-12,590,28,"GameFontNormalLarge",C.gold)
 label(frame,"전체 퀘스트 검색  ·  여러 퀘스트 통합 동선  ·  이동 중 안내 HUD  ·  던전 분류",20,-43,845,18,"GameFontHighlightSmall",C.dim)
 button(frame,"×",1036,-12,28,28,function()frame:Hide()end)
 label(frame,"검색",20,-80,50,22,"GameFontNormal",C.gold)
 searchInput=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
 searchInput:SetSize(402,25);searchInput:SetPoint("TOPLEFT",frame,"TOPLEFT",73,-77)
 searchInput:SetAutoFocus(false);searchInput:SetText("")
 searchInput:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnTextChanged",function()
  dungeonPage=0;questPage=0
  if G.UIRefresh then G.UIRefresh() end
 end)
 local tabs={{"all","전체 퀘스트"},{"active","진행 중"},{"turnin","보고 대기"},{"dungeon","던전별"},{"selected","체크 목록"}}
 for i,tab in ipairs(tabs) do
  modeButtons[tab[1]]=button(frame,tab[2],489+(i-1)*115,-78,109,27,function()
   G.SetViewMode(tab[1]);questPage=0;dungeonPage=0
  end)
 end
 local left=panel(frame,12,-117,232,487)
 local mid=panel(frame,254,-117,383,487)
 local right=panel(frame,647,-117,421,487)
 label(left,"던전 퀘스트 분류",12,-7,215,24,"GameFontNormal",C.gold)
 hideToggle=button(left,"제한 숨김",8,-32,103,24,function()
  G.db.hideUnavailable=not G.db.hideUnavailable;G.UIRefresh()
 end)
 incompleteToggle=button(left,"완료 제외",119,-32,105,24,function()
  G.db.onlyIncomplete=not G.db.onlyIncomplete;G.UIRefresh()
 end)
 dungeonRows={}
 for i=1,13 do
  dungeonRows[i]=row(left,8,-64-(i-1)*29,216,27,function(self)
   if self.dungeon then G.SetDungeon(self.dungeon);questPage=0;dungeonPage=0 end
  end)
 end
 left.pagination=label(left,"",12,-460,133,20,"GameFontHighlightSmall",C.dim)
 button(left,"◀",164,-458,24,23,function()dungeonPage=math.max(0,dungeonPage-1);G.UIRefresh()end)
 button(left,"▶",193,-458,24,23,function()dungeonPage=dungeonPage+1;G.UIRefresh()end)
 label(mid,"퀘스트 목록 · ☑ 여러 개 선택",12,-7,350,25,"GameFontNormal",C.gold)
 headerInfo=label(mid,"",12,-31,357,27,"GameFontHighlightSmall",C.dim)
 questRows={}
 for i=1,12 do
  local r=row(mid,8,-65-(i-1)*32,366,30,function(self)
   if self.quest then G.SetQuest(self.quest) end
  end)
  makeQuestCheckbox(r);questRows[i]=r
 end
 mid.pagination=label(mid,"",12,-460,226,20,"GameFontHighlightSmall",C.dim)
 button(mid,"◀",314,-458,24,23,function()questPage=math.max(0,questPage-1);G.UIRefresh()end)
 button(mid,"▶",342,-458,24,23,function()questPage=questPage+1;G.UIRefresh()end)
 label(right,"선택 퀘스트 · 선행 관계",12,-7,396,25,"GameFontNormal",C.gold)
 detailHead=label(right,"",12,-34,392,52,"GameFontHighlight",C.cyan)
 detailPrereqs=label(right,"",13,-97,392,205,"GameFontHighlightSmall",C.gray)
 detailPrereqs:SetJustifyV("TOP")
 button(right,"☑ 선택 전체 동선 최적화",10,-311,196,33,function()
  G.StartSelectedGuide()
 end)
 button(right,"✓ 보고 대기만 동선",212,-311,197,33,function()
  G.StartTurninGuide()
 end)
 button(right,"선택 퀘스트 체크",10,-351,194,30,function()
  local id=G.selection.quest
  if not id then G.Print("퀘스트를 선택하세요.");return end
  G.ToggleQuestChecked(id,true)
 end)
 button(right,"퀘스트 위치 표시",210,-351,199,30,function()
  local q=G.selection.quest
  if not q then G.Print("퀘스트를 선택하세요.");return end
  local kind=G.IsReadyToTurnIn(q) and "turnin" or G.IsInLog(q) and "objective" or "accept"
  local p=G.QuestPoint(q,kind)
  if not p and kind=="objective" then
   local obj=G.QuestObjectivePoints(q)
   p=obj[1] and obj[1].point
  end
  if p then G.Navigate(p,true) else G.Print("이 퀘스트의 지도 좌표는 아직 확인되지 않았습니다.") end
 end)
 button(right,"선택 던전 전체 준비 가이드",10,-390,399,31,function()
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil)
  else G.Print("왼쪽에서 던전을 선택하세요.") end
 end)
 selectedInfo=label(right,"",12,-432,258,23,"GameFontHighlightSmall",C.cyan)
 button(right,"체크 전체 해제",275,-429,134,26,function()G.ClearCheckedQuests()end)
 local foot=panel(frame,12,-611,1056,112)
 guideInfo=label(foot,"가이드 대기 중",11,-7,570,21,"GameFontNormal",C.gold)
 guideNow=label(foot,"",11,-34,1014,23,"GameFontHighlightSmall",C.gray)
 guideNote=label(foot,"",11,-80,1020,23,"GameFontHighlightSmall",C.dim)
 navStatus=label(foot,"",11,-58,1020,21,"GameFontHighlightSmall",C.cyan)
 button(foot,"이동 안내",611,-6,74,24,function()G.ToggleHUD()end)
 button(foot,"동선표",689,-6,68,24,function()G.TogglePlanWindow()end)
 button(foot,"◀ 이전",762,-6,83,24,function()G.NextGuide(-1,false)end)
 button(foot,"다음 완료 ▶",849,-6,108,24,function()G.NextGuide(1,true)end)
 button(foot,"중지",961,-6,76,24,function()G.StopGuide()end)
 frame.left=left;frame.mid=mid
 frame:Hide()
end
local function buildPlanUI()
 if planFrame or not UIParent then return end
 planFrame=CreateFrame("Frame","ForeverDungeonQuestGuidePlanFrame",UIParent)
 planFrame:SetSize(555,685);planFrame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 planFrame:SetClampedToScreen(true);planFrame:SetFrameStrata("FULLSCREEN_DIALOG")
 planFrame:SetMovable(true);planFrame:EnableMouse(true);planFrame:RegisterForDrag("LeftButton")
 planFrame:SetScript("OnDragStart",function(self)if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end end)
 planFrame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 local back=planFrame:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(unpack(C.bg))
 planHeading=label(planFrame,"전체 방문 동선",16,-10,480,31,"GameFontNormalLarge",C.gold)
 button(planFrame,"×",518,-11,26,27,function()planFrame:Hide()end)
 label(planFrame,"체크한 모든 퀘스트의 방문 순서 · 걸으면서 보려면 이동 안내 HUD",16,-44,515,23,"GameFontHighlightSmall",C.cyan)
 planRows={}
 for i=1,17 do
  planRows[i]=row(planFrame,11,-81-(i-1)*31,531,29,function(self)
   local gd=G.db and G.db.guide
   if gd and gd.steps and self.guideIndex then
    gd.index=self.guideIndex
    G.ActivateGuideStep(true)
    G.NotifyDataChange()
   end
  end)
 end
 planCounter=label(planFrame,"",16,-616,315,26,"GameFontHighlightSmall",C.dim)
 button(planFrame,"◀ 이전 단계",326,-614,96,26,function()planPage=math.max(0,planPage-1);G.PlanRefresh()end)
 button(planFrame,"다음 단계 ▶",428,-614,115,26,function()planPage=planPage+1;G.PlanRefresh()end)
 label(planFrame,"전체 이동 비용은 좌표 기준 추정. 도로·포탈·비행 경로는 계산하지 않습니다.",16,-645,516,20,"GameFontHighlightSmall",C.dim)
 planFrame:Hide()
end
function G.PlanRefresh()
 if not planFrame or not planFrame:IsShown() then return end
 local gd=G.db and G.db.guide
 if not gd or not gd.steps or #gd.steps==0 then
  planHeading:SetText("진행 중인 동선 없음")
  for _,r in ipairs(planRows)do r:Hide()end
  planCounter:SetText("0 / 0")
  return
 end
 local dungeon=G.GetDungeon(gd.dungeon)
 planHeading:SetText(gd.mode=="selected" and (gd.turninOnly and "보고 대기 퀘스트 방문 동선" or "체크한 퀘스트 통합 동선") or ((dungeon and dungeon.name or "던전").." 준비 동선"))
 planPage=showPage(planPage,#gd.steps,#planRows)
 for i,r in ipairs(planRows) do
  local ix=planPage*#planRows+i
  local st=gd.steps[ix]
  if st then
   r.guideIndex=ix
   local prefix=ix==(gd.index or 1) and "|cffffe07a▶|r" or (tostring(ix)..".")
   local texts={accept="|cff74d7ff[수락]|r",turnin="|cff7cd18d[보고]|r",objective="|cffffd178[수행]|r",entrance="|cffffa36e[입구]|r",inside="|cffacaad4[던전]|r"}
   r.text:SetText(prefix.." "..(texts[st.kind] or "[단계]").." "..st.title..(st.point and " |cff72ce98[지도]|r" or " |cff9ba4aa[좌표 미확인]|r"))
   r.marker:SetColorTexture(ix==(gd.index or 1) and .97 or .22,ix==(gd.index or 1) and .73 or .31,.18,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{st.title,st.note or "",st.point and "클릭하여 지도에 표시" or "좌표가 없습니다"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
   r:Show()
  else r.guideIndex=nil;r:Hide() end
 end
 planCounter:SetText("전체 "..#gd.steps.."단계 · "..(planPage+1).."/"..math.ceil(#gd.steps/#planRows).." 페이지")
end
function G.TogglePlanWindow()
 buildPlanUI()
 if not planFrame then return end
 if planFrame:IsShown() then planFrame:Hide() else planFrame:Show();G.PlanRefresh() end
end
function G.IsUIShown() return frame and frame:IsShown() or false end
function G.UIRefresh()
 if not frame or not G.db then return end
 local mode=G.selection.mode or "all"
 local search=searchInput and searchInput:GetText() or ""
 if dataInfo then
  dataInfo:SetText(G.Ready() and ("QuestieDB 연결 · "..G.QuestIndexStatus()) or "QuestieDB 미연결")
 end
 for key,b in pairs(modeButtons) do
  b:SetText((key==mode and "▶ " or "")..({all="전체 퀘스트",active="진행 중",turnin="보고 대기",dungeon="던전별",selected="체크 목록"})[key])
 end
 local choices=G.SearchDungeons(mode=="dungeon" and search or "")
 dungeonPage=showPage(dungeonPage,#choices,#dungeonRows)
 for i,r in ipairs(dungeonRows) do
  local entry=choices[dungeonPage*#dungeonRows+i]
  if entry then
   local d=entry.dungeon;r.dungeon=d.id;r:Show()
   r.text:SetText((G.selection.dungeon==d.id and "|cffffd77b▶ |r" or "")..d.name.." |cff899aa3("..#d.ids..")|r")
   r.marker:SetColorTexture(G.selection.dungeon==d.id and .94 or .25,G.selection.dungeon==d.id and .75 or .45,.22,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{d.name,"레벨 "..(d.level or "미확인"),d.warning or ("관련 퀘스트 "..#d.ids.."건")})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.dungeon=nil;r:Hide() end
 end
 frame.left.pagination:SetText(#choices==0 and "0개" or ((dungeonPage+1).." / "..math.ceil(#choices/#dungeonRows).." 쪽"))
 hideToggle:SetText(G.db.hideUnavailable and "제한 숨김 ON" or "제한 숨김 OFF")
 incompleteToggle:SetText(G.db.onlyIncomplete and "완료 제외 ON" or "완료 제외 OFF")
 local ids,total,building
 local d=G.GetDungeon(G.selection.dungeon)
 if mode=="dungeon" then
  ids=filteredQuests(d);total=#ids;building=false
 else
  ids,total,building=G.SearchQuestIds(mode,search)
 end
 questPage=showPage(questPage,#ids,#questRows)
 frame.mid.pagination:SetText(#ids==0 and "0개" or ((questPage+1).." / "..math.ceil(#ids/#questRows).." 쪽"))
 local suffix=building and " (목록 구성 중)" or ""
 if mode=="dungeon" then
  headerInfo:SetText(d and ((d.name).." · "..#d.ids.."건") or "왼쪽에서 던전을 선택하세요")
 elseif mode=="all" then
  headerInfo:SetText(search=="" and "이름·ID 검색 / 검색 전에는 진행·체크 목록 표시" or ("검색 결과 "..total.."건"..suffix))
 elseif mode=="active" then
  headerInfo:SetText("퀘스트 창의 진행 중인 퀘스트 "..total.."건")
  elseif mode=="turnin" then
  headerInfo:SetText("목표 완료 · NPC 보고 대기 "..total.."건")
 else headerInfo:SetText("체크한 퀘스트 "..total.."건") end
 for i,r in ipairs(questRows) do
  local id=ids[questPage*#questRows+i]
  if id then
   r.quest=id;r:Show()
   local state,code=G.QuestState(id)
   local name=G.GetQuestName(id)
   local col=DASH_COLOR[code] or "|cffffffff"
   r.checkbox:SetChecked(G.db.selectedQuests[id]==true)
   r.text:SetText((G.selection.quest==id and "|cffffdb76▶ |r" or "")..name.." "..col.."["..state.."]|r")
   r.marker:SetColorTexture(G.selection.quest==id and .98 or .25,G.selection.quest==id and .75 or .40,.20,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{name,"퀘스트 #"..id.." · 최소 "..G.GetQuestMinLevel(id).."레벨",state,"왼쪽 체크박스로 동선에 추가"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.quest=nil;r:Hide() end
 end
 local readyCount=0
 for id,yes in pairs(G.db.selectedQuests or {}) do
  if yes and G.IsReadyToTurnIn(tonumber(id)) then readyCount=readyCount+1 end
 end
 selectedInfo:SetText("☑ "..G.SelectedCount().."개 · 보고 대기 "..readyCount.."개 · 동선 자동 갱신")
 local q=G.selection.quest
 if q then
  local desc=G.QuestDetails(q)
  local lines={"|cffffdc88"..(desc.code=="turnin" and "보고 NPC: " or "수락 NPC: ").."|r "..desc.starter,"|cffffdc88위치:|r "..(desc.coords or "확인 필요"),
     "|cffffdc88레벨:|r "..desc.level.."  |cffffdc88현재:|r "..desc.status}
  if #desc.all>0 then lines[#lines+1]="\n|cffffd89b모두 완료할 선행 (AND):|r\n"..prereqString(desc.all) end
  if #desc.one>0 then lines[#lines+1]="\n|cffffd89b하나만 완료할 선행 (OR):|r\n"..prereqString(desc.one) end
  if #desc.all==0 and #desc.one==0 then lines[#lines+1]="\n|cff83ce90직접 선행 퀘스트 없음|r" end
  if desc.note then lines[#lines+1]="\n|cffffa173주의:|r "..desc.note end
  detailHead:SetText(desc.name.."\n|cffacb5be#"..q.."   |r"..(DASH_COLOR[desc.code] or "")..desc.status.."|r")
  detailPrereqs:SetText(table.concat(lines,"\n"))
 else
  detailHead:SetText("퀘스트를 선택하면 선행 조건을 확인할 수 있습니다.")
  detailPrereqs:SetText("여러 퀘스트를 체크하고 통합 동선 또는 보고 대기만 동선을 선택하세요.\n\n목표 완료는 [보고 대기], NPC 보고 후는 [보고 완료]로 구분합니다.\n\n지도 직선은 참고용이며 실제 길과는 다릅니다.")
 end
 local guide=G.db.guide
 if guide and guide.completed then
  guideInfo:SetText("|cff8be19e보고 동선 완료|r")
  guideNow:SetText("보고 대기 퀘스트가 모두 처리되어 동선을 종료했습니다.")
  guideNote:SetText("체크 목록은 그대로 유지됩니다. 필요하면 다른 퀘스트를 추가하고 다시 시작하세요.")
 elseif guide and guide.steps and #guide.steps>0 then
  local done,count=G.GuideProgress();local step=G.CurrentStep()
  local guideDungeon=G.GetDungeon(guide.dungeon)
  local title=guide.mode=="selected" and (guide.turninOnly and "체크한 퀘스트 보고 동선" or "체크한 퀘스트 통합 동선") or (guideDungeon and guideDungeon.name or "던전 준비")
  local multi=guide.optimization and (" · 체크 "..(guide.optimization.selectedQuestCount or 0).."개 통합") or ""
  guideInfo:SetText("|cffffdc89진행 "..done.."/"..count.."|r  ·  "..title..multi)
  guideNow:SetText(step and ("|cff8adff1다음:|r "..(guide.index or 1)..". "..step.title) or "|cff86d695모든 단계 완료 · 퀘스트 창 확인|r")
  local routeWarning=guide.optimization and guide.optimization.approximate and " · 여러 지역/좌표 미확인: 이동 시간 최적 보장 불가" or ""
  guideNote:SetText(step and ((step.note or "")..routeWarning) or "")
 else
  guideInfo:SetText("가이드 대기 중")
  guideNow:SetText("전체 퀘스트 검색 → 복수 체크 → 모든 퀘스트 통합 최적 동선 시작 → 이동 안내 HUD")
  guideNote:SetText("미확인 좌표는 임의 생성하지 않습니다. 필드 최단 길찾기는 ShortestPathForever 연동이 필요합니다.")
 end
 navStatus:SetText("지도 길찾기: "..(G.navStatus or "대기"))
end
function G.ShowUI(show)
 buildUI();if not frame then return end
 if show==false or (show==nil and frame:IsShown()) then frame:Hide();return end
 frame:Show();G.UIRefresh()
end
function G.ToggleUI() G.ShowUI(nil) end

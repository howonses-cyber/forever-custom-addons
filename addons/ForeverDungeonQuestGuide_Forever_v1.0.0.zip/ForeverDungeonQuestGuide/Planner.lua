local addon,G=...
local function addStep(plan,step)
 step.serial=#plan+1
 plan[#plan+1]=step
end
local function stage(plan,id,kind,label,prereq)
 local title=G.GetQuestName(id)
 if kind=="objective" and G.QuestObjectivePoints then
  local objectives=G.QuestObjectivePoints(id)
  if #objectives>0 then
   for _,objective in ipairs(objectives) do
    local verb=objective.kind=="creature" and "처치" or objective.kind=="object" and "확인" or "획득"
    addStep(plan,{kind=kind,quest=id,title=title.." - "..objective.title.." "..verb,
      questName=title,note="목표 후보 위치입니다. 드랍과 최단경로를 보장하지 않으며, 여러 출현지 중 하나만 표시합니다.",
      prereq=prereq==true,point=objective.point,objectiveId=objective.id})
   end
   return
  end
 end
 local point=G.QuestPoint(id,kind)
 local suffix=kind=="accept" and "수락" or kind=="objective" and "수행" or kind=="turnin" and "보고" or "확인"
 addStep(plan,{kind=kind,quest=id,title=title.." - "..suffix,questName=title,
   note=label or "",prereq=prereq==true,point=point})
end
local function fullyComplete(id)
 return G.IsCompleted(id)
end
local function appendRequired(plan,id,seen,stack,warnings,level)
 if level>25 or stack[id] then warnings[#warnings+1]="선행 연결 순환 또는 25단계 초과: #"..id;return end
 if seen[id] or fullyComplete(id) then return end
 stack[id]=true
 for _,pre in ipairs(G.GetMissingPrereqs(id)) do
  if G.IsEligibleQuest(pre) then appendRequired(plan,pre,seen,stack,warnings,level+1)
  else warnings[#warnings+1]="진영/직업 제한으로 선행 퀘스트 확인 필요: #"..pre end
 end
 stack[id]=nil
 if not seen[id] and not fullyComplete(id) then
  seen[id]=true
  if not G.IsInLog(id) then stage(plan,id,"accept","선행 퀘스트를 수락합니다.",true) end
  stage(plan,id,"objective","퀘스트 목표를 수행합니다. 목표 위치 자료가 없으면 Questie 지도를 확인하세요.",true)
  stage(plan,id,"turnin","완료 NPC에게 보고한 후 다음 연계가 열립니다.",true)
 end
end
local function sortedTargets(d,focusedId)
 local ids={}
 if focusedId then return {focusedId} end
 local currentMap=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 for _,id in ipairs(d.ids) do
  if G.IsEligibleQuest(id) and (not G.db.onlyIncomplete or not G.IsCompleted(id)) then ids[#ids+1]=id end
 end
 -- Important: this is a limited zone-grouping heuristic, not a cross-continent
 -- shortest-path claim. Dependency ordering is enforced separately.
 table.sort(ids,function(a,b)
  local ap=G.QuestPoint(a,"accept");local bp=G.QuestPoint(b,"accept")
  local am=ap and ap.map or 999999;local bm=bp and bp.map or 999999
  if currentMap then
   if am==currentMap and bm~=currentMap then return true end
   if bm==currentMap and am~=currentMap then return false end
  end
  if am~=bm then return am<bm end
  return a<b
 end)
 return ids
end
function G.BuildGuide(dungeonID,questID)
 if not G.Ready() then return nil,"QuestieDB 연결이 필요합니다. QuestieDB를 활성화하고 다시 접속하세요." end
 local d=G.GetDungeon(dungeonID)
 if not d then return nil,"알 수 없는 던전입니다." end
 if #d.ids==0 then return nil,"이 던전의 퀘스트 연계 자료는 아직 검증되지 않았습니다." end
 local targets=sortedTargets(d,questID)
 if #targets==0 then return nil,"현재 캐릭터 조건에 맞는 미완료 퀘스트가 없습니다." end
 local plan,seen,warnings={}, {}, {}
 local queuedPickup={}
 for _,id in ipairs(targets) do
  if not fullyComplete(id) then
   for _,pre in ipairs(G.GetMissingPrereqs(id)) do
    if G.IsEligibleQuest(pre) then appendRequired(plan,pre,seen,{},warnings,1) end
   end
   local special=G.specialQuestMeta[id]
   if not G.IsInLog(id) and not seen[id] and not (special and special.inside) and not queuedPickup[id] then
    queuedPickup[id]=true
    stage(plan,id,"accept","던전에 들어가기 전에 퀘스트를 받으세요.",false)
   end
  end
 end
 -- Drop-started quests cannot be picked up before entering; do not invent points.
 if d.entrance then
  addStep(plan,{kind="entrance",quest=nil,title=d.name.." 던전 지역으로 이동",
   note="표시는 던전 부근 위치입니다. 실제 차원문까지 계단/수중 경로가 추가로 필요할 수 있습니다. 필드 경로는 ShortestPathForever 설치 시에만 계산됩니다.",
   point={map=d.entrance.map,x=d.entrance.x,y=d.entrance.y,name=d.name.." 던전 부근"}})
 end
 local included={}
 for _,id in ipairs(targets) do
  if not fullyComplete(id) and not included[id] then
   included[id]=true
   local special=G.specialQuestMeta[id]
   if special and special.inside then
    addStep(plan,{kind="inside",quest=id,title=G.GetQuestName(id).." - 던전 내부에서 시작",
      note=special.note or "던전 내부에서 얻는 퀘스트입니다. 좌표를 임의 생성하지 않습니다."})
   else
    addStep(plan,{kind="inside",quest=id,title=G.GetQuestName(id).." - 던전에서 진행",
      note="던전 안의 퀘스트 목표를 수행하세요. 보스 경로는 Forever Dungeon Navigator에서 선택하세요."})
   end
  end
 end
 if #plan==0 then return nil,"진행할 단계가 없습니다." end
 return {dungeon=dungeonID,focus=questID,steps=plan,index=1,warnings=warnings},nil
end
local function guide() return G.db and G.db.guide end
function G.StepIsDone(step,idx)
 local g=guide()
 if not step then return false end
 local key=(g and g.dungeon or "none")..":"..(g and g.focus or "all")..":"..idx
 if G.db.manualProgress[key] then return true end
 if not step.quest then return false end
 if G.IsCompleted(step.quest) then return true end
 if step.kind=="accept" then return G.IsInLog(step.quest) end
 if step.kind=="objective" then return G.IsReadyToTurnIn(step.quest) end
 return false
end
function G.ReconcileGuide()
 local g=guide();if not g or type(g.steps)~="table" then return end
 local old=g.index or 1
 while g.index<=#g.steps and G.StepIsDone(g.steps[g.index],g.index) do
  g.index=g.index+1
 end
 if old~=g.index then
  if g.index<=#g.steps then G.ActivateGuideStep(false)
  else G.Print("가이드의 모든 단계가 완료되었습니다. 재확인 후 던전을 진행하세요.") end
 end
 if G.UIRefresh then G.UIRefresh() end
end
function G.ActivateGuideStep(openMap)
 local g=guide();local step=g and g.steps and g.steps[g.index or 1]
 if not step then return end
 if step.point then
  local ok=G.Navigate and G.Navigate(step.point,openMap)
  if not ok and openMap then G.OpenPointMap(step.point) end
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
end
function G.StartGuide(dungeonId,questId)
 local g,err=G.BuildGuide(dungeonId,questId)
 if not g then G.Print(err);return false,err end
 G.db.guide=g
 G.db.manualProgress={}
 G.ReconcileGuide()
 if g.index<=#g.steps then G.ActivateGuideStep(true) end
 G.Print((questId and "선택 퀘스트" or "던전 전체").." 준비 가이드 시작: "..G.GetDungeon(dungeonId).name.." ("..#g.steps.."단계)")
 G.NotifyDataChange()
 return true
end
function G.NextGuide(delta,manual)
 local g=guide();if not g or not g.steps or #g.steps==0 then return end
 local index=g.index or 1
 if manual and delta>0 and index<=#g.steps then
  local key=(g.dungeon or "none")..":"..(g.focus or "all")..":"..index
  G.db.manualProgress[key]=true
 end
 g.index=math.max(1,math.min(#g.steps+1,index+delta))
 if delta>0 then G.ReconcileGuide() end
 if g.index<=#g.steps then G.ActivateGuideStep(false) end
 G.NotifyDataChange()
end
function G.StopGuide()
 G.db.guide={}
 if G.ClearWaypoint then G.ClearWaypoint() end
 G.NotifyDataChange()
end
function G.CurrentStep()
 local g=guide();if not g or not g.steps then return nil end
 return g.steps[g.index or 1]
end
function G.GuideProgress()
 local g=guide()
 if not g or not g.steps or #g.steps==0 then return 0,0 end
 return math.min(g.index-1,#g.steps),#g.steps
end

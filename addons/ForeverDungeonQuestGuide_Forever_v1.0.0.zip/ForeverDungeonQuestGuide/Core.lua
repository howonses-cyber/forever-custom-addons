local addon, G = ...
_G.ForeverDungeonQuestGuide = G
G.addon=addon
G.version="1.0.0"
G.db={}
G.selection={dungeon=nil,quest=nil}
G.player={faction="Alliance",classId=0,level=1}
G.activeQuests={}
G.nameCache={}
G.pendingRefresh=false
G.API={}
function G.Print(msg)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffd9b565[Dungeon Quest Guide]|r "..tostring(msg)) end
end
function G.Clean(s)
 return string.lower(tostring(s or "")):gsub("[%s%p%c]","")
end
function G.SafeCall(fn,...)
 if type(fn)~="function" then return nil end
 local ok,result=pcall(fn,...)
 if ok then return result end
 return nil
end
function G.GetDungeon(id) return G.dungeonById and G.dungeonById[id] end
function G.PlayerRefresh()
 G.player.faction=(UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"
 local classToken,classID
 if type(UnitClass)=="function" then
  local _,token,numericId=UnitClass("player")
  classToken,classID=token,numericId
 end
 if not classID then
  local classes={WARRIOR=1,PALADIN=2,HUNTER=3,ROGUE=4,PRIEST=5,DEATHKNIGHT=6,SHAMAN=7,MAGE=8,WARLOCK=9,MONK=10,DRUID=11}
  classID=classes[classToken] or 0
 end
 G.player.classId=classID or 0
 G.player.level=UnitLevel and (UnitLevel("player") or 1) or 1
end
function G.Ready() return type(QuestDB)=="table" and type(QuestDB.Get)=="function" end
function G.StartSaved()
 if type(ForeverDungeonQuestGuideDB)~="table" then ForeverDungeonQuestGuideDB={} end
 G.db=ForeverDungeonQuestGuideDB
 if G.db.hideUnavailable==nil then G.db.hideUnavailable=true end
 if G.db.onlyIncomplete==nil then G.db.onlyIncomplete=false end
 if G.db.openOnLogin==nil then G.db.openOnLogin=false end
 G.db.manualProgress=G.db.manualProgress or {}
 G.db.position=G.db.position or {}
 G.db.selectedDungeon=G.db.selectedDungeon or "sunken"
 G.db.guide=G.db.guide or {}
 G.selection.dungeon=G.db.selectedDungeon
 G.selection.quest=G.db.selectedQuest
end
function G.RefreshQuestLog()
 wipe(G.activeQuests)
 local num=G.SafeCall(GetNumQuestLogEntries) or (C_QuestLog and G.SafeCall(C_QuestLog.GetNumQuestLogEntries)) or 0
 for i=1,num do
  local title,level,suggested,isHeader,isCollapsed,isComplete,frequency,questID
  if type(GetQuestLogTitle)=="function" then
   title,level,suggested,isHeader,isCollapsed,isComplete,frequency,questID=GetQuestLogTitle(i)
  end
  if C_QuestLog and type(C_QuestLog.GetInfo)=="function" then
   local info=G.SafeCall(C_QuestLog.GetInfo,i)
   if type(info)=="table" then
    questID=info.questID or questID
    title=info.title or title
    if info.isHeader~=nil then isHeader=info.isHeader end
    if info.isComplete~=nil then isComplete=info.isComplete end
   end
  end
  if not isHeader then
   local id=tonumber(questID)
   if not id and C_QuestLog and C_QuestLog.GetQuestIDForLogIndex then id=G.SafeCall(C_QuestLog.GetQuestIDForLogIndex,i) end
   if id and id>0 then G.activeQuests[id]={title=title,complete=isComplete==1 or isComplete==true} end
  end
 end
end
function G.IsCompleted(id)
 if C_QuestLog and type(C_QuestLog.IsQuestFlaggedCompleted)=="function" then
  local ok,done=pcall(C_QuestLog.IsQuestFlaggedCompleted,id)
  if ok and done~=nil then return done==true or done==1 end
 end
 if IsQuestFlaggedCompleted then
  local ok,done=pcall(IsQuestFlaggedCompleted,id)
  if ok and done~=nil then return done==true or done==1 end
 end
 -- Questie stores a character-local completion cache; use only as fallback.
 local q=Questie and Questie.db and Questie.db.char
 if q and q.complete then return q.complete[id]==true end
 return false
end
function G.IsInLog(id) return G.activeQuests[id]~=nil end
function G.IsReadyToTurnIn(id) return G.activeQuests[id] and G.activeQuests[id].complete or false end
function G.QuestState(id)
 if not G.Ready() then return "DB 연결 필요","unknown" end
 if G.IsCompleted(id) then return "완료","done" end
 if G.IsInLog(id) then return G.IsReadyToTurnIn(id) and "보고 가능" or "진행 중", "active" end
 local lv=G.GetQuestMinLevel and G.GetQuestMinLevel(id) or 0
 if G.IsEligibleQuest and not G.IsEligibleQuest(id) then return "진영/직업 제한","blocked" end
 if lv and lv>G.player.level then return "레벨 부족","low" end
 local prereq=G.GetMissingPrereqs and G.GetMissingPrereqs(id) or {}
 if #prereq>0 then return "선행 필요","locked" end
 return "수락 가능","ready"
end
function G.SearchDungeons(text)
 local needle=G.Clean(text); local list={}
 for _,d in ipairs(G.dungeons) do
  local hit=(needle=="" or string.find(G.Clean(d.name),needle,1,true) or string.find(G.Clean(d.aliases),needle,1,true))
  local questHit
  if not hit and needle~="" then
   for _,id in ipairs(d.ids) do
    if string.find(G.Clean(G.GetQuestName(id)),needle,1,true) then questHit=id; break end
    if tostring(id)==needle then questHit=id;break end
   end
  end
  if hit or questHit then list[#list+1]={dungeon=d,matchedQuest=questHit} end
 end
 return list
end
function G.SetDungeon(id)
 local d=G.GetDungeon(id);if not d then return end
 G.selection.dungeon=id;G.selection.quest=nil
 G.db.selectedDungeon=id;G.db.selectedQuest=nil
 if G.UIRefresh then G.UIRefresh() end
end
function G.SetQuest(id)
 G.selection.quest=id
 G.db.selectedQuest=id
 if G.UIRefresh then G.UIRefresh() end
end
function G.StatusLabel()
 local guide=G.db and G.db.guide
 if guide and guide.steps and #guide.steps>0 then
  return tostring(math.min(guide.index or 1,#guide.steps)).."/"..#guide.steps
 end
 return "대기 중"
end
function G.NotifyDataChange()
 if G.UIRefresh then G.UIRefresh() end
 if G.RefreshMapPins then G.RefreshMapPins() end
 if G.PlanRefresh then G.PlanRefresh() end
 if G.HUDRefresh then G.HUDRefresh() end
end
G.API.Open=function(dungeonId,questId)
 if dungeonId and G.GetDungeon(dungeonId) then G.SetDungeon(dungeonId) end
 if questId then G.SetQuest(questId) end
 if G.ShowUI then G.ShowUI(true) end
end
G.API.StartDungeon=function(dungeonId)
 if G.StartGuide then return G.StartGuide(dungeonId,nil) end
 return false
end

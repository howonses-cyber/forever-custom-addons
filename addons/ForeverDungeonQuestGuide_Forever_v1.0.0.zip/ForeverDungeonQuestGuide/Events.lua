local addon,G=...
local controller=CreateFrame("Frame")
local dirty=false
local elapsed=0
local function sync()
 G.PlayerRefresh()
 G.RefreshQuestLog()
 if G.ReconcileGuide then G.ReconcileGuide() end
 G.NotifyDataChange()
end
controller:SetScript("OnEvent",function(self,event,arg1,...)
 if event=="ADDON_LOADED" then
  if arg1==addon then
   G.StartSaved()
   G.PlayerRefresh()
   G.RefreshQuestLog()
  elseif arg1=="QuestieDB" then
   G.nameCache={}
   dirty=true
  elseif arg1=="Blizzard_WorldMap" then
   dirty=true
  end
 elseif event=="PLAYER_LOGIN" then
  G.StartSaved()
  sync()
  local gd=G.db.guide
  if gd and gd.steps and #gd.steps>0 then G.ReconcileGuide() end
  if G.db.openOnLogin then G.ShowUI(true) end
  if not G.Ready() then G.Print("QuestieDB가 없으면 퀘스트/선행 정보가 표시되지 않습니다. QuestieDB 설치 후 /reload 하세요.") end
 elseif event=="QUEST_LOG_UPDATE" or event=="QUEST_ACCEPTED" or event=="QUEST_TURNED_IN" or event=="QUEST_REMOVED" or event=="PLAYER_LEVEL_UP" then
  dirty=true
 elseif event=="ZONE_CHANGED_NEW_AREA" or event=="WORLD_MAP_UPDATE" then
  if G.RefreshMapPins then G.RefreshMapPins() end
 elseif event=="PLAYER_REGEN_ENABLED" then
  if G.OnLeaveCombat then G.OnLeaveCombat() end
 end
end)
controller:SetScript("OnUpdate",function(_,dt)
 elapsed=elapsed+dt
 if elapsed<.5 then return end
 elapsed=0
 if dirty then dirty=false;sync() end
 if G.RefreshMapPins then G.RefreshMapPins() end
end)
for _,ev in ipairs({"ADDON_LOADED","PLAYER_LOGIN","QUEST_LOG_UPDATE","QUEST_ACCEPTED","QUEST_TURNED_IN","QUEST_REMOVED","PLAYER_LEVEL_UP","ZONE_CHANGED_NEW_AREA","PLAYER_REGEN_ENABLED"}) do
 controller:RegisterEvent(ev)
end
-- WORLD_MAP_UPDATE is not available on all Forever-era clients.
if C_EventUtils and C_EventUtils.IsEventValid and C_EventUtils.IsEventValid("WORLD_MAP_UPDATE") then
 controller:RegisterEvent("WORLD_MAP_UPDATE")
end
SLASH_FOREVERDUNGEONQUESTGUIDE1="/fdq"
SLASH_FOREVERDUNGEONQUESTGUIDE2="/던전퀘"
SlashCmdList.FOREVERDUNGEONQUESTGUIDE=function(msg)
 msg=tostring(msg or ""):gsub("^%s+",""):gsub("%s+$","")
 local cmd,rest=msg:match("^(%S+)%s*(.-)$")
 cmd=cmd or ""
 if cmd=="" then G.ToggleUI();return end
 if cmd=="stop" or cmd=="중지" then G.StopGuide();return end
 if cmd=="hud" or cmd=="표시" then if G.ToggleHUD then G.ToggleHUD() end;return end
 if cmd=="steps" or cmd=="동선" then if G.TogglePlanWindow then G.TogglePlanWindow() end;return end
 if cmd=="next" or cmd=="다음" then G.NextGuide(1,true);return end
 if cmd=="map" or cmd=="지도" then
  local step=G.CurrentStep()
  if step and step.point then G.Navigate(step.point,true)
  else G.Print("선택한 단계에는 지도 좌표가 없습니다.") end
  return
 end
 if cmd=="guide" or cmd=="시작" then
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil);G.ShowUI(true)
  else G.Print("먼저 던전을 선택하세요.") end
  return
 end
 if cmd=="quest" or cmd=="퀘스트" then
  local qid=tonumber(rest)
  if qid then
   local id
   for _,d in ipairs(G.dungeons or {}) do
    for _,q in ipairs(d.ids) do if q==qid then id=d.id;break end end
    if id then break end
   end
   if id then G.SetDungeon(id);G.SetQuest(qid);G.ShowUI(true)
   else G.Print("해당 퀘스트는 등록된 던전 목록에 없습니다.") end
  end
  return
 end
 local found=G.SearchDungeons(msg)
 if found and #found>0 then
  G.SetDungeon(found[1].dungeon.id)
  if found[1].matchedQuest then G.SetQuest(found[1].matchedQuest) end
  G.ShowUI(true)
 else G.Print("검색 결과가 없습니다: "..msg);G.ShowUI(true) end
end

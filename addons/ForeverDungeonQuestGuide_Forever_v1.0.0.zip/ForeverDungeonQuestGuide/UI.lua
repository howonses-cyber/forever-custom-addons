local addon,G=...
local C={bg={.055,.065,.082,.98}, panel={.085,.10,.13,.96}, border={.44,.36,.18,.9}, gold={.95,.77,.39}, cyan={.41,.82,.91}, dim={.64,.69,.74}, green={.4,.85,.54}, gray={.85,.86,.89}}
local frame,searchInput,headerInfo,dataInfo,dungeonRows,questRows,detail,detailHead,detailPrereqs,guideInfo,guideNow,guideNote,guideWarn,navStatus
local stepRows,stageTitle,hideToggle,incompleteToggle,startAll,startOne,navButton,guideButton
local planFrame,planRows,planHeading,planCounter,planPage= nil,nil,nil,nil,0
local dungeonPage,questPage,stepPage=0,0,0
local shownDungeons,shownQuestIds={},{ }
local DASH_COLOR={done="|cff7ccf84",active="|cff7dd1ed",ready="|cfff5da80",low="|cffa7a8aa",blocked="|cffbb7777",locked="|cffdbad62",unknown="|cffabb3b7"}
local function label(parent,text,x,y,w,h,size,color)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontHighlightSmall")
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(w,h)
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
 if color then f:SetTextColor(color[1],color[2],color[3]) end
 if text then f:SetText(text) end
 return f
end
local function bg(parent,color,rim)
 local t=parent:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(color));
 if rim then
  local line=parent:CreateTexture(nil,"BORDER")
  line:SetPoint("TOPLEFT",parent,"TOPLEFT",0,-1);line:SetSize(parent:GetWidth() or 1,1);line:SetColorTexture(unpack(rim))
 end
end
local function panel(parent,x,y,w,h)
 local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h);f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(unpack(C.panel))
 return f
end
local function button(parent,text,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetText(text)
 if fn then b:SetScript("OnClick",fn) end
 return b
end
local function row(parent,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent);b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 local t=b:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.12,.15,.19,.54)
 local glow=b:CreateTexture(nil,"HIGHLIGHT");glow:SetAllPoints();glow:SetColorTexture(.35,.40,.43,.22)
 b.marker=b:CreateTexture(nil,"ARTWORK");b.marker:SetPoint("LEFT",b,"LEFT",0,0);b.marker:SetSize(3,h)
 b.marker:SetColorTexture(.31,.36,.39,.8)
 b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 b.text:SetPoint("LEFT",b,"LEFT",9,0);b.text:SetPoint("RIGHT",b,"RIGHT",-4,0)
 b.text:SetJustifyH("LEFT");b.text:SetHeight(h)
 b:SetScript("OnClick",fn)
 return b
end
local function showPage(current,total,perPage)
 local max=math.max(0,math.ceil(total/perPage)-1)
 return math.max(0,math.min(current,max))
end
local function filteredQuests(d)
 local list={}
 if not d then return list end
 for _,id in ipairs(d.ids) do
  local allowed=G.IsEligibleQuest(id)
  if (allowed or not G.db.hideUnavailable) and (not G.db.onlyIncomplete or not G.IsCompleted(id)) then list[#list+1]=id end
 end
 table.sort(list,function(a,b)
  local as=G.QuestState(a);local bs=G.QuestState(b)
  local weight={["수락 가능"]=1,["진행 중"]=2,["보고 가능"]=2,["선행 필요"]=3,["레벨 부족"]=4,["완료"]=5,["진영/직업 제한"]=6}
  local aw,bw=weight[as] or 9,weight[bs] or 9
  if aw~=bw then return aw<bw end
  local al,bl=G.GetQuestMinLevel(a),G.GetQuestMinLevel(b)
  if al~=bl then return al<bl end
  return a<b
 end)
 return list
end
local function prereqString(idList,delimiter)
 local names={}
 for _,id in ipairs(idList) do
  local tag=G.IsCompleted(math.abs(id)) and "|cff75cf86[완료]|r " or "|cffffd06c[미완료]|r "
  names[#names+1]=tag..G.GetQuestName(math.abs(id))
 end
 if #names==0 then return "없음" end
 return table.concat(names,delimiter or ", ")
end
local function itemTooltip(self,lines)
 if not GameTooltip then return end
 GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
 for i,v in ipairs(lines) do
  if i==1 then GameTooltip:SetText(v) else GameTooltip:AddLine(v,.84,.85,.89,true) end
 end
 GameTooltip:Show()
end
local function buildUI()
 if frame or not UIParent then return end
 frame=CreateFrame("Frame","ForeverDungeonQuestGuideFrame",UIParent)
 frame:SetSize(1080,734);frame:SetPoint("CENTER",UIParent,"CENTER",(G.db.position and G.db.position.x) or 0,(G.db.position and G.db.position.y) or 0)
 frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag("LeftButton")
 frame:SetFrameStrata("DIALOG");frame:SetToplevel(true)
 local base=frame:CreateTexture(nil,"BACKGROUND");base:SetAllPoints();base:SetColorTexture(unpack(C.bg))
 local top=frame:CreateTexture(nil,"BORDER");top:SetPoint("TOPLEFT",0,-1);top:SetPoint("TOPRIGHT",0,-1);top:SetHeight(2);top:SetColorTexture(.85,.63,.26)
 frame:SetScript("OnDragStart",function(self) if not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end end)
 frame:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
  if x and y and ux and uy then G.db.position={x=x-ux,y=y-uy} end
 end)
 label(frame,"FOREVER DUNGEON QUEST GUIDE",19,-12,580,28,"GameFontNormalLarge",C.gold)
 label(frame,"던전 검색  →  선행 퀘스트  →  수락 동선  →  지도 길찾기",20,-43,780,18,"GameFontHighlightSmall",C.dim)
 button(frame,"×",1036,-12,28,28,function()frame:Hide()end)
 label(frame,"검색",20,-80,50,22,"GameFontNormal",C.gold)
 searchInput=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
 searchInput:SetSize(410,25);searchInput:SetPoint("TOPLEFT",frame,"TOPLEFT",73,-77)
 searchInput:SetAutoFocus(false);searchInput:SetText("")
 searchInput:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
 searchInput:SetScript("OnTextChanged",function(self)
  dungeonPage=0;questPage=0
  local text=self:GetText()
  local choices=G.SearchDungeons(text)
  if #choices==1 and choices[1].matchedQuest then
   G.selection.dungeon=choices[1].dungeon.id
   G.selection.quest=choices[1].matchedQuest
   G.db.selectedDungeon=G.selection.dungeon
   G.db.selectedQuest=G.selection.quest
  end
  if G.UIRefresh then G.UIRefresh() end
 end)
 local status=label(frame,"/fdq   ·   /fdq 학카르",495,-78,535,24,"GameFontHighlightSmall",C.dim)
 dataInfo=status
 local left=panel(frame,12,-117,232,487)
 local mid=panel(frame,254,-117,383,487)
 local right=panel(frame,647,-117,421,487)
 label(left,"던전 목록",12,-7,177,25,"GameFontNormal",C.gold)
 local dungeonPagination=label(left,"",12,-460,140,20,"GameFontHighlightSmall",C.dim)
 button(left,"◀",164,-458,24,23,function()dungeonPage=math.max(0,dungeonPage-1);G.UIRefresh()end)
 button(left,"▶",193,-458,24,23,function()dungeonPage=dungeonPage+1;G.UIRefresh()end)
 dungeonRows={}
 for i=1,14 do
  local r=row(left,8,-40-(i-1)*29,216,27,function(self)
   if self.dungeon then G.SetDungeon(self.dungeon);questPage=0;stepPage=0 end
  end)
  dungeonRows[i]=r
 end
 left.pagination=dungeonPagination
 frame.dungeonPagination=dungeonPagination
 label(mid,"퀘스트 목록 · 현재 캐릭터 기준",12,-7,340,25,"GameFontNormal",C.gold)
 headerInfo=label(mid,"",12,-31,358,24,"GameFontHighlightSmall",C.dim)
 local questPagination=label(mid,"",12,-460,170,20,"GameFontHighlightSmall",C.dim)
 button(mid,"◀",314,-458,24,23,function()questPage=math.max(0,questPage-1);G.UIRefresh()end)
 button(mid,"▶",342,-458,24,23,function()questPage=questPage+1;G.UIRefresh()end)
 questRows={}
 for i=1,12 do
  local r=row(mid,8,-65-(i-1)*32,366,30,function(self) if self.quest then G.SetQuest(self.quest) end end)
  questRows[i]=r
 end
 mid.pagination=questPagination
 frame.questPagination=questPagination
 label(right,"선택 퀘스트 · 선행 관계",12,-7,396,25,"GameFontNormal",C.gold)
 detailHead=label(right,"",12,-34,392,52,"GameFontHighlight",C.cyan)
 detailPrereqs=label(right,"",13,-97,392,205,"GameFontHighlightSmall",C.gray)
 detailPrereqs:SetJustifyV("TOP")
 button(right,"이 퀘스트 가이드 시작",10,-330,187,31,function()
  local d=G.selection.dungeon;local id=G.selection.quest
  if d and id then G.StartGuide(d,id) else G.Print("퀘스트를 선택하세요.") end
 end)
 button(right,"퀘스트 위치 표시",204,-330,205,31,function()
  local q=G.selection.quest
  if not q then G.Print("퀘스트를 선택하세요.");return end
  local state=G.QuestState(q)
  local p=G.QuestPoint(q,G.IsInLog(q) and "turnin" or "accept")
  if p then G.Navigate(p,true) else G.Print("현재 퀘스트의 지도 좌표가 없습니다. Questie 지도를 확인하세요.") end
  G.UIRefresh()
 end)
 button(right,"선택 던전 전체 준비 가이드 시작",10,-374,399,33,function()
  if G.selection.dungeon then G.StartGuide(G.selection.dungeon,nil) end
 end)
 local explain=label(right,"실제 필드 경로는 ShortestPathForever 연결 시 계산됩니다.",12,-413,397,36,"GameFontHighlightSmall",C.dim)
 explain:SetJustifyV("TOP")
 local foot=panel(frame,12,-611,1056,112)
 guideInfo=label(foot,"가이드 대기 중",11,-7,740,21,"GameFontNormal",C.gold)
 guideNow=label(foot,"던전을 검색하고 가이드 시작을 눌러 주세요.",11,-34,1014,23,"GameFontHighlightSmall",C.gray)
 guideNote=label(foot,"",11,-80,1020,23,"GameFontHighlightSmall",C.dim)
 navStatus=label(foot,"",11,-58,1020,21,"GameFontHighlightSmall",C.cyan)
 button(foot,"HUD",626,-6,58,24,function()G.ToggleHUD()end)
 button(foot,"동선표",690,-6,68,24,function()G.TogglePlanWindow()end)
 button(foot,"◀ 이전",762,-6,83,24,function()G.NextGuide(-1,false)end)
 button(foot,"다음 완료 ▶",849,-6,108,24,function()G.NextGuide(1,true)end)
 button(foot,"중지",961,-6,76,24,function()G.StopGuide()end)
 -- Option controls at the top of the list, not hidden behind UI scroll panels.
 hideToggle=button(frame,"진영/직업 제한 숨김",645,-78,195,25,function()
  G.db.hideUnavailable=not G.db.hideUnavailable;G.UIRefresh()
 end)
 incompleteToggle=button(frame,"완료 퀘스트 제외",843,-78,189,25,function()
  G.db.onlyIncomplete=not G.db.onlyIncomplete;G.UIRefresh()
 end)
 frame:Hide()
end

-- Readable, clickable full stage list; not limited to the one current instruction.
local function buildPlanUI()
 if planFrame or not UIParent then return end
 planFrame=CreateFrame("Frame","ForeverDungeonQuestGuidePlanFrame",UIParent)
 planFrame:SetSize(555,685)
 planFrame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 planFrame:SetClampedToScreen(true);planFrame:SetFrameStrata("FULLSCREEN_DIALOG")
 planFrame:SetMovable(true);planFrame:EnableMouse(true);planFrame:RegisterForDrag("LeftButton")
 planFrame:SetScript("OnDragStart",function(self)self:StartMoving()end)
 planFrame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
 local back=planFrame:CreateTexture(nil,"BACKGROUND");back:SetAllPoints();back:SetColorTexture(unpack(C.bg))
 planHeading=label(planFrame,"전체 준비 동선",16,-10,480,31,"GameFontNormalLarge",C.gold)
 button(planFrame,"×",518,-11,26,27,function()planFrame:Hide()end)
 label(planFrame,"원하는 단계 클릭 → 현재 목적지로 지정 · 지도 표시",16,-44,515,23,"GameFontHighlightSmall",C.cyan)
 planRows={}
 for i=1,17 do
  local r=row(planFrame,11,-81-(i-1)*31,531,29,function(self)
   local gd=G.db and G.db.guide
   if gd and gd.steps and self.guideIndex then
    gd.index=self.guideIndex
    G.ActivateGuideStep(true)
    G.NotifyDataChange()
   end
  end)
  planRows[i]=r
 end
 planCounter=label(planFrame,"",16,-616,315,26,"GameFontHighlightSmall",C.dim)
 button(planFrame,"◀ 이전 단계",326,-614,96,26,function()
  planPage=math.max(0,planPage-1)
  G.PlanRefresh()
 end)
 button(planFrame,"다음 단계 ▶",428,-614,115,26,function()
  planPage=planPage+1
  G.PlanRefresh()
 end)
 label(planFrame,"연속 직선 표시는 경유지 표시일 뿐, 통행 가능한 길 보장은 아닙니다.",16,-645,516,20,"GameFontHighlightSmall",C.dim)
 planFrame:Hide()
end
function G.PlanRefresh()
 if not planFrame or not planFrame:IsShown() then return end
 local gd=G.db and G.db.guide
 if not gd or not gd.steps or #gd.steps==0 then
  planHeading:SetText("가이드 없음 · 먼저 시작 버튼을 눌러주세요.")
  for _,r in ipairs(planRows)do r:Hide()end
  planCounter:SetText("단계 0 / 0")
  return
 end
 local dungeon=G.GetDungeon(gd.dungeon)
 planHeading:SetText((dungeon and dungeon.name or "던전").." 전체 준비 동선")
 planPage=showPage(planPage,#gd.steps,#planRows)
 for i,r in ipairs(planRows) do
  local idx=planPage*#planRows+i
  local st=gd.steps[idx]
  if st then
   r.guideIndex=idx
   local prefix=(idx==(gd.index or 1)) and "|cffffe07a▶|r" or tostring(idx).."."
   local typeText={accept="|cff74d7ff[수락]|r",turnin="|cff7cd18d[보고]|r",objective="|cffffd178[수행]|r",entrance="|cffffa36e[입구]|r",inside="|cffacaad4[던전]|r"}
   local mark=(st.point and " |cff72ce98[지도]|r") or " |cff9ba4aa[위치 확인]|r"
   r.text:SetText(prefix.." "..(typeText[st.kind] or "[단계]").." "..st.title..mark)
   r.marker:SetColorTexture(idx==(gd.index or 1) and .97 or .22,idx==(gd.index or 1) and .73 or .31,.18,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{st.title,st.note or "",st.point and "클릭하여 지도 표시" or "좌표가 확인되지 않았습니다"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
   r:Show()
  else r.guideIndex=nil;r:Hide() end
 end
 planCounter:SetText("전체 "..#gd.steps.."단계  ·  "..(planPage+1).." / "..math.ceil(#gd.steps/#planRows).." 페이지")
end
function G.TogglePlanWindow()
 buildPlanUI()
 if not planFrame then return end
 if planFrame:IsShown() then planFrame:Hide() else planFrame:Show();G.PlanRefresh() end
end
function G.UIRefresh()
 if not frame then return end
 if dataInfo then dataInfo:SetText(G.Ready() and ("퀘스트 DB 연결 · 레벨 "..tostring(G.player.level).." · "..(G.player.faction=="Alliance" and "얼라이언스" or "호드")) or "|cffff9988QuestieDB 없음: 퀘스트·선행 데이터 로드 필요|r") end
 local text=searchInput and searchInput:GetText() or ""
 shownDungeons=G.SearchDungeons(text)
 dungeonPage=showPage(dungeonPage,#shownDungeons,#dungeonRows)
 for i,r in ipairs(dungeonRows) do
  local rowData=shownDungeons[dungeonPage*#dungeonRows+i]
  if rowData then
   local d=rowData.dungeon;r.dungeon=d.id;r:Show()
   r.text:SetText((G.selection.dungeon==d.id and "|cffffd77b▶ |r" or "")..d.name.." |cff899aa3("..#d.ids..")|r")
   r.marker:SetColorTexture(G.selection.dungeon==d.id and .94 or .25,G.selection.dungeon==d.id and .75 or .45,.22,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{d.name,"레벨 "..(d.level or "미확인"),d.warning or "연관 퀘스트 "..#d.ids.."건"})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.dungeon=nil;r:Hide() end
 end
 frame.dungeonPagination:SetText(#shownDungeons==0 and "0개" or (dungeonPage+1).." / "..math.max(1,math.ceil(#shownDungeons/#dungeonRows)).." 쪽")
 local d=G.GetDungeon(G.selection.dungeon)
 shownQuestIds=filteredQuests(d)
 questPage=showPage(questPage,#shownQuestIds,#questRows)
 frame.questPagination:SetText(#shownQuestIds==0 and "0개" or (questPage+1).." / "..math.max(1,math.ceil(#shownQuestIds/#questRows)).." 쪽")
 if d then
  local counts={ready=0,done=0,locked=0}
  for _,id in ipairs(shownQuestIds) do
   local _,code=G.QuestState(id)
   if code=="ready"then counts.ready=counts.ready+1 elseif code=="done"then counts.done=counts.done+1 elseif code=="locked"then counts.locked=counts.locked+1 end
  end
  headerInfo:SetText("레벨 "..(d.level or "미확인").."  ·  관련 "..#d.ids.."건  ·  수락 가능 "..counts.ready.."  ·  선행 필요 "..counts.locked)
 else headerInfo:SetText("왼쪽에서 던전을 선택하세요.") end
 for i,r in ipairs(questRows) do
  local id=shownQuestIds[questPage*#questRows+i]
  if id then
   r.quest=id;r:Show()
   local state,code=G.QuestState(id)
   local col=DASH_COLOR[code] or "|cffffffff"
   local name=G.GetQuestName(id)
   r.text:SetText((G.selection.quest==id and "|cffffdb76▶ |r" or "")..name.."  "..col.."["..state.."]|r")
   r.marker:SetColorTexture(G.selection.quest==id and .98 or .25,G.selection.quest==id and .75 or .40,.20,1)
   r:SetScript("OnEnter",function(self)itemTooltip(self,{name,"퀘스트 ID "..id.." / 최소 "..G.GetQuestMinLevel(id).."레벨",state})end)
   r:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
  else r.quest=nil;r:Hide() end
 end
 local q=G.selection.quest
 if q then
  local desc=G.QuestDetails(q)
  local all,one=desc.all,desc.one
  local details={"|cffffdc88수락 NPC:|r "..desc.starter,
    "|cffffdc88위치:|r "..(desc.coords or "미확인"),
    "|cffffdc88최소 수락 레벨:|r "..desc.level,
    "|cffffdc88선행 상태:|r "..desc.status}
  if #all>0 then details[#details+1]="\n|cffffd89b모두 완료해야 하는 선행 (AND):|r\n"..prereqString(all,"\n") end
  if #one>0 then details[#details+1]="\n|cffffd89b다음 중 하나의 선행 (OR):|r\n"..prereqString(one,"\n") end
  if #all==0 and #one==0 then details[#details+1]="\n|cff83ce90직접적인 선행 퀘스트 없음|r" end
  if desc.note then details[#details+1]="\n|cffffa173주의:|r "..desc.note end
  detailHead:SetText(desc.name.."\n|cffacb5be#"..q.."   |r"..(DASH_COLOR[desc.code] or "")..desc.status.."|r")
  detailPrereqs:SetText(table.concat(details,"\n"))
 else
  detailHead:SetText("퀘스트를 선택하면 여기서\n선행 관계와 수락 조건을 볼 수 있어.")
  detailPrereqs:SetText("진행 동선은 먼저 선행퀘스트를 정렬하고, 현재 퀘스트 상태를 확인하여 생성됩니다.\n\n현재 던전 안에서 시작되는 아이템 퀘스트는 자동 경로를 만들지 않습니다.")
 end
 local g=G.db.guide
 if g and g.steps and #g.steps>0 then
  local done,total=G.GuideProgress()
  local step=G.CurrentStep()
  guideInfo:SetText("|cffffdc89가이드 진행 "..done.."/"..total.."|r  ·  "..(G.GetDungeon(g.dungeon) and G.GetDungeon(g.dungeon).name or "던전"))
  if step then guideNow:SetText("|cff8adff1다음:|r "..(step.serial or g.index)..". "..step.title)
  else guideNow:SetText("|cff86d695모든 준비 단계를 확인했어. 던전 입장을 점검해!|r") end
  guideNote:SetText(step and (step.note or "") or "")
 else
  guideInfo:SetText("가이드 대기 중")
  guideNow:SetText("던전 또는 퀘스트 선택 → 가이드 시작 → 지도에 목표 표시")
  guideNote:SetText("가이드가 시작되면 해당 단계의 수락/보고/입구 위치를 안내해.")
 end
 if navStatus then navStatus:SetText("지도 길찾기: "..(G.navStatus or "대기")) end
 hideToggle:SetText(G.db.hideUnavailable and "제한 퀘스트 숨김: ON" or "제한 퀘스트 숨김: OFF")
 incompleteToggle:SetText(G.db.onlyIncomplete and "완료 퀘스트 제외: ON" or "완료 퀘스트 제외: OFF")
end
function G.ShowUI(show)
 buildUI();if not frame then return end
 if show==false or (show==nil and frame:IsShown()) then frame:Hide();return end
 frame:Show();G.UIRefresh()
end
function G.ToggleUI() G.ShowUI(nil) end

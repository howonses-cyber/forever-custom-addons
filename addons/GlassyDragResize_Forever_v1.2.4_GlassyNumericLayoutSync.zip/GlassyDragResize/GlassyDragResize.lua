-- Glassy Drag Resize 1.2.4 - WoW Forever 1.60.1 (Interface 16001)
-- Glassy owns the main container; Blizzard owns each detached ChatFrame.
-- IMPORTANT: A chat TAB is not a detached chat WINDOW. We never resize tab labels.
-- GlassyFrame is only the message panel. GlassyMoverFrame is the layout
-- owner (including the edit box) and therefore the actual OUTER corner.
-- The grip is anchored directly to the mover, never to GlassyFrame plus
-- guessed pixel offsets or persisted grip displacement.
-- The grip uses Blizzard's native sizing when possible. OnUpdate watches the
-- actual left-button state so a lost OnMouseUp / OnDragStop cannot latch resizing.

local _G = _G
local math_floor, math_min, math_max = math.floor, math.min, math.max
local type, tonumber, tostring, pairs, pcall = type, tonumber, tostring, pairs, pcall
local panes = {}
local mainPane, dragging, options
local started, saved = false, nil
local scanElapsed, loginAge = 0, 0
local MIN_W, MIN_H = 220, 110
local MAX_W, MAX_H = 2000, 1200
local EDGE = 6
local GRIP_SIZE = 17
local KEY_MAIN = "main"
local OpenOptions, RefreshOptions
local SyncDetachedLayout, VerifyDetachedLayout

local function Inform(s)
    local chat = _G.DEFAULT_CHAT_FRAME
    if chat and chat.AddMessage then
        chat:AddMessage("|cff91a9c2[Glassy 크기]|r " .. tostring(s))
    end
end

local function Combat()
    return type(_G.InCombatLockdown) == "function" and _G.InCombatLockdown()
end

local function Glassy()
    local core = _G.Glassy
    if type(core) == "table" and core.db and core.db.profile and
        type(core.Dispatch) == "function" then return core end
end

local function ChatName(i)
    if type(_G.GetChatWindowInfo) == "function" then
        local name = _G.GetChatWindowInfo(i)
        if type(name) == "string" and name ~= "" then return name end
    end
    return "ChatFrame" .. tostring(i)
end

local function Key(i)
    return tostring(i) .. ":" .. ChatName(i)
end

local function Undocked(f)
    if not f or not f.IsShown or not f:IsShown() or f.isDocked or f.minimized then
        return false
    end
    return (f:GetWidth() or 0) > 20 and (f:GetHeight() or 0) > 20
end

local function Alive(pane)
    if not pane or not pane.target or not pane.target.IsShown then return false end
    if pane.main then return pane.target:IsShown() and Glassy() ~= nil end
    return Undocked(pane.target)
end

local function Scale(f)
    local s = f.GetEffectiveScale and f:GetEffectiveScale()
    if type(s) ~= "number" or s <= 0 then
        s = _G.UIParent and _G.UIParent:GetEffectiveScale() or 1
    end
    if type(s) ~= "number" or s <= 0 then return 1 end
    return s
end

local function Bounds(f)
    local root = _G.UIParent
    if not root then return MAX_W, MAX_H end
    local right = root:GetRight() or (root:GetWidth() or 1920)
    local bottom = root:GetBottom() or 0
    local left, top = f:GetLeft(), f:GetTop()
    local width = left and right - left - EDGE or MAX_W
    local height = top and top - bottom - EDGE or MAX_H
    return math_max(MIN_W, math_min(MAX_W, math_floor(width))),
           math_max(MIN_H, math_min(MAX_H, math_floor(height)))
end

local function Dimensions(pane)
    if pane.main then
        local core = Glassy()
        if core then
            return tonumber(core.db.profile.frameWidth) or pane.target:GetWidth(),
                   tonumber(core.db.profile.frameHeight) or pane.target:GetHeight()
        end
    end
    return pane.target:GetWidth(), pane.target:GetHeight()
end

local function AnchorTopLeft(target)
    -- This is needed only for numeric adjustments or the manual fallback.
    -- Native Blizzard StartSizing retains the opposite corner by itself.
    local parent = _G.UIParent
    local left, top = target:GetLeft(), target:GetTop()
    if not parent or not left or not top then return false end
    local pLeft, pTop = parent:GetLeft() or 0, parent:GetTop() or 0
    target:ClearAllPoints()
    target:SetPoint("TOPLEFT", parent, "TOPLEFT", left - pLeft, top - pTop)
    if type(target.SetUserPlaced) == "function" then target:SetUserPlaced(true) end
    return true
end

local function SaveDetached(pane)
    if pane.main or not Undocked(pane.target) then return end
    local f, i = pane.target, pane.index
    local w, h = math_floor(f:GetWidth() + 0.5), math_floor(f:GetHeight() + 0.5)
    if saved then
        saved.windows = saved.windows or {}
        saved.windows[Key(i)] = {width = w, height = h}
    end
    if type(_G.FCF_SavePositionAndDimensions) == "function" then
        if pcall(_G.FCF_SavePositionAndDimensions, f) then return end
    end
    if type(_G.SetChatWindowSavedDimensions) == "function" then
        pcall(_G.SetChatWindowSavedDimensions, i, w, h)
    end
end

local function CommitMain(w, h)
    local core = Glassy()
    if not core then return false end
    local profile = core.db.profile
    if profile.frameWidth ~= w then
        profile.frameWidth = w
        core:Dispatch("Glassy/UPDATE_CONFIG", "frameWidth")
    end
    if profile.frameHeight ~= h then
        profile.frameHeight = h
        core:Dispatch("Glassy/UPDATE_CONFIG", "frameHeight")
    end
    return true
end

local function SnapshotDetached()
    local result = {}
    for index, pane in pairs(panes) do
        if Undocked(pane.target) then
            result[index] = {pane.target:GetWidth(), pane.target:GetHeight()}
        end
    end
    return result
end

local function PreserveDetached(snap)
    -- A Glassy version or UI mod may have a shared-layout update listener.
    -- Guard against changing unrelated detached windows on a main resize.
    if not snap then return end
    for index, size in pairs(snap) do
        local pane = panes[index]
        if pane and Undocked(pane.target) and
           (math_floor(pane.target:GetWidth() + 0.5) ~= math_floor(size[1] + 0.5) or
            math_floor(pane.target:GetHeight() + 0.5) ~= math_floor(size[2] + 0.5)) then
            pane.target:SetSize(size[1], size[2])
            SaveDetached(pane)
        end
    end
end

local function FinishDrag()
    local state = dragging
    if not state then return end
    -- Clear state FIRST so callbacks triggered by StopMovingOrSizing cannot latch.
    dragging = nil
    local target, pane = state.pane.target, state.pane
    if state.native and type(target.StopMovingOrSizing) == "function" then
        pcall(target.StopMovingOrSizing, target)
    end
    if pane.main then
        if Glassy() then
            local w, h = math_floor(target:GetWidth() + 0.5),
                         math_floor(target:GetHeight() + 0.5)
            CommitMain(w, h)  -- One config commit on release; not every mouse pixel.
            PreserveDetached(state.detached)
        end
    elseif Undocked(target) then
        if SyncDetachedLayout then
            SyncDetachedLayout(pane, target:GetWidth(), target:GetHeight())
        end
        SaveDetached(pane)
    end
    if options and options.IsShown and options:IsShown() and RefreshOptions then
        RefreshOptions(false)
    end
end

local function SetupNativeBounds(frame)
    if type(frame.SetResizable) == "function" then
        pcall(frame.SetResizable, frame, true)
    end
    if type(frame.SetResizeBounds) == "function" then
        pcall(frame.SetResizeBounds, frame, MIN_W, MIN_H, MAX_W, MAX_H)
    elseif type(frame.SetMinResize) == "function" then
        pcall(frame.SetMinResize, frame, MIN_W, MIN_H)
        if type(frame.SetMaxResize) == "function" then
            pcall(frame.SetMaxResize, frame, MAX_W, MAX_H)
        end
    end
end

local function StartDrag(pane)
    if dragging or Combat() or not Alive(pane) then return end
    local x, y = _G.GetCursorPosition()
    if not x or not y then return end
    local w, h = Dimensions(pane)
    if not w or not h then return end
    local target = pane.target
    local state = {pane = pane, x = x, y = y, width = w, height = h,
                   scale = Scale(target), elapsed = 0, native = false}
    pane.resizeGeneration = (pane.resizeGeneration or 0) + 1
    if pane.main then state.detached = SnapshotDetached() end

    -- StartSizing is Blizzard's actual chat-frame resize mechanism. It handles
    -- mouse capture and the anchored opposite corner more naturally.
    if not pane.main and type(target.StartSizing) == "function" and
       type(target.StopMovingOrSizing) == "function" then
        SetupNativeBounds(target)
        state.native = pcall(target.StartSizing, target, "BOTTOMRIGHT")
    end
    if not state.native and not pane.main then
        if not AnchorTopLeft(target) then return end
    end
    dragging = state
end

local function DragStep(elapsed)
    local state = dragging
    if not state then return end
    state.elapsed = state.elapsed + (elapsed or 0)
    if Combat() or not Alive(state.pane) then FinishDrag(); return end

    -- The old implementation could remain stuck forever when its overlay lost
    -- OnMouseUp/OnDragStop. Check the physical mouse button on EVERY update.
    if type(_G.IsMouseButtonDown) == "function" and state.elapsed > 0.03 then
        local ok, down = pcall(_G.IsMouseButtonDown, "LeftButton")
        if ok and not down then FinishDrag(); return end
    end
    if state.native then
        -- Keep Glassy's detached panel in step with native sizing, but avoid
        -- rebuilding all message rows on every single rendered frame.
        state.visualElapsed = (state.visualElapsed or 0) + (elapsed or 0)
        if state.visualElapsed >= 0.06 then
            state.visualElapsed = 0
            local cw, ch = state.pane.target:GetWidth(), state.pane.target:GetHeight()
            if SyncDetachedLayout and cw and ch and
               (cw ~= state.lastW or ch ~= state.lastH) then
                state.lastW, state.lastH = cw, ch
                SyncDetachedLayout(state.pane, cw, ch)
            end
        end
        return
    end

    local x, y = _G.GetCursorPosition()
    if not x or not y then return end
    local maxW, maxH = Bounds(state.pane.target)
    local w = math_floor(math_min(math_max(MIN_W, state.width + (x - state.x) / state.scale), maxW) + 0.5)
    local h = math_floor(math_min(math_max(MIN_H, state.height + (state.y - y) / state.scale), maxH) + 0.5)
    if w == state.lastW and h == state.lastH then return end
    state.lastW, state.lastH = w, h
    if state.pane.main then
        -- GlassyMoverFrame reads frameWidth/frameHeight from the profile.
        -- Updating the profile here makes both the outer border and grip
        -- follow the cursor immediately, instead of lagging until release.
        CommitMain(w, h)
    else
        state.pane.target:SetSize(w, h)
        if SyncDetachedLayout then SyncDetachedLayout(state.pane, w, h) end
    end
end

-- Root cause of the 1.2.1/1.2.2 screenshot mismatch:
-- the sizing button was attached to GlassyFrame (inner message panel) and
-- then shifted by guessed offsets, while a saved offset could override those
-- guesses. GlassyMoverFrame is the canonical FULL layout region used by
-- Glassy itself: its bottom-right follows chat + edit-box geometry.
local function GripAnchor(pane)
    if not pane.main then return pane.target end
    local mover = _G.GlassyMoverFrame
    if mover and type(mover.GetWidth) == "function" and
       type(mover.GetHeight) == "function" then
        return mover
    end
    return pane.target -- only until Glassy finishes initializing its mover
end

local function PositionGrip(pane, force)
    if not pane or not pane.grip then return end
    local anchor = GripAnchor(pane)
    -- BOTTOMRIGHT of the grip must coincide with BOTTOMRIGHT of the
    -- OUTER root, not with its center or the inner message container.
    -- An anchor follows layout changes without polling coordinate math.
    if not force and pane.gripAnchor == anchor then return end
    pane.gripAnchor = anchor
    pane.grip:ClearAllPoints()
    pane.grip:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", 0, 0)
end

local function CreateGrip(target, index, main)
    -- Parent the tiny button directly to UIParent, rather than to a full-size
    -- overlay over the chat. The grip is still clickable if the visual corner
    -- extends below GlassyFrame, and does not intercept chat clicks elsewhere.
    local grip = _G.CreateFrame("Button", nil, _G.UIParent)
    grip:SetSize(GRIP_SIZE, GRIP_SIZE)
    grip:SetFrameStrata("DIALOG")
    grip:SetFrameLevel(math_max(10, (target:GetFrameLevel() or 1) + 12))
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    if type(grip.RegisterForClicks) == "function" then
        grip:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    end
    if type(grip.SetNormalTexture) == "function" then
        grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
        grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
        grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    else
        -- Older frame templates without texture setters still get a triangle.
        for i = 0, 2 do
            local line = grip:CreateTexture(nil, "OVERLAY")
            line:SetColorTexture(0.80, 0.88, 0.95, 0.90)
            line:SetSize(2, 5 + i * 3)
            line:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", -3 - i * 4, 3)
        end
    end
    grip:SetAlpha(0.40)
    local pane = {index = index, main = main, target = target,
                  grip = grip, restoredKey = nil}
    PositionGrip(pane, true)
    grip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then StartDrag(pane) end
    end)
    grip:SetScript("OnDragStart", function()
        if not dragging then StartDrag(pane) end
    end)
    grip:SetScript("OnMouseUp", function(_, button)
        if button == "LeftButton" then
            if dragging and dragging.pane == pane then FinishDrag() end
        elseif button == "RightButton" and OpenOptions then
            if dragging then FinishDrag() end
            OpenOptions(pane)
        end
    end)
    grip:SetScript("OnDragStop", function()
        if dragging and dragging.pane == pane then FinishDrag() end
    end)
    grip:SetScript("OnEnter", function(self)
        self:SetAlpha(1)
        if _G.GameTooltip then
            _G.GameTooltip:SetOwner(self, "ANCHOR_TOP")
            _G.GameTooltip:AddLine("채팅창 크기 조절", 0.93, 0.96, 1)
            _G.GameTooltip:AddLine("좌클릭 드래그 / 우클릭 수치 입력", 0.80, 0.85, 0.91)
            _G.GameTooltip:Show()
        end
    end)
    grip:SetScript("OnLeave", function(self)
        self:SetAlpha(0.40)
        if _G.GameTooltip then _G.GameTooltip:Hide() end
    end)
    return pane
end

local function RestoreDetached(pane)
    if not saved or not saved.windows or Combat() or loginAge < 1 then return end
    if not Undocked(pane.target) then
        pane.restoredKey = nil -- can restore separately after docking/undocking
        return
    end
    local key = Key(pane.index)
    if pane.restoredKey == key then return end
    local size = saved.windows[key]
    if size then
        local w, h = tonumber(size.width), tonumber(size.height)
        if w and h and w >= MIN_W and h >= MIN_H then
            local nw, nh = math_min(w, MAX_W), math_min(h, MAX_H)
            pane.target:SetSize(nw, nh)
            if SyncDetachedLayout then
                local ok = SyncDetachedLayout(pane, nw, nh)
                if not ok then return end -- Glassy UIManager may still be initializing.
            end
        end
    end
    pane.restoredKey = key
end

local function Scan()
    local limit = math_max(10, tonumber(_G.NUM_CHAT_WINDOWS) or 10) + 20
    for i = 2, limit do
        local target = _G["ChatFrame" .. i]
        if target then
            local current = panes[i]
            if current and current.target ~= target then
                if dragging and dragging.pane == current then FinishDrag() end
                current.grip:Hide()
                panes[i] = nil
                current = nil
            end
            if not current and Undocked(target) then
                current = CreateGrip(target, i, false)
                panes[i] = current
            end
            if current then RestoreDetached(current) end
        end
    end
end

local function TryStart()
    if not started then
        if not Glassy() or not _G.GlassyFrame or not _G.UIParent then return end
        if type(_G.GlassyDragResizeDB) ~= "table" then _G.GlassyDragResizeDB = {} end
        saved = _G.GlassyDragResizeDB
        if type(saved.windows) ~= "table" then saved.windows = {} end
        -- Retire inaccurate manually calibrated offsets from versions 1.2.1/2.
        -- Detached window dimensions and all other personal settings remain.
        saved.gripPlacement = nil
        mainPane = CreateGrip(_G.GlassyFrame, 1, true)
        started = true
    end
    Scan()
end

local function OrderedPanes()
    local result = {}
    if Alive(mainPane) then result[#result+1] = mainPane end
    local indices = {}
    for index, pane in pairs(panes) do
        if Alive(pane) then indices[#indices+1] = index end
    end
    table.sort(indices)
    for _, index in ipairs(indices) do result[#result+1] = panes[index] end
    return result
end

local function PaneLabel(pane)
    if pane.main then return "기본 채팅창 (Glassy)" end
    return "분리 채팅창 " .. pane.index .. " - " .. ChatName(pane.index)
end

-- Glassy renders detached chat in a DIFFERENT frame from ChatFrameN:
-- UIManager:GetChatWindow(...).detachedLayout.container and slidingMessageFrame.
-- Changing the Blizzard ChatFrame dimensions alone is not evidence that the
-- visible Glassy window was resized. This was the false-success bug in v1.2.3.
local function GlassyWindow(pane)
    if not pane or pane.main then return nil, nil end
    local core = Glassy()
    if not core or type(core.GetModule) ~= "function" then return nil, nil end
    local ok, manager = pcall(core.GetModule, core, "UIManager", true)
    if not ok or not manager or type(manager.GetChatWindow) ~= "function" then
        return nil, nil
    end
    local found, window = pcall(manager.GetChatWindow, manager, pane.target)
    if not found then return nil, nil end
    if not window and type(manager.RefreshChatFrameLayout) == "function" then
        pcall(manager.RefreshChatFrameLayout, manager, pane.target)
        found, window = pcall(manager.GetChatWindow, manager, pane.target)
        if not found then window = nil end
    end
    return window, manager
end

local function VisualBounds(pane)
    local window = GlassyWindow(pane)
    if not window then return nil, nil, nil, nil end
    local layout = window.detachedLayout
    local container = layout and layout.container
    local renderer = window.slidingMessageFrame
    if not container or not renderer then return nil, nil, nil, nil end
    return container, renderer, window, layout
end

local function DockHeight(layout)
    local height = layout and layout.dock and layout.dock.GetHeight and layout.dock:GetHeight()
    if type(height) ~= "number" or height < 1 or height > 70 then return 20 end
    return height
end

SyncDetachedLayout = function(pane, width, height)
    if pane.main or not Undocked(pane.target) then return false, "분리된 채팅창이 아닙니다." end
    local container, renderer, window, layout = VisualBounds(pane)
    if not container or not renderer then
        return false, "Glassy 분리 창의 실제 표시 프레임을 찾지 못했습니다. /reload 후 다시 시도하세요."
    end
    local header = DockHeight(layout)
    -- Rebind to the actual native window. Rebuilding the anchors also repairs
    -- stale detached layout references left by Glassy/EUI/FCF resizes.
    local ok, err = pcall(function()
        container:ClearAllPoints()
        -- ONE top-left anchor, followed by explicit size. If the original
        -- BOTTOMRIGHT anchor is retained, WoW may keep the OLD size from two
        -- constraining anchors and silently ignore SetSize. This was a key
        -- cause of a native 300x160 chat with a visually 400px-wide panel.
        container:SetPoint("TOPLEFT", pane.target, "TOPLEFT", 0, header)
        container:SetSize(width, height + header)
        if window.editBox and type(window.editBox.SetGlassyParent) == "function" then
            window.editBox:SetGlassyParent(container, true)
        end
        renderer:SetLayout(container, width, height + header, window.editBox or false, container)
    end)
    if not ok then return false, "Glassy 표시창 갱신 오류: " .. tostring(err) end
    return true
end

VerifyDetachedLayout = function(pane, width, height)
    if not Undocked(pane.target) then return false, "분리 창이 닫혔습니다." end
    local actualW, actualH = pane.target:GetWidth(), pane.target:GetHeight()
    if not actualW or not actualH or math.abs(actualW - width) > 1 or math.abs(actualH - height) > 1 then
        return false, "게임 채팅창 크기가 반영되지 않았습니다 (" ..
            tostring(math_floor((actualW or 0) + 0.5)) .. "x" .. tostring(math_floor((actualH or 0) + 0.5)) .. ")."
    end
    local container, renderer, _, layout = VisualBounds(pane)
    if not container or not renderer then return false, "Glassy 실제 표시 프레임을 찾지 못했습니다." end
    local visualW, visualH = container:GetWidth(), container:GetHeight()
    local renderW = renderer.GetWidth and renderer:GetWidth()
    local internalW, internalH = tonumber(renderer.layoutWidth), tonumber(renderer.layoutHeight)
    local expectedH = height + DockHeight(layout)
    if not visualW or not visualH or math.abs(visualW - width) > 1 or math.abs(visualH - expectedH) > 1 or
       not internalW or not internalH or math.abs(internalW - width) > 1 or math.abs(internalH - expectedH) > 1 or
       (type(renderW) == "number" and math.abs(renderW - width) > 1) then
        return false, "Glassy 표시 크기가 다릅니다 (표시 " ..
            tostring(math_floor((visualW or 0) + 0.5)) .. "x" .. tostring(math_floor((visualH or 0) + 0.5)) ..
            ", 내부 " .. tostring(math_floor((internalW or 0) + 0.5)) .. "x" ..
            tostring(math_floor((internalH or 0) + 0.5)) .. ")."
    end
    return true
end

-- Glassy uses C_Timer.After(0) for some layout work. Verify AFTER that
-- scheduler has run; retry the visible-layout sync once before reporting an
-- error. Never print success merely because ChatFrameN:SetSize was called.
local function ConfirmDetached(pane, width, height, originalW, originalH, generation, notify)
    local function finish(ok, message)
        if pane.resizeGeneration ~= generation then return end
        if ok then
            SaveDetached(pane)
        else
            -- Keep the user's last known-good dimensions if visible layout
            -- cannot be synchronized. Do not persist a half-applied size.
            pcall(pane.target.SetSize, pane.target, originalW, originalH)
            SyncDetachedLayout(pane, originalW, originalH)
        end
        if notify then notify(ok, message) end
    end
    local function inspect(second)
        if pane.resizeGeneration ~= generation then return end
        if not Alive(pane) then finish(false, "채팅창이 닫히거나 합쳐졌습니다."); return end
        local ok, errorText = VerifyDetachedLayout(pane, width, height)
        if ok then finish(true, "실제 표시 크기 " .. width .. " x " .. height .. " 확인 완료"); return end
        if second then finish(false, errorText); return end
        local synced, syncErr = SyncDetachedLayout(pane, width, height)
        if not synced then finish(false, syncErr); return end
        if _G.C_Timer and type(_G.C_Timer.After) == "function" then
            _G.C_Timer.After(0.12, function() inspect(true) end)
        else
            inspect(true)
        end
    end
    if _G.C_Timer and type(_G.C_Timer.After) == "function" then
        _G.C_Timer.After(0.08, function() inspect(false) end)
    else
        inspect(false)
    end
end

local function ApplySize(pane, width, height, notify)
    if Combat() then return false, "전투 중에는 크기를 변경할 수 없습니다." end
    if not Alive(pane) then return false, "닫혔거나 메인에 합쳐진 채팅창입니다." end
    local w, h = tonumber(width), tonumber(height)
    if not w or not h or w ~= w or h ~= h then
        return false, "가로와 세로에 숫자를 입력하세요."
    end
    w, h = math_floor(w + 0.5), math_floor(h + 0.5)
    local maxW, maxH = Bounds(pane.target)
    if w < MIN_W or h < MIN_H or w > maxW or h > maxH then
        return false, "허용 범위: 가로 " .. MIN_W .. "~" .. maxW .. ", 세로 " .. MIN_H .. "~" .. maxH
    end
    if dragging then FinishDrag() end
    if pane.main then
        local snap = SnapshotDetached()
        -- Update Glassy ONLY for main; detached windows are owned by Blizzard.
        if not CommitMain(w, h) then return false, "Glassy 설정을 확인할 수 없습니다." end
        PreserveDetached(snap)
    else
        if not VisualBounds(pane) then
            return false, "Glassy 분리 창의 실제 표시 프레임을 찾지 못했습니다. /reload 후 다시 시도하세요."
        end
        local prevW, prevH = pane.target:GetWidth(), pane.target:GetHeight()
        if not AnchorTopLeft(pane.target) then return false, "창 위치를 확인할 수 없습니다." end
        pane.resizeGeneration = (pane.resizeGeneration or 0) + 1
        local generation = pane.resizeGeneration
        local setOK, setErr = pcall(pane.target.SetSize, pane.target, w, h)
        if not setOK then return false, "게임 채팅창 크기 변경 실패: " .. tostring(setErr) end
        local synced, err = SyncDetachedLayout(pane, w, h)
        if not synced then
            pcall(pane.target.SetSize, pane.target, prevW, prevH)
            return false, err
        end
        ConfirmDetached(pane, w, h, prevW, prevH, generation, notify)
        return true, nil, "pending"
    end
    return true
end

local function Text(parent, size, x, y, color)
    local f = parent:CreateFontString(nil, "OVERLAY", size and "GameFontNormalLarge" or "GameFontNormal")
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    if color and f.SetTextColor then f:SetTextColor(color[1], color[2], color[3]) end
    return f
end

local function Button(parent, text, x, y, w, h, callback)
    local b = _G.CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, h)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", callback)
    return b
end

local function Edit(parent, x, y)
    local e = _G.CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    e:SetSize(76, 24)
    e:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    if type(e.SetAutoFocus) == "function" then e:SetAutoFocus(false) end
    if type(e.SetNumeric) == "function" then e:SetNumeric(true) end
    if type(e.SetMaxLetters) == "function" then e:SetMaxLetters(4) end
    if type(e.SetJustifyH) == "function" then e:SetJustifyH("CENTER") end
    return e
end

local function SelectedPane()
    return options and options.list and options.list[options.selected]
end

RefreshOptions = function(rebuild)
    if not options then return end
    local pane = SelectedPane()
    local keep = pane and pane.index or options.wantedIndex or 1
    if rebuild then
        options.list = OrderedPanes()
        options.selected = 1
        for i, candidate in ipairs(options.list) do
            if candidate.index == keep then options.selected = i; break end
        end
    end
    pane = SelectedPane()
    if not pane then
        options.target:SetText("열린 채팅창이 없습니다.")
        options.width:SetText("")
        options.height:SetText("")
        return
    end
    local w, h = Dimensions(pane)
    options.target:SetText(PaneLabel(pane) .. " (" .. options.selected .. "/" .. #options.list .. ")")
    options.width:SetText(tostring(math_floor((w or 0) + 0.5)))
    options.height:SetText(tostring(math_floor((h or 0) + 0.5)))
    if options.message then options.message:SetText("") end
end

local function EnsureOptions()
    if options then return options end
    local panel = _G.CreateFrame("Frame", "GlassyDragResizeOptions", _G.UIParent)
    panel:SetSize(360, 228)
    panel:SetPoint("CENTER", _G.UIParent, "CENTER", 0, 0)
    panel:SetFrameStrata("DIALOG")
    panel:SetFrameLevel(150)
    panel:EnableMouse(true)
    if type(panel.SetMovable) == "function" then panel:SetMovable(true) end
    if type(panel.RegisterForDrag) == "function" then panel:RegisterForDrag("LeftButton") end
    panel:SetScript("OnDragStart", function(self)
        if not Combat() and type(self.StartMoving) == "function" then self:StartMoving() end
    end)
    panel:SetScript("OnDragStop", function(self)
        if type(self.StopMovingOrSizing) == "function" then self:StopMovingOrSizing() end
    end)
    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(panel)
    bg:SetColorTexture(0.075, 0.095, 0.13, 0.96)
    for _, edge in ipairs({"TOP", "BOTTOM", "LEFT", "RIGHT"}) do
        local border = panel:CreateTexture(nil, "BORDER")
        border:SetColorTexture(0.24, 0.31, 0.41, 0.90)
        if edge == "TOP" then border:SetPoint("TOPLEFT"); border:SetPoint("TOPRIGHT"); border:SetHeight(1)
        elseif edge == "BOTTOM" then border:SetPoint("BOTTOMLEFT"); border:SetPoint("BOTTOMRIGHT"); border:SetHeight(1)
        elseif edge == "LEFT" then border:SetPoint("TOPLEFT"); border:SetPoint("BOTTOMLEFT"); border:SetWidth(1)
        else border:SetPoint("TOPRIGHT"); border:SetPoint("BOTTOMRIGHT"); border:SetWidth(1) end
    end
    local heading = Text(panel, true, 20, -18)
    heading:SetText("채팅창 크기 설정")
    local sub = Text(panel, false, 20, -51, {0.72, 0.79, 0.89})
    sub:SetText("손잡이: 채팅창 우하단 직접 드래그 / 우클릭: 수치 입력")
    panel.target = Text(panel, false, 52, -91)
    panel.target:SetText("")
    Button(panel, "<", 18, -83, 28, 26, function()
        if #panel.list < 1 then return end
        panel.selected = (panel.selected - 2) % #panel.list + 1
        RefreshOptions(false)
    end)
    Button(panel, ">", 314, -83, 28, 26, function()
        if #panel.list < 1 then return end
        panel.selected = panel.selected % #panel.list + 1
        RefreshOptions(false)
    end)
    local labelW = Text(panel, false, 36, -139)
    labelW:SetText("가로")
    local labelH = Text(panel, false, 195, -139)
    labelH:SetText("세로")
    panel.width = Edit(panel, 74, -131)
    panel.height = Edit(panel, 232, -131)
    panel.message = Text(panel, false, 18, -170, {0.94, 0.72, 0.49})
    panel.message:SetText("")
    local function Submit()
        local pane = SelectedPane()
        if not pane then return end
        local w, h = tonumber(panel.width:GetText()), tonumber(panel.height:GetText())
        local function showResult(confirmed, detail)
            if options == panel and panel:IsShown() and SelectedPane() == pane then
                RefreshOptions(false)
                panel.message:SetText((confirmed and "적용 확인 - " or "적용 실패 - ") .. detail)
            end
            if not confirmed then Inform(detail) end
        end
        local ok, err, pending = ApplySize(pane, w, h, showResult)
        if ok then
            if type(panel.width.ClearFocus) == "function" then panel.width:ClearFocus() end
            if type(panel.height.ClearFocus) == "function" then panel.height:ClearFocus() end
            if pending == "pending" then
                panel.message:SetText("실제 Glassy 채팅창 크기 확인 중...")
            else
                showResult(true, PaneLabel(pane))
            end
        else
            panel.message:SetText("적용 실패 - " .. tostring(err))
            Inform(err)
        end
    end
    Button(panel, "적용", 188, -190, 72, 26, Submit)
    Button(panel, "닫기", 269, -190, 72, 26, function() panel:Hide() end)
    panel.width:SetScript("OnEnterPressed", Submit)
    panel.height:SetScript("OnEnterPressed", Submit)
    panel.width:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    panel.height:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    panel:SetScript("OnShow", function() RefreshOptions(true) end)
    panel:Hide()
    panel.list = {}
    panel.selected = 1
    options = panel
    return panel
end

OpenOptions = function(wanted)
    TryStart()
    if not started then Inform("Glassy 로딩을 기다린 뒤 다시 실행해 주세요."); return end
    local panel = EnsureOptions()
    panel.wantedIndex = wanted and wanted.index or (SelectedPane() and SelectedPane().index) or 1
    -- Rebuild on every open to discover newly detached or recombined windows.
    panel.list = OrderedPanes()
    panel.selected = 1
    for i, pane in ipairs(panel.list) do
        if pane.index == panel.wantedIndex then panel.selected = i; break end
    end
    RefreshOptions(false)
    panel:Show()
end

local driver = _G.CreateFrame("Frame")
driver:RegisterEvent("PLAYER_LOGIN")
driver:RegisterEvent("PLAYER_ENTERING_WORLD")
driver:RegisterEvent("UPDATE_CHAT_WINDOWS")
driver:SetScript("OnEvent", function() TryStart() end)
driver:SetScript("OnUpdate", function(_, dt)
    loginAge = loginAge + (dt or 0)
    if dragging then DragStep(dt) end
    scanElapsed = scanElapsed + (dt or 0)
    if scanElapsed >= 0.5 then
        scanElapsed = 0
        TryStart()
        if mainPane then PositionGrip(mainPane) end
    end
    if not started then return end
    if mainPane then
        if Alive(mainPane) and not Combat() then mainPane.grip:Show()
        else mainPane.grip:Hide() end
    end
    for _, pane in pairs(panes) do
        if Alive(pane) and not Combat() then pane.grip:Show()
        else pane.grip:Hide() end
    end
    if options and options:IsShown() and options.list and SelectedPane() and not Alive(SelectedPane()) then
        RefreshOptions(true)
    end
end)

_G.SLASH_GLASSYDRAGRESIZE1 = "/gdr"
_G.SLASH_GLASSYDRAGRESIZE2 = "/채팅크기"
_G.SlashCmdList.GLASSYDRAGRESIZE = function(arg)
    arg = (arg or ""):match("^%s*(.-)%s*$")
    local cmd = arg:lower()
    TryStart()
    if cmd == "debug" then
        if not mainPane then Inform("Glassy 프레임 초기화 대기 중"); return end
        local anchor = GripAnchor(mainPane)
        local frame = mainPane.target
        local function N(x) return x and tostring(math_floor(x + 0.5)) or "?" end
        local function P(f)
            return "R=" .. N(f and f.GetRight and f:GetRight()) ..
                   " B=" .. N(f and f.GetBottom and f:GetBottom())
        end
        Inform("손잡이 기준=" .. (anchor == _G.GlassyMoverFrame and "GlassyMoverFrame" or "GlassyFrame") ..
               " 외곽(" .. P(anchor) .. ") 본문(" .. P(frame) .. ")")
        for _, pane in ipairs(OrderedPanes()) do
            if not pane.main then
                local c, renderer = VisualBounds(pane)
                Inform("창" .. tostring(pane.index) .. " 기본=" .. N(pane.target:GetWidth()) .. "x" .. N(pane.target:GetHeight()) ..
                       " Glassy=" .. (c and N(c:GetWidth()) .. "x" .. N(c:GetHeight()) or "없음") ..
                       " 메시지=" .. (renderer and N(renderer.layoutWidth) .. "x" .. N(renderer.layoutHeight) or "없음"))
            end
        end
        return
    end
    if cmd == "status" then
        local count = 0
        for _, pane in pairs(panes) do if Undocked(pane.target) then count = count + 1 end end
        Inform("Glassy=" .. tostring(Glassy() ~= nil) .. ", 분리 창=" .. count .. ", 버전=1.2.4")
        return
    end
    if cmd == "help" then
        Inform("/gdr : 수치 설정 | /gdr main 600 250 | /gdr 3 400 230 | /gdr status | /gdr debug")
        return
    end
    local index, width, height = cmd:match("^(%S+)%s+(%d+)%s+(%d+)$")
    if index then
        local idx = index == KEY_MAIN and 1 or tonumber(index)
        local pane = idx == 1 and mainPane or panes[idx or -1]
        if not pane then Inform("해당 채팅창을 찾을 수 없습니다. /gdr 를 열어 목록을 확인하세요."); return end
        local ok, err, pending = ApplySize(pane, width, height, function(confirmed, detail)
            Inform((confirmed and "적용 확인: " or "적용 실패: ") .. PaneLabel(pane) .. ": " .. detail)
        end)
        if not ok then Inform(err)
        elseif pending ~= "pending" then Inform(PaneLabel(pane) .. " " .. width .. " x " .. height .. " 적용") end
        return
    end
    OpenOptions()
end

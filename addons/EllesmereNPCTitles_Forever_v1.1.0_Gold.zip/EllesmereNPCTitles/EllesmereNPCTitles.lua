-- EllesmereNPCTitles - standalone companion for EllesmereUI Nameplates / WoW Forever
-- Does not overwrite original EllesmereUI code, nameplate health bars, or CVars.
-- Licensed as original companion code; not a redistribution of EllesmereUI.

local ADDON = ...
local eventFrame = CreateFrame("Frame")
local activeByUnit = {}  -- unit token -> Ellesmere friendly plate (while title shown)
local db
local enabled = true
local DEFAULT_SIZE = 10

local function IsSecret(value)
    return issecretvalue and issecretvalue(value) or false
end

local function Say(message)
    print("|cff0cd29f[EUI NPC Titles]|r " .. tostring(message))
end

local function Namespace()
    local eui = EllesmereUI
    if not eui or not eui._ModuleNS then return nil end
    return eui._ModuleNS["EllesmereUINameplates"]
end

local function Profile(ns)
    return ns and ns.db and ns.db.profile
end

-- Uses EllesmereUI's existing, version-appropriate method for NPC subtitles:
-- C_TooltipInfo.GetUnit(unit), second tooltip line (colorblind offset included).
local function GetNPCTitle(unit)
    if not (C_TooltipInfo and C_TooltipInfo.GetUnit) then return nil end
    local ok, data = pcall(C_TooltipInfo.GetUnit, unit)
    if not ok or not data or not data.lines then return nil end
    local cb = (GetCVar and tonumber(GetCVar("colorblindMode"))) or 0
    local line = data.lines[2 + cb]
    if not line then return nil end
    local text = line.leftText
    if not text or IsSecret(text) or type(text) ~= "string" or text == "" then
        return nil
    end
    -- Ignore the character-level line. It is not a vendor/guard/trainer title.
    local template = UNIT_LEVEL_TEMPLATE or "Level %d"
    local pattern = template:lower():gsub("%%d", "(.+)")
    if text:lower():match(pattern) then return nil end
    return text
end

local function TitleSize(ns)
    if db and db.size then return db.size end
    local fp = Profile(ns)
    local size = fp and fp.friendlyNPCTitleSize
    if type(size) == "number" then return math.max(8, math.min(24, size)) end
    return DEFAULT_SIZE
end

local function RestoreName(plate)
    if not plate or not plate._enpctMoved then return end
    plate._enpctMoved = nil
    if plate.name and plate.health then
        -- Respect EllesmereUI's guild-line offset for recycled player plates.
        local original = plate._subOff or 4
        pcall(plate.name.SetPoint, plate.name, "BOTTOM", plate.health, "TOP", 0, original)
    end
end

local function ClearPlate(plate)
    if not plate then return end
    if plate._enpctTitle then
        plate._enpctTitle:Hide()
        plate._enpctTitle:SetText("")
    end
    RestoreName(plate)
    local previousUnit = plate._enpctUnit
    if previousUnit then
        activeByUnit[previousUnit] = nil
        plate._enpctUnit = nil
    end
end

local function ApplyFont(fontString, ns, size)
    if ns and ns.SetFSFont then
        local ok = pcall(ns.SetFSFont, fontString, size, "OUTLINE, SLUG")
        if ok then return end
    end
    local font = (ns and ns.GetFont and ns.GetFont()) or STANDARD_TEXT_FONT
    pcall(fontString.SetFont, fontString, font, size, "OUTLINE")
end

-- Separate NPC role-title color from the green EUI NPC-name/healthbar color.
-- 'gold' is a deep warm gold (#DBA626), chosen for clear contrast.
local TITLE_COLORS = {
    gold   = { 0.86, 0.65, 0.15 },  -- dark gold (#DBA626), default
    yellow = { 1.00, 0.82, 0.24 },  -- lighter yellow-gold (#FFD13D)
    white  = { 0.90, 0.90, 0.90 },
}

local function StyleTitle(fontString, unit, ns, size)
    ApplyFont(fontString, ns, size)
    local colorName = db and db.color or "gold"
    local color = TITLE_COLORS[colorName] or TITLE_COLORS.gold
    fontString:SetTextColor(color[1], color[2], color[3], 1)
    fontString:SetJustifyH("CENTER")
    fontString:SetJustifyV("MIDDLE")
    fontString:SetWordWrap(false)
    fontString:SetMaxLines(1)
end

local function PositionTitle(plate, fontString, size, moved)
    -- Fully bounded rectangle between name and healthbar. This geometry avoids
    -- the single-point font positioning issues in recent WoW nameplate clients.
    fontString:ClearAllPoints()
    if moved then
        fontString:SetPoint("TOPLEFT", plate.health, "TOP", -150, size + 4)
        fontString:SetPoint("BOTTOMRIGHT", plate.health, "TOP", 150, 2)
    else
        -- Fallback: if the client blocks moving Ellesmere's name, place the
        -- subtitle ABOVE the name so the health bar remains unobstructed.
        fontString:SetPoint("TOPLEFT", plate.health, "TOP", -150, size * 2 + 17)
        fontString:SetPoint("BOTTOMRIGHT", plate.health, "TOP", 150, size + 15)
    end
end

local RefreshPlate -- forward declaration (hooks below)

local function HookPlate(plate)
    if plate._enpctHooked then return end
    plate._enpctHooked = true
    -- Name changes / profile refreshes: EUI updates its name first, then we
    -- adjust the extra line. No global nameplate or protected template hooks.
    if type(plate.UpdateName) == "function" then
        pcall(hooksecurefunc, plate, "UpdateName", function(self)
            if RefreshPlate then RefreshPlate(self) end
        end)
    end
    -- The same EUI frame can be recycled for another NPC or for a player.
    if type(plate.ClearUnit) == "function" then
        pcall(hooksecurefunc, plate, "ClearUnit", function(self)
            ClearPlate(self)
        end)
    end
end

RefreshPlate = function(plate)
    if not plate or not plate.health or not plate.name then return end
    local unit = plate.unit
    local ns = Namespace()
    local fp = Profile(ns)
    -- EUI only uses its custom friendly health bars when friendlyNameOnly is
    -- false. Leave name-only mode and player/hostile nameplates unchanged.
    if not enabled or not unit or not ns or not fp or
       fp.friendlyNameOnly ~= false or fp.showFriendlyNPCs ~= true then
        ClearPlate(plate)
        return
    end
    if UnitExists and not UnitExists(unit) then ClearPlate(plate); return end
    if UnitIsPlayer then
        local ok, isPlayer = pcall(UnitIsPlayer, unit)
        if not ok or IsSecret(isPlayer) or isPlayer then
            ClearPlate(plate)
            return
        end
    end
    local title = GetNPCTitle(unit)
    if not title then ClearPlate(plate); return end
    if plate._enpctUnit and plate._enpctUnit ~= unit then ClearPlate(plate) end

    local fontString = plate._enpctTitle
    if not fontString then
        fontString = plate:CreateFontString(nil, "OVERLAY")
        plate._enpctTitle = fontString
    end
    local size = TitleSize(ns)
    StyleTitle(fontString, unit, ns, size)
    fontString:SetText("<" .. title .. ">")

    -- EUI positions the NPC name 4px above its bar. Lift the name to make a
    -- separate line without resizing, hiding, or recreating the original bar.
    local shift = size + 8
    local ok = pcall(plate.name.SetPoint, plate.name, "BOTTOM", plate.health, "TOP", 0, shift)
    if ok then plate._enpctMoved = true end
    local rectOK = pcall(PositionTitle, plate, fontString, size, ok)
    if not rectOK then
        -- Never leave a new line half-attached when the client forbids it.
        ClearPlate(plate)
        return
    end
    plate._enpctUnit = unit
    activeByUnit[unit] = plate
    fontString:Show()
end

local function ScanOne(unit)
    local ns = Namespace()
    local plate = ns and ns.friendlyPlates and ns.friendlyPlates[unit]
    if plate then
        HookPlate(plate)
        RefreshPlate(plate)
    end
end

local function ScanAll()
    local ns = Namespace()
    if not (ns and ns.friendlyPlates) then return end
    for unit, plate in pairs(ns.friendlyPlates) do
        if plate then
            HookPlate(plate)
            RefreshPlate(plate)
        end
    end
    -- Remove overlays that EUI no longer associates with a unit token.
    for unit, plate in pairs(activeByUnit) do
        if ns.friendlyPlates[unit] ~= plate then
            ClearPlate(plate)
        end
    end
end

local function RefreshAll()
    if not enabled then
        for unit, plate in pairs(activeByUnit) do ClearPlate(plate) end
    else
        ScanAll()
    end
end

local function InitializeDB()
    if type(EllesmereNPCTitlesDB) ~= "table" then
        EllesmereNPCTitlesDB = {}
    end
    db = EllesmereNPCTitlesDB
    if db.enabled == nil then db.enabled = true end
    enabled = db.enabled ~= false
end

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
eventFrame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
eventFrame:RegisterEvent("UNIT_NAME_UPDATE")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_LOGIN" then
        InitializeDB()
        C_Timer.After(0.3, ScanAll)
    elseif event == "PLAYER_ENTERING_WORLD" then
        if db then C_Timer.After(0.3, ScanAll) end
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        if enabled and unit then
            C_Timer.After(0, function() ScanOne(unit) end)
            C_Timer.After(0.15, function() ScanOne(unit) end)
        end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        local plate = activeByUnit[unit]
        if plate then ClearPlate(plate) end
    elseif event == "UNIT_NAME_UPDATE" then
        if enabled and unit then ScanOne(unit) end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if enabled then ScanAll() end
    end
end)

SLASH_ELLESMERENPCTITLES1 = "/enpct"
SlashCmdList.ELLESMERENPCTITLES = function(text)
    local arg, value = (text or ""):lower():match("^%s*(%S*)%s*(.-)%s*$")
    if not db then InitializeDB() end
    if arg == "on" then
        db.enabled = true
        enabled = true
        RefreshAll()
        Say("켜짐. NPC 이름 + 칭호 + 체력바를 함께 표시합니다.")
    elseif arg == "off" then
        db.enabled = false
        enabled = false
        RefreshAll()
        Say("꺼짐. EllesmereUI 원래 이름표 상태로 돌아갑니다.")
    elseif arg == "size" then
        local size = tonumber(value)
        if not size or size < 8 or size > 24 then
            Say("사용법: /enpct size 8~24  (예: /enpct size 10)")
            return
        end
        db.size = math.floor(size + 0.5)
        RefreshAll()
        Say("칭호 글꼴 크기: " .. db.size)
    elseif arg == "color" then
        if not TITLE_COLORS[value] then
            Say("사용법: /enpct color gold | yellow | white")
            return
        end
        db.color = value
        RefreshAll()
        Say("NPC 칭호 색상: " .. value)
    elseif arg == "reset" then
        db.size = nil
        db.color = nil
        db.enabled = true
        enabled = true
        RefreshAll()
        Say("기본 설정(짙은 금색)으로 초기화했습니다.")
    elseif arg == "status" then
        local count = 0
        for _ in pairs(activeByUnit) do count = count + 1 end
        local ns = Namespace()
        Say((enabled and "켜짐" or "꺼짐") .. " / 표시 중 " .. count .. "명 / EllesmereUI Nameplates " .. (ns and "감지" or "미감지"))
    else
        Say("명령어: /enpct on | off | size 10 | color gold/yellow/white | reset | status")
    end
end

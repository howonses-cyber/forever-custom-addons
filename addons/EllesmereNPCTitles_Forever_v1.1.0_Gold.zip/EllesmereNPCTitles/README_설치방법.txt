EllesmereUI NPC Titles + Healthbars  v1.1.0
==========================================
목적
- 아군 NPC의 EllesmereUI 체력바를 유지하며 상인/여관주인/직업전문가 같은 칭호(<...>)를 짙은 금색으로 표시합니다.
- 적 이름표, 플레이어 이름표, 체력 수치, 원본 EllesmereUI 파일은 변경하지 않습니다.

설치 / 기존 v1.0.0에서 업데이트
1. 압축을 풀어 EllesmereNPCTitles 폴더를 WoW Forever의
   _retail_\\Interface\\AddOns\\ (또는 실제 게임 클라이언트의 Interface\\AddOns\\) 안에 넣으세요.
   올바른 형태: Interface\\AddOns\\EllesmereNPCTitles\\EllesmereNPCTitles.toc
2. 기존 v1.0.0이 있다면 같은 이름의 EllesmereNPCTitles 폴더에 덮어쓴 뒤 /reload 하세요.
3. EllesmereUI와 EllesmereUINameplates가 설치되고 활성화되어 있어야 합니다.
3. 게임 재시작 또는 /reload 후 애드온 목록에서 'EllesmereUI NPC Titles + Healthbars' 활성화 확인.
4. EllesmereUI 이름표 > 아군에서 '아군 NPC 이름표 표시' 켜기,
   '아군 이름표 모양'은 '이름표'(체력바 보이는 모드)로 설정하세요.
   '이름만 표시' 모드에서는 기본 EllesmereUI의 칭호 기능을 사용합니다.

명령어
/enpct on          칭호 표시 켜기 (기본값)
/enpct off         이 애드온 칭호만 끄기
/enpct size 10     칭호 글자 크기 변경 (8~24)
/enpct color gold  짙은 금색 (기본값 #DBA626)
/enpct color yellow 조금 더 밝은 금색
/enpct color white 흰색
/enpct reset       기본값 복원
/enpct status      적용 상태/표시 중인 NPC 개수 확인

작동 방식
- EllesmereUINameplates의 friendlyPlates 공개 모듈 데이터로 체력바를 찾고,
  게임 API C_TooltipInfo.GetUnit에서 NPC 칭호를 읽어 별도 글자로 추가합니다.
- 기존 체력바와 초록색 NPC 이름 색에 손대지 않고 이름만 위로 조금 올려 칭호를 배치합니다.
- NPC 칭호만 독립적인 금색을 적용하며, 기존 설정을 가진 사용자도 기본 금색으로 표시됩니다.
- 해당 NPC가 사라지거나 프레임이 재사용되면 칭호를 숨기고 원래 이름 위치로 복원합니다.

제약 및 확인 사항
- WoW Forever 실제 게임 클라이언트에서 실행 검증한 것은 아니며 코드/패키지 정적 확인본입니다.
- EllesmereUI 원본 버전에 따라 내부 friendlyPlates 구조가 바뀌면 작동하지 않을 수 있습니다.
- 일부 NPC는 C_TooltipInfo에서 칭호가 전달되지 않아 표시되지 않을 수 있습니다.
- /enpct status에서 'EllesmereUI Nameplates 미감지'라면 종속 애드온 활성화 여부를 확인하세요.
- 설정 변경 후 바로 반영되지 않으면 /reload를 한 번 실행하세요.
- 다른 애드온에서 동일 NPC 칭호를 띄우면 중복 표시될 수 있으므로 해당 기능은 끄세요.

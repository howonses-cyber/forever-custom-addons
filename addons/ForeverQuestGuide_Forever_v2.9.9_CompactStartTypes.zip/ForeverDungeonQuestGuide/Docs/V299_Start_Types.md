# V2.9.9 - compact quest starter type

Existing status badge and route decisions are unchanged. A muted secondary label identifies NPC pickup, monster loot, world object, indoor pickup, mixed methods, or unknown starter data. Indoor loot and object pickup use combined tags. Source evidence is structured QuestieDB starter/drop/spawn data or existing authored source records (4264, 7761); it does not establish eligibility, current spawn availability, or confirmed drop rates. Missing and mixed data are not fabricated. The 7761 unconfirmed availability warning remains in the full guide.

Each page's quest and same-title subchapter types are calculated once at refresh and reused by the viewport. No inventory query, source classification, or new UI allocation occurs on wheel movement. Group headings do not inherit recycled row labels. Row height and existing compact condition line remain unchanged.

Local Lua 5.4 with compatibility aliases: 24 suites excluding pinned native chat fixture, 96 classifier assertions and 63 UI checks passed. Native Lua 5.1/LuaJIT and pinned native chat suite must pass CI before publication. No in-game rendering or live server validation claimed.

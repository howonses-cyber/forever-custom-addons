-- Production classifier with fixture DBs: types, mixed paths, missing data.
local base=arg[1] or './'
local Mock=assert(loadfile(base..'tests/mock_wow.lua'))().install()
local G={}
for line in io.lines(base..'ForeverDungeonQuestGuide.toc') do
 local file=line:match('^([^#].-%.lua)%s*$');if file then assert(loadfile(base..file))('ForeverDungeonQuestGuide',G) end
end
local q={ [99001]={startedBy={{101}},zoneOrSort=1583}, [99002]={startedBy={{102}}}, [99003]={startedBy={[3]={201}}},
 [99004]={startedBy={[2]={301}}}, [99005]={startedBy={[3]={202}}}, [99006]={startedBy={[2]={302}}}, [99007]={startedBy={[3]={203}}},
 [99008]={startedBy={[3]={204}}},[99009]={startedBy={[1]={101},[2]={301}}},[99010]={startedBy={[1]={103}}},
 [99011]={startedBy={[1]={104}}},[99012]={zoneOrSort=1583},[99013]={startedBy={npc={{101}}}},[99014]={startedBy={[3]={205}}},[99015]={startedBy={[3]={206}}},[99016]={startedBy={[1]={102,105}}},[99017]={startedBy={[3]={201,207}}}}
local npc={[101]={spawns={[46]={{20,40}}}},[102]={spawns={[1583]={{-1,-1}}}},[103]={spawns={[1583]={{1,2}},[46]={{2,3}}}},[104]={},[105]={}}
local object={[301]={spawns={[46]={{30,40}}}},[302]={spawns={[1583]={{-1,-1}}}}}
local item={[201]={npcDrops={101}},[202]={npcDrops={{102}}},[203]={objectDrops={301}},[204]={},[205]={npcDrops={101},objectDrops={301}},[206]={objectDrops={302}},[207]={}}
local reads=0
local function db(data)return {Get=function(id,key)reads=reads+1;return data[id] and data[id][key] end}end
QuestDB=db(q);NpcDB=db(npc);ObjectDB=db(object);ItemDB=db(item)
C_Item={GetItemCount=function()error('classifier must not request inventory')end}
local N=0;local function eq(a,b)N=N+1;assert(a==b,tostring(a)..' ~= '..tostring(b))end
local function expect(id,label,method,location)
 local t=G.QuestStartType(id);eq(t.label,label);eq(t.method,method);eq(t.location,location);eq(#t.color,3);assert(type(t.detail)=='string')
end
expect(99001,'NPC 수락','npc','unknown') -- dungeon-related is not indoor pickup
expect(99002,'던전 내부','npc','inside')
expect(99003,'몹 드롭','drop','unknown')
expect(99004,'클릭 시작','object','unknown')
expect(99005,'던전·드롭','drop','inside')
expect(99006,'던전·클릭','object','inside')
expect(99007,'클릭 시작','object','unknown')
expect(99008,'아이템 시작','item','unknown')
expect(99009,'복수 유형','mixed','unknown')
expect(99010,'NPC 수락','npc','mixed')
expect(99011,'NPC 수락','npc','unknown')
expect(99012,'유형 미확인','unknown','unknown')
expect(99013,'NPC 수락','npc','unknown')
expect(99014,'복수 유형','mixed','unknown')
expect(99015,'던전·클릭','object','inside')
expect(99016,'NPC 수락','npc','unknown')
expect(99017,'복수 유형','mixed','unknown')
expect(7761,'몹 드롭','drop','unknown')
expect(4264,'던전·드롭','drop','inside')
expect(4083,'던전·클릭','object','inside')
expect(4342,'던전 내부','npc','inside')
local cache={};eq(G.QuestStartTypeGroup({99001,99013},cache).label,'NPC 수락');local before=reads
G.QuestStartTypeGroup({99001,99013},cache);eq(reads,before)
eq(G.QuestStartTypeGroup({99001,99003},cache).label,'복수 유형')
eq(G.QuestStartTypeGroup({},cache).label,'유형 미확인')
QuestDB=nil;expect(99012,'유형 미확인','unknown','unknown');expect(7761,'몹 드롭','drop','unknown')
print('PASS V2.9.9 starter types, actual indoor evidence, alternatives, missing source and cache: '..N..' assertions')

-- Actual production modules; simulated bag/DB/map APIs, not evidence of live spawn.
local base=arg[1] or './'
local Mock=assert(loadfile(base..'tests/mock_wow.lua'))().install()
GetLocale=function()return 'koKR'end;GetTime=function()return 100 end
local G={}
for line in io.lines(base..'ForeverDungeonQuestGuide.toc') do
 local file=line:match('^([^#].-%.lua)%s*$');if file then assert(loadfile(base..file))('ForeverDungeonQuestGuide',G) end
end
G.StartSaved();G.player={level=56,classId=7,faction='Alliance'}
local counts={[18987]=0,[910001]=0,[910002]=0,[910003]=0,[910004]=0}
local qs={[7761]={name='블랙핸드의 명령서',requiredLevel=55,questLevel=60,zoneOrSort=1583,startedBy={{9046},nil,{18987}}},[91001]={name='아이템 출처 검사',requiredLevel=1,zoneOrSort=46,startedBy={[3]={910001}}},[91002]={name='광역 위치 검사',requiredLevel=1,zoneOrSort=46,startedBy={[3]={910002}}},[91003]={name='복수 출처 검사',requiredLevel=1,zoneOrSort=46,startedBy={[3]={910003}}},[91004]={name='위치 미확인 검사',requiredLevel=1,zoneOrSort=46,startedBy={[3]={910004}}}}
local items={[18987]={name='블랙핸드의 명령서',npcDrops={9046}},[910001]={name='검사 시작품',npcDrops={910101}},[910002]={name='광역 시작품',objectDrops={910102}},[910003]={name='복수 시작품',npcDrops={910101},objectDrops={910102}},[910004]={name='미확인 시작품'}}
local npcs={[9046]={name='방패부대 병참장교',spawns={[10074]={{49.1,64.1}}}},[910101]={name='검사 몬스터',spawns={[46]={{25,35}}}}}
local objects={[910102]={name='검사 상자',spawns={[10074]={{50,60}}}}}
QuestDB={Get=function(i,k)return qs[i] and qs[i][k]end}
NpcDB={Get=function(i,k)return npcs[i] and npcs[i][k]end}
ItemDB={Get=function(i,k)return items[i] and items[i][k]end}
ObjectDB={Get=function(i,k)return objects[i] and objects[i][k]end}
C_Item={GetItemCount=function(id,bank)assert(bank==false);return counts[id]end}
C_Map={GetBestMapForUnit=function()return 1428 end,GetMapInfo=function(m)return {name=m==1415 and '동부 왕국' or '불타는 평원',mapType=m==1415 and 2 or 3}end,GetAreaInfo=function(a)if a==10074 then return '검은바위 산' end end}
LibQuestieDB={Support={Get=function(k)if k=='ZoneDB'then return {private={areaIdToUiMapId={[10074]=1415}}}end end}}
local active={}
G.IsInLog=function(i)return active[i]==true end
G.IsCompleted=function()return false end
G.IsReadyToTurnIn=function()return false end
G.RouteExclusionReason=function()return nil end
G.IsRouteSatisfied=function()return false end
G.IsInGuideDungeon=function()return false end
local N=0
local function eq(a,b)N=N+1;assert(a==b,tostring(a)..' ~= '..tostring(b))end
local function has(s,x)N=N+1;assert(type(s)=='string' and s:find(x,1,true),'missing '..x..': '..tostring(s))end
local function no(s,x)N=N+1;assert(not s:find(x,1,true),'unexpected '..x..': '..s)end
local function step(id)return G.EnrichStepLocation({kind='accept',quest=id,questName=G.GetQuestName(id)})end
local function rendered(st,full)return table.concat((full and G.BuildFullStepDirections or G.BuildCompactStepDirections)(st,nil).lines,'\n')end
local item=G.QuestStartItemGuide(7761);eq(item.itemId,18987);eq(item.owned,0);eq(item.inside,false);eq(item.availability,'unconfirmed');has(item.place,'검은바위 첨탑 입구 앞 오른쪽 통로');has(item.warning,'미확인')
local s=step(7761);eq(s.contactType,'item');eq(s.contactName,'블랙핸드의 명령서');eq(s.point,nil);eq(s.indoor,nil);eq(G.GuideStepNavPoint(s),nil);eq(s.landmark.zone,'검은바위 산')
for _,full in ipairs({false,true})do local t=rendered(s,full);has(t,'방패부대 병참장교 처치');has(t,'가방에서 우클릭');has(t,'검은바위 첨탑 입구 앞 오른쪽 통로');has(t,'출현·드롭 여부 미확인');no(t,'동부 왕국 → 방패부대 병참장교')end
local contact=G.ContactPreview(7761,'accept');eq(contact.kind,'item');eq(contact.name,'블랙핸드의 명령서');eq(contact.point,nil);has(contact.place,'오른쪽 통로');has(contact.note,'미확인')
local journey=G.QuestJourney(7761);has(journey.detail,'방패부대 병참장교');has(journey.detail,'미확인');has(journey.location,'오른쪽 통로')
local objective=G.QuestInsideInfo(7761,'objective');eq(objective.dungeonId,'brs');has(objective.instruction,'사령관 드라키사스')
local report=G.QuestInsideInfo(7761,'turnin');eq(report.contactType,'object');eq(report.npcName,'드라키사스의 낙인')
G.dungeonById.itemtest={id='itemtest',name='검사 던전',ids={7761,91001}}
local g=assert(G.BuildSelectedGuide(false,{scope='dungeon',dungeon='itemtest',actionMode='prepare'}))
local excluded=false;for _,e in ipairs(g.excluded)do if e.id==7761 then excluded=true;has(e.reason,'획득 가능 여부 미확인')end end;eq(excluded,true)
for _,r in ipairs(g.steps)do eq(r.quest==7761,false)end
counts[18987]=1
-- The route step is not completed merely by owning an item.
G.EnrichStepLocation(s);eq(s.prepInventory,true);eq(s.point,nil);eq(s.landmark,nil);eq(G.StepIsDone(s,1),false)
for _,full in ipairs({false,true})do local t=rendered(s,full);has(t,'1개 보유');has(t,'가방 · 시작 아이템');no(t,'병참장교');no(t,'오른쪽 통로')end
contact=G.ContactPreview(7761,'accept');eq(contact.map,nil);eq(contact.point,nil);has(contact.place,'가방')
g=assert(G.BuildSelectedGuide(false,{scope='dungeon',dungeon='itemtest',actionMode='prepare'}))
local found=false;for _,r in ipairs(g.steps)do if r.quest==7761 then found=true;eq(r.kind,'accept');eq(r.prepInventory,true)end end;eq(found,true)
active[7761]=true;eq(G.StepIsDone(s,1),true);active[7761]=nil
counts[18987]=nil;G.EnrichStepLocation(s);eq(s.prepInventory,nil);has(rendered(s,false),'소지 여부 미확인')
-- Generic database sources: real local candidate, broad-map rejection, alternatives, and missing data.
local a=step(91001);eq(a.point.map,1428);eq(a.point.approx,true);has(rendered(a,false),'검사 몬스터 · 처치 후 전리품 획득');has(rendered(a,false),'25.0, 35.0')
local b=step(91002);eq(b.point,nil);eq(b.landmark.map,nil);eq(b.landmark.zone,'검은바위 산');has(rendered(b,false),'검사 상자 · 상호작용 후 획득');no(rendered(b,false),'동부 왕국 · 검사 상자')
local c=step(91003);eq(c.point,nil);eq(c.landmark,nil);has(rendered(c,false),'검사 몬스터');has(rendered(c,false),'검사 상자');has(rendered(c,false),'위치 미확인')
local d=step(91004);eq(d.point,nil);eq(d.landmark,nil);has(rendered(d,false),'획득처 위치 미확인');has(rendered(d,false),'실제 획득처를 확인')
-- An unowned item cannot inherit a previous bag-only or phantom map stop.
counts[910001]=1;G.EnrichStepLocation(a);eq(a.prepInventory,true);eq(a.point,nil);counts[910001]=0;G.EnrichStepLocation(a);eq(a.prepInventory,nil);eq(a.point.map,1428)
eq(G.version,'2.9.9');eq(G.journeyVersion,G.version)
print('PASS V2.9.8 source-aware item acquisition, 7761 uncertainty, prep exclusion, bag changes and contact/HUD parity: '..N..' assertions')

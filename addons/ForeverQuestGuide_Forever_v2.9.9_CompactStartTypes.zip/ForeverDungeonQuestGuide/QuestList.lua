local addon,G=...
-- Rows are lightweight render data; the game UI renders only the visible window.
-- Level = quest level (not required/minimum player level); unknown is '?'.
local dungeonIds={}
local dungeonAreas={}
for _,d in ipairs(G.dungeons or {}) do
 if d.area then dungeonAreas[d.area]=dungeonAreas[d.area] or d end
 for _,qid in ipairs(d.ids or {}) do
  -- Explicit dungeon quest associations take precedence over the pickup zone.
  -- Some prerequisite chains lead through outdoor areas; those remain labelled
  -- as dungeon-related rather than pretending the pickup NPC is inside.
  if not dungeonIds[qid] then dungeonIds[qid]=d end
 end
end
local function questLevel(id)
 local active=G.activeQuests and G.activeQuests[id]
 local lv=active and tonumber(active.level)
 if not lv or lv<=0 then lv=tonumber(G.GetQuestLevel and G.GetQuestLevel(id)) end
 if lv and lv>0 then return tostring(math.floor(lv)) end
 return "?"
end
function G.QuestListMeta(id)
 id=tonumber(id)
 local area=tonumber(G.DBGet and G.DBGet(QuestDB,id,"zoneOrSort"))
 local dungeon=dungeonIds[id] or (area and dungeonAreas[area])
 if dungeon then
  return {key="dungeon:"..dungeon.id,label=dungeon.name,isDungeon=true,kind="dungeon",level=questLevel(id)}
 end
 local map,zone,kind=G.GetQuestZone(id)
 if zone and zone~="" then
  return {key="zone:"..tostring(map),label=zone,isDungeon=kind=="dungeon",kind=kind,level=questLevel(id)}
 end
 local log=G.activeQuests and G.activeQuests[id]
 local fallback=log and log.header
 if type(fallback)~="string" or fallback=="" then fallback="기타 · 지역 확인 필요" end
 if G.KoreanText then fallback=G.KoreanText(fallback) end
 return {key="unknown:"..fallback,label=fallback,isDungeon=false,level=questLevel(id)}
end
function G.QuestListRows(ids,grouped)
 ids=ids or {}
 local out={}
 if not grouped then
  for _,id in ipairs(ids) do
   local m=G.QuestListMeta(id)
   out[#out+1]={kind="quest",id=id,meta=m}
  end
  return out
 end
 local groups,sorted={},{}
 for _,id in ipairs(ids) do
  local m=G.QuestListMeta(id)
  local group=groups[m.key]
  if not group then
   group={meta=m,quests={}}
   groups[m.key]=group
   sorted[#sorted+1]=group
  end
  group.quests[#group.quests+1]={kind="quest",id=id,meta=m}
 end
 table.sort(sorted,function(a,b)
  local aUnknown=string.sub(a.meta.key,1,8)=="unknown:"
  local bUnknown=string.sub(b.meta.key,1,8)=="unknown:"
  if aUnknown~=bUnknown then return not aUnknown end
  if a.meta.isDungeon~=b.meta.isDungeon then return not a.meta.isDungeon end
  if a.meta.label~=b.meta.label then return a.meta.label<b.meta.label end
  return a.meta.key<b.meta.key
 end)
 for _,group in ipairs(sorted) do
  table.sort(group.quests,function(a,b)
   local al,bl=tonumber(a.meta.level) or 999,tonumber(b.meta.level) or 999
   if al~=bl then return al<bl end
   return a.id<b.id
  end)
  out[#out+1]={kind="header",label=group.meta.label,count=#group.quests,isDungeon=group.meta.isDungeon,category=group.meta.kind}
  for _,entry in ipairs(group.quests) do out[#out+1]=entry end
 end
 return out
end

-- Start mechanism and start location are independent of quest category/status.
-- Read only structured starter/source fields. Never scan the world or request
-- item information when painting a row. Unknown/mixed evidence stays explicit.
local startColors={npc={.69,.79,.73},drop={.78,.70,.57},object={.72,.68,.82},item={.72,.68,.82},inside={.61,.76,.85},mixed={.69,.73,.77},unknown={.53,.59,.65}}
local function startResult(method,location,detail)
 local label=({npc="NPC 수락",drop="몹 드롭",object="클릭 시작",item="아이템 시작",mixed="복수 유형",unknown="유형 미확인"})[method] or "유형 미확인"
 local color=startColors[method] or startColors.unknown
 if location=="inside" then
  label=({npc="던전 내부",drop="던전·드롭",object="던전·클릭",item="던전·아이템",mixed="던전·복수",unknown="던전 내부"})[method] or "던전 내부"
  -- Acquisition method remains distinguishable for indoor drop/object.
  if method=="npc" or method=="unknown" then color=startColors.inside end
 end
 return {label=label,color=color,method=method,location=location,detail=detail or label}
end
local function readField(db,id,key)
 if type(db)~="table" or not id then return nil end
 local get=G.DBRawGet or G.DBGet
 if type(get)~="function" then return nil end
 local ok,value=pcall(get,db,id,key);if ok then return value end
end
local function eachId(list,visit)
 if type(list)~="table" then return end
 for _,value in ipairs(list) do
  local id=tonumber(type(value)=="table" and value[1] or value)
  if id and id~=0 then visit(math.abs(id)) end
 end
end
local function locationEvidence(db,id,evidence)
 local spawns=readField(db,id,"spawns")
 local found=false
 if type(spawns)=="table" then
  for area in pairs(spawns) do
   area=tonumber(area)
   if area and area>0 then
    found=true
    if (G.IsInstanceArea and G.IsInstanceArea(area)) or dungeonAreas[area] then evidence.inside=true
    else evidence.other=true end
   end
  end
 end
 if not found then evidence.unknown=true end
end
local function locationOf(e)
 if e.inside and not e.other and not e.unknown then return "inside" end
 if e.inside and e.other then return "mixed" end
 return "unknown" -- no assertion of outdoor accessibility from a missing spawn
end
local function itemMethod(ids,evidence)
 local methods={}
 eachId(ids,function(itemId)
  local found=false
  eachId(readField(ItemDB,itemId,"npcDrops"),function(id) found=true;methods.drop=true;locationEvidence(NpcDB,id,evidence) end)
  eachId(readField(ItemDB,itemId,"objectDrops"),function(id) found=true;methods.object=true;locationEvidence(ObjectDB,id,evidence) end)
  if not found then methods.item=true;evidence.unknown=true end
 end)
 local n,one=0,nil;for method in pairs(methods) do n=n+1;one=method end
 return n>1 and "mixed" or one or "item"
end
function G.QuestStartType(id)
 id=tonumber(id)
 local recipe=G.verifiedStartItems and G.verifiedStartItems[id]
 if recipe then
  return startResult(recipe.startMethod or "item",recipe.inside==true and "inside" or "unknown","시작 아이템 · "..(recipe.sources or "획득처 확인 필요"))
 end
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 local hint=meta and meta.insideStages and meta.insideStages.accept
 -- Explicit stage-specific evidence outranks generic catalog association.
 if hint and hint.contactType=="object" then return startResult("object","inside","던전 내부 오브젝트 클릭 후 수락") end
 if hint and (hint.contactType==nil or hint.contactType=="npc") then return startResult("npc","inside","던전 내부 NPC 수락") end
 local row=readField(QuestDB,id,"startedBy")
 local methods,evidence={},{}
 if type(row)=="table" then
  local function direct(list,db,method)
   eachId(list,function(eid) methods[method]=true;locationEvidence(db,eid,evidence) end)
  end
  direct(row.npc or row.NPC or row[1],NpcDB,"npc")
  direct(row.object or row.Object or row[2],ObjectDB,"object")
  local itemIds=row.item or row.Item or row[3]
  local hasItem=false;eachId(itemIds,function() hasItem=true end)
  if hasItem then methods[itemMethod(itemIds,evidence)]=true end
 end
 local n,method=0,nil;for k in pairs(methods) do n=n+1;method=k end
 if n>1 then method="mixed" end
 method=method or "unknown"
 local location=locationOf(evidence)
 if hint then location="inside" end
 local detail=({npc="NPC에게 수락 · 선행/레벨 조건은 별도 확인",drop="몬스터 전리품으로 시작 아이템 획득 후 사용",object="오브젝트 클릭 또는 오브젝트에서 시작 아이템 획득",item="시작 아이템 사용 · 획득 방법 미확인",mixed="수락 또는 아이템 획득 방식이 여러 종류 · 상세 확인",unknown="수락 유형 자료 미확인"})[method]
 if location=="inside" then detail="던전 내부 · "..detail elseif location=="mixed" then detail=detail.." · 내부/외부 출처 혼재" end
 return startResult(method,location,detail)
end
function G.QuestStartTypeGroup(ids,cache)
 local first
 for _,id in ipairs(ids or {}) do
  local t=cache and cache[id] or nil
  if not t then t=G.QuestStartType(id);if cache then cache[id]=t end end
  if not first then first=t elseif first.method~=t.method or first.location~=t.location then return startResult("mixed","unknown","하위 단계별 수락 유형이 다릅니다. 펼쳐서 확인하세요.") end
 end
 return first or startResult("unknown","unknown")
end

local addon,G=...
-- Read-only item-start quest acquisition instructions. DB links are source
-- candidates, not guaranteed drops or measured Forever probabilities.
-- The current inventory is never inferred from a missing API.
local curated={
 [4264]={itemId=11446,name="꼬깃꼬깃한 쪽지",place="검은바위 나락 · 입구/채석장 및 검은무쇠 적 활동 구역",
  startMethod="drop",sources="성난모루단 감독관·교도관·보초 등 검은바위 나락 적들의 전리품 (확률 드롭 · 반복 처치 가능)",
  after="획득한 쪽지를 가방에서 우클릭하여 수락한 다음, 검은바위 나락 감금 구역의 치안대장 윈저에게 보고하세요.",
  source="포에버 와우헤드 퀘스트 #4264 및 공개 드롭 대상 목록 · 실게임 드롭률 미측정",inside=true},
 [7761]={itemId=18987,name="블랙핸드의 명령서",place="검은바위 산 · 검은바위 첨탑 입구 앞 오른쪽 통로",
  startMethod="drop",sources="방패부대 병참장교 처치 후 전리품 획득",inside=false,availability="unconfirmed",
  after="명령서를 획득하면 가방에서 우클릭해 수락하세요.",
  note="포에버 현재 출현·드롭 여부 미확인. 병참장교가 없으면 나중에로 보류하세요.",
  source="와우헤드 포에버 던전 퀘스트 목록·NPC 9046·아이템 18987 및 클래식 입장퀘 공략 대조 (2026-11-28); 현행 출현 미검증"},
}
G.verifiedStartItems=curated
local function dbget(db,id,key)
 if not db or not G.DBGet then return nil end
 local ok,value=pcall(G.DBGet,db,id,key)
 return ok and value or nil
end
local function itemCount(id)
 local fn=C_Item and C_Item.GetItemCount or GetItemCount
 if type(fn)~="function" then return nil end
 local ok,value=pcall(fn,id,false)
 if ok and type(value)=="number" and value>=0 then return value end
 return nil
end
local function sourceNames(itemId)
 local found={}
 for _,entry in ipairs({{ItemDB and dbget(ItemDB,itemId,"npcDrops"),NpcDB},
                         {ItemDB and dbget(ItemDB,itemId,"objectDrops"),ObjectDB}}) do
  local ids,db=entry[1],entry[2]
  if type(ids)=="table" then
   for _,source in ipairs(ids) do
    local id=type(source)=="table" and tonumber(source[1]) or tonumber(source)
    local name=id and dbget(db,math.abs(id),"name")
    if type(name)=="string" and name~="" then
     if G.KoreanText then name=G.KoreanText(name) end
     found[#found+1]=name
     if #found>=3 then return table.concat(found," · ").." 등 (QuestieDB 출처 후보)" end
    end
   end
  end
 end
 if #found>0 then return table.concat(found," · ").." (QuestieDB 출처 후보)" end
 return nil
end
function G.QuestStartItemGuide(questId)
 local id=tonumber(questId)
 if not id or id%1~=0 then return nil end
 local recipe=curated[id]
 local name,itemId,_,kind
 if type(G.QuestContactName)=="function" then name,itemId,_,kind=G.QuestContactName(id,"accept") end
 if kind~="item" and not recipe then return nil end
 itemId=recipe and recipe.itemId or (kind=="item" and tonumber(itemId))
 if not itemId then return nil end
 name=(recipe and recipe.name) or name or ("아이템 #"..itemId)
 if G.KoreanText then name=G.KoreanText(name) end
 local count=itemCount(itemId)
 local sources=(recipe and recipe.sources) or sourceNames(itemId)
 local candidates=not recipe and G.QuestStartItemSourceLocations and G.QuestStartItemSourceLocations(itemId) or {}
 local candidate=#candidates==1 and candidates[1] or nil
 local lm=G.QuestStageLandmark and G.QuestStageLandmark(id,"accept") or nil
 local indoor=G.QuestInsideInfo and G.QuestInsideInfo(id,"accept") or nil
 local place=(recipe and recipe.place) or (candidate and candidate.place) or "시작 아이템 획득처 위치 미확인"
 local detail={}
 for _,c in ipairs(candidates) do detail[#detail+1]=c.action.." · "..(c.place or "위치 미확인") end
 local after=(recipe and recipe.after) or ("‘"..name.."’을 가방에서 우클릭해 퀘스트를 수락하세요.")
 local action,verb
 if count and count>0 then
  verb="시작 아이템 사용"
  action="가방에 ‘"..name.."’ "..count.."개 보유 · 우클릭해 퀘스트를 수락하세요."
 elseif count==0 then
  verb="시작 아이템 획득"
  action="시작 아이템 ‘"..name.."’을 가방에서 찾지 못했습니다."..(sources and ("\n획득 방법: "..sources) or " 퀘스트 아이템의 실제 획득처를 확인하세요.")
 else
  verb="시작 아이템 확보 확인"
  action="시작 아이템 ‘"..name.."’ 소지 여부 미확인 · 가방에 없으면 "..(sources and ("다음 방법으로 확보하세요.\n획득 방법: "..sources) or "획득처 자료를 확인하세요.")
 end
 local owned=count~=nil and count>0
 return {itemId=itemId,name=name,owned=count,place=owned and "가방 · 시작 아이템" or place,sourceText=sources,source=recipe and recipe.source,
  action=action,verb=verb,note=after,warning=not owned and recipe and recipe.note or nil,uncertain=true,
  known=recipe~=nil or sources~=nil,locationKnown=owned or recipe~=nil or (candidate and candidate.locationKnown==true) or false,
  inside=not owned and ((recipe and recipe.inside==true) or (not recipe and (indoor~=nil or (candidate and candidate.inside==true)))) or false,
  availability=recipe and recipe.availability,landmark=not owned and (lm or (candidate and candidate.landmark)) or nil,
  indoor=not owned and indoor or nil,point=not owned and not lm and not indoor and candidate and candidate.point or nil,
  candidates=detail}
end

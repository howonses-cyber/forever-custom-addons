-- Synthetic records test actual planner and prerequisite resolver. No live quest facts.
local base=arg[1] or './'
local Mock=assert(loadfile(base..'tests/mock_wow.lua'))().install()
local G={}
for _,name in ipairs({'Core.lua','Data.lua','VerifiedRoutes.lua','QuestData.lua','FactionFilter.lua','QuestSearch.lua','RouteOptimizer.lua','Planner.lua','QuestStatus.lua'}) do
 assert(loadfile(base..name))('ForeverDungeonQuestGuide',G)
end
G.StartSaved();G.player={faction='Alliance',classId=7,level=60}
local records,active,rewarded,ready,indoor,unknown={},{},{},{},{},{}
local function q(n)return 99000+n end
for i=1,20 do records[q(i)]={name='Fixture '..i,requiredLevel=40,questLevel=50,zoneOrSort=46} end
QuestDB={Get=function(id,key)return records[id] and records[id][key] end}
C_QuestLog={IsQuestFlaggedCompleted=function(id)return rewarded[id] or false end}
function G.IsInLog(id)return active[id]==true end
function G.IsReadyToTurnIn(id)return ready[id]==true end
function G.IsCompleted(id)return not active[id] and rewarded[id]==true end
local function syncLog() G.activeQuests={};for id in pairs(active)do G.activeQuests[id]={title=records[id].name,complete=ready[id] or false} end end
G.QuestInsideInfo=function(id,stage) if indoor[id..':'..stage] then return {dungeon='Fixture dungeon',dungeonId='testprep',room='room',npcName='NPC'} end end
G.QuestStageLandmark=function()end
G.QuestContactLandmark=function()end
G.QuestContactName=function()return 'NPC',1,nil,'npc' end
G.QuestObjectivePoints=function()return{}end
G.QuestObjectiveText=function()return 'Objective' end
G.QuestRegionHint=function()end
G.QuestPoint=function(id,stage)if not unknown[id..':'..stage] then return {map=1428,x=.25,y=.3,name='NPC'}end end
G.QuestStartItemGuide=function(id)if id==q(14) then return {owned=1,inside=true,name='Bag item',action='Use bag item'}elseif id==q(15)then return {owned=0,inside=true} end end
G.Print=function()end;G.NotifyDataChange=function()end;G.ActivateGuideStep=function()end
local n=0
local function eq(a,b,m)n=n+1;assert(a==b,(m or '')..': '..tostring(a)..' ~= '..tostring(b))end
local function ok(a,m)n=n+1;assert(a,m)end
local function selectIds(ids)G.db.selectedQuests={};for _,id in ipairs(ids)do G.db.selectedQuests[id]=true end end
local function contains(g,id,kind)for i,s in ipairs(g.steps)do if s.quest==id and s.kind==kind then return i,s end end end
local function excluded(g,id,kind)for _,e in ipairs(g.excluded)do if e.id==id and (not kind or e.kind==kind)then return e end end end
local function build(mode,scope,dungeon)local g,e=G.BuildSelectedGuide(false,{scope=scope or 'checked',dungeon=dungeon,actionMode=mode});assert(g,e);eq(g.actionMode,mode);return g end
records[q(2)].preQuestGroup={q(3)}
active[q(4)]=true;active[q(5)]=true;ready[q(5)]=true;rewarded[q(6)]=true;syncLog()
selectIds({q(1),q(2),q(4),q(5),q(6)})
local g=build('accept');eq(#g.steps,1);eq(g.steps[1].quest,q(1));eq(g.steps[1].kind,'accept');ok(excluded(g,q(2),'prerequisite'));eq(g.alreadyAccepted,2);eq(G.SelectedCount(),5)
g=build('full');ok(contains(g,q(3),'turnin')<contains(g,q(2),'accept'),'dependency must precede acceptance');ok(contains(g,q(2),'objective'));ok(contains(g,q(2),'turnin'));ok(contains(g,q(5),'turnin'));eq(contains(g,q(4),'accept'),nil)
g=build('progress');eq(#g.steps,3);ok(contains(g,q(4),'objective'));ok(contains(g,q(4),'turnin'));ok(contains(g,q(5),'turnin'));for _,s in ipairs(g.steps)do ok(s.kind~='accept')end
ok(excluded(g,q(1),'notAccepted'))
g=build('report');eq(#g.steps,1);eq(g.steps[1].quest,q(5));eq(g.steps[1].kind,'turnin');ok(excluded(g,q(4),'notReady'))
g=build('progress','active');eq(#g.steps,3)
g=build('report','active');eq(#g.steps,1)
-- Dungeon pickup roots, external prerequisites, an alternate indoor branch,
-- unknown positions, and an item already carried in the bag.
indoor[q(7)..':accept']=true;records[q(8)].preQuestGroup={q(9)};indoor[q(9)..':objective']=true
unknown[q(10)..':accept']=true;records[q(11)].preQuestSingle={q(12),q(13)};indoor[q(12)..':objective']=true
indoor[q(16)..':accept']=true;records[q(16)].preQuestGroup={q(17)}
G.dungeonById.testprep={id='testprep',name='Fixture dungeon',ids={q(1),q(2),q(4),q(5),q(6),q(7),q(8),q(10),q(11),q(14),q(15),q(16)}}
g=build('prepare','dungeon','testprep')
local p=g.preparation;eq(p.alreadyAccepted,2);eq(p.reported,1);eq(p.inside,3);eq(p.unknown,1);eq(p.blocked,1);eq(p.externalPrerequisites,3)
for _,id in ipairs({q(1),q(2),q(11),q(14)})do ok(contains(g,id,'accept'));eq(contains(g,id,'objective'),nil);eq(contains(g,id,'turnin'),nil)end
for _,id in ipairs({q(3),q(13),q(17)})do ok(contains(g,id,'accept'));ok(contains(g,id,'objective'));ok(contains(g,id,'turnin'))end
ok(contains(g,q(3),'turnin')<contains(g,q(2),'accept'));ok(contains(g,q(13),'turnin')<contains(g,q(11),'accept'))
for _,id in ipairs({q(4),q(5),q(6),q(7),q(8),q(9),q(10),q(12),q(15),q(16)})do for _,s in ipairs(g.steps)do ok(s.quest~=id,'unsafe preparation root/stage '..id)end end
ok(excluded(g,q(7),'insidePickup'));ok(excluded(g,q(8),'insidePrereq'));ok(excluded(g,q(10),'unknownLocation'));ok(excluded(g,q(15),'insidePickup'));ok(excluded(g,q(16),'insidePickup'))
local _,bag=contains(g,q(14),'accept');eq(bag.prepInventory,true);eq(bag.point,nil);eq(bag.indoor,nil)
-- Saved action mode survives a live state change, and acceptance does not
-- silently switch to a full objective/turn-in route.
selectIds({q(18)});g=build('accept');G.db.guide=g
active[q(18)]=true;syncLog();eq(G.ReplanSelectedGuide('퀘스트 상태 변경'),false);eq(g.completed,true);eq(g.actionMode,'accept');eq(#g.steps,1);eq(g.steps[1].kind,'accept')
G.db.guide={};selectIds({q(1)});local a,b=G.CheckQuestBatch({q(1),q(2),q(4),q(6)});eq(a,2);eq(b,1);eq(G.SelectedCount(),3);ok(G.db.selectedQuests[q(1)]);eq(G.db.selectedQuests[q(6)],nil)
eq(G.GuideActionMode(true,{}),'report');eq(G.GuideActionMode(false,{scope='active'}),'progress');eq(G.GuideActionMode(false,{}),'full')
print('PASS V2.9.5 action modes, outdoor-only preparation and checked-state preservation: '..n..' assertions')

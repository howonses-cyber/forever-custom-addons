local addon,G=...
G.statusVersion="2.9.6"
-- Game status is independent of checked routes, postponements and inferred
-- predecessor satisfaction. Only caller-owned refresh caches are populated.
local labels={unaccepted="미수락",active="수행 중",turnin="보고 가능",done="완료",unknown="기록 확인"}
local colors={unaccepted={.94,.76,.30},active={.34,.68,1},turnin={.35,.85,.53},done={.64,.69,.74},unknown={.76,.66,.92}}
local blockedCodes={locked=true,low=true,blocked=true,deferred=true,dependentDeferred=true,unknown=true,superseded=true}
local shortReasons={locked="선행 필요",low="레벨 부족",blocked="진행 조건 확인",deferred="사용자 보류",dependentDeferred="선행 보류",unknown="자료 확인 필요",superseded="지난 단계 · 완료 기록 미확인"}
local function validId(value)
 local id=tonumber(value)
 return id and id>0 and id<math.huge and id%1==0 and id or nil
end
local function truth(value)return value==true or value==1 end
local function invoke(fn,...)
 if type(fn)~="function" then return nil end
 local ok,result=pcall(fn,...)
 if ok then return result end
end
local function read(name,...)return invoke(G[name],...)end
local function isHidden(value)
 return type(issecretvalue)=="function" and invoke(issecretvalue,value)==true
end
local function finite(value)
 if isHidden(value) or type(value)~="number" or value~=value or value==math.huge or value==-math.huge then return nil end
 return value
end
local function text(value)
 if isHidden(value) or type(value)~="string" then return nil end
 value=value:gsub("^%s+",""):gsub("%s+$","")
 return value~="" and value or nil
end
local function completionKnown(id)
 local installed,failed=0,false
 for _,fn in ipairs({C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted or false,IsQuestFlaggedCompleted or false})do
  if type(fn)=="function" then
   installed=installed+1
   local ok,value=pcall(fn,id)
   if ok and not isHidden(value) and (type(value)=="boolean" or value==0 or value==1) then return true,"history_available" end
   if not ok then failed=true end
  end
 end
 -- A positive session/cache record is already handled by IsCompleted.
 -- No API, invalid/secret response, and API error are NOT negative evidence.
 if installed==0 then return false,"no_history_api" end
 return false,failed and "history_api_error" or "history_unreadable"
end
local function assessment(id)
 local fn=G.RouteAssessment or G.QuestState
 if type(fn)=="function" then
  local ok,state,code,why=pcall(fn,id)
  if ok then return text(state),code or "unknown",text(why) end
 end
 return "진행 조건 자료를 확인하지 못했습니다.","unknown"
end
local function secondaryReason(code,state)
 if code=="blocked" and state then
  if state:find("진영",1,true) or state:find("종족",1,true) or state:find("직업",1,true) then return "진영·종족·직업 제한" end
  if state:find("택일",1,true) then return "택일 조건" end
  if state:find("선행",1,true) then return "선행 조건 확인" end
  if state:find("평판",1,true) then return "평판 조건" end
  if state:find("레벨",1,true) then return "레벨 조건" end
  if state:find("전문",1,true) or state:find("숙련",1,true) then return "전문기술 조건" end
 end
 return shortReasons[code] or ""
end
function G.QuestListStatus(id,cache)
 id=validId(id);if not id then return nil end
 if type(cache)=="table" and cache[id] then return cache[id] end
 local inLog=truth(read("IsInLog",id))
 local rewarded=not inLog and truth(read("IsCompleted",id))
 local state,code,why=assessment(id)
 local known,historyReason=completionKnown(id)
 local key
 if inLog then key=truth(read("IsReadyToTurnIn",id)) and "turnin" or "active"
 elseif rewarded then key="done"
 elseif code=="superseded" then key="unknown"
 elseif known then key="unaccepted"
 else key="unknown" end
 local blocked=key~="done" and blockedCodes[code]==true
 local reason=blocked and secondaryReason(code,state) or ""
 local detail
 if key=="turnin" then detail="목표를 달성해 보고할 수 있습니다. 보고 대상에게 말을 걸어 보상을 받아야 완료 기록이 남습니다."
 elseif key=="active" then detail="현재 받은 퀘스트입니다. 게임에 표시된 목표를 수행하세요."
 elseif key=="done" then detail="보상을 받은 완료 기록이 확인되었습니다. 반복 퀘스트를 다시 받으면 수행 중으로 표시합니다."
 elseif code=="superseded" then detail="후속 단계의 진행은 확인했지만, 이 퀘스트 자체를 보고한 완료 기록은 확인하지 못했습니다."
 elseif key=="unaccepted" then detail="현재 퀘스트 목록에 없고 완료 기록도 없는 퀘스트입니다. 수락 대상과 조건을 확인하세요."
 else
  local diagnoses={no_history_api="게임 완료 이력 조회 API 미제공",history_api_error="게임 완료 이력 API 호출 오류",history_unreadable="게임 완료 이력 조회 결과 판독 불가"}
  reason=reason~="" and reason or (not G.Ready() and "진행 조건 DB 미연결" or diagnoses[historyReason] or "완료 기록 미확인")
  detail="현재 퀘스트 목록에는 없습니다. "..(diagnoses[historyReason] or "게임의 완료 기록을 확인할 수 없음").."으로 미수락과 완료를 구분할 수 없습니다."
  if not G.Ready() then detail=detail.." QuestieDB 연결 상태도 확인하세요. DB 미연결은 완료 이력의 부재를 증명하지 않습니다." end
  if code=="unknown" and G.Ready() and G.QuestFaction and G.QuestFaction(id)=="Unknown" then
   detail=detail.." 해당 퀘스트의 진영 제한 데이터도 판별되지 않았습니다."
  end
 end
 if blocked then
  if code=="deferred" then detail=detail.." 가이드에서 사용자가 보류한 상태이며, 퀘스트 자체의 수락·완료 상태는 바뀌지 않습니다."
  elseif state and code~="superseded" then detail=detail.." "..state end
  if why and why~=state and code~="superseded" then detail=detail.." "..why end
 end
 local c=colors[key]
 local result={questId=id,key=key,label=labels[key],color={c[1],c[2],c[3]},blocked=blocked,reason=reason,detail=detail,code=code,historyReason=key=="unknown" and historyReason or nil}
 if type(cache)=="table" then cache[id]=result end
 return result
end
function G.QuestStatusSummary(ids,cache)
 local counts={all=0,unaccepted=0,active=0,turnin=0,done=0,blocked=0,unknown=0}
 local seen={}
 for _,raw in ipairs(type(ids)=="table" and ids or {})do
  local id=validId(raw)
  if id and not seen[id] then
   seen[id]=true
   local status=G.QuestListStatus(id,cache)
   counts.all=counts.all+1;counts[status.key]=counts[status.key]+1
   if status.blocked then counts.blocked=counts.blocked+1 end
  end
 end
 return counts
end
function G.QuestStatusMatches(status,filter)
 if type(status)~="table" then return false end
 if filter==nil or filter=="all" then return true end
 if filter=="blocked" then return status.blocked==true end
 return labels[filter]~=nil and status.key==filter
end

-- Primary contract: Forever 1.60.1.70862 QuestLogDocumentation.lua defines
-- GetQuestObjectives(questID) -> {text,type,finished,numFulfilled,numRequired}.
-- Blizzard_QuestObjectiveTracker.lua uses GetNumQuestLeaderBoards(logIndex)
-- and GetQuestLogLeaderBoard(objectiveIndex,logIndex[,suppressPercentage]).
-- Both reads below use exact IDs/indices; neither selects a different quest.
local function logIndexFor(id,explicit)
 local index=validId(explicit) or validId(invoke(C_QuestLog and C_QuestLog.GetLogIndexForQuestID,id))
 local active=G.activeQuests and G.activeQuests[id]
 index=index or validId(active and active.logIndex)
 if not index then return nil end
 local info=invoke(C_QuestLog and C_QuestLog.GetInfo,index)
 if type(info)=="table" and info.questID and tonumber(info.questID)~=id then return nil end
 return index
end
local function liveObjectives(id,explicit)
 local modern=C_QuestLog and C_QuestLog.GetQuestObjectives
 local empty
 if type(modern)=="function" then
  local ok,rows=pcall(modern,id)
  if ok and type(rows)=="table" then
   if #rows>0 then return rows,"modern","rows" end
   empty=true
  end
 end
 local index=logIndexFor(id,explicit)
 if index and type(GetNumQuestLeaderBoards)=="function" and type(GetQuestLogLeaderBoard)=="function" then
  local count=finite(invoke(GetNumQuestLeaderBoards,index))
  if count and count>=0 and count%1==0 then
   local rows={}
   for i=1,count do
    local ok,line,kind,finished=pcall(GetQuestLogLeaderBoard,i,index)
    if not ok or not text(line) then return nil,"legacy","unavailable" end
    local current,required=line:match("(%d+)%s*/%s*(%d+)%s*$")
    rows[#rows+1]={text=line,type=kind,finished=finished,numFulfilled=tonumber(current),numRequired=tonumber(required)}
   end
   return rows,"legacy",count>0 and "rows" or "empty"
  end
 end
 if empty then return {},"modern","empty" end
 return nil,type(modern)=="function" and "modern" or "none","unavailable"
end
local function recordFinished(row,current,required)
 if not isHidden(row.finished) then
  if row.finished==true or row.finished==1 then return true end
  if row.finished==false or row.finished==0 then return false end
 end
 if current and required and required>0 then return current>=required end
 return nil
end
local function quantityInText(line,current,required)
 local a,b=line:match("(%d+)%s*/%s*(%d+)%s*%)?%s*$")
 return tonumber(a)==current and tonumber(b)==required
end
function G.QuestObjectiveProgress(id,cache)
 id=validId(id);if not id then return nil end
 if type(cache)=="table" and cache[id] then return cache[id] end
 local result={questId=id,available=false,done=0,total=0,ratio=nil,summary="진행 기록 확인 필요",objectives={},source="none",
  detail="게임에서 읽은 목표 기록이 없어 진행률을 표시하지 않습니다."}
 if not truth(read("IsInLog",id)) then
  result.summary="받은 퀘스트의 진행 기록만 표시합니다."
 else
  local rows,source,state=liveObjectives(id)
  result.source=source;result.state=state
  if state=="empty" then result.summary="표시할 진행 목표가 없습니다." end
  local allKnown=true
  local partialHasQuantity=false
  for _,row in ipairs(rows or {})do
   if type(row)~="table" then allKnown=false
   else
    local current,required=finite(row.numFulfilled),finite(row.numRequired)
    if not current or current<0 or not required or required<=0 then current=nil;required=nil end
    local finished=recordFinished(row,current,required)
    if finished==nil then allKnown=false end
    local line=text(row.text) or "목표 설명 확인 필요"
    if G.KoreanQuestObjectives then line=text(invoke(G.KoreanQuestObjectives,id,line)) or line
    elseif G.KoreanText then line=text(invoke(G.KoreanText,line)) or line end
    local quantity=current and required and (tostring(current).."/"..tostring(required)) or nil
    local display=line
    if quantity and not quantityInText(line,current,required) then display=line.." ("..quantity..")" end
    local goal={text=line,current=current,required=required,finished=finished,display=display,quantity=quantity,type=text(row.type)}
    result.objectives[#result.objectives+1]=goal;result.total=result.total+1
    if finished then result.done=result.done+1 end
    if finished~=true and (not result.partialText or (quantity and not partialHasQuantity)) then
     result.partialText=display;partialHasQuantity=quantity~=nil
    end
   end
  end
  if result.total>0 then
   result.available=true
   result.summary="완료 목표 "..result.done.."/"..result.total
   if allKnown then result.ratio=result.done/result.total
   else result.summary=result.summary.." · 일부 기록 확인 필요" end
   result.detail="진행 막대는 게임 목표 중 끝낸 목표의 비율입니다. 서로 다른 처치·수집 수량을 합산하지 않으며, 보상까지 받은 완료 상태를 뜻하지 않습니다."
  end
 end
 if type(cache)=="table" then cache[id]=result end
 return result
end
local function signatureValue(value)
 if isHidden(value) then return "hidden" end
 local kind=type(value)
 if kind=="string" then return "s"..#value..":"..value end
 if kind=="number" then return finite(value) and ("n"..tostring(value)) or "invalid-number" end
 if kind=="boolean" then return value and "true" or "false" end
 return kind
end
function G.QuestProgressSignature(id,logIndex)
 id=validId(id);if not id then return "invalid-quest" end
 if not truth(read("IsInLog",id)) then return "not-in-log" end
 local rows,source,state=liveObjectives(id,logIndex)
 local parts={source,state,truth(read("IsReadyToTurnIn",id)) and "turnin" or "active"}
 for i,row in ipairs(rows or {})do
  parts[#parts+1]=tostring(i)
  if type(row)=="table" then
   for _,key in ipairs({"text","type","finished","numFulfilled","numRequired"})do parts[#parts+1]=signatureValue(row[key]) end
  else parts[#parts+1]="invalid-objective" end
 end
 return table.concat(parts,"|")
end

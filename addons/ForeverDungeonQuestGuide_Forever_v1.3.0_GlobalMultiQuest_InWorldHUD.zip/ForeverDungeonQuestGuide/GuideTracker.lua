local addon, G = ...
-- Independent, movable in-world leveling-style route tracker. The world map
-- is optional: starting a route never opens it automatically in V1.3.
local hud,heading,progress,current,detail,distance,nextOne,nextTwo,source,collapse
local textColor="|cffffdf92"
local function control(parent,title,x,y,w,h,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 b:SetText(title);b:SetScript("OnClick",fn)
 return b
end
local function label(parent,x,y,w,h,template)
 local t=parent:CreateFontString(nil,"OVERLAY",template)
 t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 t:SetSize(w,h);t:SetJustifyH("LEFT");t:SetJustifyV("MIDDLE")
 return t
end
local function kindName(step)
 return ({accept="수락",objective="수행",turnin="보고",inside="던전",entrance="입구"})[(step and step.kind) or ""] or "이동"
end
local function questLabel(step)
 if not step then return "" end
 local title=step.title or "좌표 확인 필요"
 return "|cffffdd91["..kindName(step).."]|r "..title
end
local function collapsedSize()
 if not hud then return end
 local small=G.db and G.db.hudCollapsed
 hud:SetHeight(small and 44 or 234)
 for _,item in ipairs({progress,current,detail,distance,nextOne,nextTwo,source}) do
  if small then item:Hide() else item:Show() end
 end
 for _,b in ipairs(hud.controls or {}) do
  if small then b:Hide() else b:Show() end
 end
 if collapse then collapse:SetText(small and "+" or "−") end
end
local function initialize()
 if hud or not UIParent then return end
 hud=CreateFrame("Frame","ForeverDungeonQuestGuideHUD",UIParent)
 hud:SetSize(375,234)
 local saved=G.db and G.db.hudPosition or nil
 if saved and saved.anchor=="TOPLEFT" then
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",saved.x or 32,saved.y or -195)
 elseif saved then
  -- Read V1.2's center-based placement without changing existing preferences.
  hud:SetPoint("TOP",UIParent,"TOP",saved.x or 0,saved.y or -125)
 else
  hud:SetPoint("TOPLEFT",UIParent,"TOPLEFT",30,-210)
 end
 hud:SetClampedToScreen(true)
 hud:SetFrameStrata("MEDIUM");hud:SetToplevel(true)
 hud:SetMovable(true);hud:EnableMouse(true);hud:RegisterForDrag("LeftButton")
 local backdrop=hud:CreateTexture(nil,"BACKGROUND")
 backdrop:SetAllPoints();backdrop:SetColorTexture(.055,.068,.08,.95)
 local border=hud:CreateTexture(nil,"BORDER")
 border:SetPoint("TOPLEFT",hud,"TOPLEFT",0,0)
 border:SetPoint("TOPRIGHT",hud,"TOPRIGHT",0,0)
 border:SetHeight(3);border:SetColorTexture(.93,.71,.27,1)
 local line=hud:CreateTexture(nil,"BORDER")
 line:SetPoint("TOPLEFT",hud,"TOPLEFT",9,-42)
 line:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-9,-42)
 line:SetHeight(1);line:SetColorTexture(.33,.31,.22,1)
 hud:SetScript("OnDragStart",function(self)
  if not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
 end)
 hud:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  if not G.db then return end
  local left=self:GetLeft();local top=self:GetTop()
  local parentLeft=UIParent:GetLeft() or 0
  local parentTop=UIParent:GetTop() or 0
  if left and top then G.db.hudPosition={anchor="TOPLEFT",x=left-parentLeft,y=top-parentTop} end
 end)
 heading=label(hud,12,-8,279,25,"GameFontNormal")
 progress=label(hud,12,-49,351,21,"GameFontHighlightSmall")
 current=label(hud,12,-72,349,43,"GameFontHighlight")
 current:SetJustifyV("TOP")
 detail=label(hud,12,-112,349,25,"GameFontHighlightSmall")
 distance=label(hud,12,-136,351,19,"GameFontNormalSmall")
 nextOne=label(hud,12,-160,350,19,"GameFontHighlightSmall")
 nextTwo=label(hud,12,-181,350,19,"GameFontHighlightSmall")
 source=label(hud,12,-205,350,15,"GameFontHighlightSmall")
 collapse=control(hud,"−",300,-9,30,27,function()
  G.db.hudCollapsed=not G.db.hudCollapsed;collapsedSize()
 end)
 control(hud,"×",334,-9,29,27,function()G.db.hudHidden=true;hud:Hide()end)
 local a=control(hud,"◀ 이전",12,-225,72,22,function()G.NextGuide(-1,false)end)
 local b=control(hud,"다음 완료 ▶",89,-225,99,22,function()G.NextGuide(1,true)end)
 local c=control(hud,"지도",194,-225,53,22,function()
  local st=G.CurrentStep()
  if st and st.point then G.Navigate(st.point,true)
  else G.Print("이 단계의 지도 좌표를 확인할 수 없습니다.") end
 end)
 local d=control(hud,"동선표",253,-225,61,22,function()G.TogglePlanWindow()end)
 local e=control(hud,"전체",319,-225,44,22,function()G.ShowUI(true)end)
 hud.controls={a,b,c,d,e}
 -- Place controls above the bottom boundary and reserve height for them.
 for _,btn in ipairs(hud.controls) do btn:ClearAllPoints() end
 a:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-205)
 b:SetPoint("TOPLEFT",hud,"TOPLEFT",89,-205)
 c:SetPoint("TOPLEFT",hud,"TOPLEFT",194,-205)
 d:SetPoint("TOPLEFT",hud,"TOPLEFT",253,-205)
 e:SetPoint("TOPLEFT",hud,"TOPLEFT",319,-205)
 -- Source and buttons use the same bottom row; place source above them.
 source:ClearAllPoints();source:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-189)
 source:SetHeight(12)
 nextTwo:ClearAllPoints();nextTwo:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-173)
 nextTwo:SetHeight(16)
 nextOne:ClearAllPoints();nextOne:SetPoint("TOPLEFT",hud,"TOPLEFT",12,-157)
 hud:Hide()
 collapsedSize()
end
function G.HUDUpdateDistance()
 if not hud or not hud:IsShown() or not G.db or G.db.hudCollapsed then return end
 local step=G.CurrentStep()
 if not step then distance:SetText("");return end
 local location=G.PlayerLocation and G.PlayerLocation()
 local info,dir=G.RouteDistanceLabel and G.RouteDistanceLabel(location,step.point)
 if not info then info="거리 정보 확인 필요" end
 local direction=dir and dir~="" and ("  |cffffd47c방향 "..dir.."|r") or ""
 distance:SetText("|cff9cbfff"..info.."|r"..direction)
end
function G.HUDRefresh()
 if not G.db or not G.db.manualProgress then return end
 initialize()
 if not hud then return end
 local route=G.db.guide
 if not route or not route.steps or #route.steps==0 or G.db.hudHidden then hud:Hide();return end
 hud:Show()
 collapsedSize()
 local done,total=G.GuideProgress()
 heading:SetText(textColor.."퀘스트 이동 가이드|r  |cffaac4ca"..done.."/"..total.."|r")
 if route.mode=="selected" then
  local q=route.optimization and route.optimization.selectedQuestCount or (G.SelectedCount and G.SelectedCount()) or 0
  progress:SetText("|cff88d7e9선택 "..q.."개 퀘스트|r  ·  전체 방문 "..total.."단계"..(route.turninOnly and "  ·  보고만" or ""))
 else progress:SetText("|cff88d7e9던전 준비|r  ·  총 "..total.."단계") end
 local st=G.CurrentStep()
 if st then
  current:SetText("|cffffefbc"..(route.index or 1)..". |r"..questLabel(st))
  local npc=(st.point and st.point.name) or ""
  detail:SetText((npc~="" and ("|cffffd891NPC/위치: |r"..npc) or (st.note or "위치 확인 필요")))
 else
  current:SetText("|cff87dc98모든 방문 단계 완료|r")
  detail:SetText("퀘스트 추적기에서 최종 완료 상태를 확인하세요.")
 end
 local ix=route.index or 1
 local s1,s2=route.steps[ix+1],route.steps[ix+2]
 nextOne:SetText(s1 and ("|cff99a5af다음  |r"..questLabel(s1)) or "|cff99a5af다음 단계 없음|r")
 nextTwo:SetText(s2 and ("|cff99a5af그다음  |r"..questLabel(s2)) or "")
 local op=route.optimization
 if op and op.approximate then
  source:SetText("|cffffb36d다른 지역/좌표 미확인은 추정 순서 · 도로 미반영|r")
 else
  source:SetText("|cff9da8ac전체 체크 동선 최적화 · 직선 좌표 기준|r")
 end
 G.HUDUpdateDistance()
end
function G.ToggleHUD()
 if not G.db or not G.db.manualProgress then return end
 G.db.hudHidden=not G.db.hudHidden
 G.HUDRefresh()
end

local addon,G=...
G.navStatus="경로 대기"
local tomtomUid,usedNative,previousNative,pending
local OWNER="ForeverDungeonQuestGuide"
local function display(value) return G.KoreanText and G.KoreanText(value) or value end
local lastGuideSignature=nil
local recoveryWait=nil
local recoveryWindow=0
local recoveryBudget=0
local unsubscribeJourney=nil
local MAX_SP_STOPS=3 -- show only current + 2 upcoming, rather than flooding the world map
local function shortPathAPI()
 local s=_G.ShortestPathForever
 local api=s and s.API
 if type(api)=="table" and (api.version==1 or api.version==2) then return api end
 return nil
end
local function ownsJourney()
 local api=shortPathAPI()
 if not api then return false end
 if type(api.Journey)=="function" then
  local ok,journey=pcall(api.Journey)
  if ok and type(journey)=="table" then return journey.owner==OWNER end
 end
 if type(api.CurrentStop)=="function" then
  local ok,idx=pcall(api.CurrentStop,OWNER)
  if ok and type(idx)=="number" and idx>0 then return true end
 end
 return false
end
G.IsGuideJourneyActive=ownsJourney
local function legalPoint(point)
 return type(point)=="table" and type(point.map)=="number" and type(point.x)=="number"
    and type(point.y)=="number" and point.x>=0 and point.x<=1 and point.y>=0 and point.y<=1
end
function G.OpenRegionMap(map)
 if type(map)~="number" or map<=0 then return false end
 if InCombatLockdown and InCombatLockdown() then G.Print("전투 종료 후 지도를 엽니다.");return false end
 local opened=false
 if C_Map and type(C_Map.OpenWorldMap)=="function" then
  local ok=pcall(C_Map.OpenWorldMap,map);opened=ok or opened
 end
 local frame=_G.WorldMapFrame
 if type(ToggleWorldMap)=="function" and (not frame or (type(frame.IsShown)=="function" and not frame:IsShown())) then
  local ok=pcall(ToggleWorldMap);opened=ok or opened
  frame=_G.WorldMapFrame
 end
 if frame and type(frame.SetMapID)=="function" then
  local ok=pcall(frame.SetMapID,frame,map);opened=ok or opened
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
 return opened
end
function G.OpenPointMap(p)
 if not legalPoint(p) then return false end
 return G.OpenRegionMap(p.map)
end
local function clearLocalWaypoints()
 if tomtomUid and TomTom and type(TomTom.RemoveWaypoint)=="function" then
  pcall(TomTom.RemoveWaypoint,TomTom,tomtomUid)
 end
 tomtomUid=nil
 if usedNative and C_Map and type(C_Map.ClearUserWaypoint)=="function" then
  -- Do not clear another addon's waypoint or one the user moved to.
  local current=G.SafeCall(C_Map.GetUserWaypoint)
  if not current or (previousNative and current==previousNative) then
   pcall(C_Map.ClearUserWaypoint)
  end
 end
 usedNative=false;previousNative=nil
end
function G.ClearWaypoint()
 -- Clearing our guide must never cancel the player's own journey, or one
 -- started by Questie, Adventure Guide, RestedXP, or other external addons.
 local api=shortPathAPI()
 if api and type(api.Cancel)=="function" then pcall(api.Cancel,OWNER) end
 clearLocalWaypoints()
 lastGuideSignature=nil;recoveryWait=nil;recoveryWindow=0;recoveryBudget=0;pending=nil
end
function G.Navigate(p,openMap)
 if not legalPoint(p) then
  G.navStatus="좌표 대신 가이드의 장소·수행 절차를 확인하세요. 던전 내부는 던전 네비게이터를 이용할 수 있습니다."
  return false
 end
 if InCombatLockdown and InCombatLockdown() then
  pending={p=p,open=openMap}
  G.navStatus="전투 종료 후 길찾기를 적용합니다."
  return false
 end
 clearLocalWaypoints()
 local engine=shortPathAPI()
 if engine and type(engine.Navigate)=="function" and (engine.version==1 or engine.version==2) then
  local ok,result=pcall(engine.Navigate,OWNER,p.map,p.x,p.y,display(p.name) or "퀘스트 목적지")
  if ok and result then
   G.navStatus="실제 이동 경로: 최단 경로 애드온 연결됨"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if TomTom and type(TomTom.AddWaypoint)=="function" then
  local ok,uid=pcall(TomTom.AddWaypoint,TomTom,p.map,p.x,p.y,{title=display(p.name) or "던전 퀘스트 목적지",persistent=false})
  if ok and uid then
   tomtomUid=uid
   if type(TomTom.SetCrazyArrow)=="function" then pcall(TomTom.SetCrazyArrow,TomTom,uid,0,display(p.name) or "목적지") end
   G.navStatus="톰톰 화살표/지도 지점 표시 (지형 경로 계산 아님)"
   if openMap then G.OpenPointMap(p) end
   return true
  end
 end
 if C_Map and type(C_Map.SetUserWaypoint)=="function" and UiMapPoint and type(UiMapPoint.Create)=="function" then
  local point=G.SafeCall(UiMapPoint.Create,p.map,p.x,p.y)
  if point then
   local ok,result=pcall(C_Map.SetUserWaypoint,point)
   if ok and result~=false then
    usedNative=true;previousNative=point
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
     pcall(C_SuperTrack.SetSuperTrackedUserWaypoint,true)
    end
    G.navStatus="기본 지도 목적지 표시 (지형 경로 계산 아님)"
    if openMap then G.OpenPointMap(p) end
    return true
   end
  end
 end
 G.navStatus="지도 위치 표시 실패: 톰톰 또는 최단 경로 애드온을 확인하세요."
 if openMap then G.OpenPointMap(p) end
 return false
end
function G.OnLeaveCombat()
 if pending then
  local p=pending;pending=nil
  if p.guide then G.NavigateGuideRoute(G.db and G.db.guide,p.open,true)
  else G.Navigate(p.p,p.open) end
  if G.UIRefresh then G.UIRefresh() end
 end
end
function G.OpenDungeonNavigator()
 local nav=_G.ForeverDungeonNavigator
 if nav and type(nav.ShowLeader)=="function" then
  local ok=pcall(nav.ShowLeader,true)
  if ok then return true end
 end
 G.Print("포에버 던전 네비게이터가 없거나 준비되지 않았습니다. 설치·로드 상태를 확인하세요.")
 return false
end

-- The guide is the authority for visit order. Shortest Path supplies terrain
-- legs between those stops, but must not pick a different quest order.
-- Hold each stop until the quest status/manual advance actually changes.
local instanceIds={brd=230,rfc=389,wailing=43,deadmines=36,sfk=33,bfd=48,stockades=34,gnomer=90,rfk=47,sm=189,rfd=129,uldaman=70,zf=209,mara=349,sunken=109,brs=229,dm=429,strat=329,scholo=289}
local function inDungeon(dungeonId)
 local inside,kind
 if type(IsInInstance)=="function" then inside,kind=IsInInstance() end
 if not inside or kind~="party" then return false end
 local name,instanceID
 if type(GetInstanceInfo)=="function" then
  local _instanceType,_difficulty,_difficultyName,_maxPlayers,_dynamic,_isDynamic
  name,_instanceType,_difficulty,_difficultyName,_maxPlayers,_dynamic,_isDynamic,instanceID=GetInstanceInfo()
 end
 local d=G.GetDungeon(dungeonId)
 return (instanceIds[dungeonId] and instanceID==instanceIds[dungeonId]) or (d and name==d.name) or (dungeonId=="brd" and name=="Blackrock Depths") or false
end
G.IsInGuideDungeon=inDungeon
local function proxy(p,title)
 if not legalPoint(p) then return nil end
 return {map=p.map,x=p.x,y=p.y,name=title or p.name,approx=true,approach=true}
end
function G.GuideStepNavPoint(step)
 if not step then return nil end
 if step.indoor then
  if inDungeon(step.indoor.dungeonId) then return nil end
  return proxy(step.indoor.entrance,step.indoor.dungeon.." 입구 부근 (실내 목표 아님)")
 end
 if step.landmark then
  local lm=step.landmark
  if lm.dungeonId and inDungeon(lm.dungeonId) then return nil end
  return proxy(lm.approach,lm.approach and lm.approach.name)
 end
 if legalPoint(step.point) then return step.point end
 return nil
end
function G.OpenGuideStepMap(step)
 if not step then return false end
 local p=G.GuideStepNavPoint(step)
 if p then return G.OpenPointMap(p) end
 if step.indoor or (step.landmark and step.landmark.dungeonId) then return G.OpenDungeonNavigator() end
 if step.landmark and step.landmark.map then return G.OpenRegionMap(step.landmark.map) end
 G.Print(display(step.note) or "현재 단계의 장소/행동 안내를 확인하세요.");return false
end
function G.GuideStepNavTitle(step,p)
 local label=step.kind=="accept" and "수락" or step.kind=="turnin" and "보고" or
  (step.kind=="objective" or step.kind=="inside") and "수행" or step.kind=="entrance" and "입구" or "이동"
 if step.indoor then return display(step.indoor.dungeon.." 입구 부근 → "..step.indoor.npcName.." · "..label) end
 if step.landmark then return display(((p and p.name) or step.landmark.site or step.landmark.zone).." · 접근 지점 · "..label) end
 local target=(p and p.name) or step.contactName or step.objectiveTitle
 if type(target)~="string" or target=="" then target=step.title or "퀘스트 목적지" end
 return display(target.." · "..label)
end
local function routeStops(guide)
 local out,keys={},{}
 local ix=guide.index or 1
 for i=ix,#(guide.steps or {}) do
  local step=guide.steps[i]
  if not (G.StepIsDone and G.StepIsDone(step,i)) then
  if G.CurrentAcceptanceBlock and G.CurrentAcceptanceBlock(step) then break end
  local p=G.GuideStepNavPoint(step)
  if not legalPoint(p) then break end -- don't skip an unknown required stop
  local title=G.GuideStepNavTitle(step,p)
  out[#out+1]={map=p.map,x=p.x,y=p.y,title=title,
                 tooltip=display((step.indoor and (step.indoor.room.." · "..step.indoor.npcName.." · 실제 목표는 던전 내부")) or
                         (step.landmark and step.landmark.instruction) or (step.questName or title)),hold=true,
                 questID=tonumber(step.quest)}
  keys[#keys+1]=(step.key or (tostring(i)..":"..title))..":"..p.map..":"..string.format("%.5f,%.5f",p.x,p.y)..":"..title
  if p.approach or #out>=MAX_SP_STOPS then break end
  end
 end
 return out,table.concat(keys,"|")
end
function G.NavigateGuideRoute(guide,openMap,force)
 if not guide or type(guide.steps)~="table" then return false end
 local step=guide.steps[guide.index or 1]
 if not step then
  G.ClearWaypoint();G.navStatus="통합 동선 완료";return false
 end
 if G.StepIsDone and G.StepIsDone(step,guide.index or 1) then
  G.ClearWaypoint();G.navStatus="완료된 단계 · 이동 불필요";return false
 end
 local blocked=G.CurrentAcceptanceBlock and G.CurrentAcceptanceBlock(step)
 if blocked then
  G.ClearWaypoint();G.navStatus="수락 조건 미충족 · "..blocked
  if G.RefreshMapPins then G.RefreshMapPins() end
  return false
 end
 local navPoint=G.GuideStepNavPoint(step)
 if not legalPoint(navPoint) then
  -- No guessed points, no skipping that mandatory quest task.
  G.ClearWaypoint()
  if step.indoor and inDungeon(step.indoor.dungeonId) then
   G.navStatus="실내 진행 · "..step.indoor.room.." · "..step.indoor.npcName
  elseif step.landmark then
   G.navStatus="목표 장소: "..(step.landmark.zone or "지역").." · "..(step.landmark.site or "안내 확인").." (정밀 좌표 미제공)"
  elseif step.regionHint then
   G.navStatus="목표 위치 자료 부족 · 왼쪽 수행 안내 참고"
  else
   G.navStatus="지도 경로 없음 · 왼쪽 수행 안내 참고"
  end
  if G.RefreshMapPins then G.RefreshMapPins() end
  return false
 end
 if InCombatLockdown and InCombatLockdown() then
  pending={guide=true,open=openMap}
  G.navStatus="전투 종료 후 현재 통합 동선을 여정에 반영합니다."
  return false
 end
 local api=shortPathAPI()
 local stops,signature=routeStops(guide)
 if #stops==0 then return false end
 if api and type(api.NavigateRoute)=="function" then
  -- Avoid sending the same itinerary again on every map refresh, or movement.
  if not force and lastGuideSignature==signature and ownsJourney() then
   if openMap then G.OpenPointMap(navPoint) end
   return true
  end
  local ok,started=pcall(api.NavigateRoute,OWNER,stops)
  if ok and started then
   lastGuideSignature=signature
   clearLocalWaypoints()
   G.navStatus="여정에 통합 동선 적용: 현재 + 다음 "..tostring(#stops-1).."경유지 (수행/보고 전 대기)"
   if openMap then G.OpenPointMap(navPoint) end
   if G.RefreshMapPins then G.RefreshMapPins() end
   return true
  end
 end
 -- Older releases may only expose the single-stop API. Be explicit.
 local named={map=navPoint.map,x=navPoint.x,y=navPoint.y,name=G.GuideStepNavTitle(step,navPoint)}
 local success=G.Navigate(named,openMap)
 if success then
  lastGuideSignature=signature
  G.navStatus="외부 길찾기 구버전: 현재 경유지 1개만 안내 · 차례대로 갱신"
 end
 return success
end
-- One delayed repair per quest accept/turn-in, not a perpetual tug-of-war.
-- Other addons and manual waypoints keep control outside these quest events.
function G.ScheduleQuestJourneyRepair()
 if not G.db or not G.db.guide or not G.db.guide.steps or
    not G.db.guide.steps[G.db.guide.index or 1] then return end
 recoveryWait=1.6
 recoveryWindow=5
 recoveryBudget=2
end
function G.InitializeNavigationSubscription()
 if unsubscribeJourney then return end
 local api=shortPathAPI()
 if not api or type(api.Subscribe)~="function" then return end
 local ok,unsubscribe=pcall(api.Subscribe,function(changes)
  if recoveryWindow<=0 or recoveryBudget<=0 or type(changes)~="table" then return end
  if not (changes.changed or changes.started or changes.stop) then return end
  if ownsJourney() then return end
  local guide=G.db and G.db.guide
  if guide and guide.steps and guide.steps[guide.index or 1] then
   -- Defer instead of navigating synchronously inside ShortestPath's callback.
   recoveryWait=math.min(recoveryWait or .2,.2)
  end
 end)
 if ok and type(unsubscribe)=="function" then unsubscribeJourney=unsubscribe end
end
function G.TickQuestJourneyRepair(dt)
 dt=tonumber(dt) or 0
 if recoveryWindow>0 then recoveryWindow=math.max(0,recoveryWindow-dt) end
 if not recoveryWait then return end
 recoveryWait=recoveryWait-dt
 if recoveryWait>0 then return end
 recoveryWait=nil
 if recoveryWindow<=0 or recoveryBudget<=0 then return end
 local guide=G.db and G.db.guide
 if not guide or not guide.steps or not guide.steps[guide.index or 1] then return end
 local api=shortPathAPI()
 if not api or type(api.NavigateRoute)~="function" or ownsJourney() then return end
 recoveryBudget=recoveryBudget-1
 if G.NavigateGuideRoute(guide,false,true) then
  G.navStatus="퀘스트 변경 후 선택한 통합 동선을 여정에 다시 적용했습니다."
  if G.UIRefresh then G.UIRefresh() end
 end
end
function G.GuideNavigationInfo()
 local g=G.db and G.db.guide
 local st=g and g.steps and g.steps[g.index or 1]
 if G.GuideViewingHistory and G.GuideViewingHistory() then return "기록/미리보기 · 실제 여정은 현재 진행 단계 유지" end
 if st and G.StepIsDone and G.StepIsDone(st,g.index or 1) then return "완료 단계 · 이동 불필요" end
 if st and st.prepInventory then return "가방에서 사용 · 이동 불필요" end
 if st and not G.GuideStepNavPoint(st) then return st.indoor and "던전 내부 · 장소/행동 안내" or st.landmark and "장소/행동 안내 · 별도 이동 핀 없음" or "위치 자료 부족 · 확인된 수행 정보 안내" end
 local api=shortPathAPI()
 if not api then return "외부 여정 미설치" end
 if ownsJourney() then return "여정 동기화 · 통합 동선" end
 local j=type(api.Journey)=="function" and G.SafeCall(api.Journey)
 if j and j.owner and j.owner~=OWNER then
  return "다른 애드온이 여정을 사용 중입니다. 다시 연결하려면 /퀘스트가이드 여정"
 end
 return "여정 연결 대기 · /퀘스트가이드 여정"
end

local addon,G=...
-- Original summaries of Forever 1.60.1 quest records and documented encounter routes.
-- No guessed precise indoor coordinates. A dungeon approach is explicitly a proxy.
local function meta(id)
 G.specialQuestMeta[id]=G.specialQuestMeta[id] or {}
 return G.specialQuestMeta[id]
end
local function indoor(id,kind,room,target,action,contactType)
 local m=meta(id);m.insideStages=m.insideStages or {}
 m.insideStages[kind]={dungeon="brd",room=room,npcName=target,instruction=action,contactType=contactType or "npc",verified=true}
end
local function landmark(id,kind,zone,site,target,action,approach)
 local m=meta(id);m.stageLandmarks=m.stageLandmarks or {}
 m.stageLandmarks[kind]={zone=zone,site=site,target=target,instruction=action,approach=approach,verified=true}
end
local function objective(id,room,target,action) indoor(id,"objective",room,target,action,"objective") end
local prison="입구 쪽 감금 구역"
local tavern="험상궂은 주정뱅이 선술집"
local tomb="소환사의 무덤 (일곱 현자 구역)"
local throne="옥좌"
local approach=G.GetDungeon("brd").entrance
local mountain="검은바위 산"
local chain="검은바위 산 중앙 섬, 프랑클론의 무덤"
local function outside(id,kind,site,target,action) landmark(id,kind,mountain,site,target,action,approach) end
local function coords(id,kind,map,x,y,name)
 local t=kind=="accept" and G.pickupOverrides or G.turninOverrides
 t[id]={map=map,x=x/100,y=y/100,name=name}
end
local function same(id,map,x,y,name) coords(id,"accept",map,x,y,name);coords(id,"turnin",map,x,y,name) end
-- Quest 7761: recorded pre-instance corridor, not the dungeon interior or a continent pin.
-- Forever availability is explicitly unconfirmed; the manual guide remains conditional.
local brs=G.GetDungeon("brs")
landmark(7761,"accept",mountain,"검은바위 첨탑 입구 앞 오른쪽 통로","방패부대 병참장교",
 "방패부대 병참장교를 찾으면 처치해 블랙핸드의 명령서를 획득하고 가방에서 우클릭하세요. 현재 출현·드롭 여부는 미확인입니다.")
meta(7761).stageLandmarks.accept.map=brs and brs.entrance and brs.entrance.map
meta(7761).stageLandmarks.accept.note="첨탑 입구 앞, 검은날개 둥지 방향 통로. 실제 출현 위치·드롭 미검증."
meta(7761).insideStages={objective={dungeon="brs",room="상층 최종 보스 구역",npcName="사령관 드라키사스",contactType="objective",instruction="검은바위 첨탑 상층에서 사령관 드라키사스를 처치하세요. 이후 뒤쪽의 드라키사스의 낙인과 상호작용해야 합니다.",verified=true},
 turnin={dungeon="brs",room="상층 사령관 드라키사스 뒤쪽",npcName="드라키사스의 낙인",contactType="object",instruction="드라키사스의 낙인과 상호작용해 퀘스트를 완료하세요. 검은날개 둥지 입장 관련 퀘스트이며 현재 적용 여부는 게임에서 확인하세요.",verified=true}}
local chalice="유령의 성배"
local prepare="채광 숙련 230 이상 필요. 별루비 2개, 금괴 20개, 진은 주괴 10개를 준비하세요."
indoor(4083,"accept",tomb,chalice,prepare.." 일곱 현자 전투를 시작하기 전에 그늘의 문지기와 대화해 성배를 소환하고, 성배를 클릭해 수락하세요.","object")
indoor(4083,"turnin",tomb,chalice,"준비한 재료를 성배에 바친 뒤 그늘의 문지기와 다시 대화해 검은무쇠 제련을 배우세요. 전투가 시작되기 전에 진행하세요.","object")
meta(4083).note=prepare
G.koQuestNames[4083]="유령의 성배"
G.koQuestNames[4201]="사랑의 묘약"
local nag="지배인 나그마라"
indoor(4201,"accept",tavern,nag,"선술집 안의 나그마라에게 수락하고 빈 약병을 받으세요. 수락 후 아즈샤라의 절벽거인과 운고로의 골락카 간헐천으로 이동해야 합니다.")
indoor(4201,"turnin",tavern,nag,"그롬의 피 4개, 거대한 은 광석 10개, 가득 찬 나그마라의 약병 1개를 가지고 선술집의 나그마라에게 보고하세요.")
-- Materials that can be bought/traded should not send players to a random chest.
local function material(id,title,zone,site,action,p)
 return {kind="item",id=id,title=title,point=p,landmark={zone=zone,site=site,target=title,instruction=action,verified=true,approach=p}}
end
G.verifiedObjectives={
 [4083]={material(791,"별루비 2개","재료 준비","경매장 또는 채광 부산물","별루비 2개를 구입하거나 보유분에서 준비하세요."),material(3577,"금괴 20개","재료 준비","경매장 또는 제련","금괴 20개를 준비하세요. 금광석을 제련해도 됩니다."),material(6037,"진은 주괴 10개","재료 준비","경매장 또는 제련","진은 주괴 10개를 준비하세요. 던전 입장 전 미리 챙기는 편이 좋습니다.")},
 [4201]={material(8846,"그롬의 피 4개","재료 준비","경매장 또는 약초채집","그롬의 피 4개를 구입하거나 채집하세요."),material(11405,"거대한 은 광석 10개","아즈샤라","남동부 절벽거인 활동 지역","절벽거인·천둥절벽거인·우레절벽거인을 처치해 퀘스트 전용 은 광석 10개를 모으세요. 일반 은괴가 아닙니다.",{map=1447,x=.52,y=.76,name="아즈샤라 절벽거인 사냥 지역 (대략)",approx=true}),material(11413,"가득 찬 나그마라의 약병","운고로 분화구","골락카 간헐천","간헐천 위쪽 물이 흐르는 곳에서 수락 시 받은 빈 약병을 사용하세요.",{map=1449,x=.32,y=.50,name="골락카 간헐천 (대략)",approx=true})},
}
-- Windsor chain: identify actual recipient and item-start, not generic NPC pickup.
local windsor="치안대장 윈저"
local maxwell="치안대장 맥스웰"
coords(4241,"accept",1428,84.6,68.8,maxwell)
indoor(4241,"turnin",prison,windsor,"입구에서 감금 구역의 윈저 감방으로 이동해 대화하고 보고하세요.")
meta(4241).directTurnin=true
indoor(4242,"accept",prison,windsor,"윈저에게서 보고서를 받아 불타는 평원 모건의 망루로 돌아가세요.")
coords(4242,"turnin",1428,84.6,68.8,maxwell);meta(4242).directTurnin=true
indoor(4264,"accept","검은바위 나락의 검은무쇠 드워프 활동 구역","꼬깃꼬깃한 쪽지","버려진 희망을 보고한 뒤 던전의 검은무쇠 적에게서 쪽지를 획득하고 가방에서 사용해 수락하세요.","item")
indoor(4264,"turnin",prison,windsor,"쪽지를 윈저에게 전달하세요.");meta(4264).directTurnin=true
indoor(4282,"accept",prison,windsor,"윈저에게 수락한 뒤 두 정보 조각을 회수하세요.")
objective(4282,"병영 및 제작 구역","윈저의 잃어버린 정보 2종","사령관 앵거포지와 골렘 군주 아젤마크를 처치해 각각의 정보 조각을 하나씩 확보하세요.")
indoor(4282,"turnin",prison,windsor,"서로 다른 두 정보 조각을 가지고 감방으로 돌아가 보고하세요.")
indoor(4322,"accept",prison,windsor,"호위 시작 전 파티와 감금 구역의 이동 경로를 정리하세요.")
objective(4322,prison,windsor,"윈저를 따라 이동하며 장비 회수와 포로 구출을 돕고 탈출을 완료하세요.")
coords(4322,"turnin",1428,84.6,68.8,maxwell)
-- Kharan / king / princess chain.
local magni="국왕 마그니 브론즈비어드"
coords(4341,"accept",1455,39.4,55.8,magni)
coords(4361,"turnin",1455,39.4,55.8,magni);meta(4361).directTurnin=true
coords(4362,"accept",1455,39.4,55.8,magni)
objective(4362,throne,"제왕 다그란 타우릿산","제왕을 처치하되 모이라에게 피해를 주지 않도록 주의하세요.")
indoor(4362,"turnin",throne,"공주 모이라 브론즈비어드","제왕 처치 후 살아 있는 모이라에게 보고하세요.")
indoor(4363,"accept",throne,"공주 모이라 브론즈비어드","모이라에게서 후속 퀘스트를 수락하세요.")
coords(4363,"turnin",1455,39.4,55.8,magni);meta(4363).directTurnin=true
-- Neutral and faction-specific dungeon targets.
objective(4136,tavern,"리블리 스크류스피곳","선술집에서 리블리를 찾아 처치하고 머리카락을 회수하세요. 주변 손님과 전투가 번지지 않도록 주의하세요.")
objective(4123,"검은 금고","산의 정수","금고의 유물 보관함을 열어 산의 정수를 회수하세요. 필요한 금고 열쇠를 준비하고 방의 수호자 전투에 대비하세요.")
same(4123,1428,65.2,23.8,"맥스워트 우버글린트")
for _,id in ipairs({4126,4134}) do objective(id,tavern,"헐레이 블랙브레스","선술집 창고의 술통 3개를 파괴해 헐레이를 소환하고, 처치 후 잃어버린 양조법을 회수하세요.") end
same(4126,1426,46.8,52.4,"라그나르 썬더브루")
objective(4286,"검은무쇠 드워프가 있는 던전 구역","검은무쇠 허리띠 주머니","검은무쇠 드워프를 처치해 주머니 20개를 모으세요.")
same(4286,1428,84.6,68.6,"오랄리우스")
local forge="검은바위 나락 내부, 검은 모루 부근"
objective(3907,forge,"불의군주 인센디우스","인센디우스를 처치하고 퀘스트 요구 유물을 회수하세요.")
objective(4132,"동쪽 주둔지","사령관 앵거포지","병영의 앵거포지를 처치하세요.")
indoor(3981,"turnin",prison,"사령관 고르샤크","감금 구역의 고르샤크를 찾아 보고하세요.")
meta(3981).directTurnin=true
outside(3801,"accept",chain,"프랑클론 포지라이트","유령 상태로 중앙 섬의 프랑클론에게 대화하세요. 살아 있는 상태에서는 퀘스트 인물이 보이지 않습니다.")
outside(3801,"turnin",chain,"프랑클론 포지라이트","유령 상태로 프랑클론의 이야기를 듣고 후속 퀘스트를 받으세요.");meta(3801).directTurnin=true
outside(3802,"accept",chain,"프랑클론 포지라이트","유령 상태에서 열쇠 연계 퀘스트를 수락하세요.")
objective(3802,"검은 모루에서 장인의 전당으로 이어지는 구역","파이너스 다크바이어","파이너스를 처치하고 무쇠지옥을 획득하세요.")
indoor(3802,"turnin","타우릿산의 제단","프랑클론 포지라이트의 기념비","무쇠지옥을 기념비에 바쳐 어둠괴철로단 열쇠를 얻으세요.","object")
same(4024,1428,94.8,31.6,"사이러스 테레펜터스")
objective(4024,"입구 쪽 용암 통로","밸가르","밸가르를 처치한 후 퀘스트로 받은 변형된 검은용군단 허물을 시체에 사용해 담겨진 불의 정수를 얻으세요.")
-- Additional existing outdoor landmark: use an approach, never an exact boss pin.
if G.specialQuestMeta[4262] then G.specialQuestMeta[4262].stageLandmarks.objective.approach=approach end
-- The existing Incendius hint is more useful as an instance stage (entrance when outside).
meta(4263).stageLandmarks.objective=nil
objective(4263,"검은 모루","불의군주 인센디우스","검은 모루의 인센디우스를 처치하고 불타는 평원 모건의 망루의 잘린다 스프리그에게 보고하세요.")
G.verifiedRouteSources={"https://questing.wiki/wow-forever/dungeons/blackrock-depths/quests/","https://www.wowhead.com/forever/guide/blackrock-depths-dungeon-overview-location-rewards","https://wofwforever.com/ko/dungeons/blackrock-depths/","https://warcraft.wiki.gg/wiki/The_Spectral_Chalice","https://www.wowhead.com/forever/quest=4201/the-love-potion","https://questing.wiki/wow-forever/quests/series/4264/","https://questing.wiki/wow-forever/quests/series/4342/"}

-- Naxxramas: verified outdoor quest contacts and raid/material objectives.
-- Quest classification is not the pickup location. Sources in DATA_SOURCES.
G.verifiedQuestGoals=G.verifiedQuestGoals or {}
G.verifiedItemRequirements=G.verifiedItemRequirements or {}
local chapel="동부 역병지대 희망의 빛 예배당"
local rimblat="림블랫 어스쉐터"
local korfax="빛의 용사 코팩스"
local eligor="사령관 엘리고르 돈브링어"
local raid="낙스라마스"
local function raidMaterial(item,title,action)
 return material(item,title,raid,"공격대 내부",action.." 공격대 개방 및 입장 조건을 확인하세요.")
end
local function tradeMaterial(item,title)
 return material(item,title,"재료 준비","경매장·거래·제작",title.."을(를) 보유분, 거래 또는 제작으로 준비하세요.")
end
local function raidStage(id,kind,site,target,action)
 landmark(id,kind,raid,site,target,action.." 공격대 개방 및 입장 조건을 확인하세요.")
end
local tier3={
 {9068,"튜닉",22350,"더럽혀진 튜닉",25,4,15407,"거친 경화 가죽",3},
 {9069,"다리갑옷",22359,"더럽혀진 다리보호대",20,3,15407,"거친 경화 가죽",5},
 {9070,"투구",22360,"더럽혀진 면갑",15,4,20725,"마력의 결정체",2},
 {9071,"어깨갑옷",22361,"더럽혀진 어깨보호대",12,2,14342,"달빛 옷감",2},
 {9072,"장화",22365,"더럽혀진 장화",12,1,20725,"마력의 결정체",3},
 {9073,"장갑",22364,"더럽혀진 손보호구",8,1,15407,"거친 경화 가죽",5},
 {9074,"벨트",22363,"더럽혀진 벨트",8,1,20725,"마력의 결정체",3},
 {9075,"손목보호구",22362,"더럽혀진 손목보호대",6,1,15407,"거친 경화 가죽",2},
}
for _,v in ipairs(tier3) do
 local id=v[1]
 G.koQuestNames[id]="지축이동의 "..v[2]
 same(id,1423,71.3,49.4,rimblat)
 local part=v[4].." 1개";local scrap="닳아해진 사슬 조각 "..v[5].."개"
 local bar="아케이나이트 주괴 "..v[6].."개";local extra=v[8].." "..v[9].."개"
 G.verifiedQuestGoals[id]=part..", "..scrap..", "..bar..", "..extra.." 준비 후 "..chapel.."의 "..rimblat.."에게 교환. 장비 토큰과 사슬 조각은 낙스라마스 전리품입니다."
 G.verifiedObjectives[id]={raidMaterial(v[3],part,"낙스라마스의 해당 부위 더럽혀진 방어구 전리품을 확보하세요."),raidMaterial(22374,scrap,"공격대 내부 몬스터 전리품에서 필요한 사슬 조각을 확보하세요."),tradeMaterial(12360,bar),tradeMaterial(v[7],extra)}
 G.verifiedItemRequirements[id]={[v[3]]=1,[22374]=v[5],[12360]=v[6],[v[7]]=v[9]}
 meta(id).note="주술사 3단계 방어구 교환 퀘스트. 전쟁의 메아리 선행 및 은빛 여명회 평판 조건은 설치된 자료에서 확인. 수락과 보고는 "..chapel.."에서 진행하며, 공격대 입구가 수락 인물 위치가 아닙니다."
end
for _,id in ipairs({9121,9122,9123}) do
 G.koQuestNames[id]="공포의 요새 낙스라마스"
 same(id,1423,71.7,48.7,"대마법사 안젤라 도산토스")
 meta(id).note="은빛 여명회 평판에 따라 입장 퀘스트의 재료/비용이 달라집니다. 설치된 자료의 평판 조건과 실제 인물 요구 사항을 확인하세요."
end
G.koQuestNames[9033]="전쟁의 메아리"
same(9033,1423,71.7,48.6,eligor)
G.verifiedQuestGoals[9033]="낙스라마스에서 살아 움직이는 괴물 5마리, 돌가죽 가고일 5마리, 죽음의 기사단 대장 8명, 맹독 늑대거미 3마리를 처치한 뒤 "..eligor.."에게 보고."
raidStage(9033,"objective","공격대 내부 몬스터 활동 구역","전쟁의 메아리 목표 4종",G.verifiedQuestGoals[9033])
G.koQuestNames[9229]="라말라드니의 생사 확인"
same(9229,1423,72.0,48.5,korfax)
G.verifiedQuestGoals[9229]="낙스라마스에서 라말라드니의 유품을 획득하고 "..chapel.."의 "..korfax.."에게 보고."
G.verifiedObjectives[9229]={raidMaterial(22708,"라말라드니의 유품 1개","공격대에서 유품을 확보하세요. 정확한 드롭 위치와 확률은 실제 전리품 정보를 확인하세요.")}
G.verifiedItemRequirements[9229]={[22708]=1}
meta(9229).note="공개 포에버 공략은 전쟁의 메아리를 선행으로 안내하지만 일부 퀘스티 자료 원본에서는 이 필드가 비어 있습니다. 수락 가능 여부는 실제 인물 상태를 확인하세요."
G.koQuestNames[9230]="라말라드니의 얼음 고리"
same(9230,1423,72.0,48.5,korfax)
G.verifiedQuestGoals[9230]="얼어붙은 룬 1개, 푸른 사파이어 1개, 아케이나이트 주괴 1개를 준비해 "..korfax.."에게 보고."
G.verifiedObjectives[9230]={raidMaterial(22682,"얼어붙은 룬 1개","낙스라마스에서 얼어붙은 룬을 확보하세요. 보유 중이라면 추가 획득할 필요가 없습니다."),tradeMaterial(12361,"푸른 사파이어 1개"),tradeMaterial(12360,"아케이나이트 주괴 1개")}
G.verifiedItemRequirements[9230]={[22682]=1,[12361]=1,[12360]=1}
G.koQuestNames[9120]="켈투자드의 죽음"
raidStage(9120,"accept","켈투자드 처치 후 전리품","켈투자드의 성물함","성물함을 획득한 다음 아이템으로 시작하세요.")
coords(9120,"turnin",1423,71.7,48.6,"신부 이니고 몬토이")
meta(9120).directTurnin=true
G.verifiedQuestGoals[9120]="켈투자드의 성물함을 시작 아이템으로 사용하고 "..chapel.."의 신부 이니고 몬토이에게 전달."

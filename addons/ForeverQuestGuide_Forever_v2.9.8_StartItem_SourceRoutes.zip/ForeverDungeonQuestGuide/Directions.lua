local addon,G = ...
-- Basic, source-grounded written directions. We never infer road, ship or portal
-- connections from point proximity; the existing live navigation stays separate.
local fallbackContinents = {}
for map=1411,1413 do fallbackContinents[map]=1414 end
for map=1416,1437 do fallbackContinents[map]=1415 end
for map=1438,1452 do fallbackContinents[map]=1414 end
fallbackContinents[1453]=1415
fallbackContinents[1454]=1414
fallbackContinents[1455]=1415
fallbackContinents[1456]=1414
fallbackContinents[1457]=1414
fallbackContinents[1458]=1415
local phases={accept="수락",objective="수행",turnin="보고",entrance="입구",inside="던전"}
local function display(value) return G.KoreanText and G.KoreanText(value) or value end
local function displayLines(lines)
 for i,line in ipairs(lines) do lines[i]=display(line) end
 return lines
end
local function goodPoint(p)
 return type(p)=="table" and type(p.map)=="number" and
  type(p.x)=="number" and type(p.y)=="number" and
  p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function mapInfo(id)
 return G.SafeCall(C_Map and C_Map.GetMapInfo,id)
end
function G.StepPlace(p)
 if not goodPoint(p) then return nil end
 local info=mapInfo(p.map)
 local zone=(info and type(info.name)=="string" and info.name~="" and info.name) or
  (G.MapDisplayName(p.map) or "지역명 미확인")
 local continent=nil
 local visited={}
 local id=p.map
 for _=1,12 do
  if not id or visited[id] then break end
  visited[id]=true
  local i=mapInfo(id)
  if not i then break end
  if i.mapType==2 or id==1414 or id==1415 then
   continent=i.name
   break
  end
  local parent=tonumber(i.parentMapID)
  if not parent or parent<=0 or parent==id then break end
  id=parent
 end
 if not continent then
  local continentId=fallbackContinents[p.map]
  if continentId==1414 then continent="칼림도어" end
  if continentId==1415 then continent="동부 왕국" end
 end
 zone=(G.KoreanName and G.KoreanName("zone",nil,zone,G.MapDisplayName(p.map))) or zone
 continent=display(continent)
 if continent==zone then continent=nil end
 return {map=p.map,continent=continent,zone=zone,x=p.x,y=p.y,name=display(p.name)}
end
local function stageTitle(step)
 local label=phases[step.kind] or "이동"
 local qname=step.questName
 if type(qname)~="string" or qname=="" then
  qname=step.title or "퀘스트명 미확인"
  local suffix=" - "..label
  if qname:sub(-#suffix)==suffix then qname=qname:sub(1,-#suffix-1) end
 end
 return "["..label.."] "..display(qname)
end
G.StepDisplayTitle=stageTitle
local function actionMessage(step)
 if step.contactType=="object" then return step.kind=="turnin" and "오브젝트와 상호작용해 보고하세요." or "오브젝트와 상호작용해 수락하세요." end
 if step.contactType=="item" then return "시작 아이템을 가방에서 사용해 수락하세요." end
 if step.kind=="turnin" then return "보고 대상에게 퀘스트를 보고하고 보상을 받으세요." end
 if step.kind=="accept" then return "수락 대상과 상호작용해 퀘스트를 받으세요." end
 if step.kind=="objective" or step.kind=="inside" then
  if step.objectiveTitle then return step.objectiveTitle.." · "..(step.objectiveKind=="creature" and "처치" or step.objectiveKind=="object" and "상호작용" or "획득/사용").." 후 퀘스트 로그의 진행 수량을 확인하세요." end
  if step.goalText then return step.goalText end
  return "퀘스트 목표를 수행하고 실제 진행 상태를 확인하세요."
 end
 if step.kind=="entrance" then return "던전 입구에 도착한 뒤 내부 이동 경로를 확인하세요." end
 if step.kind=="inside" then return "던전 내부의 목표를 수행하세요. 내부 위치는 별도 확인이 필요합니다." end
 return step.note or "퀘스트 로그에서 단계 완료 여부를 확인하세요."
end
local function itemAcceptDirections(step,full)
 if step.kind~="accept" or not step.quest or not G.QuestStartItemGuide then return nil end
 local item=G.QuestStartItemGuide(step.quest);if not item then return nil end
 local owned=type(item.owned)=="number" and item.owned>0
 local lines={"|cffffdc88① 지금 할 일|r",item.action,"|cffffdc88② 이동 위치|r",item.place}
 if not owned and #(item.candidates or {})>0 then
  lines[#lines+1]="|cffffdc88③ 획득처 후보|r"
  for _,v in ipairs(item.candidates) do lines[#lines+1]=v end
 end
 if not owned then lines[#lines+1]="|cffffdc88수락 방법|r";lines[#lines+1]="획득한 시작 아이템을 가방에서 우클릭해 퀘스트를 수락하세요." end
 if item.warning then lines[#lines+1]="|cffffc675"..item.warning.."|r" end
 if full and item.source then lines[#lines+1]="근거: "..item.source end
 if full and item.note and not owned and step.quest==4264 then lines[#lines+1]=item.note end
 return {title=stageTitle(step),lines=displayLines(lines),area=not owned and G.StepPlace(item.point) or nil,indoor=not owned and item.indoor or nil,hasCoordinates=not owned and goodPoint(item.point) or false}
end
function G.BuildStepDirections(step,playerPosition,reviewStatus)
 if type(step)~="table" then return nil end
 local title=stageTitle(step)
 if reviewStatus then
  local loc=step.indoor and (step.indoor.dungeon.." · "..step.indoor.room.." · "..step.indoor.npcName) or step.landmark and (step.landmark.zone.." · "..step.landmark.site) or step.point and step.point.name or step.contactName
  local lines={reviewStatus,"기록 열람 전용입니다. 이전/동선표를 눌러도 현재 진행률과 실제 여정은 바뀌지 않습니다."}
  if loc then lines[#lines+1]="기록 장소: "..loc end
  lines[#lines+1]="[현재 단계]로 돌아가 진행하세요."
  return {title=title,lines=displayLines(lines),hasCoordinates=false,review=true}
 end
 local itemView=itemAcceptDirections(step,true);if itemView then return itemView end
 local p=step.point
 local area=G.StepPlace(p)
 local indoor=step.indoor or (step.quest and G.QuestInsideInfo and G.QuestInsideInfo(step.quest,step.kind))
 local lines={}
 if step.quest==4083 and step.kind=="accept" then
  local rank
  if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
   local ok,a,b=pcall(GetProfessions)
   if ok then for _,slot in pairs({a,b}) do local yes,name,_,level,_,_,_,skillId=pcall(GetProfessionInfo,slot);if yes and (skillId==186 or name=="Mining" or name=="채광") then rank=level end end end
  end
  lines[#lines+1]="필수 조건: 채광 230 이상. 별루비 2개·금괴 20개·진은 주괴 10개를 준비하세요."
  if type(rank)=="number" and rank<230 then lines[#lines+1]="현재 채광 "..rank.."/230 · 조건을 충족하기 전에는 [나중에]로 보류하세요." end
 end
 local procedure,replaces
 local curated=G.walkthroughRecords and G.walkthroughRecords[tonumber(step.quest)]
 if G.StepWalkthrough then procedure,replaces=G.StepWalkthrough(step,indoor~=nil or step.landmark~=nil) end
 if indoor then
  local inside=G.IsInGuideDungeon and G.IsInGuideDungeon(indoor.dungeonId)
  if not inside then
   lines[#lines+1]="1. "..indoor.dungeon.."에 입장하세요. 지도/여정은 던전 입구 부근까지 안내합니다."
   if indoor.dungeonId=="brd" then lines[#lines+1]="검은바위 산 중앙 섬에서 아래쪽 쇠사슬을 따라 내려가 나락 입장 차원문을 찾으세요." end
  else lines[#lines+1]="1. 현재 던전 내부에서 진행하세요." end
  local who=indoor.contactType=="object" and "상호작용 대상" or indoor.contactType=="item" and "시작 아이템" or indoor.contactType=="objective" and "목표" or "인물"
  lines[#lines+1]="2. "..indoor.room.." → "..who.." "..indoor.npcName
  if not curated then lines[#lines+1]="3. "..(indoor.instruction or actionMessage(step)) end
  if not indoor.verified and not indoor.instruction then lines[#lines+1]="던전/대상은 자료에서 확인했습니다. 세부 방과 이동 순서는 아래 목표 설명 및 던전 네비게이터를 참고하세요." end
  if indoor.followup then
   lines[#lines+1]="5. 완료 후 연계 퀘스트 "..G.GetQuestName(indoor.followup).."을(를) 확인하세요."
  end
 elseif area then
  if area.continent then
   lines[#lines+1]="2. "..area.continent.." → "..area.zone.." 지역으로 이동하세요."
  else
   lines[#lines+1]="2. "..area.zone.."으로 이동하세요."
  end
  local coord=string.format("%.1f, %.1f",area.x*100,area.y*100)
  local subject=type(p.name)=="string" and p.name~="" and p.name or nil
  if subject then
   local who=step.contactType=="object" and "상호작용 대상 " or ((step.kind=="accept" or step.kind=="turnin") and "인물 " or "목표 ")
   local suffix=(step.kind=="accept" or step.kind=="turnin") and
    "에게 이동하세요." or " 위치로 이동하세요."
   lines[#lines+1]="3. "..who..subject.." ("..coord..(p.approx and " · 탐색 후보" or "")..")"..suffix
  else
   lines[#lines+1]="3. "..coord.." 좌표 지점으로 이동하세요."
  end
 elseif step.landmark then
  local landmark=step.landmark
  local region=(landmark.continent and (landmark.continent.." → ") or "")..(landmark.zone or "확인된 장소")
  if region=="재료 준비" or region=="시작 아이템" then
   lines[#lines+1]="1. "..region.." · "..(landmark.site or "준비 사항")
  else
   lines[#lines+1]="1. "..region.." → "..(landmark.site or "목표 장소")
  end
  if landmark.approach and G.StepPlace(landmark.approach) then
   local a=G.StepPlace(landmark.approach)
   lines[#lines+1]=string.format("접근 지점: %s (%.1f, %.1f) · 실제 목표와 구분",a.zone,a.x*100,a.y*100)
  end
  if landmark.dungeonId then
   local inInstance=G.IsInGuideDungeon and G.IsInGuideDungeon(landmark.dungeonId)
   if not inInstance then lines[#lines+1]="던전 입장 후 대상이 있는 구역으로 이동하세요. 지도는 입구 접근 지점입니다." end
  end
  if not curated or not landmark.verified then lines[#lines+1]="2. "..(landmark.instruction or actionMessage(step)) end
  if landmark.approxArea then lines[#lines+1]="자료에서 확인된 활동 지역입니다. 세부 위치는 현장 기준으로 탐색하세요." end
  if landmark.note and landmark.note~="" then lines[#lines+1]="참고: "..landmark.note end
 elseif step.regionHint then
  lines[#lines+1]="관련 지역: "..step.regionHint.." (퀘스트 분류 기준, 방문 장소와 다를 수 있음)"
  local target=step.objectiveTitle or step.contactName or step.questName or "퀘스트 목표"
  lines[#lines+1]="대상: "..target
  if step.goalText and not G.StepWalkthrough then lines[#lines+1]="실제 목표: "..step.goalText end
  lines[#lines+1]="정확한 방문 지점은 미확인입니다. 아래 목표·아이템·대상 설명을 따라 진행하세요. 분류 지역을 실제 목적지로 찍지는 않습니다."
 else
  lines[#lines+1]="대상: "..(step.contactName or step.objectiveTitle or step.questName or "퀘스트 목표")
  if step.goalText and not G.StepWalkthrough then lines[#lines+1]="실제 목표: "..step.goalText end
  lines[#lines+1]="실제 방문 장소를 확인할 자료가 부족합니다. 임의 좌표로 이동시키지 않습니다."
 end
 if not indoor and not step.landmark and not replaces then lines[#lines+1]="4. "..actionMessage(step) end
 if procedure then for _,line in ipairs(procedure) do lines[#lines+1]=line end end
 if area and not indoor then
  if goodPoint(playerPosition) and playerPosition.map==area.map then
   local label,dir
   if G.RouteDistanceLabel then label,dir=G.RouteDistanceLabel(playerPosition,p) end
   lines[#lines+1]="같은 지도: "..(dir and dir~="" and dir.." 방향 | " or "")..(label or "현재 위치 정보 미확인")
  elseif goodPoint(playerPosition) and playerPosition.map~=area.map then
   lines[#lines+1]="다른 지역입니다. 이동 수단·지형은 오른쪽 실시간 길찾기를 확인하세요."
  end
 end
 if G.RouteTravelCaveat then
  local caution=G.RouteTravelCaveat(step,playerPosition)
  if caution then lines[#lines+1]="이동 주의: "..caution end
 end
 if step.quest and G.QuestSpecialInstruction then
  local special=G.QuestSpecialInstruction(step.quest)
  if special then lines[#lines+1]=special end
 end
 if step.quest and step.kind=="turnin" and G.QuestFollowupHint then
  local followup=G.QuestFollowupHint(step.quest)
  if followup then
   lines[#lines+1]="보고 후 다음 단계: "..followup.name.." · "..followup.state
   if followup.sameContact then lines[#lines+1]="던전을 떠나기 전 같은 NPC에게 후속 수락 여부를 확인하세요." end
  end
 end
 if (G.GuideStepNavPoint and G.GuideStepNavPoint(step)) or area then
  lines[#lines+1]="오른쪽 여정은 확인된 지도 지점까지 안내합니다."
 elseif indoor then
  lines[#lines+1]="던전 내부 이동은 위 장소 설명과 던전 네비게이터를 참고하세요."
 end
 return {title=title,lines=displayLines(lines),area=area,indoor=indoor,hasCoordinates=area~=nil}
end

-- Preview names the actual step rather than repeating the quest title.
-- This is display only: it never changes step identity or route state.
function G.StepBriefTitle(step)
 if type(step)~="table" then return "" end
 local kind=step.kind;local phase=phases[kind] or "이동"
 local target
 if kind=="accept" or kind=="turnin" then
  target=step.contactName or (step.indoor and step.indoor.npcName) or (step.landmark and step.landmark.target) or (step.point and step.point.name)
 elseif kind=="objective" or kind=="inside" then target=step.objectiveTitle end
 if type(target)=="string" and target~="" then
  local q=step.questName
  return display("["..phase.."] "..target..(type(q)=="string" and q~="" and q~=target and " · "..q or ""))
 end
 return stageTitle(step)
end
local function section(lines,label,rows)
 if type(rows)~="table" or #rows==0 then return end
 lines[#lines+1]="|cffffdc88"..label.."|r"
 for _,v in ipairs(rows) do if type(v)=="string" and v~="" then lines[#lines+1]=v end end
end
local function compactPlace(step)
 local item=step.kind=="accept" and step.quest and G.QuestStartItemGuide and G.QuestStartItemGuide(step.quest)
 if item then return item.place,G.StepPlace(item.point),item.indoor end
 local indoor=step.indoor or (step.quest and G.QuestInsideInfo and G.QuestInsideInfo(step.quest,step.kind))
 local area=G.StepPlace(step.point)
 local lm=step.landmark
 if step.prepInventory then return "가방 · 시작 아이템",nil,indoor end
 if indoor then return table.concat({indoor.dungeon or "던전",indoor.room or "세부 구역 미확인",indoor.npcName or "대상 미확인"}," · "),nil,indoor end
 if lm then
  local loc=(lm.continent and lm.continent.." → " or "")..(lm.zone or "장소 미확인")..(lm.site and " · "..lm.site or "")
  if lm.approach then loc=loc.." (지도는 접근 지점)" elseif lm.approxArea then loc=loc.." (탐색 구역)" end
  return loc,nil,nil
 end
 if area then
  return (area.continent and area.continent.." → " or "")..area.zone..(area.name and " · "..area.name or "")..string.format(" (%.1f, %.1f%s)",area.x*100,area.y*100,step.point.approx and " · 탐색 후보" or ""),area,nil
 end
 return step.regionHint and (step.regionHint.." · 관련 지역 (실제 위치 미확인)") or "방문 위치 미확인",nil,nil
end
function G.CompactStepPlace(step)
 if type(step)~="table" then return nil end
 return display((compactPlace(step)))
end
function G.BuildCompactStepDirections(step,playerPosition,reviewStatus)
 if type(step)~="table" then return nil end
 if reviewStatus then return G.BuildStepDirections(step,playerPosition,reviewStatus) end
 local itemView=itemAcceptDirections(step,false);if itemView then return itemView end
 local title=stageTitle(step)
 local lines={};local place,area,indoor=compactPlace(step)
 local model=G.CompactStepWalkthrough and G.CompactStepWalkthrough(step) or {}
 local kind=step.kind=="inside" and "objective" or step.kind
 local target=step.contactName or (indoor and indoor.npcName) or (step.landmark and step.landmark.target) or (step.point and step.point.name)
 local action={};local seen={}
 local function add(dst,s)
  if type(s)=="string" and s~="" and not seen[s] then seen[s]=true;dst[#dst+1]=s end
 end
 if kind=="accept" or kind=="turnin" then
  local verb=kind=="accept" and "수락" or "보고 및 보상 수령"
  if target then add(action,"|cff83dca1"..target.."|r · "..verb) end
  if step.prepInventory then add(action,step.note or "가방의 시작 아이템을 사용해 수락하세요.")
  elseif step.contactType=="object" or step.contactType=="item" or not target then add(action,actionMessage(step)) end
 end
 -- Indoor instructions, verified use sequences, and special conditions stay visible.
 if indoor and G.IsInGuideDungeon and not G.IsInGuideDungeon(indoor.dungeonId) then add(action,(indoor.dungeon or "던전").." 입장 후 진행") end
 if indoor and indoor.instruction then add(action,indoor.instruction)
 elseif step.landmark and step.landmark.instruction then add(action,step.landmark.instruction) end
 for _,v in ipairs(model.action or {}) do add(action,v) end
 if #action==0 then
  if kind=="objective" and #(model.goals or {})>0 then add(action,model.goals[1]);table.remove(model.goals,1)
  else add(action,actionMessage(step)) end
 end
 section(lines,"① 지금 할 일",action)
 section(lines,"② 이동 위치",{place})
 local items={};for _,v in ipairs(model.items or {}) do add(items,v) end
 local goals={};for _,v in ipairs(model.goals or {}) do add(goals,v) end
 for _,v in ipairs(model.extra or {}) do add(goals,v) end
 section(lines,"③ 목표 아이템 · 획득처",items)
 section(lines,#items>0 and "추가 목표" or "③ 수행 목표",goals)
 local supplies={};for _,v in ipairs(model.supplies or {}) do add(supplies,v) end
 section(lines,"준비 / 지급 아이템",supplies)
 if step.quest and kind=="objective" then
  local id=step.quest
  local contact=G.QuestContactName and G.QuestContactName(id,"turnin")
  local p=G.QuestPoint and G.QuestPoint(id,"turnin")
  local a=G.StepPlace(p)
  local i=G.QuestInsideInfo and G.QuestInsideInfo(id,"turnin")
  local lm=(G.QuestStageLandmark and G.QuestStageLandmark(id,"turnin")) or (G.QuestContactLandmark and G.QuestContactLandmark(id,"turnin"))
  contact=contact or (p and p.name) or (i and i.npcName) or (lm and lm.target)
  local zone=(a and a.zone) or (i and i.dungeon) or (lm and lm.zone)
  if contact then section(lines,"④ 완료 후 보고",{(zone and zone.." · " or "").."|cff83dca1"..contact.."|r"}) end
 end
 local cautions={}
 if step.quest==4083 and kind=="accept" then
  add(cautions,"채광 230 이상 · 별루비 2개·금괴 20개·진은 주괴 10개")
  if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
   local ok,a,b=pcall(GetProfessions)
   if ok then for _,slot in pairs({a,b}) do local yes,n,_,level,_,_,_,skillId=pcall(GetProfessionInfo,slot);if yes and (skillId==186 or n=="Mining" or n=="채광") and type(level)=="number" and level<230 then add(cautions,"현재 채광 "..level.."/230 · 조건 충족 전 보류") end end end
  end
 end
 if step.quest and G.QuestSpecialInstruction then add(cautions,G.QuestSpecialInstruction(step.quest)) end
 if G.RouteTravelCaveat then add(cautions,G.RouteTravelCaveat(step,playerPosition)) end
 if step.landmark then add(cautions,step.landmark.note) end
 if kind=="turnin" and step.quest and G.QuestFollowupHint then
  local f=G.QuestFollowupHint(step.quest)
  if f then add(cautions,"후속: "..f.name.." · "..f.state);if f.sameContact then add(cautions,"같은 NPC에게 후속 수락 여부 확인") end end
 end
 if indoor and indoor.followup and G.GetQuestName then add(cautions,"후속: "..G.GetQuestName(indoor.followup)) end
 section(lines,"주의 / 다음 조건",cautions)
 return {title=title,lines=displayLines(lines),area=area,indoor=indoor,hasCoordinates=area~=nil}
end

-- Explicit full view supplements authored procedures with the original log.
-- Do not repeat a narrative already included by the existing detailed builder.
function G.BuildFullStepDirections(step,playerPosition,reviewStatus)
 local r=G.BuildStepDirections(step,playerPosition,reviewStatus)
 if not r or reviewStatus or not step.quest or not G.LiveQuestNarrative then return r end
 local journal=G.LiveQuestNarrative(step.quest)
 if type(journal)~="table" then return r end
 local all=table.concat(r.lines,"\n")
 for _,entry in ipairs({{label="게임 내 수행 목표",value=journal.objective},{label="퀘스트 원문",value=journal.description}}) do
  if type(entry.value)=="string" and entry.value~="" and not all:find(display(entry.value),1,true) then
   r.lines[#r.lines+1]="|cffffdc88"..entry.label.."|r"
   r.lines[#r.lines+1]=display(entry.value)
   all=all.."\n"..display(entry.value)
  end
 end
 return r
end

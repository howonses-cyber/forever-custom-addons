local _, B = ...
-- Modern Forever tooltips are dispatched through TooltipDataProcessor;
-- OnTooltipSetItem was removed from the retail-derived UI API.
local initialized=false
local supported={
 INVTYPE_HEAD=true,INVTYPE_NECK=true,INVTYPE_SHOULDER=true,INVTYPE_CLOAK=true,
 INVTYPE_CHEST=true,INVTYPE_ROBE=true,INVTYPE_WRIST=true,INVTYPE_HAND=true,
 INVTYPE_WAIST=true,INVTYPE_LEGS=true,INVTYPE_FEET=true,
 INVTYPE_FINGER=true,INVTYPE_TRINKET=true,INVTYPE_WEAPON=true,
 INVTYPE_WEAPONMAINHAND=true,INVTYPE_WEAPONOFFHAND=true,
 INVTYPE_2HWEAPON=true,INVTYPE_SHIELD=true,INVTYPE_HOLDABLE=true,
 INVTYPE_RANGED=true,INVTYPE_RANGEDRIGHT=true,INVTYPE_THROWN=true,INVTYPE_RELIC=true
}
local slots={INVTYPE_FINGER='Finger',INVTYPE_TRINKET='Trinket',
 INVTYPE_2HWEAPON='TwoHand',INVTYPE_WEAPON='MainHand',
 INVTYPE_WEAPONMAINHAND='MainHand',INVTYPE_WEAPONOFFHAND='OffHand',
 INVTYPE_HOLDABLE='OffHand',INVTYPE_SHIELD='OffHand',
 INVTYPE_RANGED='Ranged',INVTYPE_RANGEDRIGHT='Ranged',
 INVTYPE_RELIC='Relic'}
local function formatPoints(p)
 return type(p)=='number' and string.format('%.1f',p) or '확인 불가'
end
local function equipSignature()
 if type(GetInventoryItemLink)~='function' then return 'no-api' end
 local a={}
 for _,id in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
  a[#a+1]=tostring(GetInventoryItemLink('player',id) or '')
 end
 return table.concat(a,';')
end
local function AddInfo(tooltip,data)
 if not B.db or not B.db.showTooltip or not tooltip then return end
 if tooltip~=GameTooltip and tooltip~=ItemRefTooltip then return end
 if tooltip._fbisBusy then return end
 local link=nil
 if tooltip.GetItem then
  local ok,_,itemLink=pcall(tooltip.GetItem,tooltip)
  if ok and type(itemLink)=='string' then link=itemLink end
 end
 if not link and data then
  if type(data.hyperlink)=='string' then link=data.hyperlink
  elseif type(data.id)=='number' and data.id>0 then link='item:'..tostring(data.id) end
 end
 if type(link)~='string' or not link:find('item:',1,true) then return end
 local loc=B:ResolveEquipLocation(link)
 if not supported[loc] then return end
 local cl=UnitClass and select(2,UnitClass('player')) or B.db.class
 if not B.specs[cl] then return end
 local sig=link..'|'..tostring(cl)..'|'..equipSignature()
 if tooltip._fbisSignature==sig then return end
 tooltip._fbisSignature=sig
 tooltip._fbisBusy=true
 local ok,err=pcall(function()
  tooltip:AddLine('Forever BiS |cffb9e4ff현재 착용 장비 대비 EP|r',1,.77,.28)
  local printed=0
  local ordered={}
  if B.db.class==cl then
   for _,sp in ipairs(B.specs[cl]) do
    if sp.key==B.db.spec then ordered[#ordered+1]=sp end
   end
  end
  for _,sp in ipairs(B.specs[cl]) do
   if not (B.db.class==cl and sp.key==B.db.spec) then ordered[#ordered+1]=sp end
  end
  for _,sp in ipairs(ordered) do
   local c,reason=B:Compare(link,cl,sp.key,slots[loc])
   if c and c.change~=nil then
    local direction=c.change>=0 and '+' or ''
    local formatted=direction..string.format('%.1f',c.change)..'% EP'
    tooltip:AddDoubleLine(sp.label,formatted..' ('..formatPoints(c.equipped)..' > '..formatPoints(c.candidate)..')',
      1,1,1,c.change>=0 and .4 or 1,c.change>=0 and 1 or .44,.6)
    local name=c.comparedName or (B.GetEquippedName and B.GetEquippedName(c.compared)) or '장비'
    tooltip:AddLine('  착용 기준: '..name..' / '..(B.EquipSlotLabel and B.EquipSlotLabel(c.equippedSlot) or ''),.64,.79,.92,true)
    printed=printed+1
   elseif c and c.noBaseline then
    tooltip:AddDoubleLine(sp.label,'비교 슬롯 비어 있음 / '..formatPoints(c.candidate)..' EP',1,1,1,.9,.79,.42)
    tooltip:AddLine('  '..tostring(reason or '착용 장비 기준 % 계산 불가'),.7,.7,.72,true)
    printed=printed+1
   else
    tooltip:AddDoubleLine(sp.label,'비교 보류: '..tostring(reason or '스탯 정보 불충분'),1,1,1,.74,.68,.61)
   end
  end
  if printed==0 then tooltip:AddLine('비교 가능한 착용 장비 점수를 확인하지 못했습니다.',.82,.66,.52) end
  tooltip:AddLine('※ % = 현재 착용템 대비 기본 스탯 EP 변화. DPS/힐량 증가율 아님.',1,.55,.43,true)
  tooltip:AddLine('무기 피해·세트·발동·마법부여·스탯 상한 효과는 별도 확인.',.68,.75,.80,true)
 end)
 tooltip._fbisBusy=false
 if not ok and B.Print then B.Print('툴팁 계산 오류: '..tostring(err)) end
end
function B:SetupTooltips()
 if initialized then return end
 initialized=true
 local modern=TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall)=='function'
  and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item~=nil
 if modern then
  local ok=pcall(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,function(tip,data)
   AddInfo(tip,data)
  end)
  if ok then
   for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
    if tip and tip.HookScript then
     pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)
      self._fbisSignature=nil
     end)
    end
   end
   return
  end
 end
 -- Fallback for clients still exposing the old tooltip event.
 for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
  if tip and tip.HookScript then
   pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
   pcall(tip.HookScript,tip,'OnTooltipSetItem',function(self)AddInfo(self)end)
  end
 end
end

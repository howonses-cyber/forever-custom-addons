-- Regression fixtures for presentation only; the IDs/data below are synthetic
-- except the reported same-title pair. This is not a live WoW database test.
local source=(arg and arg[1]) or 'work/ForeverDungeonQuestGuide/QuestChains.lua'
local mandatory,one,chosen,names,status,visible={},{},{},{},{},{}
QuestDB={}
local G={db={groupChains=true,chainCollapsed={},selectedQuests={[3802]=true},deferredQuests={[99]=true},guide={index=4,roots={3802}}}}
function G.Ready() return true end
function G.MandatoryRoutePrereqs(id) return mandatory[id] or {} end
function G.QuestPrerequisite(id) return mandatory[id] or {},one[id] or {} end
function G.DBGet(_,id,field) if field=='name' then return names[id] or ('Quest '..id) end end
function G.QuestListMeta(id) return {label='test zone',level='52'} end
function G.IsQuestBrowseVisible(id) return visible[id]~=false end
function G.GetQuestName(id) return names[id] or ('Quest '..id) end
function G.RouteAssessment(id) return status[id] or 'ready',status[id] or 'ready' end
function G.IsCompleted(id) return status[id]=='done' end
function G.IsRouteSatisfied(id) return status[id]=='done' or status[id]=='superseded' end
function G.ResolveRouteRequirements(id) return chosen[id] end
assert(loadfile(source))('ForeverDungeonQuestGuide',G)
local tests=0
local function check(value,message) assert(value,message);tests=tests+1 end
local function rows(...)
 local result={};for _,id in ipairs({...}) do result[#result+1]={kind='quest',id=id,meta={label='test zone'}} end;return result
end
local function serialize(t)
 if type(t)~='table' then return tostring(t) end
 local keys={};for k in pairs(t) do keys[#keys+1]=k end
 table.sort(keys,function(a,b)return tostring(a)<tostring(b)end)
 local s={};for _,k in ipairs(keys) do s[#s+1]=tostring(k)..'='..serialize(t[k]) end;return '{'..table.concat(s,',')..'}'
end
local function find(result,kind,id)
 for _,e in ipairs(result) do if e.kind==kind and (not id or e.id==id) then return e end end
end
local function reset()
 mandatory,one,chosen,names,status,visible={},{},{},{},{},{}
 G.db.groupChains=true;G.db.chainCollapsed={}
end

-- User-reported defect: the unrelated quests immediately after the 3801/3802
-- chain must have a closed boundary and their own cards, without chain fields.
mandatory[3802]={3801};names[3801]='검은무쇠 유물';names[3802]='검은무쇠 유물'
status[3801]='done';status[3802]='active'
local original=rows(3801,3802,8001,8002,8003)
local originalSnapshot=serialize(original);local savedSnapshot=serialize(G.db)
local result=G.QuestChainRows(original,'dungeon:brd',true)
check(#result==7,'two-member chain must add exactly a header and a closing row')
check(result[1].kind=='chain' and result[4].kind=='chainEnd','chain must close before any independent quest')
check(result[2].id==3801 and result[3].id==3802,'same-title chain must preserve prerequisite ordering')
check(result[2].sameTitle and result[3].sameTitle,'same-title IDs need distinct display identities')
check(result[2].chainKey==result[1].key and result[3].chainLast,'each child must retain membership after scrolling away from header')
check(result[1].memberIds[2]==3802 and result[1].linear,'simple dependency is a linear chain')
check(result[1].nextQuestId==3802 and result[1].nextCode=='active','next action must choose unfinished actionable quest')
for i=5,7 do check(result[i].standalone and not result[i].chainKey,'unrelated quest must not inherit a preceding chain') end
check(serialize(original)==originalSnapshot,'render grouping must not mutate source rows')
check(serialize(G.db)==savedSnapshot,'render grouping must not mutate checked, deferred, route, or saved progress')

-- Collapsing only changes presentation preference; it never checks prerequisites.
local key=result[1].key;G.ToggleChainGroup(key)
local collapsed=G.QuestChainRows(original,'dungeon:brd',true)
check(#collapsed==4 and collapsed[1].collapsed,'collapsed chain hides only its own members/footer')
check(collapsed[2].id==8001 and collapsed[2].standalone,'next independent card survives collapsed chain')
check(G.db.selectedQuests[3802] and not G.db.selectedQuests[3801],'collapse must not check ancestors')
G.ToggleChainGroup(key)
check(G.db.chainCollapsed[key]==false and #G.QuestChainRows(original,'dungeon:brd',true)==7,'explicit expansion must persist as false')

-- Confirmed completion is separate from inferred predecessor exclusion.
status[3802]='superseded'
local separated=G.QuestChainRows(original,'counts',true)[1]
check(separated.completed==1 and separated.done==1 and separated.superseded==1,'excluded predecessor is not a rewarded quest')
check(not separated.collapsed and not separated.nextQuestId,'excluded rows neither auto-complete nor create fake actions')
status[3802]='done'
local allDone=G.QuestChainRows(original,'done',true)[1]
check(allDone.collapsed and allDone.completed==2,'fully rewarded chain collapses by default')
G.ToggleChainGroup(allDone.key)
check(not G.QuestChainRows(original,'done',true)[1].collapsed,'user can expand a fully completed auto-collapsed chain')
check(not G.QuestChainRows(original,'done',true)[1].collapsed,'subsequent refresh must preserve that explicit expansion')

-- Turning grouping off provides individual cards and no chain boundary rows.
G.db.groupChains=false
local plain=G.QuestChainRows(original,'dungeon:brd',true)
check(#plain==5 and plain[1].kind=='quest' and plain[1].standalone,'grouping disabled must retain every original quest')
check(serialize(original)==originalSnapshot,'grouping disabled must still avoid source-row mutation')

-- A common ancestor with two children is a branch, even when every child has
-- only one prerequisite. Topological order must never be advertised as steps.
reset();mandatory[11]={10};mandatory[12]={10};status[10]='done';status[11]='ready';status[12]='turnin'
local branch=G.QuestChainRows(rows(10,11,12),'fork',true)
check(branch[1].branch and not branch[1].linear,'fan-out must be recognized as a branch')
check(not find(branch,'quest',11).chainLinear,'branch member must not claim linear step position')
check(branch[1].nextQuestId==12 and branch[1].nextCode=='turnin','already achieved goal should prioritize collecting reward')
check(branch[1].actionableIds[2]==11,'remaining parallel action must remain discoverable')

-- Fan-in similarly represents several prerequisites, not an invented sequence.
reset();mandatory[22]={20,21}
local join=G.QuestChainRows(rows(22),'join',true)
check(join[1].branch and join[1].extra==2 and #join[1].memberIds==3,'both required ancestors appear as external context')
check(find(join,'quest',20).chainContext and find(join,'quest',21).chainContext,'external prerequisites remain visibly marked')
check(not G.db.selectedQuests[20] and not G.db.selectedQuests[21],'external context must never silently select anything')

-- Only the resolver-selected OR branch appears. An unavailable alternative
-- must not be fabricated as another required stage.
reset();one[32]={30,31};chosen[32]={[32]={[31]=true},[31]={}}
local choice=G.QuestChainRows(rows(32),'or',true)
check(find(choice,'quest',31) and not find(choice,'quest',30),'OR must expose only the existing resolver choice')
check(choice[1].branch and not choice[1].linear,'chosen OR path still needs alternative/branch semantics')

-- Without addContext, hidden predecessors can link displayed siblings, but no
-- hidden quest or straight-line step number may be fabricated in this view.
reset();mandatory[42]={41};mandatory[43]={41}
local hidden=G.QuestChainRows(rows(42,43),'search',false)
check(hidden[1].incomplete and not hidden[1].linear and hidden[1].count==2,'missing context must be acknowledged')
check(not find(hidden,'quest',41),'search grouping may not silently insert hidden ancestor')

-- Incomplete/cyclic data must terminate and must not become a successful route.
reset();mandatory[50]={51};mandatory[51]={50};status[50]='blocked';status[51]='locked'
local cycle=G.QuestChainRows(rows(50,51),'cycle',true)
check(cycle[1].cycle and not cycle[1].linear,'cycle must be explicit and finite')
check(not cycle[1].nextQuestId and cycle[1].completed==0,'cycle has no fake completion or actionable recommendation')

-- A faction-hidden ancestor must stay hidden even when context is requested.
reset();mandatory[62]={61};visible[61]=false
local filtered=G.QuestChainRows(rows(62),'faction',true)
check(#filtered==1 and filtered[1].standalone and filtered[1].hasPrerequisites,'hidden prerequisite remains a single card with requirement metadata')
check(not find(filtered,'quest',61),'context must respect browse/faction visibility')

-- Section headers establish independent visual scopes; same-title section data
-- may not cause a preceding card to leak into another zone.
reset();mandatory[72]={71}
local sections={{kind='header',label='Zone A'},{kind='quest',id=71},{kind='header',label='Zone B'},{kind='quest',id=72}}
local scoped=G.QuestChainRows(sections,'sections',false)
check(#scoped==4 and scoped[3].kind=='header','separate category boundaries survive grouping')
check(scoped[2].standalone and scoped[4].standalone,'single rows in distinct sections remain separate cards')
print('PASS: '..tests..' chain presentation regression assertions')

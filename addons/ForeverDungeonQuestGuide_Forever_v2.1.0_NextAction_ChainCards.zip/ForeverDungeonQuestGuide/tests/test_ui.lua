-- Run from project root: texlua tests/test_ui.lua
-- Pure fixture data: names mirror the reported UX problem; quest IDs outside
-- 3801/3802 are synthetic and do not assert game prerequisites or locations.
local Mock=assert(loadfile("tests/mock_wow.lua"))().install()
local base=arg[1] or "work/ForeverDungeonQuestGuide/"
local G={}
local function loadAddon(file) assert(loadfile(base..file))("ForeverDungeonQuestGuide",G) end
local function eq(a,b,message) assert(a==b,(message or "mismatch")..": expected "..tostring(b)..", got "..tostring(a)) end
local function has(s,part,message) assert(type(s)=="string" and s:find(part,1,true),message or (tostring(s).." lacks "..part)) end
local checked=0
local function test(name,fn) fn();checked=checked+1;print("PASS "..name) end
loadAddon("Core.lua")
G.StartSaved();G.PlayerRefresh()
local names={[3801]="검은무쇠 유물",[3802]="검은무쇠 유물",[90101]="산의 정수",[90102]="헐레이 블랙브레스",[90103]="리블리 스크류스피곳",[90104]="준비할 퀘스트",[90105]="보고할 퀘스트",[90106]="선행이 필요한 퀘스트",[90107]="접근 불가 퀘스트",[90108]=string.rep("긴 퀘스트 이름 ",10)}
local states={[3801]="done",[3802]="active",[90101]="active",[90102]="active",[90103]="active",[90104]="ready",[90105]="turnin",[90106]="locked",[90107]="blocked",[90108]="active"}
local parents={[3802]={3801},[90106]={90104}}
local levels={[3801]=52,[3802]=52,[90101]=55,[90102]=55,[90103]=53}
local stateLabels={done="보고 완료",superseded="후속 진행 확인",active="진행 중",ready="아직 안 받음",turnin="보고 대기",locked="선행 필요",blocked="조건 확인",low="레벨 부족",unknown="정보 미확인",deferred="보류",dependentDeferred="선행 보류"}
local fixtureIds={3801,3802,90101,90102,90103}
local logIds={3802,90101,90102,90103,90105,90108}
local searchIds=fixtureIds
local dbReady=true
QuestDB={Get=function(id,key)if key=="name" then return names[id] end end}
G.DBGet=function(db,id,key)if db and dbReady then if key=="name" then return names[id] elseif key=="zoneOrSort" then return 230 elseif key=="questLevel" then return levels[id] or 55 end end end
G.Ready=function()return dbReady end
G.GetQuestName=function(id)return names[id] or ("테스트 퀘스트 "..tostring(id))end
G.GetQuestLevel=function(id)return levels[id] or 55 end
G.GetQuestMinLevel=function()return 50 end
G.GetQuestZone=function()return 230,"검은바위 나락","dungeon"end
G.RouteAssessment=function(id)local code=G.db.deferredQuests[id] and "deferred" or states[id] or "ready";return stateLabels[code],code,code=="blocked" and "다른 진영 조건" or nil end
G.QuestState=G.RouteAssessment
G.IsCompleted=function(id)return states[id]=="done"end
G.IsInLog=function(id)return states[id]=="active" or states[id]=="turnin"end
G.IsReadyToTurnIn=function(id)return states[id]=="turnin"end
G.IsRouteSatisfied=function(id)return states[id]=="done" or states[id]=="superseded"end
G.RoutePrereqEvidence=function(id)return states[id]=="superseded"end
G.MandatoryRoutePrereqs=function(id)return parents[id] or {}end
G.QuestPrerequisite=function(id)return parents[id] or {},{}end
G.ResolveRouteRequirements=function(id)
 local result={};local function walk(q)if result[q] then return end;result[q]={};for _,p in ipairs(parents[q] or {}) do if not G.IsRouteSatisfied(p) then result[q][p]=true;walk(p) end end end
 walk(id);return result
end
G.GetMissingPrereqs=function(id)local out={};for _,p in ipairs(parents[id] or {})do if not G.IsRouteSatisfied(p) then out[#out+1]=p end end;return out end
G.RouteNextPrereqs=G.GetMissingPrereqs
G.IsQuestBrowseVisible=function()return true end
G.QuestFactionTag=function()return ""end
G.DungeonMatchesFactionFilter=function()return true end
G.QuestMatchesFactionFilter=function()return true end
G.QuestIndexStatus=function()return "테스트 DB"end
local dungeon={id="brd",name="검은바위 나락",level="50–60",ids=fixtureIds,area=230}
G.dungeons={dungeon};G.dungeonById={brd=dungeon};G.db.selectedDungeon="brd";G.selection.dungeon="brd"
G.questIndex={zones={[230]={key=230,name="검은바위 나락",kind="dungeon",count=5}}}
G.SearchQuestZones=function()return {G.questIndex.zones[230]}end
G.ZoneFactionCount=function()return #searchIds end
G.SearchQuestIds=function(mode,search)
 local source=searchIds
 if mode=="active" then source=logIds elseif mode=="turnin" then source={90105} elseif mode=="deferred" then source={};for id in pairs(G.db.deferredQuests)do source[#source+1]=id end elseif mode=="selected" then source={};for id,yes in pairs(G.db.selectedQuests)do if yes then source[#source+1]=id end end end
 local result={};for _,id in ipairs(source)do if search=="" or G.GetQuestName(id):find(search,1,true) or tostring(id)==search then result[#result+1]=id end end
 return result,#result,false
end
G.QuestDetails=function(id)local status,code,reason=G.RouteAssessment(id);return{id=id,name=G.GetQuestName(id),level=G.GetQuestMinLevel(id),status=status,code=code,reason=reason,all=parents[id] or {},one={},category="검은바위 나락",startDescription="테스트 지역 · 수락 NPC",finishDescription="테스트 지역 · 보고 NPC",goal="목표 물건 3개 수집"}end
G.QuestInsideInfo=function(id,stage)if id==90101 and stage=="objective" then return{dungeon="검은바위 나락",dungeonId="brd",room="테스트 구역",instruction="퀘스트 물건을 찾으세요.",entrance={map=1427,x=.2,y=.3}} end end
G.QuestStageLandmark=function()return nil end
G.QuestContactLandmark=function()return nil end
G.QuestContactName=function(_,stage)return stage=="accept" and "수락 NPC" or "보고 NPC",1,nil,"npc"end
G.QuestGiverName=function(_,stage)return stage=="accept" and "수락 NPC" or "보고 NPC"end
G.QuestPoint=function(id,stage)return{questId=id,map=1427,x=stage=="accept" and .2 or .4,y=.3,name=stage=="accept" and "수락 NPC" or "보고 NPC"}end
G.QuestObjectivePoints=function()return{{point={map=1427,x=.3,y=.4},text="목표 물건"}}end
G.QuestObjectiveText=function()return "목표 물건 3개 수집"end
G.LiveQuestNarrative=function()return nil end
G.MapDisplayName=function()return "테스트 지역"end
G.WalkthroughDetails=function(id)return id==90108 and string.rep("아주 긴 안내 문장입니다.\n",60) or nil end
G.DeferredBlocker=function(id)return id and G.db.deferredQuests[id] and id or nil end
G.DeferredCount=function()local n=0;for _ in pairs(G.db.deferredQuests)do n=n+1 end;return n end
G.SelectedCount=function()local n=0;for _,v in pairs(G.db.selectedQuests)do if v then n=n+1 end end;return n end
G.ToggleQuestChecked=function(id,value)G.db.selectedQuests[id]=value or nil;G.UIRefresh()end
G.ClearCheckedQuests=function()G.db.selectedQuests={};G.UIRefresh()end
G.ResumeSelectedBlocker=function(id)G.db.deferredQuests[id]=nil;G.UIRefresh()end
G.ResumeDeferredQuests=function()G.db.deferredQuests={};G.UIRefresh()end
G.GuideProgress=function()return 0,0 end
G.GuideViewingHistory=function()return false end
G.GuideViewIndex=function()return 1 end
G.CurrentStep=function()return nil end
G.RouteScopeLabel=function()return "테스트 동선"end
local calls={}
for _,method in ipairs({"StartQuickGuide","StartSelectedGuide","StartTurninGuide","StartActiveGuide","StartGuide","OpenPointMap","OpenRegionMap","OpenGuideStepMap","OpenDungeonNavigator","NextGuide","ToggleHUD","StopGuide","ReturnToActiveGuide","SelectGuideStep"})do local key=method;G[key]=function(...)calls[#calls+1]={key,...};return true end end
G.ResetRoutePlanning=function()calls[#calls+1]={"ResetRoutePlanning"}end
G.EnrichStepLocation=function()end
G.activeQuests={};for _,id in ipairs(logIds)do G.activeQuests[id]={title=G.GetQuestName(id),level=G.GetQuestLevel(id),complete=states[id]=="turnin"}end
G.db.guide={sentinel="saved route"};G.db.manualProgress={sentinel=true};G.db.selectedQuests={[90101]=true};G.db.deferredQuests={[90107]={reason="user"}}
local guideBefore,manualBefore,selectedBefore,deferredBefore=G.db.guide,G.db.manualProgress,G.db.selectedQuests,G.db.deferredQuests
loadAddon("QuestList.lua");loadAddon("QuestChains.lua");loadAddon("UITheme.lua");loadAddon("QuestContacts.lua")
if io.open(base.."QuestJourney.lua","r") then loadAddon("QuestJourney.lua") end
loadAddon("UI.lua")
local function rows()return Mock.all(function(o)return o.kind=="Button" and o.checkbox~=nil end)end
local function visibleRows()local a={};for _,r in ipairs(rows())do if r:IsVisible()then a[#a+1]=r end end;return a end
local function rowFor(id)for _,r in ipairs(rows())do if r:IsVisible() and r.quest==id then return r end end end
local function parentBar(parent)return Mock.find(function(o)return o.kind=="Slider" and o.parent==parent end)end
local function checkPreserved()
 eq(G.db.guide,guideBefore,"browse replaced route");eq(G.db.manualProgress,manualBefore,"browse replaced progress");eq(G.db.selectedQuests,selectedBefore,"browse replaced checks");eq(G.db.deferredQuests,deferredBefore,"browse replaced deferrals");eq(G.db.selectedQuests[90101],true,"existing check changed")
end
test("Build and refresh with completed same-title chain and independent quests",function()
 G.selection.mode="dungeon";G.db.viewMode="dungeon";G.ShowUI(true)
 assert(G.IsUIShown());assert(rowFor(3801));assert(rowFor(3802));assert(rowFor(90101));checkPreserved()
 has(rowFor(3801).text:GetText(),"3801","duplicate quest identity is distinguishable")
end)
test("Select independent quest without route/checkbox mutation",function()
 rowFor(90101):Click();eq(G.selection.quest,90101);checkPreserved()
 local text=Mock.visibleText();has(text,"산의 정수")
end)
test("Real contact preview opens, closes on new selection, preserves route",function()
 G.ShowContactPreview(90101,"accept",ForeverDungeonQuestGuideFrame)
 assert(ForeverQuestContactPreview:IsShown());has(Mock.visibleText(ForeverQuestContactPreview),"수락 NPC")
 G.SetQuest(90102);eq(ForeverQuestContactPreview:IsShown(),false);checkPreserved()
end)
test("Shift+click quest inserts native fallback link without selecting",function()
 local inserted;local edit={IsShown=function()return true end,Insert=function(_,s)inserted=s end}
 ChatEdit_GetActiveWindow=function()return edit end;IsShiftKeyDown=function()return true end
 local before=G.selection.quest;local r=assert(rowFor(90101));r:Click();eq(G.selection.quest,before);has(inserted,"|Hquest:90101:")
 r.checkbox:Click();eq(G.db.selectedQuests[90101],true);eq(r.checkbox:GetChecked(),true)
 IsShiftKeyDown=function()return false end;ChatEdit_GetActiveWindow=nil;checkPreserved()
end)
test("Chain collapse does not hide independent rows or change state",function()
 local header=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible() end);assert(header,"chain header missing")
 header:Click();assert(not rowFor(3801));assert(rowFor(90101));checkPreserved()
 local header2=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible() end);header2:Click();assert(rowFor(3801));assert(rowFor(3802));checkPreserved()
end)
test("Selection detail handles long text and resets scroll when quest changes",function()
 dungeon.ids={3801,3802,90101,90102,90103,90108};G.UIRefresh()
 G.SetQuest(90108)
 local scroll=Mock.find(function(o)return o.kind=="ScrollFrame" and o.scrollChild and o.parent~=ForeverQuestContactPreview and o.parent.parent==ForeverDungeonQuestGuideFrame end)
 assert(scroll,"detail scroll missing");scroll:Wheel(-5);assert(scroll:GetVerticalScroll()>0,"long detail did not scroll")
 G.SetQuest(90102);eq(scroll:GetVerticalScroll(),0);checkPreserved();dungeon.ids=fixtureIds;G.UIRefresh()
end)
test("Native slider reaches top/bottom, wheel is consistent, shrinking clamps",function()
 local many={};for i=1,40 do local id=91000+i;many[i]=id;names[id]="독립 퀘스트 "..i;states[id]="ready" end
 G.db.groupChains=false;dungeon.ids=many;G.UIRefresh()
 local rs=visibleRows();local parent=rs[1].parent;local bar=assert(parentBar(parent));local _,hi=bar:GetMinMaxValues()
 eq(rs[1].quest,91001);assert(hi>0);bar:SetValue(hi);eq(visibleRows()[#visibleRows()].quest,91040)
 bar:SetValue(0);eq(visibleRows()[1].quest,91001);parent:Wheel(-1);eq(visibleRows()[1].quest,91004);eq(bar:GetValue(),3)
 parent:Wheel(1);eq(visibleRows()[1].quest,91001);bar:SetValue(hi)
 dungeon.ids={91001,91002};G.UIRefresh();eq(bar:GetValue(),0);eq(bar:IsShown(),false);eq(visibleRows()[1].quest,91001);eq(#visibleRows(),2)
 dungeon.ids=fixtureIds;G.db.groupChains=true;G.UIRefresh();checkPreserved()
end)
test("Mode and faction switches preserve route/checks and update catalogs",function()
 for _,mode in ipairs({"active","turnin","selected","deferred","all","zone","dungeon"})do G.SetViewMode(mode);eq(G.selection.mode,mode);checkPreserved()end
 local actual=G.player.faction;G.SetFactionFilter("Horde");eq(G.player.faction,actual);checkPreserved();G.SetFactionFilter("auto")
end)
test("Database missing still renders accepted quests and honest status",function()
 dbReady=false;QuestDB=nil;G.SetViewMode("active");G.SetQuest(90101);G.UIRefresh()
 assert(rowFor(90101));has(Mock.visibleText(),"QuestieDB");checkPreserved();dbReady=true;QuestDB={Get=function()end};G.UIRefresh()
end)
test("Active/turnin/dungeon bulk actions retain their correct scopes",function()
 for _,case in ipairs({{"active","현재 수락 퀘스트 전체 동선","StartActiveGuide",false},{"turnin","보고 대기 전체 동선","StartActiveGuide",true},{"dungeon","던전 전체 통합 동선","StartGuide","brd"}})do
  G.SetViewMode(case[1]);local b=(G.UIJourneyWidgets and G.UIJourneyWidgets.scopeStartButton) or Mock.button(case[2]);assert(b,"scope button missing: "..case[2]);assert(b:IsEnabled());b:Click();local c=calls[#calls];eq(c[1],case[3]);eq(c[2],case[4])
 end
 checkPreserved()
end)
if G.UIJourneyWidgets then
 local w=G.UIJourneyWidgets
 test("Phase filtering keeps full prerequisite context and excludes unrelated quests",function()
  dungeon.ids={3801,3802,90101,90102,90103,90104,90105,90106,90107};G.SetViewMode("dungeon");w.phaseButtons.accept:Click()
  assert(rowFor(90104),"accept target absent");assert(rowFor(90106),"related locked followup was stripped out");assert(not rowFor(90101),"unrelated objective appears under accept filter")
  assert(not rowFor(90105),"report target appears under accept filter");checkPreserved()
  w.phaseButtons.blocked:Click();assert(rowFor(90104),"required predecessor stripped by blocked filter");assert(rowFor(90106),"blocked target missing");checkPreserved()
  w.phaseButtons.all:Click()
 end)
 test("Report stage is actionable but never writes completion",function()
  w.phaseButtons.turnin:Click();assert(rowFor(90105));rowFor(90105):Click()
  assert(w.quickStartButton:IsEnabled());has(w.nowAction:GetText(),"보고");eq(states[90105],"turnin")
  local n=#calls;w.quickStartButton:Click();eq(#calls,n+1);eq(calls[#calls][1],"StartQuickGuide");eq(calls[#calls][2],90105)
  eq(states[90105],"turnin");checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Locked target map uses actionable predecessor, guide keeps desired target",function()
  w.phaseButtons.blocked:Click();G.SetQuest(90106);assert(w.quickStartButton:IsEnabled());has(w.nowAction:GetText(),"먼저")
  local n=#calls;w.locationButton:Click();eq(#calls,n+1);eq(calls[#calls][1],"OpenPointMap");eq(calls[#calls][2].questId,90104)
  w.quickStartButton:Click();eq(calls[#calls][1],"StartQuickGuide");eq(calls[#calls][2],90106)
  checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Done or blocked selections cannot start a new guide",function()
  G.SetQuest(3801);eq(w.quickStartButton:IsEnabled(),false);local n=#calls;w.quickStartButton:Click();eq(#calls,n)
  w.phaseButtons.blocked:Click();G.SetQuest(90107);eq(w.quickStartButton:IsEnabled(),false);eq(w.locationButton:IsEnabled(),false)
  w.quickStartButton:Click();eq(#calls,n);checkPreserved();w.phaseButtons.all:Click()
 end)
 test("Suggested action only selects/reveals a quest and does not navigate",function()
  G.SetQuest(90101);local n=#calls;w.findNextButton:Click();eq(G.selection.quest,90105);eq(#calls,n);assert(rowFor(90105),"chosen target not brought into view")
  checkPreserved()
 end)
 test("Empty phase shows explanation and disables absent action",function()
  dungeon.ids={3801};G.SetQuest(3801);w.phaseButtons.objective:Click()
  eq(#visibleRows(),0);assert(w.emptyList:IsShown());assert(#w.emptyList:GetText()>0);eq(w.quickStartButton:IsEnabled(),false);eq(w.findNextButton:IsEnabled(),false)
  checkPreserved();w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Explicit API.Open outside current filter preserves selected quest",function()
  w.search:SetText("산의 정수");G.API.Open(nil,90108)
  eq(G.selection.quest,90108);eq(G.db.selectedQuest,90108);has(w.nowTitle:GetText(),"목록 밖")
  has(w.detailHead:GetText(),G.GetQuestName(90108));assert(not rowFor(90108));checkPreserved()
  w.search:SetText("");G.SetQuest(90101)
 end)
 test("Changing search preserves explicit selection and marks outside result",function()
  G.SetQuest(90101);w.search:SetText("헐레이");eq(G.selection.quest,90101);has(w.nowTitle:GetText(),"목록 밖");assert(rowFor(90102));assert(not rowFor(90101))
  w.search:SetText("");eq(G.selection.quest,90101);has(w.nowTitle:GetText(),"지금 할 일");checkPreserved()
 end)
 test("Grouping off filters individual quests and clears reused chain visuals",function()
  dungeon.ids={3801,3802,90101,90104,90106};G.db.groupChains=false;G.UIRefresh();w.phaseButtons.accept:Click()
  assert(rowFor(90104));assert(not rowFor(90106));assert(not rowFor(3802))
  for _,r in ipairs(visibleRows())do eq(r.chainKey,nil);assert(not r.rail:IsShown());assert(not r.edge:IsShown());eq(r.entry.kind,"quest")end
  G.SetQuest(90104);has(w.relationshipInfo:GetText(),"OFF");checkPreserved()
  G.db.groupChains=true;w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Priority selection expands a collapsed chain and reveals target",function()
  states[3802]="turnin";G.UIRefresh()
  local chain=Mock.find(function(o)return o.chainKey~=nil and o:IsVisible()end);assert(chain);chain:Click();assert(not rowFor(3802))
  G.SetQuest(90101);local n=#calls;w.findNextButton:Click()
  eq(G.selection.quest,3802);assert(rowFor(3802),"collapsed target not revealed");eq(#calls,n);eq(states[3802],"turnin");checkPreserved()
  states[3802]="active";G.UIRefresh()
 end)
 test("External predecessor context does not inflate a zero-count phase",function()
  dungeon.ids={90106};G.UIRefresh();w.phaseButtons.accept:Click()
  eq(w.phaseButtons.accept:GetText(),"받기 0");eq(#visibleRows(),0);eq(w.findNextButton:IsEnabled(),false)
  w.phaseButtons.blocked:Click();assert(rowFor(90104));assert(rowFor(90106));eq(w.summary.nextQuestId,90106)
  w.findNextButton:Click();eq(G.selection.quest,90106);checkPreserved();w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Suggested target matches selected phase while preserving other chain context",function()
  dungeon.ids={90104,90106};G.UIRefresh();w.phaseButtons.blocked:Click()
  assert(rowFor(90104));assert(rowFor(90106));w.findNextButton:Click();eq(G.selection.quest,90106)
  w.phaseButtons.accept:Click();assert(rowFor(90104));assert(rowFor(90106));w.findNextButton:Click();eq(G.selection.quest,90104)
  checkPreserved();w.phaseButtons.all:Click();dungeon.ids=fixtureIds;G.UIRefresh()
 end)
 test("Branch rows do not imply a single numbered progression",function()
  parents[90106]={90104,90101};dungeon.ids={90104,90101,90106};G.UIRefresh()
  for _,r in ipairs(visibleRows())do if r.quest then assert(not r.text:GetText():find("%[연계 %d+/%d+%]"),"branch row misleadingly numbered") end end
  checkPreserved();parents[90106]={90104};dungeon.ids=fixtureIds;G.UIRefresh()
 end)
end
test("Closing browser also closes contact preview",function()
 G.ShowContactPreview(90101,"accept",ForeverDungeonQuestGuideFrame);G.ShowUI(false);eq(ForeverQuestContactPreview:IsShown(),false);eq(G.IsUIShown(),false);checkPreserved()
end)
print("UI tests: "..checked.." passed (mock only; not in-game rendering/input validation)")
if arg[2]=="preview" then
 assert(loadfile("tests/export_ui.lua"))()(Mock,G,base,names,states,levels,dungeon)
end

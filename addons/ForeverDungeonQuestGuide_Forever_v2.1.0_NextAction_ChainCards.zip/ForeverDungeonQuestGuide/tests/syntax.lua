local dir=arg[1] or 'work/ForeverDungeonQuestGuide/'
local f=assert(io.open(dir..'ForeverDungeonQuestGuide.toc'));local n=0
for line in f:lines() do if line:match('%.lua$') then assert(loadfile(dir..line));n=n+1 end end
f:close();print('PASS syntax '..n..' Lua files')

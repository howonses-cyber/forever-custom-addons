local addon, G = ...
local areas={
 [1]=1426,[3]=1418,[8]=1435,[10]=1431,[11]=1437,[12]=1429,[14]=1411,[15]=1445,
 [16]=1447,[17]=1413,[28]=1422,[33]=1434,[36]=1416,[38]=1432,[40]=1436,
 [41]=1430,[44]=1433,[45]=1417,[46]=1428,[47]=1425,[51]=1427,[85]=1420,
 [130]=1421,[139]=1423,[141]=1438,[148]=1439,[215]=1412,[267]=1424,[331]=1440,
 [357]=1444,[361]=1448,[400]=1441,[405]=1443,[406]=1442,[440]=1446,
 [490]=1449,[618]=1452,[1377]=1451,[1519]=1453,[1537]=1455,[1637]=1454,
 [1657]=1457,[1477]=1435,[978]=1446,[1584]=1428,[1583]=1428,[2557]=1444,
 [717]=1453,[718]=1413,[719]=1440,[721]=1426,[722]=1413,[796]=1420,
 [2100]=1443,[2057]=1422,[2017]=1423,[1581]=1436,[2437]=1454,
 [1517]=1418,[133]=1426,[1717]=1413,[209]=1421,
}
local function get(db,id,field)
 if type(db)~="table" then return nil end
 local getter=db.Get
 if type(getter)~="function" then return nil end
 local ok,value=pcall(getter,id,field)
 if ok and value~=0 then return value end
 return nil
end
G.DBGet=get
local mapCache={}
function G.AreaToUiMap(area)
 if not area or type(area)~="number" or area<=0 then return nil end
 if mapCache[area] then return mapCache[area] end
 local guessed=areas[area]
 if LibQuestieDB and LibQuestieDB.Support and type(LibQuestieDB.Support.Get)=="function" then
  local support=G.SafeCall(LibQuestieDB.Support.Get,"ZoneDB")
  local priv=support and support.private
  if priv then
   for _,key in ipairs({"areaIdToUiMapIdOverride","areaIdToUiMapId"}) do
    local lookup=priv[key]
    if type(lookup)=="table" then
     guessed=lookup[area] or guessed
    elseif type(lookup)=="string" and loadstring then
     -- QuestieDB publishes the mapping as a trusted, addon-supplied Lua literal.
     local decoder=loadstring(lookup)
     if decoder then
      local ok,t=pcall(decoder)
      if ok and type(t)=="table" then guessed=t[area] or guessed end
     end
    end
   end
  end
 end
 if guessed and C_Map and C_Map.GetMapInfo and not G.SafeCall(C_Map.GetMapInfo,guessed) then
  -- Keep the known mapping; a map API may not be loaded yet.
 end
 if guessed then mapCache[area]=guessed end
 return guessed
end
-- Quest zoneOrSort is a quest-category hint, not a precise target spawn.
-- Do not guess a coordinate from it; special indoor / mountain zones may
-- have no corresponding open-world UI map at all.
function G.QuestRegionHint(id)
 local area=tonumber(get(QuestDB,id,"zoneOrSort"))
 if not area or area<=0 then return nil end
 local known=G.knownQuestZones and G.knownQuestZones[area]
 if known then return known end
 for _,d in ipairs(G.dungeons or {}) do
  if d.area==area then return d.name end
 end
 local ui=G.AreaToUiMap(area)
 if ui and C_Map and C_Map.GetMapInfo then
  local info=G.SafeCall(C_Map.GetMapInfo,ui)
  if info and type(info.name)=="string" and info.name~="" then return info.name end
 end
 return nil
end
function G.QuestStageLandmark(id,kind)
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 return meta and meta.stageLandmarks and meta.stageLandmarks[kind] or nil
end
function G.GetQuestName(id)
 if not id then return "알 수 없는 퀘스트" end
 local localized=G.koQuestNames and G.koQuestNames[id]
 if localized then return localized end
 if G.nameCache[id] then return G.nameCache[id] end
 local name=get(QuestDB,id,"name")
 if type(name)~="string" or name=="" then return "퀘스트 #"..id.." (DB 확인 필요)" end
 -- If Korean localization is missing, do not fabricate a Korean translation.
 if GetLocale and GetLocale()=="koKR" and not string.find(name,"[\128-\255]") then
  name="한글 명칭 미확인 ("..name..")"
 end
 G.nameCache[id]=name
 return name
end
function G.GetQuestMinLevel(id) return tonumber(get(QuestDB,id,"requiredLevel")) or 0 end
function G.GetQuestLevel(id) return tonumber(get(QuestDB,id,"questLevel")) or 0 end
-- QuestieDB contract 3 publishes masks for Forever's extra races 95/96.
-- Classic raceId-1 arithmetic is incorrect for those high-ID race masks.
local fallbackRaceMasks={ [1]=1,[2]=2,[3]=4,[4]=8,[5]=16,[6]=32,[7]=64,[8]=128,
 [9]=256,[10]=512,[11]=1024,[22]=2097152,[24]=8388608,[25]=16777216,
 [26]=33554432,[95]=4294967296,[96]=8589934592 }
local fallbackFactionMasks={ Alliance=4294967373,Horde=8589934770 }
local function maskOverlaps(one,two)
 one=tonumber(one);two=tonumber(two)
 if not one or not two or one<=0 or two<=0 then return false end
 while one>0 and two>0 do
  if one%2==1 and two%2==1 then return true end
  one=math.floor(one/2);two=math.floor(two/2)
 end
 return false
end
local function factionMasks()
 local enum=LibQuestieDB and LibQuestieDB.Enum
 return enum and enum.factionRaceMasks or fallbackFactionMasks
end
local function playerRaceMask()
 local raceId=G.GetPlayerRaceId()
 local enum=LibQuestieDB and LibQuestieDB.Enum
 return raceId and ((enum and enum.raceMaskById and enum.raceMaskById[raceId]) or fallbackRaceMasks[raceId])
end
local function normalizeFaction(value)
 if value=="Alliance" or value=="얼라이언스" then return "Alliance" end
 if value=="Horde" or value=="호드" then return "Horde" end
 return nil
end
G.NormalizeFaction=normalizeFaction
function G.GetPlayerRaceId()
 if type(UnitRace)~="function" then return nil end
 local _,__,raceId=UnitRace("player")
 return tonumber(raceId)
end
function G.QuestFaction(id)
 id=tonumber(id)
 if not id then return "Unknown" end
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local explicit=special and normalizeFaction(special.onlyFaction)
 if explicit then return explicit end
 local mask=tonumber(get(QuestDB,id,"requiredRaces"))
 if not mask or mask<=0 then return "Any" end -- No faction restriction published.
 local masks=factionMasks()
 local alliance=maskOverlaps(mask,masks.Alliance)
 local horde=maskOverlaps(mask,masks.Horde)
 if alliance and horde then return "Both" end
 if alliance then return "Alliance" end
 if horde then return "Horde" end
 return "Unknown" -- Do not invent a faction for an unrecognized mask.
end
function G.IsClassAllowedQuest(id)
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local classes=(special and special.classMask) or tonumber(get(QuestDB,id,"requiredClasses"))
 if classes and classes>0 then
  if not G.player.classId or G.player.classId<=0 then return false end
  if not maskOverlaps(classes,2^(G.player.classId-1)) then return false end
 end
 return true
end
function G.IsEligibleQuest(id)
 id=tonumber(id)
 if not id then return false end
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 local explicit=special and normalizeFaction(special.onlyFaction)
 if explicit and G.player.faction~=explicit then return false end
 if not G.IsClassAllowedQuest(id) then return false end
 local allowed=tonumber(get(QuestDB,id,"requiredRaces"))
 if allowed and allowed>0 then
  local ownMask=playerRaceMask()
  if not ownMask then return false end -- Missing race data must not fake eligibility.
  return maskOverlaps(allowed,ownMask)
 end
 return true
end
function G.QuestPrerequisite(id)
 local oneOf=get(QuestDB,id,"preQuestSingle")
 local allOf=get(QuestDB,id,"preQuestGroup")
 return type(allOf)=="table" and allOf or {}, type(oneOf)=="table" and oneOf or {}
end
-- Only positive, unambiguous mandatory prerequisites are evidence of a
-- passed stage. Never infer completion from mere sequence/nextQuest or
-- from one of several alternatives, negative IDs or exclusive groups.
local reverseMandatory,activeEvidence,evidenceMemo={}, {}, {}
function G.MandatoryRoutePrereqs(id)
 local all,one=G.QuestPrerequisite(id)
 local result,seen={},{}
 local function add(q)
  q=tonumber(q)
  if not q or q<=0 or q==id or seen[q] then return end
  local alternatives=get(QuestDB,q,"exclusiveTo")
  if type(alternatives)=="table" and next(alternatives) then return end
  seen[q]=true;result[#result+1]=q
 end
 for _,q in ipairs(all) do add(q) end
 if #one==1 then add(one[1]) end
 return result
end
function G.ResetRouteDependencyIndex()
 reverseMandatory={};evidenceMemo={}
 if G.RefreshRouteEvidence then G.RefreshRouteEvidence() end
end
function G.IndexRouteDependencies(id)
 for _,pre in ipairs(G.MandatoryRoutePrereqs(id)) do
  local children=reverseMandatory[pre]
  if not children then children={};reverseMandatory[pre]=children end
  children[id]=true
  evidenceMemo[pre]=nil
 end
end
function G.RefreshRouteEvidence()
 local previous=activeEvidence
 activeEvidence={};evidenceMemo={}
 if not G.Ready() then return false end
 local expanded={}
 local function walk(id,root,depth)
  if depth>25 or expanded[id] then return end
  expanded[id]=true
  for _,pre in ipairs(G.MandatoryRoutePrereqs(id)) do
   if not G.IsInLog(pre) then
    activeEvidence[pre]=root
    walk(pre,root,depth+1)
   end
  end
 end
 -- Accepted and same-session rewarded descendants are direct observations.
 for id in pairs(G.activeQuests or {}) do walk(id,id,0) end
 for id in pairs(G.sessionTurnins or {}) do if G.IsCompleted(id) then walk(id,id,0) end end
 for id,root in pairs(activeEvidence) do if previous[id]~=root then return true end end
 for id in pairs(previous) do if not activeEvidence[id] then return true end end
 return false
end
function G.RoutePrereqEvidence(id)
 id=tonumber(id)
 if not id or G.IsInLog(id) or not G.Ready() then return nil end
 if activeEvidence[id] then return activeEvidence[id] end
 if evidenceMemo[id]~=nil then return evidenceMemo[id] or nil end
 -- The incremental quest index permits lookup of already rewarded downstream
 -- quests even after reload, without scanning the entire database per click.
 local visited={[id]=true}
 local queue={{id=id,depth=0}};local i=1;local found
 while i<=#queue and i<=128 and not found do
  local node=queue[i];i=i+1
  local children=reverseMandatory[node.id] or {}
  -- A forward link alone is NOT proof; validate the child's mandatory edge.
  local linked=tonumber(get(QuestDB,node.id,"nextQuestInChain"))
  local candidates={}
  for child in pairs(children) do candidates[child]=true end
  if linked and linked>0 and not candidates[linked] then
   for _,pre in ipairs(G.MandatoryRoutePrereqs(linked)) do
    if pre==node.id then candidates[linked]=true;break end
   end
  end
  for child in pairs(candidates) do
   if not visited[child] then
    visited[child]=true
    if G.IsInLog(child) or G.IsCompleted(child) then found=child;break end
    if node.depth<24 and #queue<128 then queue[#queue+1]={id=child,depth=node.depth+1} end
   end
  end
 end
 evidenceMemo[id]=found or false
 return found
end
function G.RouteExclusionReason(id)
 id=tonumber(id)
 if not id or G.IsInLog(id) or G.IsCompleted(id) then return nil end
 for _,successor in ipairs((G.routePickupBlockers and G.routePickupBlockers[id]) or {}) do
  if G.IsInLog(successor) or G.IsCompleted(successor) then
   return "후속 퀘스트 "..G.GetQuestName(successor).." 진행/완료로 선행 수락 불가",successor
  end
 end
 local root=G.RoutePrereqEvidence(id)
 if root then return "필수 후속 퀘스트 "..G.GetQuestName(root).." 진행/완료 확인",root end
 return nil
end
function G.IsRouteSatisfied(id)
 return G.IsCompleted(id) or G.RouteExclusionReason(id)~=nil
end
function G.IsRoutePrereqSatisfied(id)
 return G.IsCompleted(id) or G.RoutePrereqEvidence(id)~=nil
end
local function meetsOrEquivalent(qid)
 if G.IsRoutePrereqSatisfied(qid) then return true end
 local exclusive=get(QuestDB,qid,"exclusiveTo")
 if type(exclusive)=="table" then
  for _,alt in ipairs(exclusive) do if G.IsCompleted(math.abs(alt)) then return true end end
 end
 return false
end
function G.SelectOnePrereq(ids)
 for _,id in ipairs(ids) do
  if (id>0 and meetsOrEquivalent(id)) or (id<0 and G.IsCompleted(math.abs(id))) then return math.abs(id),true end
 end
 for _,id in ipairs(ids) do if G.IsInLog(math.abs(id)) and G.IsEligibleQuest(math.abs(id)) then return math.abs(id),false end end
 for _,id in ipairs(ids) do if G.IsEligibleQuest(math.abs(id)) then return math.abs(id),false end end
 return ids[1] and math.abs(ids[1]) or nil,false
end
function G.GetMissingPrereqs(id)
 if not G.Ready() or G.IsInLog(id) or G.IsCompleted(id) then return {} end
 local all,one=G.QuestPrerequisite(id)
 local missing,unique={},{}
 local function add(id)
  if id and id>0 and not unique[id] then missing[#missing+1]=id;unique[id]=true end
 end
 -- A group requires all entries, whereas the single list accepts one.
 -- Each nonnegative group requirement may be fulfilled by a completed exclusive alternative.
 if #one>0 then
  local candidate,satisfied=G.SelectOnePrereq(one)
  if candidate and not satisfied then add(candidate) end
 end
 for _,entry in ipairs(all) do
  local q=math.abs(entry)
  local fulfilled=(entry<0 and G.IsCompleted(q)) or (entry>0 and meetsOrEquivalent(q))
  if not fulfilled then
   if G.IsEligibleQuest(q) then add(q)
   elseif entry>=0 then
    local alts=get(QuestDB,q,"exclusiveTo")
    if type(alts)=="table" then
     for _,alt in ipairs(alts) do
      alt=math.abs(alt)
      if G.IsEligibleQuest(alt) then
       if not meetsOrEquivalent(alt) then add(alt) end
       break
      end
     end
    end
   end
  end
 end
 return missing
end
local function dungeonForArea(area)
 for _,d in ipairs(G.dungeons or {}) do if d.area and d.area==tonumber(area) then return d end end
end
local function actualZone(area)
 local d=dungeonForArea(area);if d then return d.name,d end
 local known=G.knownQuestZones and G.knownQuestZones[tonumber(area)]
 if known then return known,nil,G.AreaToUiMap(tonumber(area)) end
 local map=G.AreaToUiMap(tonumber(area))
 local info=map and G.SafeCall(C_Map and C_Map.GetMapInfo,map)
 return info and info.name or nil,nil,map
end
-- An instance area's coordinates may be sentinel or instance-relative. Never
-- project them onto the exterior zone ID used by older area mappings.
local function entityArea(db,id)
 local spawns=get(db,id,"spawns")
 if type(spawns)~="table" then return nil end
 local keys={};for area in pairs(spawns) do if tonumber(area) then keys[#keys+1]=tonumber(area) end end
 table.sort(keys)
 local current=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local first
 for _,area in ipairs(keys) do
  local name,d,map=actualZone(area)
  if name then
   local r={zone=name,dungeon=d,map=map}
   if map and map==current then return r end
   first=first or r
  end
 end
 return first
end
function G.QuestObjectiveText(id)
 local lines=get(QuestDB,id,"objectivesText")
 if type(lines)=="string" then return lines end
 if type(lines)=="table" then
  local out={};for _,v in ipairs(lines) do if type(v)=="string" and v~="" then out[#out+1]=v end end
  if #out>0 then return table.concat(out," / ") end
 end
end
local function entityLandmark(db,id,target,instruction)
 local place=entityArea(db,id)
 if not place then return nil end
 return {zone=place.zone,site=target,target=target,instruction=instruction,approxArea=true,map=place.map,
  dungeonId=place.dungeon and place.dungeon.id,approach=place.dungeon and place.dungeon.entrance}
end
local function fromSpawns(entityDB,entityID,preferredMap)
 local spawns=get(entityDB,entityID,"spawns")
 if type(spawns)~="table" then return nil end
 local choice
 for area,points in pairs(spawns) do
  local mapId=not dungeonForArea(area) and G.AreaToUiMap(tonumber(area))
  if mapId and type(points)=="table" then
   for _,coords in ipairs(points) do
    if type(coords)=="table" and type(coords[1])=="number" and type(coords[2])=="number"
       and coords[1]>=0 and coords[1]<=100 and coords[2]>=0 and coords[2]<=100 then
     local candidate={map=mapId,x=coords[1]/100,y=coords[2]/100}
     if mapId==preferredMap then return candidate end
     if not choice then choice=candidate end
    end
   end
  end
 end
 return choice
end

-- Returns named objective locations grounded in current QuestieDB drop/spawn data.
-- These are candidate spawn locations, never a guarantee of drops or a terrain route.
function G.QuestObjectivePoints(id)
 local verified=G.verifiedObjectives and G.verifiedObjectives[id]
 if verified then return verified end
 local objectives=get(QuestDB,id,"objectives")
 if type(objectives)~="table" then return {} end
 local preferred=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local results={}
 local function add(kind,entityId,point,name,landmark)
  results[#results+1]={kind=kind,id=entityId,point=point,title=name or ("대상 #"..tostring(entityId)),landmark=landmark}
 end
 local function spawn(db,entityId)
  local p=fromSpawns(db,entityId,preferred)
  if p then p.name=get(db,entityId,"name") or "목표 위치" end
  return p
 end
 -- Creature objectives.
 for _,entry in ipairs(type(objectives[1])=="table" and objectives[1] or {}) do
  local npcId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if npcId then
   local name=get(NpcDB,npcId,"name") or "처치 대상"
   local p=spawn(NpcDB,npcId)
   add("creature",npcId,p,name,not p and entityLandmark(NpcDB,npcId,name,name.."을(를) 찾아 처치하고 퀘스트 목표 수량을 확인하세요.") or nil)
  end
 end
 -- Game-object objectives.
 for _,entry in ipairs(type(objectives[2])=="table" and objectives[2] or {}) do
  local objectId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if objectId then
   local name=get(ObjectDB,objectId,"name") or "상호작용 대상"
   local p=spawn(ObjectDB,objectId)
   add("object",objectId,p,name,not p and entityLandmark(ObjectDB,objectId,name,name.."와 상호작용해 퀘스트 목표를 수행하세요.") or nil)
  end
 end
 -- Item objectives: look up actual NPC/object drop sources, not invented coordinates.
 for _,entry in ipairs(type(objectives[3])=="table" and objectives[3] or {}) do
  local itemId=type(entry)=="table" and tonumber(entry[1]) or tonumber(entry)
  if itemId then
   local p,landmark
   local itemName=get(ItemDB,itemId,"name") or ("아이템 #"..itemId)
   for _,spec in ipairs({{db=NpcDB,ids=get(ItemDB,itemId,"npcDrops")},
                          {db=ObjectDB,ids=get(ItemDB,itemId,"objectDrops")}}) do
    if type(spec.ids)=="table" then
     for _,mobId in ipairs(spec.ids) do
      local sourceId=tonumber(mobId)
      local candidate=sourceId and spawn(spec.db,math.abs(sourceId))
      if sourceId and not landmark then
       local sourceName=get(spec.db,math.abs(sourceId),"name")
       if sourceName then landmark=entityLandmark(spec.db,math.abs(sourceId),sourceName,sourceName.."에서 "..itemName.."을(를) 획득하세요. 퀘스트 로그의 필요 수량을 확인하세요.") end
      end
      if candidate then
       if not p then p=candidate end
       if candidate.map==preferred then p=candidate;break end
      end
     end
    end
    if p and p.map==preferred then break end
   end
   add("item",itemId,p,itemName,not p and landmark or nil)
  end
 end
 return results
end
-- NPC/object names can exist in QuestieDB even when no coordinate was stored.
function G.QuestContactName(id,stage)
 if stage~="accept" and stage~="turnin" then return nil end
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 for _,source in ipairs({{db=NpcDB,list=row.npc or row.NPC or row[1],kind="npc"},
                          {db=ObjectDB,list=row.object or row.Object or row[2],kind="object"},
                          {db=ItemDB,list=stage=="accept" and (row.item or row.Item or row[3]),kind="item"}}) do
  if type(source.list)=="table" then
   for _,num in ipairs(source.list) do
    local entityID=tonumber(num)
    local name=entityID and get(source.db,entityID,"name")
    if type(name)=="string" and name~="" then return name,entityID,source.db,source.kind end
   end
  end
 end
 return nil
end
function G.QuestContactLandmark(id,stage)
 local name,eid,db,kind=G.QuestContactName(id,stage)
 if not name then return nil end
 if kind=="item" then
  for _,spec in ipairs({{db=NpcDB,ids=get(ItemDB,eid,"npcDrops")},{db=ObjectDB,ids=get(ItemDB,eid,"objectDrops")}}) do
   for _,source in ipairs(type(spec.ids)=="table" and spec.ids or {}) do
    local sid=tonumber(source);local sn=sid and get(spec.db,math.abs(sid),"name")
    if sn then
     local lm=entityLandmark(spec.db,math.abs(sid),sn,sn.."에서 "..name.."을(를) 얻고 가방에서 사용해 퀘스트를 수락하세요.")
     if lm then return lm end
    end
   end
  end
  return {zone="시작 아이템",site=name,target=name,instruction="가방에 있는 시작 아이템을 사용해 퀘스트를 수락하세요. 미보유 시 아이템 획득처 확인이 필요합니다.",approxArea=true}
 end
 local action=kind=="object" and (name.."와 상호작용해 "..(stage=="accept" and "수락" or "보고").."하세요.") or (name.."에게 "..(stage=="accept" and "수락" or "보고").."하세요.")
 return entityLandmark(db,eid,name,action)
end

-- An instance NPC may be present in finishedBy but have no numeric spawn.
-- Return a trustworthy indoor destination; never substitute entrance coordinates
-- for an indoor hand-in, and never mistake a missing point for a missing NPC.
function G.QuestInsideInfo(id,stage)
 local meta=G.specialQuestMeta and G.specialQuestMeta[id]
 local hint=meta and meta.insideStages and meta.insideStages[stage]
 local dungeon
 if hint then
  dungeon=G.GetDungeon(hint.dungeon)
 else
  if stage~="accept" and stage~="turnin" then return nil end
  if G.QuestPoint and G.QuestPoint(id,stage) then return nil end
  local name,eid,db,kind=G.QuestContactName(id,stage)
  local place=eid and entityArea(db,eid)
  if place and place.dungeon then
   dungeon=place.dungeon;hint={room="던전 내부",npcId=eid,npcName=name,contactType=kind}
  end
 end
 if not dungeon or not hint then return nil end
 return {dungeon=dungeon.name,dungeonId=dungeon.id,entrance=dungeon.entrance,
  npcId=hint.npcId,npcName=hint.npcName or (hint.npcId and get(NpcDB,hint.npcId,"name")) or G.QuestContactName(id,stage) or "퀘스트 목표",
  room=hint.room or "던전 내부",followup=hint.followup,instruction=hint.instruction,contactType=hint.contactType or "npc",verified=hint.verified}
end

local function questGiver(id,stage)
 local row=get(QuestDB,id,stage=="accept" and "startedBy" or "finishedBy")
 if type(row)~="table" then return nil end
 local preferredMap=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 local providers={{db=NpcDB,list=row.npc or row.NPC or row[1]},
                  {db=ObjectDB,list=row.object or row.Object or row[2]}}
 local best
 for _,provider in ipairs(providers) do
  if type(provider.list)=="table" then
   for _,entry in ipairs(provider.list) do
    local idNum=tonumber(entry)
    if idNum then
     local point=fromSpawns(provider.db,idNum,preferredMap)
     if point then
      point.name=get(provider.db,idNum,"name") or "NPC/오브젝트 #"..idNum
      if point.map==preferredMap then return point end
      if not best then best=point end
     end
    end
   end
  end
 end
 return best
end
function G.QuestPoint(id,stage)
 local meta=G.specialQuestMeta[id]
 if meta and (meta.inside or (meta.insideStages and meta.insideStages[stage]) or (meta.stageLandmarks and meta.stageLandmarks[stage])) then return nil end
 if stage=="accept" or stage=="turnin" then
  local overrides=stage=="accept" and G.pickupOverrides or G.turninOverrides
  local override=overrides and overrides[id]
  if override then return {map=override.map,x=override.x,y=override.y,name=override.name or (G.GetQuestName(id).." "..stage)} end
 end
 if stage=="objective" then
  local trigger=get(QuestDB,id,"triggerEnd")
  if type(trigger)=="table" and type(trigger[2])=="table" then
   for area,locations in pairs(trigger[2]) do
    local m=not dungeonForArea(area) and G.AreaToUiMap(tonumber(area))
    if m and type(locations)=="table" and type(locations[1])=="table" then
     local p=locations[1]
     if type(p[1])=="number" and type(p[2])=="number" and p[1]>=0 and p[1]<=100 and p[2]>=0 and p[2]<=100 then
      return {map=m,x=p[1]/100,y=p[2]/100,name=G.GetQuestName(id).." 목표"}
     end
    end
   end
  end
  return nil -- Do not synthesize coordinates for drop/kill objectives.
 end
 return questGiver(id,stage)
end
function G.QuestGiverName(id,stage)
 local point=G.QuestPoint(id,stage)
 if point and point.name then return point.name end
 local inside=G.QuestInsideInfo(id,stage)
 local lm=G.QuestStageLandmark(id,stage) or G.QuestContactLandmark(id,stage)
 if lm then return lm.target or lm.site end
 if inside then return inside.npcName.." ("..inside.dungeon.." · "..inside.room..")" end
 return G.QuestContactName(id,stage) or
    ((G.specialQuestMeta[id] and G.specialQuestMeta[id].inside) and "던전 내부" or "위치 데이터 확인 필요")
end
function G.QuestDetails(id)
 local all,one=G.QuestPrerequisite(id)
 local state,code=G.QuestState(id)
 local point=G.QuestPoint(id,code=="turnin" and "turnin" or "accept")
 local localeName=point and C_Map and C_Map.GetMapInfo and G.SafeCall(C_Map.GetMapInfo,point.map)
 local place=point and ((localeName and localeName.name) or ("지도 #"..point.map)) or nil
 local indoor=G.QuestInsideInfo(id,code=="turnin" and "turnin" or "accept")
 local coords=point and string.format("%s %.1f, %.1f",place,point.x*100,point.y*100) or
   (indoor and (indoor.dungeon.." · "..indoor.room) or nil)
 if not coords then local lm=G.QuestStageLandmark(id,code=="turnin" and "turnin" or "accept") or G.QuestContactLandmark(id,code=="turnin" and "turnin" or "accept");coords=lm and (lm.zone.." · "..lm.site) or "실제 방문 위치 자료 부족" end
 return {id=id,name=G.GetQuestName(id),level=G.GetQuestMinLevel(id),status=state,code=code,
   all=all,one=one,starter=G.QuestGiverName(id,code=="turnin" and "turnin" or "accept"),coords=coords,
   note=G.specialQuestMeta[id] and G.specialQuestMeta[id].note}
end

local addon,G=...
local function addStep(plan,step)
 step.serial=#plan+1
 plan[#plan+1]=step
end
-- Resolve all step types using explicit route facts first, then installed DB
-- entity spawns, then the actual objective text. Quest category is only context.
function G.EnrichStepLocation(step)
 local id=tonumber(step.quest);if not id then return step end
 local kind=step.kind=="inside" and "objective" or step.kind
 if kind~="accept" and kind~="turnin" and kind~="objective" then return step end
 local indoor=G.QuestInsideInfo(id,kind)
 local lm=G.QuestStageLandmark(id,kind)
 local p,contactType
 if kind=="objective" and not indoor and not lm then
  for _,obj in ipairs(G.QuestObjectivePoints(id)) do
   if obj.id==step.objectiveId and obj.kind==step.objectiveKind then
    p=obj.point;lm=obj.landmark;step.objectiveTitle=obj.title;break
   end
  end
  if not step.objectiveId then
   local list=G.QuestObjectivePoints(id)
   if #list==1 then p=list[1].point;lm=list[1].landmark;step.objectiveTitle=list[1].title end
  end
 end
 if kind=="accept" or kind=="turnin" then
  local name,eid,db,ct=G.QuestContactName(id,kind)
  contactType=ct or "npc"
  if not indoor and not lm then
   p=G.QuestPoint(id,kind)
   if not p then lm=G.QuestContactLandmark(id,kind) end
  end
  step.contactName=(indoor and indoor.npcName) or (lm and lm.target) or (p and p.name) or name
 end
 if not indoor and not lm and not p then p=G.QuestPoint(id,kind) end
 -- Preserve a usable older point only when the DB itself is temporarily missing.
 if not G.Ready() and not indoor and not lm and not p then p=step.point end
 step.indoor=indoor;step.landmark=lm;step.point=(not indoor and not lm) and p or nil
 step.contactType=indoor and indoor.contactType or contactType
 step.regionHint=(not step.point and not indoor and not lm) and G.QuestRegionHint(id) or nil
 step.goalText=kind=="objective" and G.QuestObjectiveText(id) or nil
 if indoor then step.note=indoor.instruction or (indoor.dungeon.." · "..indoor.room.." · "..indoor.npcName)
 elseif lm then step.note=lm.instruction or lm.note or step.note
 elseif step.goalText then step.note=step.goalText end
 return step
end
local function stage(plan,id,kind,label,prereq)
 local title=G.GetQuestName(id)
 local suffix=kind=="accept" and "수락" or kind=="objective" and "수행" or kind=="turnin" and "보고" or "확인"
 local function make(extra)
  local st={kind=kind,quest=id,title=title.." - "..suffix,questName=title,note=label or "",prereq=prereq==true}
  if extra then for k,v in pairs(extra) do st[k]=v end end
  G.EnrichStepLocation(st);addStep(plan,st)
 end
 if kind=="objective" and not G.QuestStageLandmark(id,kind) and not G.QuestInsideInfo(id,kind) then
  local objectives=G.QuestObjectivePoints(id)
  if #objectives>0 then
   for _,o in ipairs(objectives) do
    local verb=o.kind=="creature" and "처치" or o.kind=="object" and "확인" or "획득"
    make({title=title.." - "..o.title.." "..verb,objectiveTitle=o.title,objectiveId=o.id,objectiveKind=o.kind})
   end
   return
  end
 end
 make()
end
local function fullyComplete(id)
 return G.IsRouteSatisfied(id)
end
local function appendRequired(plan,id,seen,stack,warnings,level)
 if level>25 or stack[id] then warnings[#warnings+1]="선행 연결 순환 또는 25단계 초과: #"..id;return end
 if seen[id] or fullyComplete(id) then return end
 stack[id]=true
 for _,pre in ipairs(G.GetMissingPrereqs(id)) do
  if G.IsEligibleQuest(pre) then appendRequired(plan,pre,seen,stack,warnings,level+1)
  else warnings[#warnings+1]="진영/직업 제한으로 선행 퀘스트 확인 필요: #"..pre end
 end
 stack[id]=nil
 if not seen[id] and not fullyComplete(id) then
  seen[id]=true
  if not G.IsInLog(id) then stage(plan,id,"accept","선행 퀘스트를 수락합니다.",true) end
  local special=G.specialQuestMeta and G.specialQuestMeta[id]
  if not G.IsReadyToTurnIn(id) and not (special and special.directTurnin) then
   stage(plan,id,"objective","퀘스트 목표를 수행합니다. 목표 위치 자료가 없으면 Questie 지도를 확인하세요.",true)
  end
  stage(plan,id,"turnin","완료 NPC에게 보고한 후 다음 연계가 열립니다.",true)
 end
end
-- A deferred dungeon chain must be excluded without marking any quest
-- completed or pretending its missing prerequisite was rewarded.
local function blockedByDeferred(id,stack)
 if G.IsRouteSatisfied(id) then return false end
 if G.db.deferredQuests and G.db.deferredQuests[id] then return true end
 if G.IsInLog(id) then return false end
 if stack[id] then return false end
 stack[id]=true
 for _,pre in ipairs(G.GetMissingPrereqs(id)) do
  if blockedByDeferred(pre,stack) then stack[id]=nil;return true end
 end
 stack[id]=nil
 return false
end
local function sortedTargets(d,focusedId)
 local ids={}
 if focusedId then return (G.IsRouteSatisfied(focusedId) or blockedByDeferred(focusedId,{})) and {} or {focusedId} end
 local currentMap=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 for _,id in ipairs(d.ids) do
  if G.IsEligibleQuest(id) and not G.IsRouteSatisfied(id)
     and not blockedByDeferred(id,{}) then ids[#ids+1]=id end
 end
 -- Important: this is a limited zone-grouping heuristic, not a cross-continent
 -- shortest-path claim. Dependency ordering is enforced separately.
 table.sort(ids,function(a,b)
  local ap=G.QuestPoint(a,"accept");local bp=G.QuestPoint(b,"accept")
  local am=ap and ap.map or 999999;local bm=bp and bp.map or 999999
  if currentMap then
   if am==currentMap and bm~=currentMap then return true end
   if bm==currentMap and am~=currentMap then return false end
  end
  if am~=bm then return am<bm end
  return a<b
 end)
 return ids
end
function G.BuildGuide(dungeonID,questID)
 if not G.Ready() then return nil,"QuestieDB 연결이 필요합니다. QuestieDB를 활성화하고 다시 접속하세요." end
 if G.RefreshRouteEvidence then G.RefreshRouteEvidence() end
 local d=G.GetDungeon(dungeonID)
 if not d then return nil,"알 수 없는 던전입니다." end
 local dungeonFaction=G.NormalizeFaction(d.onlyFaction)
 if dungeonFaction and dungeonFaction~=G.player.faction then
  return nil,"현재 캐릭터 진영으로 진행할 수 없는 던전입니다. 진영 필터는 검색용입니다."
 end
 if questID and not G.IsInLog(questID) and not G.IsEligibleQuest(questID) then
  return nil,"선택한 퀘스트는 현재 캐릭터의 진영/종족/직업으로 진행할 수 없습니다."
 end
 if #d.ids==0 then return nil,"이 던전의 퀘스트 연계 자료는 아직 검증되지 않았습니다." end
 local targets=sortedTargets(d,questID)
 if #targets==0 then
  local reason=questID and G.RouteExclusionReason(questID)
  if reason then return nil,"동선 제외: "..reason end
  return nil,"현재 퀘스트가 모두 완료되었거나 나중에 진행하도록 보류했습니다. /fdq resume all 로 복귀하세요."
 end
 local plan,seen,warnings={}, {}, {}
 local queuedPickup={}
 for _,id in ipairs(targets) do
  if not fullyComplete(id) then
   for _,pre in ipairs(G.GetMissingPrereqs(id)) do
    if G.IsEligibleQuest(pre) then appendRequired(plan,pre,seen,{},warnings,1) end
   end
   local special=G.specialQuestMeta[id]
   if not G.IsInLog(id) and not seen[id] and not (special and special.inside)
       and not G.QuestInsideInfo(id,"accept")
       and not queuedPickup[id] then
    queuedPickup[id]=true
    stage(plan,id,"accept","던전에 들어가기 전에 퀘스트를 받으세요.",false)
   end
  end
 end
 -- Drop-started quests cannot be picked up before entering; do not invent points.
 if d.entrance then
  addStep(plan,{kind="entrance",quest=nil,title=d.name.." 던전 지역으로 이동",
   note="표시는 던전 부근 위치입니다. 실제 차원문까지 계단/수중 경로가 추가로 필요할 수 있습니다. 필드 경로는 ShortestPathForever 설치 시에만 계산됩니다.",
   point={map=d.entrance.map,x=d.entrance.x,y=d.entrance.y,name=d.name.." 던전 부근"}})
 end
 local included={}
 for _,id in ipairs(targets) do
  if not fullyComplete(id) and not included[id] and not seen[id] then
   included[id]=true
   local special=G.specialQuestMeta[id]
   if not G.IsInLog(id) and not queuedPickup[id] then stage(plan,id,"accept","퀘스트를 수락하세요.",false) end
   if not G.IsReadyToTurnIn(id) and not (special and special.directTurnin) then
    stage(plan,id,"objective","목표를 수행하세요.",false)
   end
   stage(plan,id,"turnin","퀘스트를 보고하세요.",false)
  end
 end
 -- Place the approach before the first indoor step, without moving any other
 -- step across its own prerequisite or subsequent outdoor turn-in.
 local entranceAt,firstInside
 for i,st in ipairs(plan) do
  if st.kind=="entrance" and not entranceAt then entranceAt=i end
  if (st.indoor and st.indoor.dungeonId==dungeonID) or (st.landmark and st.landmark.dungeonId==dungeonID) then firstInside=firstInside or i end
 end
 if entranceAt and firstInside and firstInside<entranceAt then
  local entry=table.remove(plan,entranceAt);table.insert(plan,firstInside,entry)
 end
 for i,st in ipairs(plan) do st.serial=i end
 if #plan==0 then return nil,"진행할 단계가 없습니다." end
 return {dungeon=dungeonID,focus=questID,steps=plan,index=1,warnings=warnings},nil
end
-- Refresh a saved guide's location references in place after an addon update.
-- Never discard manually completed steps, progress index or selected quests.
function G.HydrateGuideLocations()
 local gd=G.db and G.db.guide
 if not gd or type(gd.steps)~="table" then return false end
 -- Hydrate every saved row, including old incorrect outdoor positions for
 -- instance objects. Keep step identities, progress, and existing history.
 local steps=gd.steps
 if gd.locationSchema~=3 then
  local repaired,hasReport={},{}
  local index=gd.index or 1
  for i,step in ipairs(steps) do if i>=index and step.kind=="turnin" and step.quest then hasReport[step.quest]=true end end
  local serial=#steps+1
  for i,step in ipairs(steps) do
   if i>=index and step.kind=="inside" and step.quest and not G.StepIsDone(step,i) then
    local temp={};local m=G.specialQuestMeta[step.quest]
    if not (m and m.directTurnin) then stage(temp,step.quest,"objective",step.note,step.prereq) end
    if not hasReport[step.quest] then stage(temp,step.quest,"turnin","퀘스트를 보고하세요.",step.prereq);hasReport[step.quest]=true end
    for _,st in ipairs(temp) do st.serial=serial;serial=serial+1;repaired[#repaired+1]=st end
   else repaired[#repaired+1]=step end
  end
  gd.steps=repaired;steps=repaired;gd.locationSchema=3
 end
 for _,step in ipairs(steps) do G.EnrichStepLocation(step) end
 return true
end
local function guide() return G.db and G.db.guide end
-- Viewing history is independent of the active route index and is not a new
-- destination. A new plan resets the transient review cursor by table identity.
local reviewGuide,reviewStep
function G.GuideReviewIndex()
 local g=guide()
 if not g or g~=reviewGuide or not reviewStep then return nil end
 for i,st in ipairs(g.steps or {}) do
  if st==reviewStep then
   if i==(g.index or 1) then reviewGuide=nil;reviewStep=nil;return nil end
   return i
  end
 end
 reviewGuide=nil;reviewStep=nil
end
function G.GuideViewIndex()
 local g=guide();return G.GuideReviewIndex() or (g and g.index or 1)
end
function G.DisplayGuideStep()
 local g=guide();return g and g.steps and g.steps[G.GuideViewIndex()]
end
function G.SelectGuideStep(i)
 local g=guide();if not g or not g.steps then return false end
 i=math.floor(tonumber(i) or (g.index or 1))
 if i==(g.index or 1) then reviewGuide=nil;reviewStep=nil
 elseif g.steps[i] then reviewGuide=g;reviewStep=g.steps[i]
 else return false end
 G.guideFeedback=nil;G.NotifyDataChange();return true
end
function G.GuideViewStatus(step,i)
 local g=guide();if not step or not g then return nil end
 if G.StepIsDone(step,i) then
  if step.quest and G.IsCompleted(step.quest) then return "퀘스트 보고 완료" end
  if step.quest and G.RouteExclusionReason(step.quest) then return "후속 진행 확인 · 동선 제외" end
  if step.kind=="accept" then return "수락 완료" end
  if step.kind=="objective" or step.kind=="inside" then return "목표 수행 완료" end
  return "단계 완료"
 end
 if i<(g.index or 1) then return "이전 단계 기록 · 실제 완료 상태 미확인" end
 if i~=(g.index or 1) then return "예정 단계 미리보기" end
end
function G.GuideViewingHistory()
 return G.GuideReviewIndex()~=nil
end
function G.ReturnToActiveGuide()
 local g=guide();return g and G.SelectGuideStep(g.index or 1)
end
-- Keep the already-visited prefix, selection and real quest state. Remove
-- obsolete future visits before building navigation and next-step previews.
function G.ReconcileGuide()
 local g=guide();if not g or type(g.steps)~="table" then return false end
 local oldIndex=g.index or 1
 local oldStep=g.steps[oldIndex]
 local kept,removed,advanced={},0,0
 local prefix=true
 for i,step in ipairs(g.steps) do
  if i<oldIndex then kept[#kept+1]=step
  elseif G.StepIsDone(step,i) then
   if prefix and not (step.quest and G.RouteExclusionReason(step.quest) and not G.IsCompleted(step.quest)) then
    kept[#kept+1]=step;advanced=advanced+1
   elseif step.quest then removed=removed+1
   else kept[#kept+1]=step end
  else kept[#kept+1]=step;prefix=false end
 end
 if removed>0 then g.steps=kept end
 g.index=math.max(1,math.min(oldIndex+advanced,#g.steps+1))
 while g.index<=#g.steps and G.StepIsDone(g.steps[g.index],g.index) do g.index=g.index+1 end
 local changed=removed>0 or oldIndex~=g.index or oldStep~=g.steps[g.index]
 if changed then
  G.guideFeedback=nil
  if g.index<=#g.steps then G.ActivateGuideStep(false)
  else
   if G.ClearWaypoint then G.ClearWaypoint() end
   G.navStatus="통합 동선 완료 · 실제 퀘스트 상태는 로그에서 확인"
  end
 end
 if G.UIRefresh then G.UIRefresh() end
 if G.HUDRefresh then G.HUDRefresh() end
 return changed
end
function G.ActivateGuideStep(openMap)
 local g=guide();local step=g and g.steps and g.steps[g.index or 1]
 if not step then if G.ClearWaypoint then G.ClearWaypoint() end;return end
 if G.StepIsDone and G.StepIsDone(step,g.index or 1) then G.ReconcileGuide();return end
 -- A new step without coordinates must cancel the previous quest waypoint.
 local ok=G.NavigateGuideRoute and G.NavigateGuideRoute(g,openMap)
 if not ok and openMap and step.point then G.OpenPointMap(step.point) end
 if G.RefreshMapPins then G.RefreshMapPins() end
end
function G.StartGuide(dungeonId,questId)
 local g,err=G.BuildGuide(dungeonId,questId)
 if not g then G.Print(err);return false,err end
 G.db.guide=g
 G.guideFeedback=nil
 G.db.manualProgress={}
 G.ReconcileGuide()
 G.db.hudHidden=false
 if g.index<=#g.steps then G.ActivateGuideStep(false) end
 if G.ShowUI then G.ShowUI(false) end
 G.Print((questId and "선택 퀘스트" or "던전 전체").." 준비 가이드 시작: "..G.GetDungeon(dungeonId).name.." ("..#g.steps.."단계)")
 G.NotifyDataChange()
 return true
end
function G.StopGuide()
 G.guideFeedback=nil
 G.db.guide={}
 if G.ClearWaypoint then G.ClearWaypoint() end
 G.NotifyDataChange()
end
function G.CurrentStep()
 local g=guide();if not g or not g.steps then return nil end
 return g.steps[g.index or 1]
end
function G.GuideProgress()
 local g=guide()
 if not g or not g.steps or #g.steps==0 then return 0,0 end
 return math.min(g.index-1,#g.steps),#g.steps
end

-- Any checked quest participates in one shared dependency-aware live plan.
-- V1.3 optimizes the whole sequence with RouteOptimizer.lua. It compares
-- coordinate-based travel costs, never claims walkable terrain shortest paths.
local function playerLocation()
 local map=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
 if not map then return nil end
 local pos=G.SafeCall(C_Map and C_Map.GetPlayerMapPosition,map,"player")
 if type(pos)=="table" or type(pos)=="userdata" then
  local ok,x,y=pcall(function() return pos.x,pos.y end)
  if not ok then x,y=nil,nil end
  if (not x or not y) and type(pos.GetXY)=="function" then
   x,y=G.SafeCall(pos.GetXY,pos)
  end
  if type(x)=="number" and type(y)=="number" and x>=0 and x<=1 and y>=0 and y<=1 then
   return {map=map,x=x,y=y}
  end
 end
 return {map=map,approx=true}
end
G.PlayerLocation=playerLocation

local function addQuestTasks(tasks,byKey,id,requiredBy)
 local steps={}
 local active=G.IsInLog(id)
 local ready=G.IsReadyToTurnIn(id)
 if not active then stage(steps,id,"accept","퀘스트를 수락합니다.",requiredBy) end
 local special=G.specialQuestMeta and G.specialQuestMeta[id]
 if not ready and not (special and special.directTurnin) then
  stage(steps,id,"objective","퀘스트 목표를 진행합니다.",requiredBy)
 end
 stage(steps,id,"turnin","퀘스트를 보고합니다.",requiredBy)
 local last=nil
 local objectiveKeys={}
 local occurrence={}
 for _,step in ipairs(steps) do
  local baseKey="selected:"..id..":"..step.kind..":"..tostring(step.objectiveKind or "-")..":"..tostring(step.objectiveId or 0)
  occurrence[baseKey]=(occurrence[baseKey] or 0)+1
  step.key=baseKey..":"..occurrence[baseKey]
  step.dependencies={}
  -- Multiple objectives can run in any order after acceptance, and reporting
  -- requires every objective instead of just the last rendered row.
  if step.kind=="objective" then
   if last and string.find(last,":accept:",1,true) then step.dependencies[#step.dependencies+1]=last end
   objectiveKeys[#objectiveKeys+1]=step.key
  elseif step.kind=="turnin" then
   if #objectiveKeys>0 then
    for _,key in ipairs(objectiveKeys) do step.dependencies[#step.dependencies+1]=key end
   elseif last then step.dependencies[#step.dependencies+1]=last end
  end
  step.prerequisiteFor=requiredBy
  tasks[#tasks+1]=step
  byKey[step.key]=step
  if step.kind=="accept" then last=step.key end
 end
 local first=nil
 for _,step in ipairs(steps) do if step.kind=="accept" or step.kind=="objective" or step.kind=="turnin" then first=step;break end end
 local final=steps[#steps]
 return first,final
end
-- Global optimization is implemented in RouteOptimizer.lua.
-- All selected quest tasks share one dependency graph and one route.
function G.BuildSelectedGuide(turninOnly)
 if not G.Ready() then return nil,"QuestieDB 연결이 필요합니다." end
 if G.RefreshRouteEvidence then G.RefreshRouteEvidence() end
 local chosen=G.SelectedQuestIds()
 if #chosen==0 then return nil,"퀘스트 목록에서 먼저 체크해 주세요." end
 local warnings={}
 if #chosen>60 then return nil,"체크된 퀘스트가 너무 많습니다. 한 번에 60개까지 묶을 수 있습니다." end
 local expanded,needed,requiredBy,blocked={}, {},{},{}
 local deferred=G.db and G.db.deferredQuests or {}
 local function collect(id,parent,stack,depth)
  if depth>24 or stack[id] then
   warnings[#warnings+1]="선행 퀘스트 순환/깊이 제한: #"..id;return
  end
  if G.IsRouteSatisfied(id) then return end
  if deferred[id] then blocked[id]=true;return end
  if not G.DBGet(QuestDB,id,"name") then
   warnings[#warnings+1]="QuestieDB에 없는 퀘스트: #"..id;return
  end
  -- A blocked ancestor must not be recreated when another selected child
  -- refers to the same already-expanded dependency.
  if blocked[id] or expanded[id] then return end
  if parent and parent~=id then requiredBy[id]=true end
  needed[id]=needed[id] or {}
  stack[id]=true
  if not G.IsInLog(id) then
   for _,pre in ipairs(G.GetMissingPrereqs(id)) do
    if G.IsEligibleQuest(pre) and not G.IsRouteSatisfied(pre) then
     needed[id][pre]=true
     collect(pre,id,stack,depth+1)
     if blocked[pre] then blocked[id]=true end
    else
     if G.RouteExclusionReason(pre) and not G.IsRoutePrereqSatisfied(pre) then blocked[id]=true end
     warnings[#warnings+1]="선행 제한 또는 완료 여부 확인: #"..tostring(pre)
    end
   end
  end
  stack[id]=nil;expanded[id]=true
  if blocked[id] then needed[id]=nil end
 end
 for _,id in ipairs(chosen) do
  if turninOnly then
   if G.IsReadyToTurnIn(id) and not G.IsCompleted(id) and not deferred[id] then needed[id]={} end
  elseif G.IsInLog(id) or G.IsEligibleQuest(id) then collect(id,nil,{},0)
  else warnings[#warnings+1]="현재 진영/직업에 맞지 않는 퀘스트: #"..id end
 end
 local tasks,byKey,firstById,lastById={}, {},{},{}
 local ids={}
 for id in pairs(needed) do ids[#ids+1]=id end
 table.sort(ids)
 for _,id in ipairs(ids) do
  local first,last=addQuestTasks(tasks,byKey,id,requiredBy[id])
  firstById[id]=first;lastById[id]=last
 end
 -- The first step of a non-accepted quest is gated by every still-missing
 -- prerequisite's turn-in, even when the nearest-neighbour solver reorders zones.
 for id,parents in pairs(needed) do
  local first=firstById[id]
  if first and not G.IsInLog(id) then
   for pre in pairs(parents) do
    local last=lastById[pre]
    if last and last.key~=first.key then
     first.dependencies[#first.dependencies+1]=last.key
    end
   end
  end
 end
 local start=playerLocation()
 if #tasks>200 then return nil,"선택된 퀘스트의 방문 단계가 200개를 초과합니다. 체크 개수를 줄여 동선을 다시 생성하세요." end
 if #tasks==0 then
  if next(blocked) or next(deferred) then
   return nil,"선택된 퀘스트가 보류 중이거나 보류된 선행 퀘스트에 묶여 있습니다. /fdq resume all 로 복귀하세요."
  end
  return nil,turninOnly and "체크한 퀘스트 중 현재 보고 가능한 퀘스트가 없습니다." or "체크된 퀘스트가 모두 보고되었거나 후속 진행으로 동선 제외되었습니다. (실제 완료 여부는 별도)"
 end
 local steps,optimization=G.OptimizeQuestTasks(tasks,byKey,start)
 if not steps then return nil,(optimization and optimization.error) or "선행 관계 오류로 통합 동선을 만들 수 없습니다." end
 if #steps==0 then
  return nil,turninOnly and "체크한 보고 대기 단계가 모두 처리되었습니다." or "체크한 퀘스트의 남은 단계가 없습니다."
 end
 for _,step in ipairs(steps) do
  if not step.point and not step.indoor and not step.landmark and not step.regionHint then
   warnings[#warnings+1]=step.questName.."의 "..step.kind.." 위치 데이터가 확인되지 않았습니다."
  end
 end
 return {mode="selected",turninOnly=turninOnly==true,steps=steps,index=1,warnings=warnings,
   optimization=optimization,generatedAt=GetTime and GetTime() or 0},nil
end
function G.StartSelectedGuide(turninOnly)
 if not G.db then return false end
 -- Read current quest state before building; Questie can update the log lazily.
 if G.RefreshQuestLog then G.RefreshQuestLog() end
 -- A NEW route must never inherit manually skipped tasks from a former run.
 local previousManual=G.db.manualProgress
 G.db.manualProgress={}
 local g,err=G.BuildSelectedGuide(turninOnly)
 if not g then
  G.db.manualProgress=previousManual
  G.Print(err);return false,err
 end
 G.db.guide=g
 G.guideFeedback=nil
 -- The user walks in the world, NOT inside the world map. Keep the map optional.
 G.db.hudHidden=false
 G.ReconcileGuide()
 if g.index<=#g.steps then G.ActivateGuideStep(false) end
 G.Print("체크한 퀘스트 "..G.SelectedCount().."개 전체 · "..(turninOnly and "보고 NPC" or "수락/수행/보고").." 동선 "..#g.steps.."단계 (좌표 기준)")
 G.NotifyDataChange()
 if G.ShowUI then G.ShowUI(false) end
 return true
end
function G.StartTurninGuide()
 return G.StartSelectedGuide(true)
end
function G.ReplanSelectedGuide(reason)
 local prev=G.db and G.db.guide
 if not prev or prev.mode~="selected" then return false end
 if G.SelectedCount()==0 then G.StopGuide();return false end
 local old=prev.steps and prev.steps[prev.index or 1]
 local oldKey=old and old.key
 local history={}
 local oldIndex=prev.index or 1
 for i,st in ipairs(prev.steps or {}) do
  if i<oldIndex or (i==oldIndex and G.StepIsDone(st,i) and not (st.quest and G.RouteExclusionReason(st.quest) and not G.IsCompleted(st.quest))) then history[#history+1]=st end
 end
 local nextGuide,err=G.BuildSelectedGuide(prev.turninOnly)
 if not nextGuide then
   if err and (string.find(err,"보류 중",1,true) or string.find(err,"보고 가능한",1,true) or string.find(err,"모두 보고",1,true)
     or string.find(err,"모두 처리",1,true) or string.find(err,"남은 단계가 없습니다",1,true)) then
   -- All turn-ins have been reported: do not route back to an old NPC.
   prev.steps=history;prev.index=#history+1;prev.completed=true
   prev.deferredOnly=err and string.find(err,"보류 중",1,true)~=nil
   if G.ClearWaypoint then G.ClearWaypoint() end
   G.navStatus=(err and string.find(err,"보류 중",1,true)) and
       "남은 체크 퀘스트가 보류 중입니다. /fdq resume all 로 재개할 수 있습니다." or
       (prev.turninOnly and "체크한 보고 대기 퀘스트가 모두 처리되었습니다." or "선택한 퀘스트의 남은 동선이 없습니다.")
   G.NotifyDataChange()
  else
   -- Transient DB outage: preserve progress without silently deleting it.
   G.navStatus=err or "재계산 자료 확인 필요"
  end
  return false
 end
 if nextGuide.steps[1] and nextGuide.steps[1].key~=oldKey then G.guideFeedback=nil end
 local activeIndex=#history+1
 for _,st in ipairs(nextGuide.steps) do history[#history+1]=st end
 for k,v in pairs(nextGuide) do if k~="steps" and k~="index" then prev[k]=v end end
 prev.steps=history;prev.index=activeIndex;prev.completed=nil;prev.deferredOnly=nil
 G.ReconcileGuide()
 local current=G.CurrentStep()
 if current then
  if current.key~=oldKey or (old and current.point and old.point and
   (current.point.map~=old.point.map or current.point.x~=old.point.x or current.point.y~=old.point.y)) then
   G.ActivateGuideStep(false)
  elseif G.IsGuideJourneyActive and not G.IsGuideJourneyActive() and
         (reason=="퀘스트 상태 변경" or reason=="퀘스트 완료 상태 갱신") then
   -- Reclaim once when the client updated the quest; other changes stay user-owned.
   if G.ScheduleQuestJourneyRepair then G.ScheduleQuestJourneyRepair() end
  end
 end
 if G.RefreshMapPins then G.RefreshMapPins() end
 if G.HUDRefresh then G.HUDRefresh() end
 if G.PlanRefresh then G.PlanRefresh() end
 if G.UIRefresh then G.UIRefresh() end
 return true
end
-- Manual completion uses stable task identities: route reordering must not
-- replay a step the user explicitly marked finished.
function G.ManualStepKey(g,step,index)
 if step and step.key then return step.key end
 local p=step and step.point
 return tostring(g and g.dungeon or "none")..":"..tostring(g and g.focus or "all")..":"..
  tostring(step and step.kind or "step")..":"..tostring(step and step.serial or index)..":"..
  tostring(p and p.map or 0)
end
function G.StepIsDone(step,idx)
 local g=guide()
 if not step then return false end
 if not step.quest then
  if step.kind=="entrance" and g and g.dungeon and G.IsInGuideDungeon and G.IsInGuideDungeon(g.dungeon) then return true end
  local legacy=tostring(g and g.dungeon or "none")..":"..tostring(g and g.focus or "all")..":"..tostring(step.serial or idx)
  return G.db.manualProgress[G.ManualStepKey(g,step,idx)]==true or G.db.manualProgress[legacy]==true
 end
 if G.IsRouteSatisfied(step.quest) then return true end
 if step.kind=="accept" then return G.IsInLog(step.quest) end
 if step.kind=="objective" or step.kind=="inside" then
  if G.IsReadyToTurnIn(step.quest) then return true end
  if step.objectiveKind=="item" and G.IsInLog(step.quest) then
   local required=({[4083]={[791]=2,[3577]=20,[6037]=10},[4201]={[8846]=4,[11405]=10,[11413]=1}})[step.quest]
   local count=required and required[step.objectiveId]
   local owned=count and G.SafeCall(C_Item and C_Item.GetItemCount or GetItemCount,step.objectiveId,false)
   if type(owned)=="number" and owned>=count then return true end
  end
  return false
 end
 return false
end
function G.NextGuide(delta,manual)
 local g=guide()
 if not g or not g.steps or #g.steps==0 then return false end
 local index=g.index or 1
 local viewed=G.GuideReviewIndex()
 if delta<0 then return G.SelectGuideStep(math.max(1,(viewed or index)-1)) end
 if viewed then return G.ReturnToActiveGuide() end
 local current=g.steps[index]
 G.guideFeedback=nil
 if manual and delta>0 and current then
  -- Query the live quest log before refusing a click; never require a new
  -- quest to appear when a verified descendant already made it unavailable.
  if G.RefreshQuestLog then G.RefreshQuestLog() end
  if G.HydrateGuideLocations then G.HydrateGuideLocations() end
  local reason=current.quest and G.RouteExclusionReason(current.quest)
  G.ReconcileGuide()
  if G.CurrentStep()~=current or g.index~=index then
   if reason then G.Print("[동선 제외] "..G.GetQuestName(current.quest).." · "..reason) end
   if g.mode=="selected" then G.ReplanSelectedGuide("수동 상태 확인") end
   G.NotifyDataChange();return true
  end
  if current.quest and not G.StepIsDone(current,index) then
   local why=current.kind=="accept" and "아직 수락 상태가 확인되지 않았습니다." or
    current.kind=="turnin" and "아직 퀘스트 보고가 확인되지 않았습니다." or "아직 목표 완료가 확인되지 않았습니다."
   G.guideFeedback=why.." 이동을 건너뛰려면 [나중에]를 누르세요."
   G.Print(G.guideFeedback)
   if G.HUDRefresh then G.HUDRefresh() end
   if G.UIRefresh then G.UIRefresh() end
   return false
  end
  if not current.quest then G.db.manualProgress[G.ManualStepKey(g,current,index)]=true end
 end
 g.index=math.max(1,math.min(#g.steps+1,index+delta))
 if g.mode=="selected" and delta>0 then G.ReplanSelectedGuide("수동 진행")
 else
  if delta>0 then G.ReconcileGuide() end
  G.ActivateGuideStep(false)
  G.NotifyDataChange()
 end
 return true
end

-- Defer an entire quest without lying about its completion. Dependent chains
-- also pause until the prerequisite resumes or is rewarded in game.
function G.DeferCurrentQuest()
 local g=G.db and G.db.guide
 if not g or type(g.steps)~="table" then
  G.Print("진행 중인 동선이 없습니다. 퀘스트를 체크하고 동선을 시작하세요.")
  return false
 end
 if G.GuideViewingHistory() then G.Print("기록 보기 중입니다. 현재 진행 단계로 돌아간 뒤 보류하세요.");return false end
 local step=G.CurrentStep()
 if not step or not step.quest then
  G.Print("이 단계는 퀘스트가 아닌 이동 단계입니다. 완료 확인 후 다음으로 진행하세요.")
  return false
 end
 G.guideFeedback=nil
 G.db.deferredQuests=G.db.deferredQuests or {}
 G.db.deferredQuests[step.quest]=true
 local name=G.GetQuestName(step.quest)
 if g.mode=="selected" then
  G.ReplanSelectedGuide("퀘스트 보류")
 else
  -- Dungeon plans have fixed prepared stages rather than the selected route's
  -- task graph. Filter this quest and its dependent stages IN PLACE, preserving
  -- already-visited steps. A fresh plan on resume is built from real flags.
  local blocked={[step.quest]=true}
  local changed=true
  while changed do
   changed=false
   for _,st in ipairs(g.steps) do
    local id=st.quest
    if id and not blocked[id] and not G.IsInLog(id) then
     for _,pre in ipairs(G.GetMissingPrereqs(id)) do
      if blocked[pre] then blocked[id]=true;changed=true;break end
     end
    end
   end
  end
  local steps,nextIndex={},1
  for ix,st in ipairs(g.steps) do
   if not st.quest or not blocked[st.quest] then
    steps[#steps+1]=st
    if ix<(g.index or 1) then nextIndex=nextIndex+1 end
   end
  end
  g.steps=steps;g.index=math.min(nextIndex,#steps+1)
  G.ReconcileGuide()
  if g.steps[g.index] then G.ActivateGuideStep(false)
  elseif G.ClearWaypoint then G.ClearWaypoint() end
 end
 G.Print("[보류] "..name.." · 실제 퀘스트 완료 상태는 변경하지 않았습니다. 복귀: /fdq resume "..step.quest)
 G.NotifyDataChange()
 return true
end
function G.ResumeDeferredQuests(id)
 if not G.db then return false end
 G.db.deferredQuests=G.db.deferredQuests or {}
 if id and id~="all" then
  id=tonumber(id)
  if not id or not G.db.deferredQuests[id] then G.Print("해당 퀘스트는 보류 중이 아닙니다.");return false end
  G.db.deferredQuests[id]=nil
 else
  G.db.deferredQuests={}
 end
 if G.db.guide and G.db.guide.mode=="selected" then
  if not G.db.guide.steps or #G.db.guide.steps==0 then
   G.StartSelectedGuide(G.db.guide.turninOnly)
  else
   G.ReplanSelectedGuide("퀘스트 보류 해제")
  end
 elseif G.db.guide and G.db.guide.dungeon then
  local old=G.db.guide
  local rebuilt,err=G.BuildGuide(old.dungeon,old.focus)
  if rebuilt then
   G.db.guide=rebuilt;G.ReconcileGuide()
   if rebuilt.steps[rebuilt.index] then G.ActivateGuideStep(false) end
  else
   G.Print(err or "던전 가이드 재계산 실패")
  end
 end
 G.Print("보류 해제 완료. 체크한 퀘스트의 실제 상태로 동선을 다시 계산합니다.")
 G.NotifyDataChange()
 return true
end

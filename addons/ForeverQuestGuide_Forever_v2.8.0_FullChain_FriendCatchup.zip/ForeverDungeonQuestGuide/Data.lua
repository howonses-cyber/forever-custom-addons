local addon, G = ...
-- Dungeon -> quest ID indices are lightweight references, not a bundled copy of QuestieDB.
-- Quest titles, starter/finisher locations, prerequisite graphs are read from the user's
-- installed Forever QuestieDB at runtime. New Forever instances are shown honestly as
-- unverified until authoritative quest mappings are available.
local defs = {
 -- id, Korean display name, English search, UIMap ID, entrance X/Y (percent), zoneOrSort ID, quest IDs, level range
 {"rfc", "성난불길 협곡", "Ragefire Chasm RFC", 1454, 52.8, 49.0, 2437, "5722 5723 5724 5725 5728 5761", "13-18", "호드"},
 {"wailing", "통곡의 동굴", "Wailing Caverns WC", 1413, 46.0, 36.5, 718, "914 959 962 1486 1487 1489 1490 1491 6981", "17-25"},
 {"deadmines", "죽음의 폐광", "Deadmines DM", 1436, 42.5, 71.7, 1581, "166 167 168 214 2040", "17-26", "얼라이언스"},
 {"sfk", "그림자송곳니 성채", "Shadowfang Keep SFK", 1421, 44.8, 67.8, 209, "1013 1014 1098", "20-30"},
 {"bfd", "검은심연 나락", "Blackfathom Deeps BFD", 1440, 14.5, 14.2, 719, "971 1198 1199 1200 1275 6561 6562 6563 6564 6565 6921", "22-32"},
 {"stockades", "스톰윈드 지하감옥", "The Stockade Stockades", 1453, 52.4, 70.0, 717, "377 378 386 387 388 391", "23-29", "얼라이언스"},
 {"gnomer", "놈리건", "Gnomeregan", 1426, 24.3, 39.8, 133, "2841 2842 2843 2904 2922 2923 2924 2925 2926 2927 2928 2929 2930 2931 2945 2947 2949 2951 2952 2953 2962 4601 4602 4603 4604 4605 4606", "25-38"},
 {"rfk", "가시덩굴 우리", "Razorfen Kraul RFK", 1413, 42.9, 90.2, 1717, "1101 1102 1109 1142 1144 1221", "24-40"},
 {"sm", "붉은십자군 수도원", "Scarlet Monastery SM", 1420, 82.6, 33.8, 796, "1048 1049 1050 1051 1053 1113 1160", "30-45"},
 {"rfd", "가시덩굴 구릉", "Razorfen Downs RFD", 1413, 49.0, 93.9, 722, "3341 3523 3525 3636 6521 6522 6626", "37-46"},
 {"uldaman", "울다만", "Uldaman", 1418, 44.6, 12.1, 1517, "17 704 709 721 722 1139 1360 2198 2199 2200 2201 2202 2204 2240 2278 2279 2280 2283 2284 2318 2338 2339 2340 2341 2342 2361 2398 2418 3375", "41-51"},
 {"zf", "줄파락", "Zul'Farrak ZF", 1446, 38.7, 20.1, 978, "2768 2770 2846 2861 2864 2865 2936 2991 3042 3527", "44-54"},
 {"mara", "마라우돈", "Maraudon", 1443, 29.1, 62.5, 2100, "7028 7029 7041 7044 7046 7064 7065 7066 7067 7068 7070", "46-55"},
 {"sunken", "아탈학카르 신전", "Sunken Temple Temple of Atal'Hakkar 가라앉은 사원 학카르 아탈", 1435, 69.9, 53.5, 1417,
   "1445 1446 1475 3373 3380 3446 3447 3528 4143 4146 8733 8413", "50-56"},
 {"brd", "검은바위 나락", "Blackrock Depths BRD", 1428, 29.4, 38.3, 1584,
  "3801 3802 3907 3981 3982 4001 4002 4003 4004 4024 4063 4081 4082 4083 4121 4122 4123 4126 4128 4132 4133 4134 4136 4201 4241 4242 4263 4264 4282 4286 4295 4322 4324 4341 4342 4361 4362 4363 7201 7604 9015", "52-60"},
 {"brs", "검은바위 첨탑", "Blackrock Spire LBRS UBRS", 1428, 29.4, 38.3, 1583,
  "4701 4724 4729 4734 4735 4742 4743 4764 4765 4766 4768 4769 4788 4862 4866 4867 4903 4907 4974 4981 4982 4983 5001 5002 5047 5081 5089 5102 5127 5160 6502 6569 6602 7761 8966 8989 8995", "55-60"},
 {"dm", "혈투의 전장", "Dire Maul", 1444, 59.2, 45.1, 2557,
  "1193 1318 5518 5519 5525 5528 7429 7441 7461 7462 7463 7481 7482 7483 7484 7485 7488 7489 7492 7494 7498 7499 7500 7501 7502 7503 7504 7505 7506 7507 7508 7703 7877 8948 8949 8950 8967 8990", "54-60"},
 {"strat", "스트라솔름", "Stratholme", 1423, 26.5, 10.4, 2017,
  "5122 5125 5212 5213 5214 5243 5251 5262 5263 5282 5463 5848 6163 8945 8968 8991", "55-60"},
 {"scholo", "스칼로맨스", "Scholomance", 1422, 69.7, 73.2, 2057,
  "4771 5341 5343 5382 5384 5466 5515 5529 5531 5582 8969 8992", "57-60"},
 -- Names: LibBabble-SubZone-3.0 12.1-release4 (client-derived koKR).
 -- Forever-original quest mappings remain unverified; names do not imply mapped quests.
 {"thanes", "영주의 전당", "Ironforge Hall of Thanes", nil,nil,nil,nil,"","13-18",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"lordaeron", "로데론의 폐허", "Ruins of Lordaeron", nil,nil,nil,nil,"","15-22",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"wetlands", "발굴 현장: 저습지", "Wetlands Excavation Site", nil,nil,nil,nil,"","24-31",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
 {"dalaran", "달라란", "City of Dalaran", nil,nil,nil,nil,"","28-35",nil,"포에버 신규 던전: 퀘스트 매핑 미검증"},
}
G.dungeons={}
G.dungeonById={}
for _,v in ipairs(defs) do
 local row={id=v[1],name=v[2],aliases=v[3],entrance=(v[4] and {map=v[4],x=v[5]/100,y=v[6]/100,name=v[2].." 던전 부근"} or nil),area=v[7],ids={},level=v[9],onlyFaction=v[10],warning=v[11]}
 for q in string.gmatch(v[8],"%d+") do row.ids[#row.ids+1]=tonumber(q) end
 G.dungeons[#G.dungeons+1]=row; G.dungeonById[row.id]=row
end
-- Authoritative Korean spellings sourced from localized Forever quest records.
G.koQuestNames={
 [4262]="멸망의 파이론",[4263]="인센디우스!",
 [4324]="유카 스크류스피곳",[4136]="리블리 스크류스피곳",
 [1448]="신전을 찾아서",[1449]="동부 내륙지로",[1450]="그리핀 조련사 탈론액스",[1451]="랩소디 신디거",[1452]="랩소디의 칼림도어 칵테일",[1469]="랩소디의 이야기",[1475]="아탈학카르 신전으로",
 [1445]="아탈학카르 신전",[1446]="예언자 잠말란",[3373]="에라니쿠스의 정수",[3380]="가라앉은 사원",[3446]="심연의 늪",[3447]="돌무리의 비밀",[3528]="학카르의 화신",[4143]="악의 아지랑이",[4146]="구제장치 연료",
}
-- Exact outdoor locations only when grounded. Other quests use the live DB spawn positions.
G.pickupOverrides={
 [4324]={map=1446,x=.670,y=.240,name="요르바 스크류스피곳"},
 [4136]={map=1428,x=.660,y=.220,name="유카 스크류스피곳"},
 [4262]={map=1428,x=.854,y=.701,name="잘린다 스프리그"},
 [4263]={map=1428,x=.854,y=.701,name="잘린다 스프리그"},
 [1448]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},[1449]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},[1475]={map=1453,x=.643,y=.208,name="브로한 캐스크벨리"},
 [1446]={map=1425,x=.338,y=.752,name="추방된 아탈라이트롤"},[1445]={map=1435,x=.479,y=.548,name="펠제룰"},
 [3446]={map=1446,x=.526,y=.458,name="마본 리벳시커"},[3447]={map=1446,x=.526,y=.458,name="마본 리벳시커"},
 [3520]={map=1446,x=.670,y=.220,name="예킨야"},[3528]={map=1446,x=.670,y=.220,name="예킨야"},
 [4143]={map=1444,x=.450,y=.250,name="그레간 브루스퓨"},[4146]={map=1413,x=.620,y=.380,name="리브 리즐픽스"},
 [8413]={map=1416,x=.805,y=.669,name="바스라 윈드워처"},
}
-- Verified hand-in point for the Alliance Jalinda Sprig chain.
-- Separate the turn-in from a kill target with no navigable interior map.
G.turninOverrides={
 [4324]={map=1428,x=.660,y=.220,name="유카 스크류스피곳"},
 [4136]={map=1428,x=.660,y=.220,name="유카 스크류스피곳"},
 [4262]={map=1428,x=.854,y=.701,name="잘린다 스프리그"},
 [4263]={map=1428,x=.854,y=.701,name="잘린다 스프리그"},
}
-- The referral cannot be picked up when Ribbly is active or rewarded.
-- https://questing.wiki/wow-forever/quests/4324/ (pickup restrictions)
-- https://www.wowhead.com/forever/quest=4324/yuka-screwspigot (chain)
G.routePickupBlockers={[4324]={4136}}
-- A landmark describes an area, not an exact target position or waypoint.
G.knownQuestZones={
 [25]="검은바위 산",
}
-- This supplement is necessary because some class quests use a class sort rather
-- than the dungeon zone and thus are absent from simple instance-area lookups.
G.specialQuestMeta={
 -- NPC 9026 is in Blackrock Mountain's pre-instance corridor; do NOT enter
 -- the BRD portal to kill it. Sources: Forever QuestieDB quest 4262 and
 -- Wowhead Forever Blackrock Depths guide (checked 2026-11-24).
 [4262]={stageLandmarks={objective={zone="검은바위 산",continent="동부 왕국",
   site="검은바위 나락 차원문 직전 회랑",target="멸망의 파이론",
   instruction="검은바위 산 내부의 쇠사슬을 따라 아래로 내려간 뒤, 검은바위 나락 입장 차원문 앞 통로에서 멸망의 파이론을 처치하세요. 던전 차원문 안으로 들어갈 필요는 없습니다.",
   note="실내 순찰 구간입니다. 야외 지도 좌표를 파이론의 정확한 위치로 표시하지 않습니다."}}},
 [4263]={stageLandmarks={objective={zone="검은바위 나락",continent="동부 왕국",
   site="던전 내부 검은 모루 부근",target="불의군주 인센디우스",
   instruction="검은바위 나락 던전에 입장해 검은 모루 부근의 불의군주 인센디우스를 처치하세요.",
   note="실제 던전 내부 보스 위치는 별도 던전 지도에서 확인하세요."}}},
 -- Source: Wowhead Forever quest 4341/4342/4361, QuestieDB finisher NPC 9021.
 -- Instance NPCs can have sentinel spawns rather than outdoor x/y. Do not fake
 -- an interior coordinate or treat the entrance as the hand-in itself.
 [4341]={insideStages={turnin={dungeon="brd",npcId=9021,npcName="카란 마이트해머",room="감금 구역",followup=4342}},directTurnin=true},
 [4342]={insideStages={accept={dungeon="brd",npcId=9021,npcName="카란 마이트해머",room="감금 구역"},
                       objective={dungeon="brd",npcId=9021,npcName="카란 마이트해머",room="감금 구역"},
                       turnin={dungeon="brd",npcId=9021,npcName="카란 마이트해머",room="감금 구역",followup=4361}}},
 [4361]={insideStages={accept={dungeon="brd",npcId=9021,npcName="카란 마이트해머",room="감금 구역"}}},
 [8413]={onlyFaction="Horde",classMask=64,note="주술사 50레벨 직업 연계(현재 공식 가이드: 호드 전용)."},
 [3373]={inside=true,note="던전 내부의 에라니쿠스가 떨어뜨리는 물건에서 시작."},
 [8733]={inside=true,note="추가 고레벨 연계, 레벨·진행 조건 확인 필요."},
}

-- v1.9.7: quest category IDs and navigation map IDs are different namespaces.
-- Names/aliases verified against Forever QuestieDB's ZoneDB support data.
-- Legacy dungeon aliases are ONLY catalog keys, never valid route destinations.
G.regionMapNames={
 [1411]="듀로타",[1412]="멀고어",[1413]="불모의 땅",[1414]="칼림도어",[1415]="동부 왕국",
 [1416]="알터랙 산맥",[1417]="아라시 고원",[1418]="황야의 땅",[1419]="저주받은 땅",[1420]="티리스팔 숲",
 [1421]="은빛소나무 숲",[1422]="서부 역병지대",[1423]="동부 역병지대",[1424]="힐스브래드 구릉지",[1425]="동부 내륙지",
 [1426]="던 모로",[1427]="이글거리는 협곡",[1428]="불타는 평원",[1429]="엘윈 숲",[1430]="죽음의 고개",
 [1431]="그늘숲",[1432]="모단 호수",[1433]="붉은마루 산맥",[1434]="가시덤불 골짜기",[1435]="슬픔의 늪",
 [1436]="서부 몰락지대",[1437]="저습지",[1438]="텔드랏실",[1439]="어둠해안",[1440]="잿빛 골짜기",
 [1441]="버섯구름 봉우리",[1442]="돌발톱 산맥",[1443]="잊혀진 땅",[1444]="페랄라스",[1445]="먼지진흙 습지대",
 [1446]="타나리스",[1447]="아즈샤라",[1448]="악령의 숲",[1449]="운고로 분화구",[1450]="달의 숲",
 [1451]="실리더스",[1452]="여명의 설원",[1453]="스톰윈드",[1454]="오그리마",[1455]="아이언포지",
 [1456]="썬더 블러프",[1457]="다르나서스",[1458]="언더시티",[1459]="알터랙 계곡",[1460]="전쟁노래 협곡",[1461]="아라시 분지",
}
G.regionOutdoorAreas={
 [1]=1426,[3]=1418,[4]=1419,[8]=1435,[9]=1429,[10]=1431,[11]=1437,[12]=1429,[14]=1411,[15]=1445,[16]=1447,[17]=1413,
 [24]=1429,[28]=1422,[33]=1434,[35]=1434,[36]=1416,[38]=1432,[40]=1436,[41]=1430,[44]=1433,[45]=1417,[46]=1428,[47]=1425,[51]=1427,
 [85]=1420,[130]=1421,[132]=1426,[139]=1423,[141]=1438,[148]=1439,[154]=1420,[188]=1438,[215]=1412,[220]=1412,[221]=1412,[267]=1424,
 [331]=1440,[357]=1444,[361]=1448,[363]=1411,[400]=1441,[405]=1443,[406]=1442,[440]=1446,[490]=1449,[493]=1450,[618]=1452,[702]=1438,
 [1116]=1444,[1377]=1451,[1497]=1458,[1519]=1453,[1537]=1455,[1637]=1454,[1638]=1456,[1657]=1457,[1769]=1448,[2079]=1445,
 [2597]=1459,[2839]=1459,[3277]=1460,[3358]=1461,
}
G.regionInstanceAreas={};G.regionInstanceKeys={}
local function regionInstance(key,name,kind,id,aliases,english)
 local r={key=key,name=name,kind=kind,dungeonId=id,aliases=english};G.regionInstanceKeys[key]=r
 for _,a in ipairs(aliases) do G.regionInstanceAreas[a]=r end
end
regionInstance(213,"성난불길 협곡","dungeon","rfc",{2437},"Ragefire Chasm")
regionInstance(279,"통곡의 동굴","dungeon","wailing",{718},"Wailing Caverns")
regionInstance(291,"죽음의 폐광","dungeon","deadmines",{1581,10029},"Deadmines")
regionInstance(310,"그림자송곳니 성채","dungeon","sfk",{209,10014,10015,10016,10017,10018,10019},"Shadowfang Keep")
regionInstance(221,"검은심연 나락","dungeon","bfd",{719,10020,10021},"Blackfathom Deeps")
regionInstance(225,"스톰윈드 지하감옥","dungeon","stockades",{717},"Stockade")
regionInstance(226,"놈리건","dungeon","gnomer",{133,721,10030,10031,10032},"Gnomeregan")
regionInstance(301,"가시덩굴 우리","dungeon","rfk",{491,1717},"Razorfen Kraul")
regionInstance(300,"가시덩굴 구릉","dungeon","rfd",{722},"Razorfen Downs")
regionInstance(302,"붉은십자군 수도원","dungeon","sm",{796,6109,6386,10008,10009,10010},"Scarlet Monastery")
regionInstance(230,"울다만","dungeon","uldaman",{1337,1517,10033},"Uldaman")
regionInstance(219,"줄파락","dungeon","zf",{1176,978},"Zul'Farrak")
regionInstance(280,"마라우돈","dungeon","mara",{2100,10000},"Maraudon")
regionInstance(220,"아탈학카르 신전","dungeon","sunken",{1417,1477},"Temple of Atal'Hakkar")
regionInstance(242,"검은바위 나락","dungeon","brd",{1584,1585},"Blackrock Depths")
regionInstance(253,"검은바위 첨탑","dungeon","brs",{1583,10003,10004,10005,10006,10007},"Blackrock Spire")
regionInstance(234,"혈투의 전장","dungeon","dm",{2557,10022,10023,10024,10025,10026,10027},"Dire Maul")
regionInstance(317,"스트라솔름","dungeon","strat",{2017,10001},"Stratholme")
regionInstance(306,"스칼로맨스","dungeon","scholo",{2057,10011,10012,10013},"Scholomance")
regionInstance(233,"줄구룹","raid",nil,{19,1977},"Zul'Gurub")
regionInstance(248,"오닉시아의 둥지","raid",nil,{2159},"Onyxia's Lair")
regionInstance(287,"검은날개 둥지","raid",nil,{2677},"Blackwing Lair")
regionInstance(232,"화산 심장부","raid",nil,{2717},"Molten Core")
regionInstance(320,"안퀴라즈 사원","raid",nil,{3428,10040,10041},"Temple of Ahn'Qiraj")
regionInstance(247,"안퀴라즈 폐허","raid",nil,{3429},"Ruins of Ahn'Qiraj")
regionInstance(166,"낙스라마스","raid",nil,{3456,10062,10063,10064,10065,10066},"Naxxramas")
G.regionMapNames[947]="아제로스"
for key,r in pairs(G.regionInstanceKeys) do G.regionMapNames[key]=r.name end
G.knownQuestZones[2257]="깊은굴 지하철"
G.knownQuestZones[25]="검은바위 산"
function G.IsInstanceArea(area) return G.regionInstanceAreas[tonumber(area)]~=nil end
function G.MapDisplayName(map)
 local info=G.SafeCall(C_Map and C_Map.GetMapInfo,map)
 local n=info and info.name
 local known=G.regionMapNames[tonumber(map)]
 -- C_Map uses UIMap IDs, not quest-zone/AreaTable IDs. Never cross those
 -- namespaces; an unknown map may be translated only by its exact name.
 if G.KoreanName then return G.KoreanName("zone",nil,n,known) end
 if known then return known end
 if type(n)=="string" and n~="" and not n:match("^%d+$") then return n end
end

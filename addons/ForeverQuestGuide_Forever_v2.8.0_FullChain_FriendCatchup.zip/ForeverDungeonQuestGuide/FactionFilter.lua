local addon,G=...
-- Browsing mode only. Actual quest acceptance and route planning always use
-- UnitFactionGroup(player) and the player's own race/class masks.
function G.FactionFilterMode()
 local mode=G.db and G.db.factionFilter or "auto"
 if mode=="auto" then return G.player.faction or "all" end
 return mode
end
function G.FactionFilterLabel()
 local mode=G.db and G.db.factionFilter or "auto"
 if mode=="auto" then
  return G.player.faction=="Alliance" and "자동(얼라)" or
     G.player.faction=="Horde" and "자동(호드)" or "자동(?)"
 end
 return ({Alliance="얼라이언스",Horde="호드",all="전체"})[mode] or "자동(?)"
end
function G.QuestMatchesFactionFilter(id)
 local mode=G.FactionFilterMode()
 if mode=="all" then return true end
 local qFaction=G.QuestFaction(id)
 if G.IsInLog and G.IsInLog(id) and mode==G.player.faction then return true end
 return qFaction=="Any" or qFaction=="Both" or qFaction==mode
end
function G.DungeonMatchesFactionFilter(d)
 if not d then return false end
 local mode=G.FactionFilterMode()
 local faction=G.NormalizeFaction(d.onlyFaction)
 return mode=="all" or not faction or faction==mode
end
function G.IsQuestBrowseVisible(id,options)
 if not G.QuestMatchesFactionFilter(id) then return false end
 -- Status counts use the same search/faction scope before presentation hiding.
 -- A direct status filter can then reveal completed or blocked quests without
 -- changing the user's saved browsing preferences or route eligibility.
 if type(options)=="table" and options.ignoreStateFilters then return true end
 if G.db and G.db.onlyIncomplete and G.IsCompleted(id) then return false end
 if G.db and G.db.hideUnavailable then
  if not G.IsClassAllowedQuest(id) then return false end
  -- The player can inspect the opposite faction without claiming that those
  -- quests are accepted or runnable on their own character.
  if G.FactionFilterMode()==G.player.faction then return G.IsEligibleQuest(id) end
 end
 return true
end
function G.QuestFactionTag(id)
 local faction=G.QuestFaction(id)
 if faction=="Alliance" then return "|cff8fbaff[얼라]|r " end
 if faction=="Horde" then return "|cffff9182[호드]|r " end
 if faction=="Unknown" then return "|cffb1b9bf[진영?]|r " end
 return ""
end

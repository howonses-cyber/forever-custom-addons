local addon,G=...
-- Shared, self-contained presentation. Native buttons retain input/disabled states.
G.UIColors={bg={.055,.067,.084,.98},panel={.082,.101,.125,.96},surface={.115,.142,.177,.95},line={.22,.27,.33,1},accent={.91,.72,.34,1},text={.91,.93,.95},muted={.65,.73,.79},green={.43,.84,.58},blue={.42,.77,.98}}
local function paint(parent,layer,c)
 local t=parent:CreateTexture(nil,layer);t:SetAllPoints(parent);t:SetColorTexture(unpack(c));return t
end
local palette={normal={.145,.181,.22,1},primary={.28,.35,.40,1},selected={.23,.36,.46,1},quiet={.10,.13,.16,1},danger={.32,.16,.17,1}}
function G.UIButton(parent,text,w,h,action,style)
 local b=CreateFrame("Button",nil,parent)
 b:SetSize(w,h)
 local n=paint(b,"BACKGROUND",palette[style] or palette.normal)
 local push=paint(b,"ARTWORK",{.08,.11,.14,.96})
 local hi=paint(b,"HIGHLIGHT",{.65,.79,.91,.16})
 local dis=paint(b,"ARTWORK",{.10,.12,.15,.95})
 b:SetNormalTexture(n);b:SetPushedTexture(push);b:SetHighlightTexture(hi);b:SetDisabledTexture(dis)
 b:SetNormalFontObject("GameFontHighlightSmall");b:SetHighlightFontObject("GameFontHighlightSmall");b:SetDisabledFontObject("GameFontDisableSmall")
 local f=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");f:SetPoint("LEFT",b,"LEFT",3,0);f:SetPoint("RIGHT",b,"RIGHT",-3,0);f:SetJustifyH("CENTER");f:SetJustifyV("MIDDLE")
 if f.SetWordWrap then f:SetWordWrap(false) end
 b:SetFontString(f);b:SetText(text)
 b._fdqNormal=n;b._fdqStyle=style or "normal"
 local line=b:CreateTexture(nil,"BORDER");line:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",0,0);line:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",0,0);line:SetHeight(1);line:SetColorTexture(.29,.35,.41,.9)
 b._fdqLine=line
 if action then b:SetScript("OnClick",action) end
 return b
end
function G.UIButtonState(b,active,style)
 if not b then return end
 local c=palette[active and "selected" or style or b._fdqStyle] or palette.normal
 if b._fdqNormal then b._fdqNormal:SetColorTexture(unpack(c)) end
 if b._fdqLine then if active then b._fdqLine:SetColorTexture(.48,.77,.91,1) else b._fdqLine:SetColorTexture(.29,.35,.41,.9) end end
end
function G.UIProgress(parent)
 local f=CreateFrame("Frame",nil,parent)
 local track=paint(f,"BACKGROUND",{.145,.183,.218,1})
 local bar=f:CreateTexture(nil,"ARTWORK");bar:SetPoint("TOPLEFT",f,"TOPLEFT",0,0);bar:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,0);bar:SetColorTexture(.42,.77,.91,1);bar:Hide()
 f.bar=bar;f.fraction=0
 function f:UpdateProgress()
  local width=(self:GetWidth() or 0)*self.fraction
  if width>0 then self.bar:SetWidth(math.max(1,width));self.bar:Show() else self.bar:Hide() end
 end
 function f:SetProgress(done,total)
  self.fraction=total and total>0 and math.max(0,math.min(1,(done or 0)/total)) or 0
  self:UpdateProgress()
 end
 f:SetScript("OnSizeChanged",function(self)self:UpdateProgress()end)
 return f
end
function G.UIFit(frame)
 -- Keep large dialogs usable on smaller UIParent dimensions; no saved UI scale change.
 if not frame or not UIParent or not frame.SetScale then return end
 local w,h=UIParent:GetWidth(),UIParent:GetHeight()
 local fw,fh=frame:GetWidth(),frame:GetHeight()
 if w and h and fw and fh and fw>0 and fh>0 then frame:SetScale(math.min(1,math.max(.55,math.min((w-20)/fw,(h-20)/fh)))) end
end

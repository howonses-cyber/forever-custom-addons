local addon, G = ...
-- V1.3: global, multi-quest route optimization. A step is one acceptance,
-- objective or hand-in *across every checked quest*, never a separate tour per
-- quest. Edges are optimistic straight-line estimates, NOT safe walkable paths.
local sqrt,abs,floor,min,max=math.sqrt,math.abs,math.floor,math.min,math.max
local function valid(p)
 return p and type(p.map)=="number" and type(p.x)=="number" and type(p.y)=="number"
  and p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local worldCache={}
local worldCacheSize=0
local function world(p)
 if not valid(p) then return nil end
 local key=string.format("%d:%.5f:%.5f",p.map,p.x,p.y)
 if worldCache[key]~=nil then return worldCache[key] or nil end
 local f=C_Map and C_Map.GetWorldPosFromMapPos
 if type(f)~="function" or type(CreateVector2D)~="function" then return nil end
 local ok,continent,vec=pcall(f,p.map,CreateVector2D(p.x,p.y))
 if ok and type(continent)=="number" and vec then
  local x,y
  local safe=pcall(function()
   if type(vec.GetXY)=="function" then x,y=vec:GetXY() else x,y=vec.x,vec.y end
  end)
  if safe and type(x)=="number" and type(y)=="number" then
   local data={continent=continent,x=x,y=y}
   worldCache[key]=data
   worldCacheSize=worldCacheSize+1
   if worldCacheSize>600 then worldCache={};worldCacheSize=0 end
   return data
  end
 end
 worldCache[key]=false
 worldCacheSize=worldCacheSize+1
 if worldCacheSize>600 then worldCache={};worldCacheSize=0 end
 return nil
end
local function straight(a,b)
 local dx,dy=a.x-b.x,a.y-b.y
 return sqrt(dx*dx+dy*dy)
end
function G.RouteLegInfo(a,b)
 if not a or not valid(b) then return 0,"시작 또는 좌표 미확인" end
 if not valid(a) then return 0,"현재 위치 확인 필요" end
 local aw,bw=world(a),world(b)
 if aw and bw and aw.continent==bw.continent then
  local distance=straight(aw,bw)
  return max(0,distance),"월드 좌표 직선거리",distance
 end
 if a.map==b.map then
  -- A common zone-map cannot provide its aspect ratio without world coords.
  -- The scaled normalized length is ONLY a relative ordering heuristic.
  return straight(a,b)*8000,"동일 지도 상대 거리",nil
 end
 -- Unknown transfer topology. High fixed penalty reduces unnecessary zone
 -- switching but does not invent a ferry/portal or an exact travel time.
 return 24000,"지역 간 실제 이동 수단 확인 필요",nil
end
function G.RouteDistanceLabel(position,target)
 if not valid(target) then return "목적지 좌표 미확인", "" end
 if not valid(position) then return "캐릭터 위치 확인 필요", "" end
 local direction=""
 if position.map==target.map then
  local dx=target.x-position.x
  local dy=position.y-target.y
  if abs(dx)+abs(dy)>0.001 then
   local ns=dy>0.012 and "북" or dy<-.012 and "남" or ""
   local ew=dx>0.012 and "동" or dx<-.012 and "서" or ""
   direction=ns..ew
  end
 end
 local _,mode,meters=G.RouteLegInfo(position,target)
 if meters then return string.format("직선 약 %.0f야드 (지형 미반영)",meters),direction end
 if position.map==target.map then
  return string.format("지도 직선 %.1f%% (실제 거리 아님)",straight(position,target)*100),direction
 end
 return "다른 지도 · 이동 방법 확인 필요",direction
end
local function makeMatrix(tasks,start)
 local n=#tasks
 local points={}
 for i=1,n do
  local st=tasks[i]
  points[i]=st.point or (st.indoor and st.indoor.entrance) or (st.landmark and st.landmark.approach)
 end
 local matrix,fromStart={},{}
 for i=1,n do
  matrix[i]={}
  local point=points[i]
  -- With a missing point, put its task near the end unless a prerequisite
  -- forces its earlier execution; no invented route segments.
  fromStart[i]=valid(point) and (valid(start) and select(1,G.RouteLegInfo(start,point)) or 0) or 90000
  for j=1,i-1 do
   local other=points[j]
   local cost=(valid(point) and valid(other)) and select(1,G.RouteLegInfo(point,other)) or 90000
   matrix[i][j]=cost;matrix[j][i]=cost
  end
  matrix[i][i]=0
 end
 return matrix,fromStart
end
local function dependencyGraph(tasks)
 local positions={}
 for i,task in ipairs(tasks) do positions[task.key]=i end
 local deps={}
 for i,task in ipairs(tasks) do
  deps[i]={}
  for _,key in ipairs(task.dependencies or {}) do
   local idx=positions[key]
   if idx and idx~=i then deps[i][#deps[i]+1]=idx end
  end
 end
 return deps
end
local function routeLength(order,matrix,fromStart)
 local cost,prior=0,nil
 for _,i in ipairs(order) do
  cost=cost+(prior and matrix[prior][i] or fromStart[i])
  prior=i
 end
 return cost
end
local function validOrder(order,deps)
 local seen={}
 for _,i in ipairs(order) do
  for _,prereq in ipairs(deps[i]) do if not seen[prereq] then return false end end
  seen[i]=true
 end
 return true
end
-- Held-Karp dynamic programming on all steps and prerequisites when small.
-- This is exact for the chosen coordinate-cost model (not exact travel time).
local function exactOrder(n,deps,matrix,fromStart)
 local powers={}
 for i=1,n do powers[i]=2^(i-1) end
 local function has(mask,i) return floor(mask/powers[i])%2==1 end
 local full=2^n-1
 local costs,parents={},{}
 costs[0]={[0]=0};parents[0]={}
 for mask=0,full-1 do
  local choices=costs[mask]
  if choices then
   for last,score in pairs(choices) do
    for i=1,n do
     if not has(mask,i) then
      local eligible=true
      for _,d in ipairs(deps[i]) do if not has(mask,d) then eligible=false;break end end
      if eligible then
       local nextMask=mask+powers[i]
       local value=score+(last==0 and fromStart[i] or matrix[last][i])
       costs[nextMask]=costs[nextMask] or {}
       parents[nextMask]=parents[nextMask] or {}
       if not costs[nextMask][i] or value<costs[nextMask][i]-0.000001 then
        costs[nextMask][i]=value;parents[nextMask][i]=last
       end
      end
     end
    end
   end
  end
 end
 local best,bestCost=nil,nil
 for i,value in pairs(costs[full] or {}) do
  if not bestCost or value<bestCost-0.000001 or (abs(value-bestCost)<0.000001 and i<best) then
   best,bestCost=i,value
  end
 end
 if not best then return nil,nil end
 local order,mask={},full
 while mask>0 do
  table.insert(order,1,best)
  local old=best
  best=parents[mask][old]
  mask=mask-powers[old]
 end
 return order,bestCost
end
-- Multiple candidate starts improve on a single nearest-neighbour walk.
local function greedyOrder(n,deps,matrix,fromStart,first)
 local seen,order={},{}
 local prior=nil
 for step=1,n do
  local choice,best
  for i=1,n do
   if not seen[i] then
    local allowed=true
    for _,d in ipairs(deps[i]) do if not seen[d] then allowed=false;break end end
    if allowed then
     local c=prior and matrix[prior][i] or fromStart[i]
     if step==1 and first and i~=first then c=c+100000000 end
     if not best or c<best-.000001 or (abs(c-best)<.000001 and i<choice) then
      best=c;choice=i
     end
    end
   end
  end
  if not choice then return nil end
  seen[choice]=true;order[#order+1]=choice;prior=choice
 end
 return order
end
local function improve(order,deps,matrix,fromStart,n)
 if not order then return nil,nil end
 local value=routeLength(order,matrix,fromStart)
 -- Do not run potentially expensive local search on huge quest batches.
 if n>125 then return order,value end
 for pass=1,(n>50 and 1 or n>28 and 2 or 3) do
  local improved=false
  -- Two-opt over ALL quests, respecting acceptance/objective/turn-in deps.
  for i=1,n-1 do
   for j=i+1,n do
    local before=i==1 and nil or order[i-1]
    local after=j==n and nil or order[j+1]
    local a,b=order[i],order[j]
    local old=(before and matrix[before][a] or fromStart[a])+(after and matrix[b][after] or 0)
    local new=(before and matrix[before][b] or fromStart[b])+(after and matrix[a][after] or 0)
    if new+0.000001<old then
     local x,y=i,j
     while x<y do order[x],order[y]=order[y],order[x];x=x+1;y=y-1 end
     if validOrder(order,deps) then
      value=value+new-old;improved=true
     else
      x,y=i,j
      while x<y do order[x],order[y]=order[y],order[x];x=x+1;y=y-1 end
     end
    end
   end
  end
  -- 1-point relocate catches opportunities that segment reversal cannot.
  -- Copying tiny lists is acceptable for the user-limited selected set.
  if n<=35 then
   for i=1,n do
    local bestCandidate,bestCost
    for j=1,n do
     if i~=j then
      local candidate={}
      for k=1,n do if k~=i then candidate[#candidate+1]=order[k] end end
      table.insert(candidate,j,order[i])
      if validOrder(candidate,deps) then
       local score=routeLength(candidate,matrix,fromStart)
       if score+0.000001<value and (not bestCost or score<bestCost) then
        bestCost,bestCandidate=score,candidate
       end
      end
     end
    end
    if bestCandidate then order=bestCandidate;value=bestCost;improved=true end
   end
  end
  if not improved then break end
 end
 return order,routeLength(order,matrix,fromStart)
end
function G.OptimizeQuestTasks(tasks,byKey,start)
 local active={}
 local omitted={}
 local manual=G.db and G.db.manualProgress or {}
 for _,task in ipairs(tasks) do
  if manual[task.key] then omitted[task.key]=true
  else active[#active+1]=task end
 end
 local n=#active
 if n==0 then return {},{method="empty",cost=0,known=0,total=0,approximate=false} end
 local dependencies=dependencyGraph(active)
 local matrix,firstLeg=makeMatrix(active,start)
 local order,score,method
 if n<=11 then
  order,score=exactOrder(n,dependencies,matrix,firstLeg)
  if order then method="exact-coordinate" end
 end
 if not order then
  -- Use several distinct eligible first tasks and refine each complete tour.
  local candidates={}
  for i=1,n do if #dependencies[i]==0 then candidates[#candidates+1]=i end end
  table.sort(candidates,function(a,b)
   if firstLeg[a]~=firstLeg[b] then return firstLeg[a]<firstLeg[b] end
   return active[a].key<active[b].key
  end)
  local samples=n>125 and 1 or n>50 and 2 or n>28 and 3 or 6
  for trial=0,min(samples,#candidates) do
   local candidate=greedyOrder(n,dependencies,matrix,firstLeg,trial==0 and nil or candidates[trial])
   if candidate then
    local improved,value=improve(candidate,dependencies,matrix,firstLeg,n)
    if improved and (not score or value<score) then order,score=improved,value end
   end
  end
  method="multi-start-2opt"
 end
 -- A bad imported dependency cycle must never freeze route creation. If it
 -- happens, return no route rather than silently violate the chain.
 if not order then return nil,{error="선행 관계가 순환합니다. 선택한 퀘스트의 선행 조건을 확인하세요."} end
 local result,known,maps={},0,{}
 for serial,i in ipairs(order) do
  local t=active[i]
  t.serial=serial
  result[#result+1]=t
  if valid(t.point) then known=known+1;maps[t.point.map]=true end
 end
 local areaCount=0;for _ in pairs(maps) do areaCount=areaCount+1 end
 return result,{method=method,cost=score or 0,known=known,total=n,maps=areaCount,
   approximate=(areaCount>1 or known<n),selectedQuestCount=G.SelectedCount and G.SelectedCount() or 0}
end

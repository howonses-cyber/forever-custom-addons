local addon,G=...
-- Only our guide's current/next marker. Questie, Blizzard and ShortestPath
-- markers belong to their owners; never hide, move, or reparent those widgets.
local pins={}
local painted=nil
local revision=0
local shown=0
local palette={
 accept={.25,.82,.96}, objective={.98,.77,.30},
 turnin={.42,.90,.50}, entrance={1,.56,.25}, inside={.69,.70,.75},
}
local function canvas()
 local frame=_G.WorldMapFrame
 if not frame or not frame.IsShown or not frame:IsShown() then return nil,nil end
 local id=frame.GetMapID and frame:GetMapID()
 local scroll=frame.ScrollContainer
 local child=scroll and (scroll.Child or (scroll.GetCanvas and scroll:GetCanvas()))
 if not child or type(child.GetWidth)~="function" or type(child.GetHeight)~="function" then return nil,nil end
 return child,id
end
local function hideOwnPins()
 if shown==0 then return end
 for i=1,shown do if pins[i] then pins[i]:Hide() end end
 shown=0
end
function G.InvalidateMapPins()
 revision=revision+1
 painted=nil
end
local function makePin(i,parent)
 local b=pins[i]
 if b then
  if b:GetParent()~=parent then b:SetParent(parent) end
  return b
 end
 b=CreateFrame("Button",nil,parent)
 b:SetSize(17,17)
 if b.SetFrameStrata then b:SetFrameStrata("HIGH") end
 local border=b:CreateTexture(nil,"BORDER")
 border:SetAllPoints();border:SetColorTexture(.03,.05,.08,.92)
 b.border=border
 local fill=b:CreateTexture(nil,"ARTWORK")
 fill:SetPoint("TOPLEFT",b,"TOPLEFT",2,-2)
 fill:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-2,2)
 b.fill=fill
 local txt=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
 txt:SetPoint("CENTER",0,0)
 b.text=txt
 b:SetScript("OnEnter",function(self)
  if GameTooltip then
   GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
   GameTooltip:SetText(self.title or "선택한 퀘스트 경유지")
   GameTooltip:AddLine(self.desc or "",.86,.86,.90,true)
   GameTooltip:AddLine("길찾기는 이동 안내에서 확인 · 지도 핀은 위치 참고",.65,.70,.75)
   GameTooltip:Show()
  end
 end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide() end end)
 b:SetScript("OnClick",function(self)
  if self.point and G.OpenPointMap then G.OpenPointMap(self.point) end
 end)
 pins[i]=b
 return b
end
function G.RefreshMapPins()
 local parent,mapId=canvas()
 local mode=G.db and G.db.mapPinMode or "auto"
 local guide=G.db and G.db.guide
 local external=mode=="auto" and G.IsGuideJourneyActive and G.IsGuideJourneyActive() or false
 if not parent or not mapId or mode=="off" or external or not guide or type(guide.steps)~="table" then
  hideOwnPins();painted=nil;return
 end
 local w,h=parent:GetWidth(),parent:GetHeight()
 if type(w)~="number" or type(h)~="number" or w<=0 or h<=0 then
  hideOwnPins();painted=nil;return
 end
 local ix=tonumber(guide.index) or 1
 if ix<1 then ix=1 end
 local step=guide.steps[ix]
 local second=mode=="next" and guide.steps[ix+1] or nil
 -- The OnUpdate safety poll is frequent, but a stable map/guide must not
 -- repeatedly erase and reposition icons (or cause visual flicker).
 if painted and painted.parent==parent and painted.mapId==mapId and
    painted.w==w and painted.h==h and painted.mode==mode and
    painted.guide==guide and painted.steps==guide.steps and
    painted.ix==ix and painted.first==step and painted.second==second and
    painted.revision==revision then return end
 hideOwnPins()
 painted={parent=parent,mapId=mapId,w=w,h=h,mode=mode,guide=guide,steps=guide.steps,
          ix=ix,first=step,second=second,revision=revision}
 local maxVisible=mode=="next" and 2 or 1
 local count=0
 for i=ix,math.min(#guide.steps,ix+maxVisible-1) do
  local nextStep=guide.steps[i]
  local blocked=nextStep and G.CurrentAcceptanceBlock and G.CurrentAcceptanceBlock(nextStep)
  if blocked then break end
  local point=nextStep and G.StepIsDone and not G.StepIsDone(nextStep,i) and
              G.GuideStepNavPoint and G.GuideStepNavPoint(nextStep)
  if point and point.map==mapId and type(point.x)=="number" and type(point.y)=="number" and
     point.x>=0 and point.x<=1 and point.y>=0 and point.y<=1 then
   count=count+1
   local b=makePin(count,parent)
   local active=i==ix
   b:SetSize(active and 19 or 14,active and 19 or 14)
   b:ClearAllPoints()
   b:SetPoint("CENTER",parent,"TOPLEFT",w*point.x,-h*point.y)
   local color=palette[nextStep.kind] or palette.objective
   b.fill:SetColorTexture(color[1],color[2],color[3],active and .95 or .68)
   b.text:SetText(active and "1" or "2")
   b.title=G.GuideStepNavTitle and G.GuideStepNavTitle(nextStep,point) or point.name or nextStep.title
   b.desc=(active and "현재 방문" or "다음 방문")..(point.approach and " · 접근 지점 (실제 목표 아님)" or "").." · "..
      (nextStep.questName or nextStep.title or "").." · "..string.format("%.1f, %.1f",100*point.x,100*point.y)
   if G.KoreanText then b.title=G.KoreanText(b.title);b.desc=G.KoreanText(b.desc) end
   b.point=point
   b:Show()
  end
 end
 shown=count
end

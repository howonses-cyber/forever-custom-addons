local addon,G=...
-- Opt-in, party-only status hints. Never broadcast completed history, objectives,
-- locations, routes, settings, or quest selections. Peer data is memory-only.
local PREFIX="FQGuideParty5" -- 13 ASCII characters (max 16).
local peers,parts={},{}
local registered=false
local sendQueue={}
local dirty=true
local counter=0
local clock=0
local lastHello=-100
local lastSnapshot=-100
local lastPacket=-100
local lastChannel=nil
local lastRoster=nil
local function now()
 if type(GetTime)=="function" then local ok,t=pcall(GetTime);if ok and type(t)=="number" then return t end end
 return clock
end
local function cleanName(name)
 if type(name)~="string" or #name<1 or #name>100 then return nil end
 return string.lower(name)
end
local function unitName(unit)
 if type(UnitName)~="function" then return nil end
 local ok,n,realm=pcall(UnitName,unit)
 if not ok or not n or n=="" or n==UNKNOWNOBJECT then return nil end
 if (not realm or realm=="") and type(UnitFullName)=="function" then
  local success,full,server=pcall(UnitFullName,unit)
  if success and full==n and type(server)=="string" and server~="" then realm=server end
 end
 if type(realm)=="string" and realm~="" and not n:find("-",1,true) then return n.."-"..realm end
 return n
end
local function group()
 local raid=type(IsInRaid)=="function" and IsInRaid()==true
 local n=0
 if raid then
  n=(type(GetNumGroupMembers)=="function" and GetNumGroupMembers()) or (type(GetNumRaidMembers)=="function" and GetNumRaidMembers()) or 0
 else
  n=(type(GetNumSubgroupMembers)=="function" and GetNumSubgroupMembers()) or (type(GetNumPartyMembers)=="function" and GetNumPartyMembers()) or 0
 end
 n=math.max(0,math.min(raid and 40 or 4,tonumber(n) or 0))
 local roster={};local count=0
 local selfName=cleanName(unitName("player"))
 for i=1,n do
  local name=unitName((raid and "raid" or "party")..i)
  local key=cleanName(name)
  if key and key~=selfName and not roster[key] then roster[key]=name;count=count+1 end
 end
 return roster,count>0 and (raid and "RAID" or "PARTY") or nil
end
local function clearExpired()
 local roster,channel=group()
 local t=now()
 for name,peer in pairs(peers) do
  if not roster[name] or t-(peer.at or 0)>85 then peers[name]=nil end
 end
 for name,part in pairs(parts) do
  if not roster[name] or t-(part.at or 0)>15 then parts[name]=nil end
 end
 local names={};for key in pairs(roster) do names[#names+1]=key end
 table.sort(names)
 local signature=table.concat(names,"|")
 if channel~=lastChannel or signature~=lastRoster then
  peers={};parts={};sendQueue={};dirty=true;lastChannel=channel;lastRoster=signature;lastHello=-100;lastSnapshot=-100
 end
 return roster,channel
end
local function hasPartner()
 for _,peer in pairs(peers) do if peer.optIn then return true end end
 return false
end
local function send(message,channel)
 if not registered or not channel or #message>210 then return false end
 local fn=C_ChatInfo and C_ChatInfo.SendAddonMessage or SendAddonMessage
 if type(fn)~="function" then return false end
 local ok,value=pcall(fn,PREFIX,message,channel)
 if not ok or value==false then return false end
 -- Modern enum returns 0 on success; 1+ signals throttling or rejection.
 if type(value)=="number" and value~=0 then return false end
 return true
end
local function register()
 if registered then return true end
 local fn=C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix or RegisterAddonMessagePrefix
 if type(fn)~="function" then return false end
 local ok,result=pcall(fn,PREFIX)
 registered=ok and result~=false and (type(result)~="number" or result==0 or result==1)
 return registered
end
local function scheduleSnapshot()
 counter=counter%99999+1
 local entries={}
 for id in pairs(G.activeQuests or {}) do
  id=tonumber(id)
  if id and id==math.floor(id) and id>0 and id<100000000 then entries[#entries+1]=id end
 end
 table.sort(entries)
 local chunks={};local current=""
 local complete=#entries<=60
 for index=1,math.min(#entries,60) do
  local id=entries[index]
  local encoded=tostring(id).."="..(G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) and "R" or "A")
  if #current>0 and #current+#encoded+1>135 then chunks[#chunks+1]=current;current="" end
  current=current=="" and encoded or (current..","..encoded)
 end
 if current~="" or #chunks==0 then chunks[#chunks+1]=current end
 if #chunks>6 then return false end
 sendQueue={}
 for i,part in ipairs(chunks) do
  sendQueue[#sendQueue+1]="5|S|"..counter.."|"..i.."|"..#chunks.."|"..(complete and "1" or "0").."|"..part
 end
 return true
end
function G.PartyShareEnabled() return G.db and G.db.partyShareEnabled==true or false end
function G.PartyShareSupported()
 return type(C_ChatInfo and C_ChatInfo.SendAddonMessage or SendAddonMessage)=="function" and
        type(C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix or RegisterAddonMessagePrefix)=="function"
end
function G.PartyShareStatus()
 if not G.PartyShareEnabled() then return "꺼짐 · 본인 동의 필요" end
 if not G.PartyShareSupported() or not registered then return "API 미지원 또는 전송 등록 실패" end
 local _,channel=group()
 if not channel then return "켜짐 · 파티 없음" end
 local count=0;for _,peer in pairs(peers) do if peer.optIn then count=count+1 end end
 return "켜짐 · 공유 중인 파티원 "..count.."명"
end
function G.PartyShareSetEnabled(value)
 if not G.db then return false end
 G.db.partyShareEnabled=value==true
 peers={};parts={};sendQueue={};dirty=true;lastHello=-100;lastSnapshot=-100
 if G.db.partyShareEnabled then register() end
 if G.IsUIShown and G.IsUIShown() and G.UIRefresh then G.UIRefresh() end
 return G.PartyShareEnabled()
end
function G.PartyShareLogin()
 peers={};parts={};sendQueue={};dirty=true;lastChannel=nil;lastHello=-100;lastSnapshot=-100;lastPacket=-100
 registered=false;lastRoster=nil
 if G.PartyShareEnabled() then register() end
end
function G.PartyShareRosterChanged()
 clearExpired();dirty=true
end
function G.PartyShareDirty()
 dirty=true
end
function G.PartyShareTick(dt)
 if not G.PartyShareEnabled() then return end
 clock=clock+(tonumber(dt) or 0)
 if not register() then return end
 local roster,channel=clearExpired()
 if not channel then return end
 local t=now()
 if t-lastHello>=45 then
  -- A hello has no quest IDs. Only opted-in peers can trigger a snapshot.
  if send("5|H",channel) then lastHello=t end
 end
 if hasPartner() and #sendQueue==0 and (dirty or t-lastSnapshot>=55) then
  if scheduleSnapshot() then dirty=false;lastSnapshot=t end
 end
 if #sendQueue>0 and t-lastPacket>=.9 then
  if send(sendQueue[1],channel) then table.remove(sendQueue,1);lastPacket=t end
 end
end
local function decode(text,full)
 if #text>850 then return nil end
 local quests={};local count=0
 if text~="" then
  for token in string.gmatch(text,"[^,]+") do
   local id,state=token:match("^(%d+)=([AR])$")
   id=tonumber(id)
   if not id or id<1 or id>=100000000 or quests[id] or count>=60 then return nil end
   quests[id]=state;count=count+1
  end
  if count==0 or select(2,text:gsub(",", ""))~=count-1 then return nil end
 end
 return {quests=quests,complete=full=="1"}
end
function G.PartyShareReceive(prefix,message,distribution,sender)
 if not G.PartyShareEnabled() or not registered or prefix~=PREFIX or type(message)~="string" or #message>210 then return false end
 if distribution~="PARTY" and distribution~="RAID" then return false end
 local roster,channel=clearExpired()
 local key=cleanName(sender)
 if not channel or not key or distribution~=channel or not roster[key] then return false end
 local t=now()
 if message=="5|H" then
  if not peers[key] then peers[key]={at=t,optIn=true,quests=nil} else peers[key].at=t;peers[key].optIn=true end
  dirty=true
  return true
 end
 local sequence,partIndex,total,full,payload=message:match("^5|S|(%d+)|(%d+)|(%d+)|([01])|(.*)$")
 sequence=tonumber(sequence);partIndex=tonumber(partIndex);total=tonumber(total)
 if not sequence or sequence<1 or sequence>99999 or not total or total<1 or total>6 or
    not partIndex or partIndex<1 or partIndex>total or #payload>135 then return false end
 local pending=parts[key]
 if not pending or pending.seq~=sequence or pending.total~=total then
  pending={seq=sequence,total=total,full=full,at=t,chunks={}}
  parts[key]=pending
 end
 if pending.full~=full then parts[key]=nil;return false end
 if pending.chunks[partIndex] and pending.chunks[partIndex]~=payload then parts[key]=nil;return false end
 pending.chunks[partIndex]=payload
 local all={}
 for i=1,total do
  if pending.chunks[i]==nil then return true end
  all[#all+1]=pending.chunks[i]
 end
 local records=decode(table.concat(all,","),full)
 parts[key]=nil
 if not records then return false end
 peers[key]={at=t,optIn=true,quests=records.quests,complete=records.complete}
 if G.IsUIShown and G.IsUIShown() and G.UIRefresh then G.UIRefresh() end
 return true
end
function G.PartyQuestSummary(id)
 if not G.PartyShareEnabled() then return "파티 공유 꺼짐 · 직접 켜야 전송 및 조회" end
 if not G.PartyShareSupported() or not registered then return "파티 통신 API 미지원 · 공유 상태 확인 불가" end
 local roster,channel=clearExpired()
 if not channel then return "파티원이 없어 비교할 기록이 없습니다." end
 id=tonumber(id)
 if not id then return "퀘스트를 선택해야 상태를 비교할 수 있습니다." end
 local statuses={};local extras=0
 for key,name in pairs(roster) do
  local peer=peers[key]
  local label
  if not peer or not peer.quests then label="상태 미공유"
  elseif peer.quests[id]=="R" then label="보고 가능"
  elseif peer.quests[id]=="A" then label="수행 중"
  elseif peer.complete then label="수락 기록 없음 · 완료 여부 미확인"
  else label="일부 목록만 공유 · 확인 불가" end
  if #statuses<5 then statuses[#statuses+1]=name..": "..label else extras=extras+1 end
 end
 table.sort(statuses)
 return "동의한 파티원들의 현재 수락 정보만 참고 (완료 기록 아님)\n"..table.concat(statuses,"\n")..(extras>0 and ("\n외 "..extras.."명") or "")
end
G.API.PartyShare=function(enabled) return G.PartyShareSetEnabled(enabled) end

local addon,G=...
-- Dedicated, query-only opt-in. Unlike PartySync this can disclose completed
-- flags, so it requires a SEPARATE explicit consent per character on BOTH ends.
-- Only the selected story family is queried over a private addon whisper.
local PREFIX="FQGuideCatch8"
local sendQueue={}
local pending,responses,receiving,lastAsked,lastAnswered={},{},{},{},{}
local enabled=false
local registered=false
local clock=0
local lastPacket=-100
local counter=0
local signature=""
local function now()
 if type(GetTime)=="function" then
  local ok,t=pcall(GetTime);if ok and type(t)=="number" then return t end
 end
 return clock
end
local function clean(s)
 if type(s)~="string" or #s<1 or #s>100 or s:find("|",1,true) then return nil end
 return string.lower(s)
end
local function name(unit)
 if type(UnitName)~="function" then return nil end
 local ok,value,realm=pcall(UnitName,unit)
 if not ok or type(value)~="string" or value=="" then return nil end
 if (not realm or realm=="") and type(UnitFullName)=="function" then
  local success,full,server=pcall(UnitFullName,unit)
  if success and full==value and type(server)=="string" and server~="" then realm=server end
 end
 if realm and realm~="" and not value:find("-",1,true) then value=value.."-"..realm end
 return value
end
local function members()
 local raid=type(IsInRaid)=="function" and IsInRaid()==true
 local n=0
 if raid then n=type(GetNumGroupMembers)=="function" and GetNumGroupMembers() or 0
 else n=type(GetNumSubgroupMembers)=="function" and GetNumSubgroupMembers()
    or type(GetNumPartyMembers)=="function" and GetNumPartyMembers() or 0 end
 n=math.max(0,math.min(raid and 40 or 4,tonumber(n) or 0))
 local roster={};local mine=clean(name("player"))
 for i=1,n do
  local original=name((raid and "raid" or "party")..i)
  local key=clean(original)
  if key and key~=mine then roster[key]=original end
 end
 return roster
end
local function member(sender)
 local roster=members()
 local key=clean(sender)
 if not key then return nil end
 if roster[key] then return key,roster[key] end
 -- Some clients omit the realm on CHAT_MSG_ADDON, but never guess when two
 -- same-name members are present.
 local short=key:match("^([^-]+)")
 local answer,count
 for k,original in pairs(roster) do
  if k:match("^([^-]+)")==short then answer={k,original};count=(count or 0)+1 end
 end
 if count==1 then return answer[1],answer[2] end
end
local function rosterChanged()
 local roster=members();local names={}
 for key in pairs(roster) do names[#names+1]=key end
 table.sort(names)
 local nextSig=table.concat(names,"|")
 if nextSig~=signature then
  signature=nextSig;pending={};responses={};receiving={};sendQueue={};lastAsked={};lastAnswered={}
 end
 return roster
end
local function register()
 if registered then return true end
 local fn=C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix or _G.RegisterAddonMessagePrefix
 if type(fn)~="function" then return false end
 local ok,value=pcall(fn,PREFIX)
 registered=ok and value~=false and (type(value)~="number" or value==0 or value==1)
 return registered
end
local function send(text,to)
 if type(text)~="string" or #text>210 or not to or not register() then return false end
 local fn=C_ChatInfo and C_ChatInfo.SendAddonMessage or _G.SendAddonMessage
 if type(fn)~="function" then return false end
 local ok,status=pcall(fn,PREFIX,text,"WHISPER",to)
 if not ok or status==false or (type(status)=="number" and status~=0) then return false end
 return true
end
local function queue(text,to)
 if #sendQueue>40 or type(text)~="string" or #text>210 then return false end
 sendQueue[#sendQueue+1]={wire=true,text=text,to=to};return true
end
local function statusDump(root)
 local family=G.QuestNarrativeFamily and G.QuestNarrativeFamily(root,42)
 if not family or family.cycle or family.truncated or (G.questIndex and G.questIndex.available and not G.questIndex.ready) then return nil end
 if #family.ids>42 then return nil end
 local encoded={}
 for _,id in ipairs(family.ids) do
  local state=G.CatchupSelfState and G.CatchupSelfState(id) or "U"
  if not ({D=true,T=true,A=true,N=true,U=true})[state] then state="U" end
  encoded[#encoded+1]=id.."="..state
 end
 return encoded
end
function G.CatchupShareEnabled() return G.db and G.db.catchupShareEnabled==true or false end
function G.CatchupShareSetEnabled(value)
 if not G.db then return false end
 G.db.catchupShareEnabled=value==true
 enabled=G.db.catchupShareEnabled
 pending={};responses={};receiving={};sendQueue={};lastAsked={};lastAnswered={}
 if enabled then register() end
 if G.CatchupUIRefresh then G.CatchupUIRefresh() end
 return enabled
end
function G.CatchupShareLogin()
 registered=false;signature="";lastPacket=-100
 pending={};responses={};receiving={};sendQueue={};lastAsked={};lastAnswered={}
 enabled=G.CatchupShareEnabled()
 if enabled then register() end
end
function G.CatchupShareRosterChanged()
 rosterChanged()
 if G.CatchupUIRefresh then G.CatchupUIRefresh() end
end
function G.CatchupPeerNames()
 local roster=rosterChanged();local list={}
 for _,original in pairs(roster) do list[#list+1]=original end
 table.sort(list);return list
end
function G.CatchupPeerSnapshot(peer,root)
 local key=member(peer)
 if not key then return nil,"파티원 미확인 · 동일 파티에서 확인하세요." end
 if not enabled then return nil,"동행 공유 꺼짐 · 양쪽에서 켜야 조회할 수 있습니다." end
 local value=responses[key]
 if value and value.root==tonumber(root) and now()-value.at<=90 then
  if value.error then return nil,"상대방의 연계 데이터 준비 안 됨 ("..value.error..")" end
  return value
 end
 if pending[key] and pending[key].root==tonumber(root) then return nil,"조회 요청 전송됨 · 친구의 동의/응답 대기" end
 return nil,"친구의 진행 상태 미확인 · [친구 정보 요청] 선택"
end
function G.CatchupRequest(root,peer)
 root=tonumber(root)
 if not root or root<1 or root%1~=0 then return false,"퀘스트를 먼저 선택하세요." end
 if not enabled then return false,"내 동행 공유가 꺼져 있습니다. 양쪽에서 동의한 다음 요청하세요." end
 rosterChanged()
 local key,to=member(peer)
 if not key then return false,"현재 파티원을 선택하세요." end
 if not register() then return false,"애드온 통신 API를 사용할 수 없습니다." end
 local t=now()
 if lastAsked[key] and t-lastAsked[key]<10 then return false,"요청 간격은 10초 이상입니다." end
 local fam=G.QuestNarrativeFamily and G.QuestNarrativeFamily(root,42)
 if not fam or fam.cycle or fam.truncated or fam.indexing then return false,"연계 자료가 완전히 준비되지 않았습니다. 데이터 색인을 확인하세요." end
 counter=counter%90000+1
 local nonce=counter
 if not send("8|Q|"..nonce.."|"..root,to) then return false,"상대방에게 요청을 전송하지 못했습니다." end
 lastAsked[key]=t
 pending[key]={root=root,nonce=nonce,at=t}
 responses[key]=nil;receiving[key]=nil
 if G.CatchupUIRefresh then G.CatchupUIRefresh() end
 return true,"선택한 연계만 친구에게 조회 요청했습니다. 친구도 동행 공유를 켜야 합니다."
end
local function parseEncoded(data)
 local map={}
 if data=="" then return nil end
 local count=0
 for token in data:gmatch("[^,]+") do
  local raw,code=token:match("^(%d+)=([DATNU])$")
  local id=tonumber(raw)
  if not id or id<1 or id>=100000000 or map[id] or count>=42 then return nil end
  map[id]=code;count=count+1
 end
 if count==0 or select(2,data:gsub(",",""))~=count-1 then return nil end
 return map
end
function G.CatchupShareReceive(prefix,msg,distribution,sender)
 if prefix~=PREFIX or distribution~="WHISPER" or type(msg)~="string" or #msg>210 or not enabled then return false end
 rosterChanged()
 local key,to=member(sender)
 if not key or not register() then return false end
 local t=now()
 local nonce,root=msg:match("^8|Q|(%d+)|(%d+)$")
 if nonce then
  nonce,root=tonumber(nonce),tonumber(root)
  if not nonce or nonce<1 or nonce>99999 or not root or root<1 or root>=100000000 then return false end
  if lastAnswered[key] and t-lastAnswered[key]<15 then return false end
  lastAnswered[key]=t
  local encoded=statusDump(root)
  if not encoded then queue("8|E|"..nonce.."|"..root.."|INDEX",to);return true end
  local chunks={};local current=""
  for _,value in ipairs(encoded) do
   if #current>0 and #current+#value+1>125 then chunks[#chunks+1]=current;current="" end
   current=current=="" and value or (current..","..value)
  end
  if current~="" then chunks[#chunks+1]=current end
  if #chunks==0 or #chunks>6 then queue("8|E|"..nonce.."|"..root.."|SIZE",to);return true end
  for i,part in ipairs(chunks) do
   queue("8|S|"..nonce.."|"..root.."|"..i.."|"..#chunks.."|"..part,to)
  end
  return true
 end
 local errorNonce,errorRoot,errorCode=msg:match("^8|E|(%d+)|(%d+)|([A-Z]+)$")
 if errorNonce then
  local p=pending[key]
  if not p or p.nonce~=tonumber(errorNonce) or p.root~=tonumber(errorRoot) then return false end
  pending[key]=nil;responses[key]={at=t,root=p.root,error=errorCode,quests={}}
  if G.CatchupUIRefresh then G.CatchupUIRefresh() end
  return true
 end
 local rNonce,rRoot,part,total,payload=msg:match("^8|S|(%d+)|(%d+)|(%d+)|(%d+)|(.+)$")
 if not rNonce then return false end
 rNonce,rRoot,part,total=tonumber(rNonce),tonumber(rRoot),tonumber(part),tonumber(total)
 local request=pending[key]
 if not request or request.nonce~=rNonce or request.root~=rRoot or t-request.at>75 or
    not part or not total or total<1 or total>6 or part<1 or part>total or #payload>125 then return false end
 local buffer=receiving[key]
 if not buffer or buffer.nonce~=rNonce or buffer.total~=total then
  buffer={nonce=rNonce,total=total,at=t,chunks={}};receiving[key]=buffer
 end
 if buffer.chunks[part] and buffer.chunks[part]~=payload then receiving[key]=nil;return false end
 buffer.chunks[part]=payload
 local chunks={}
 for i=1,total do
  if not buffer.chunks[i] then return true end
  chunks[#chunks+1]=buffer.chunks[i]
 end
 local states=parseEncoded(table.concat(chunks,","))
 local fam=G.QuestNarrativeFamily and G.QuestNarrativeFamily(rRoot,42)
 receiving[key]=nil
 if not states or not fam or fam.truncated or fam.cycle then return false end
 -- A peer may only answer about the exact quest IDs in the requested chain.
 for id in pairs(states) do if not fam.member[id] then return false end end
 for _,id in ipairs(fam.ids) do if not states[id] then return false end end
 pending[key]=nil
 responses[key]={at=t,root=rRoot,quests=states}
 if G.CatchupUIRefresh then G.CatchupUIRefresh() end
 return true
end
function G.CatchupShareSendChat(root,peer)
 if not enabled then return false,"동행 공유를 켜고 친구 진행도를 조회하세요." end
 rosterChanged()
 local key,to=member(peer)
 if not key then return false,"현재 파티원을 선택하세요." end
 if type(SendChatMessage)~="function" then return false,"게임의 귓속말 전송을 사용할 수 없습니다." end
 local lines,why=G.CatchupChatLines(root,to)
 if not lines then return false,why end
 if #sendQueue>0 then return false,"진행 중인 전송이 끝난 다음 다시 시도하세요." end
 -- An explicit button is required. Bounded, throttled whispers; no automatic
 -- group broadcast or background history export.
 local count=0
 for _,line in ipairs(lines) do
  if count>=9 then break end
  if #line>225 then
   local cut=225
   while cut>0 do
    local b=line:byte(cut+1)
    if b and b>=128 and b<192 then cut=cut-1 else break end
   end
   line=line:sub(1,cut)
  end
  line=line:gsub("|","")
  sendQueue[#sendQueue+1]={wire=false,text=line,to=to}
  count=count+1
 end
 return true,"친구에게 따라잡기 안내 "..count.."줄 전송을 시작했습니다."
end
function G.CatchupShareTick(dt)
 clock=clock+(tonumber(dt) or 0)
 if not enabled then return end
 rosterChanged()
 local t=now()
 for key,p in pairs(pending) do if t-p.at>75 then pending[key]=nil end end
 for key,p in pairs(responses) do if t-p.at>90 then responses[key]=nil end end
 if #sendQueue==0 or t-lastPacket<.85 then return end
 local pkt=sendQueue[1]
 if not member(pkt.to) then table.remove(sendQueue,1);return end
 local ok=false
 if pkt.wire then ok=send(pkt.text,pkt.to)
 else ok=pcall(SendChatMessage,pkt.text,"WHISPER",nil,pkt.to) end
 if ok then table.remove(sendQueue,1);lastPacket=t end
end
G.API.CatchupShare=function(enabled)return G.CatchupShareSetEnabled(enabled)end

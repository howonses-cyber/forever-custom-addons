local base=arg[1] or "./"
local G={}
local dbRows={
 [123]={name="여러 NPC",startedBy={{20}},finishedBy={{21}},objectives={{{30}}}},
 [4341]={name="카란 마이트해머",nextQuestInChain=4342},
 [4342]={name="카란의 이야기"},
 [999]={name="테스트 미수락"},
}
QuestDB={};NpcDB={};ObjectDB={}
local spawns={
 [20]={name="여러 NPC",spawns={[46]={{10,20},{10,20},{13,25}},[47]={{90,70}},[9999]={{55,55}}}},
 [21]={name="보고 NPC",spawns={[46]={{8,8}}}},
 [30]={name="목표 NPC",spawns={[46]={{44,12},{46,12}}}},
}
function G.DBGet(o,id,key)
 if o==QuestDB then return dbRows[id] and dbRows[id][key] end
 if o==NpcDB then return spawns[id] and spawns[id][key] end
end
function G.AreaToUiMap(id) return ({[46]=1428,[47]=1427})[id] end
function G.IsInstanceArea(id) return id==9999 end
function G.GetQuestName(id) return dbRows[id] and dbRows[id].name or ("퀘스트 #"..id) end
function G.GetDungeon(id) if id=="brd" then return {id="brd",name="검은바위 나락",ids={123,4341,999,777}} end end
function G.QuestInsideInfo(id,stage)
 if id==4341 and stage=="turnin" then return {dungeon="검은바위 나락",dungeonId="brd"} end
end
function G.QuestStageLandmark() return nil end
function G.QuestContactName(id,stage) return nil,nil,nil,id==8 and "item" or "npc" end
function G.Ready()return true end
local active,rewarded,ready={}, {}, {}
function G.IsInLog(id)return active[id] or false end
function G.IsCompleted(id)return rewarded[id] or false end
function G.IsReadyToTurnIn(id)return ready[id] or false end
function G.RouteAssessment(id)
 if id==999 then return "선행 필요","locked","선행 충족 전" end
 if id==123 then return "미수락","ready" end
 return "확인 필요","unknown","자료 부족"
end
G.specialQuestMeta={
 [4341]={insideStages={turnin={dungeon="brd",npcName="카란",followup=4342}}},
 [4342]={insideStages={accept={dungeon="brd",npcName="카란"}}},
}
assert(loadfile(base.."QuestRouteSafety.lua"))("ForeverDungeonQuestGuide",G)
local n=0
local function eq(a,b,m)n=n+1;assert(a==b,(m or "mismatch").." "..tostring(a).." ~= "..tostring(b)) end
local function has(s,p) n=n+1;assert(type(s)=="string" and s:find(p,1,true),tostring(s).." missing "..p) end
local p,count=G.QuestVisitCandidates(123,"accept",2)
eq(count,3,"deduplicated DB samples")
eq(#p,2,"sample limit")
eq(p[1].map,1427,"deterministic map sort")
eq(p[1].x,.9)
eq(p[2].map,1428)
p,count=G.QuestVisitCandidates(123,"objective",4)
eq(count,2,"objective spawn samples")
p,count=G.QuestVisitCandidates(4341,"turnin",3)
eq(count,0,"no fake indoor point")
p,count=G.QuestVisitCandidates(123,"bad",3)
eq(count,0,"unsupported stage")
local hint=G.QuestFollowupHint(4341)
eq(hint.id,4342);eq(hint.sameContact,true);has(hint.state,"기록")
active[4341]=true;ready[4341]=true
hint=G.QuestFollowupHint(4341);has(hint.state,"먼저 보고")
rewarded[4341]=true;ready[4341]=nil;active[4341]=nil
hint=G.QuestFollowupHint(4341);has(hint.state,"현장 확인")
active[4342]=true;hint=G.QuestFollowupHint(4341);has(hint.state,"이미 수락")
rewarded[4342]=true;hint=G.QuestFollowupHint(4341);has(hint.state,"보고 완료")
active[4342]=nil
local result=G.DungeonPreflight("brd")
eq(result.confirmedReady,false,"no fabricated preparedness")
eq(result.counts.unaccepted,1);eq(result.counts.locked,1);eq(result.counts.unknown,1)
local lines=table.concat(G.DungeonPreflightLines("brd",2),"\n");has(lines,"DB 미확인");has(lines,"감금 구역")
eq(G.QuestSpecialInstruction(4322)~=nil,true)
has(G.QuestSpecialInstruction(4264),"가방")
local caveat=G.RouteTravelCaveat({indoor={dungeonId="brd"}},nil)
has(caveat,"입구")
has(G.RouteTravelCaveat({point={map=1428,x=.5,y=.4,approx=true}},nil),"탐색 후보")
has(G.RouteTravelCaveat({point={map=1428,x=.5,y=.4}},{map=1453,x=.3,y=.2}),"지도 간 직선거리")
eq(G.QuestFollowupHint(123),nil)
print("PASS phase-2 source-aware spawn candidates, followups, dungeon preflight, special and travel caveats: "..n.." assertions")

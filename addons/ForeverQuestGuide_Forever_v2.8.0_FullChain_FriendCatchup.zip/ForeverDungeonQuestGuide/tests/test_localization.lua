-- Runtime contract tests against the shipped localization modules and real
-- lookup tables. The synthetic client/database below is not a live WoW test.
local base=arg[1] or './'
local G={}
local function loadModule(name)assert(loadfile(base..name))('ForeverDungeonQuestGuide',G)end
for _,name in ipairs({'Core.lua','Data.lua','VerifiedRoutes.lua','KoreanGameData.lua','KoreanPlaces.lua','QuestLocalization.lua','QuestData.lua','Walkthrough.lua','FactionFilter.lua','QuestSearch.lua'})do loadModule(name)end
local checks,failures=0,{}
local function check(ok,label,detail)
 checks=checks+1
 if not ok then failures[#failures+1]=label..(detail and ': '..detail or '')end
end
local function eq(actual,expected,label)check(actual==expected,label,tostring(actual)..' ~= '..tostring(expected))end
local function has(text,part,label)check(type(text)=='string' and text:find(part,1,true)~=nil,label,tostring(text))end
local function contains(list,id)for _,v in ipairs(list)do if v==id then return true end end;return false end
local function group(label,fn)
 local ok,why=pcall(fn)
 if not ok then failures[#failures+1]=label..' crashed: '..tostring(why)end
end
local function signature(t)
 local keys={};for k in pairs(t)do keys[#keys+1]=k end
 table.sort(keys,function(a,b)return tostring(a)<tostring(b)end)
 local out={}
 for _,k in ipairs(keys)do local v=t[k];out[#out+1]=tostring(k)..'='..(type(v)=='table' and signature(v) or tostring(v))end
 return table.concat(out,'\001')
end
local sourceTables={G.koGameNames,G.enGameNames,G.koQuestObjectives,G.enQuestObjectives,G.koQuestObjectiveWarnings,G.koTextReplacements,G.koQuestNames}
local before={};for i,t in ipairs(sourceTables)do before[i]=signature(t)end
local rows={
 [3801]={name='Dark Iron Legacy',zoneOrSort=1584,requiredLevel=48},
 [3802]={name='Dark Iron Legacy',zoneOrSort=1584,requiredLevel=48,objectivesText={G.enQuestObjectives[3802][1]}},
 [4126]={name='Hurley Blackbreath',zoneOrSort=1584,requiredLevel=50},
 [216]={name=G.enGameNames.quest[216],zoneOrSort=331,objectivesText={'Take down 8 Thistlefur Avengers and 8 Thistlefur Shaman; most are located east of Zoram Strand in Thistlefur Village. Once completed, return to Karang Amakkar at Zoram\'gar Outpost, Ashenvale.'}},
 [990001]={name='Runtime localization fixture',startedBy={{9623}},finishedBy={{},{173324}},objectives={{{9623}},{{173324}},{{10999}}}},
 [990002]={name='Runtime item starter fixture',startedBy={{},{},{10999}}},
}
local sharedIds={3801,3802,4126,216}
local titles={}
QuestDB={Get=function(id,field)return rows[id] and rows[id][field]end,GetAllIds=function()return sharedIds end}
NpcDB={Get=function(id,field)if field=='name' then return G.enGameNames.npc[id]end end}
ItemDB={Get=function(id,field)if field=='name' then return G.enGameNames.item[id]end end}
ObjectDB={Get=function(id,field)if field=='name' then return G.enGameNames.object[id]end end}
C_QuestLog={GetTitleForQuestID=function(id)return titles[id]end,IsQuestFlaggedCompleted=function()return false end}
C_Map={GetMapInfo=function(id)return{name='Unverified Test Area'}end}
GetLocale=function()return'enUS'end -- Korean output is explicitly requested regardless of client locale.
GetTime=function()return 100 end
UnitRace=function()return'드워프','Dwarf',3 end
G.player={faction='Alliance',classId=7,level=60}
G.db={selectedQuests={},deferredQuests={},guide={},factionFilter='all',hideUnavailable=false,onlyIncomplete=false}
local fixtureBefore=signature(rows)

group('paired names and live client priority',function()
 eq(G.KoreanName('quest',3801,'Dark Iron Legacy'),'검은무쇠 유물','quest ID/title pair')
 eq(G.KoreanName('npc',9623,'A-Me 01'),'에이미 01','NPC ID/title pair')
 eq(G.KoreanName('object',173324,'Corrupted Night Dragon'),'오염된 어둠용풀','object ID/title pair')
 eq(G.KoreanName('item',10999,'Ironfel'),'무쇠지옥','item ID/title pair')
 eq(G.KoreanName('quest',3801,' DARK IRON LEGACY! '),'검은무쇠 유물','safe case and surrounding punctuation tolerance')
 has(G.KoreanName('quest',3801,'Custom Forever Replacement'),'한글 명칭 미확인','reused ID must not force unrelated Korean title')
 has(G.KoreanName('quest',999999999,'Custom Forever Replacement'),'Custom Forever Replacement','unknown original retained')
 eq(G.DBGet(QuestDB,3801,'name'),'검은무쇠 유물','display getter translates DB title')
 eq(G.DBRawGet(QuestDB,3801,'name'),'Dark Iron Legacy','raw getter retains original')
 eq(G.DBGet(NpcDB,9623,'name'),'에이미 01','NPC display getter')
 eq(G.DBGet(ItemDB,10999,'name'),'무쇠지옥','item display getter')
 eq(G.DBGet(ObjectDB,173324,'name'),'오염된 어둠용풀','object display getter')
 eq(G.GetQuestName(3801),'검은무쇠 유물','English client with English database uses verified Korean')
 G.activeQuests[3801]={title='Dark Iron Legacy'}
 eq(G.GetQuestName(3801),'검은무쇠 유물','English accepted title is translated')
 titles[3801]='실제 한국어 클라이언트 제목'
 eq(G.GetQuestName(3801),'실제 한국어 클라이언트 제목','real Korean client title wins over English log/DB')
 G.activeQuests[3801].title='실제 한국어 수락 제목'
 eq(G.GetQuestName(3801),'실제 한국어 수락 제목','real Korean accepted title priority')
 G.activeQuests[3801]=nil;titles[3801]=nil
 rows[3801].name='설치된 한국어 자료 제목'
 eq(G.GetQuestName(3801),'설치된 한국어 자료 제목','installed Korean database priority')
 rows[3801].name='Custom Forever Replacement'
 has(G.GetQuestName(3801),'한글 명칭 미확인','GetQuestName rejects reused source ID')
 rows[3801].name='Dark Iron Legacy'
 -- 4136 has an older authored override: even it must not override a different live title.
 G.activeQuests[4136]={title='Custom Server Quest With Reused ID'}
 has(G.GetQuestName(4136),'Custom Server Quest With Reused ID','authored overrides cannot rename a different live quest')
 G.activeQuests[4136]=nil
end)

group('missing runtime data stays missing',function()
 eq(G.DBGet(QuestDB,99670,'name'),nil,'bundled Korean name does not manufacture a missing DB record')
 local reason,code=G.RouteHardBlock(99670)
 eq(code,'unknown','missing DB record is still unavailable');has(reason,'자료 없음','missing record explanation')
 local db=QuestDB;QuestDB=nil
 eq(G.Ready(),false,'language pack alone does not make QuestieDB ready')
 eq(G.DBGet(QuestDB,3801,'name'),nil,'absent database is not filled by localization')
 local _,missingCode=G.RouteHardBlock(3801);eq(missingCode,'unknown','absent database blocks unaccepted quest')
 QuestDB=db
end)

group('dynamic entity getter paths',function()
 local name,id,db,kind=G.QuestContactName(990001,'accept')
 eq(name,'에이미 01','dynamic NPC starter name');eq(id,9623,'starter ID remains unchanged');eq(db,NpcDB,'starter DB remains unchanged');eq(kind,'npc','starter kind remains unchanged')
 local object,objectId,objectDB,objectKind=G.QuestContactName(990001,'turnin')
 eq(object,'오염된 어둠용풀','dynamic object finisher name');eq(objectId,173324,'finisher ID remains unchanged');eq(objectDB,ObjectDB,'finisher DB remains unchanged');eq(objectKind,'object','finisher kind remains unchanged')
 local item,itemId,_,itemKind=G.QuestContactName(990002,'accept')
 eq(item,'무쇠지옥','dynamic item starter name');eq(itemId,10999,'starter item ID remains unchanged');eq(itemKind,'item','item starter kind remains unchanged')
 local targets=G.QuestObjectivePoints(990001)
 eq(#targets,3,'all dynamic target kinds retained')
 eq(targets[1].title,'에이미 01','creature target name');eq(targets[2].title,'오염된 어둠용풀','object target name');eq(targets[3].title,'무쇠지옥','item target name')
 for _,target in ipairs(targets)do eq(target.point,nil,'language pack does not invent spawn coordinates for '..target.kind)end
end)

group('source objectives and original data integrity',function()
 local original=rows[3802].objectivesText
 local translated=G.DBGet(QuestDB,3802,'objectivesText')
 eq(translated[1],G.koQuestObjectives[3802][1],'exact English objective uses confirmed Korean')
 check(translated~=original,'translated objective array is a new table')
 eq(original[1],G.enQuestObjectives[3802][1],'source objective array is untouched')
 eq(G.DBRawGet(QuestDB,3802,'objectivesText'),original,'raw objective getter retains original reference')
 local changed=G.enQuestObjectives[3802][1]..' Additional server-specific requirement.'
 local changedResult=G.KoreanQuestObjectives(3802,changed)
 check(changedResult~=G.koQuestObjectives[3802][1],'changed English objective is not overwritten by stale source text')
 has(changedResult,'Additional server-specific requirement.','unpaired server requirement remains present')
 eq(G.KoreanQuestObjectives(3802,'실제 로그 목표: 무쇠지옥 2개'),'실제 로그 목표: 무쇠지옥 2개','actual Korean objective remains authoritative')
 local warnings=0
 for id in pairs(G.koQuestObjectiveWarnings)do
  warnings=warnings+1
  check(G.koQuestObjectives[id]==nil and G.enQuestObjectives[id]==nil,'withheld objective '..id..' has no usable fallback')
 end
 eq(warnings,204,'all known mismatched source quantities withheld')
 local withheld=G.DBGet(QuestDB,216,'objectivesText')[1]
 has(withheld,'8 Thistlefur','runtime objective retains current eight-count');check(not withheld:find('12',1,true),'stale twelve-count never inserted')
 -- A punctuation-only normalization must not collapse 10 into 1.0. Find a
 -- real paired objective with a multi-digit quantity instead of inventing a dataset row.
 local found=false
 local ids={};for id in pairs(G.enQuestObjectives)do ids[#ids+1]=id end;table.sort(ids)
 for _,id in ipairs(ids)do
  for i,line in ipairs(G.enQuestObjectives[id])do
   local number=line:match('%f[%d](%d%d)%f[^%d]')
   if number then
    local altered=line:gsub('%f[%d]'..number..'%f[^%d]',number:sub(1,1)..'.'..number:sub(2,2),1)
    check(G.KoreanQuestObjectives(id,altered)~=G.koQuestObjectives[id][i],'different decimal count must not match source objective '..id)
    found=true;break
   end
  end
  if found then break end
 end
 check(found,'numeric normalization regression uses an actual source objective')
 G.activeQuests[3802]={title='Dark Iron Legacy'}
 C_QuestLog.GetLogIndexForQuestID=function(id)return id==3802 and 17 or 0 end
 C_QuestLog.GetInfo=function(index)return index==17 and {questID=3802} or nil end
 GetQuestLogQuestText=function(index)assert(index==17,'wrong quest selected');return 'Client narrative',G.enQuestObjectives[3802][1]end
 SelectQuestLogEntry=function()error('localization must not select a quest in the client')end
 eq(G.LiveQuestNarrative(3802).objective,G.koQuestObjectives[3802][1],'live English objective uses exact matched translation without changing quest selection')
 GetQuestLogQuestText=function()return '실제 설명','실제 게임 목표 2개'end
 eq(G.LiveQuestNarrative(3802).objective,'실제 게임 목표 2개','live Korean objective remains authoritative')
 G.activeQuests[3802]=nil
end)

group('WoW formatting and place text',function()
 eq(G.KoreanText('The Lyceum'),'훈련강당','verified subzone name')
 eq(G.KoreanText("Zaetar's Grave"),'재타르의 무덤','verified dungeon floor')
 eq(G.KoreanText("자에타르의 무덤 (Zaetar's Grave)"),'재타르의 무덤','legacy mixed label canonicalization')
 eq(G.KoreanText('검은 금고 (The Black Vault)'),'검은 금고','known bilingual parenthetical is deduplicated')
 eq(G.KoreanText('검은 금고 (보물 방)'),'검은 금고 (보물 방)','different Korean parenthetical is preserved')
 eq(G.KoreanText('Unknown Custom Place'),'Unknown Custom Place','unverified prose is not invented')
 eq(G.KoreanText('|cffffffffIronfel|r'),'|cffffffff무쇠지옥|r','color tokens survive whole-name translation')
 eq(G.KoreanText('|cffa335ee|Hitem:10999:::::::::|h[Ironfel]|h|r'),'|cffa335ee|Hitem:10999:::::::::|h[무쇠지옥]|h|r','hyperlink payload and color survive visible-label translation')
 eq(G.KoreanText('|TInterface\\Icons\\Ironfel:16|t Ironfel'),'|TInterface\\Icons\\Ironfel:16|t 무쇠지옥','texture payload is not localized')
 eq(G.KoreanText('|A:Ironfel:16:16|a Ironfel'),'|A:Ironfel:16:16|a 무쇠지옥','atlas payload is not localized')
 eq(G.KoreanText('https://example.invalid/Ironfel Ironfel'),'https://example.invalid/Ironfel 무쇠지옥','URL is not localized')
 eq(G.KoreanText('|cffffffff검은 금고 (The Black Vault)|r'),'|cffffffff검은 금고|r','deduplication preserves formatting')
end)

group('raw English search after localized display',function()
 G.RestartQuestIndex();G.TickQuestIndex(100)
 check(G.questIndex.ready,'fixture index finished')
 local english=G.SearchQuestIds('all','Dark Iron Legacy')
 local korean=G.SearchQuestIds('all','검은무쇠 유물')
 check(contains(english,3801) and contains(english,3802),'global English-name search preserved')
 check(contains(korean,3801) and contains(korean,3802),'global Korean-name search works')
 local dungeon=G.SearchDungeons('Hurley Blackbreath')
 check(#dungeon>0 and dungeon[1].dungeon.id=='brd','dungeon search retains raw English name')
 G.activeQuests[4126]={title='Hurley Blackbreath'};G.questIndex.normalized[4126]=nil
 check(contains(G.SearchQuestIds('active','Hurley Blackbreath'),4126),'on-demand active search retains raw English')
 G.activeQuests[4126]=nil
 eq(signature(sharedIds),signature({3801,3802,4126,216}),'shared GetAllIds array is unchanged')
end)

group('version mismatch report',function()
 local ver=G.version
 G.uiVersion=ver;G.chainVersion=ver;G.journeyVersion=ver;G.statusVersion=ver
 C_AddOns={GetAddOnMetadata=function(_,field)if field=='Version'then return ver end end}
 local report,mismatch=G.VersionReport()
 eq(mismatch,false,'matching runtime and install versions');has(report,'버전이 일치합니다','matching version report text')
 G.uiVersion='2.1.0'
 local mixed,isMixed=G.VersionReport();eq(isMixed,true,'mixed UI source is detected');has(mixed,'일부 파일 버전이 일치하지 않습니다','mixed version explanation')
 G.uiVersion=ver;C_AddOns.GetAddOnMetadata=function()return'2.0.1'end
 local _,metadataMixed=G.VersionReport();eq(metadataMixed,true,'old install metadata is detected')
end)

eq(signature(rows),fixtureBefore,'runtime localization/search never changes database fixture values')
for i,t in ipairs(sourceTables)do eq(signature(t),before[i],'bundled source table remains unchanged '..i)end
if #failures>0 then
 for _,failure in ipairs(failures)do io.stderr:write('FAIL '..failure..'\n')end
 error(#failures..' localization contract failures in '..checks..' checks')
end
print('PASS runtime localization: '..checks..' checks against real game/place lookup data; exact title/objective guards, missing DB, English search, formatting, no source mutations, version diagnostics (mock APIs only)')

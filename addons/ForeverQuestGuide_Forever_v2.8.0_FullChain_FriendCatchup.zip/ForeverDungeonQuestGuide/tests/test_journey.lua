local base=arg[1] or './'
local G={db={selectedQuests={[1]=true},deferredQuests={[11]=true},manualProgress={keep=true},guide={index=7,steps={{quest=2}}}},player={level=52},selection={quest=6}}
local calls={}
local codes={[1]='ready',[2]='active',[3]='turnin',[4]='done',[5]='superseded',[6]='locked',[7]='low',[8]='blocked',[9]='dependentDeferred',[10]='unknown',[11]='deferred',[12]='ready',[13]='active',[14]='ready',[15]='locked',[16]='locked',[17]='ready'}
local names={[1]='야외 수락',[2]='목표 수행',[3]='실내 보고',[4]='끝난 일',[5]='지나간 선행',[6]='최종 연계',[7]='고레벨 퀘스트',[12]='선택된 선행',[13]='진행 중 선행',[14]='다른 택일',[15]='진행 불가 연계',[16]='분기 연계',[17]='아이템 시작'}
function G.GetQuestName(id) return names[id] or '퀘스트 '..id end
function G.RouteAssessment(id) calls[id]=(calls[id] or 0)+1;return 'state:'..tostring(codes[id]),codes[id],codes[id]=='blocked' and '직업 조건 불충족' or nil end
function G.ResolveRouteRequirements(id)
 if id==6 then return {[6]={[12]=true},[12]={}} end
 if id==16 then return {[16]={[12]=true,[13]=true},[12]={},[13]={}} end
 return nil,'선행 경로 확인 불가'
end
function G.GetQuestMinLevel() return 58 end
function G.MapDisplayName(map) return map==1428 and '불타는 평원' or '다른 지역' end
function G.QuestPoint(id,stage)
 if id==1 then return {map=1428,x=.66,y=.22,name='야외 NPC'} end
 if id==3 then return {map=1428,x=.294,y=.383,name='던전 입구'} end
end
function G.QuestInsideInfo(id,stage)
 if id==3 and stage=='turnin' then return {dungeon='검은바위 나락',dungeonId='brd',room='감금 구역',npcName='실내 NPC',entrance={map=1428,x=.294,y=.383}} end
end
function G.QuestContactName(id,stage)
 if id==17 then return '시작 물건',101,{},'item' end
 return 'NPC '..id,100+id,{},'npc'
end
function G.QuestContactLandmark(id,stage)
 if id==17 then return {zone='시작 아이템',target='시작 물건',instruction='시작 물건이 없으면 획득처를 확인하세요.'} end
end
function G.QuestObjectiveText(id) return id==2 and '대상 처치 3마리' or nil end
function G.QuestObjectivePoints(id)
 if id==2 then return {{kind='creature',id=88,title='대상',landmark={zone='검은바위 나락',site='검은 모루',dungeonId='brd',instruction='대상을 처치하세요.'}}} end
 return {}
end
function G.LiveQuestNarrative(id) return id==2 and {objective='실제 로그 목표 2/3'} or nil end
function G.QuestRegionHint() error('list category must not be used as actual objective destination') end
function G.RouteExclusionReason(id) return id==5 and '후속 퀘스트 진행 확인' or nil end
assert(loadfile(base..'QuestJourney.lua'))('ForeverDungeonQuestGuide',G)
local n=0
local function eq(a,b,note) n=n+1;assert(a==b,(note or 'equal')..': '..tostring(a)..' ~= '..tostring(b)) end
local function has(s,p,note) n=n+1;assert(type(s)=='string' and s:find(p,1,true),note or (tostring(s)..' missing '..p)) end
local function notHas(s,p,note) n=n+1;assert(not s:find(p,1,true),note or ('unexpected '..p)) end
local initial=G.db;local route=G.db.guide;local steps=route.steps;local checked=G.db.selectedQuests;local deferred=G.db.deferredQuests;local manual=G.db.manualProgress
local r=G.QuestJourney(1);eq(r.phase,'accept');eq(r.canGuide,true);has(r.location,'66.0, 22.0');has(r.detail,'야외 NPC');eq(r.contactStage,'accept')
r=G.QuestJourney(2);eq(r.phase,'objective');has(r.detail,'실제 로그 목표');has(r.location,'검은 모루');eq(r.inside,true);eq(r.contactStage,nil);has(r.nextText,'보고해야')
r=G.QuestJourney(3);eq(r.phase,'turnin');has(r.location,'검은바위 나락');has(r.location,'감금 구역');notHas(r.location,'29.4');eq(r.point,nil);eq(r.canGuide,true);has(r.detail,'실내 NPC');has(r.nextText,'던전 안')
r=G.QuestJourney(4);eq(r.phase,'done');eq(r.canGuide,false);has(r.detail,'보고 완료')
r=G.QuestJourney(5);eq(r.phase,'superseded');eq(r.canGuide,false);has(r.nextText,'보고 완료 기록과 구분')
r=G.QuestJourney(6);eq(r.code,'locked');eq(r.phase,'blocked');eq(r.actionPhase,'accept');eq(r.prerequisite,true);eq(r.actionQuestId,12);eq(r.questId,6);eq(r.canGuide,true);notHas(r.title,'다른 택일')
r=G.QuestJourney(16);eq(r.actionQuestId,13);eq(r.actionPhase,'objective');eq(r.phase,'blocked')
r=G.QuestJourney(15);eq(r.canGuide,false);eq(r.actionQuestId,15)
r=G.QuestJourney(7);has(r.detail,'최소 58레벨');has(r.detail,'현재 52레벨');has(r.detail,'6레벨 더 필요');eq(r.canGuide,false)
r=G.QuestJourney(8);has(r.detail,'직업 조건');eq(r.canGuide,false)
r=G.QuestJourney(9);has(r.nextText,'선행 퀘스트의 보류');eq(r.canGuide,false)
r=G.QuestJourney(10);has(r.detail,'자료가 부족');eq(r.canGuide,false)
r=G.QuestJourney(11);has(r.nextText,'보류 해제');eq(r.canGuide,false)
r=G.QuestJourney(17);has(r.detail,'가방에서');has(r.detail,'시작 물건');eq(r.locationKnown,false)
r=G.QuestJourney(13);has(r.location,'미확인');eq(r.locationKnown,false)
eq(G.QuestJourney(nil),nil);eq(G.QuestJourney(-1),nil);eq(G.QuestJourney(1.5),nil);eq(G:QuestJourney(1).questId,1)
local cache={};local summary=G.JourneySummary({1,2,3,4,5,6,7,8,9,10,11,1},cache)
eq(summary.total,11);eq(summary.nextQuestId,3);eq(summary.counts.accept,1);eq(summary.counts.objective,1);eq(summary.counts.turnin,1);eq(summary.counts.done,1);eq(summary.counts.superseded,1);eq(summary.counts.blocked,6);eq(summary.counts.prerequisite,1);eq(summary.counts.deferred,2);eq(summary.allDone,false);eq(summary.nextAction,cache[3])
local prior=calls[3];G.JourneySummary({3},cache);eq(calls[3],prior,'cache reuse')
eq(G.JourneySummary({12,1}).nextQuestId,1,'id tie stable');eq(G.JourneySummary({1,2}).nextQuestId,2);eq(G.JourneySummary({6,15}).nextQuestId,6);eq(G.JourneySummary({4}).allDone,true);eq(G.JourneySummary({4,5}).allDone,false);eq(G.JourneySummary({}).allDone,false)
local details=table.concat(G.JourneyDetailLines(6),'\n');has(details,'1. 받기');has(details,'2. 목표 수행');has(details,'3. 보고');has(details,'선택된 선행');notHas(details,'다른 택일');eq(#G.JourneyDetailLines(nil),0)
eq(G.db,initial);eq(G.db.guide,route);eq(route.steps,steps);eq(route.index,7);eq(G.db.selectedQuests,checked);eq(checked[1],true);eq(G.db.deferredQuests,deferred);eq(deferred[11],true);eq(G.db.manualProgress,manual);eq(manual.keep,true);eq(G.selection.quest,6)
print('PASS QuestJourney: '..n..' assertions; read-only action stages, prerequisites, honest locations, cache and summaries')
-- Integration: exercise the real route solver, rather than teaching the model
-- a fake chain via the presentation stub above.
local H={}
assert(loadfile(base..'Core.lua'))('ForeverDungeonQuestGuide',H)
assert(loadfile(base..'Data.lua'))('ForeverDungeonQuestGuide',H)
assert(loadfile(base..'QuestData.lua'))('ForeverDungeonQuestGuide',H)
assert(loadfile(base..'QuestJourney.lua'))('ForeverDungeonQuestGuide',H)
local database={
 [1000]={name='택일 뒤 단계',preQuestSingle={1002,1001}},
 [1001]={name='가능한 선행',requiredLevel=50},
 [1002]={name='불가능한 대안',requiredLevel=60},
 [1003]={name='최종 퀘스트',preQuestGroup={1000}},
 [1004]={name='순환 A',preQuestGroup={1005}},
 [1005]={name='순환 B',preQuestGroup={1004}},
}
QuestDB={Get=function(id,key)return database[id] and database[id][key] end}
H.player={level=52,faction='Alliance',classId=7};H.db={deferredQuests={},selectedQuests={[1003]=true},guide={index=2,steps={}},manualProgress={sentinel=true}}
local z=H.QuestJourney(1003);eq(z.code,'locked');eq(z.actionQuestId,1001);eq(z.actionPhase,'accept')
H.activeQuests[1001]={title='가능한 선행',complete=false}
z=H.QuestJourney(1003);eq(z.actionQuestId,1001);eq(z.actionPhase,'objective')
H.activeQuests[1001].complete=true
z=H.QuestJourney(1003);eq(z.actionPhase,'turnin');eq(z.phase,'blocked')
H.activeQuests[1001]=nil;H.sessionTurnins[1001]=true
z=H.QuestJourney(1003);eq(z.actionQuestId,1000);eq(z.actionPhase,'accept')
H.sessionTurnins[1000]=true
z=H.QuestJourney(1003);eq(z.code,'ready');eq(z.actionQuestId,1003)
H.sessionTurnins={};H.db.deferredQuests[1001]=true
z=H.QuestJourney(1003);eq(z.code,'dependentDeferred');eq(z.canGuide,false)
z=H.QuestJourney(1004);eq(z.code,'blocked');eq(z.canGuide,false)
eq(H.db.selectedQuests[1003],true);eq(H.db.guide.index,2);eq(H.db.manualProgress.sentinel,true)
print('PASS QuestJourney including real prerequisite solver: '..n..' total assertions')
-- A summary scans state only; it should not resolve hundreds of NPC/objective
-- locations or live narratives just to count the receive/perform/report badges.
local lazyCache,lazyStates={},{}
local originalJourney=G.QuestJourney
local built={}
G.QuestJourney=function(id,stateCache) built[#built+1]=id;return originalJourney(id,stateCache) end
local lazy=G.JourneySummary({1,2,3,4,5,6,7,8,9,10,11},lazyCache,lazyStates)
eq(#built,1,'summary constructs detail only for the best viable candidate');eq(built[1],3);eq(lazy.nextQuestId,3);eq(lazyCache[1],nil);eq(lazyStates[1].phase,'accept')
local before=calls[1];G.QuestJourney(1,lazyStates);eq(calls[1],before,'visible row reuses summary state');eq(G.JourneyState(6,lazyStates).phase,'blocked')
G.QuestJourney=originalJourney
G.walkthroughRecords={[13]={objective={'가방에서 지급 물건을 꺼내세요.','지정된 장소에서 물건을 사용하세요.'}},[2]={objective={'참고 공략 첫 단계'}}}
local curated=G.QuestJourney(13);has(curated.detail,'지급 물건');has(curated.detail,'지정된 장소');notHas(curated.detail,'자료가 아직 없습니다')
local authoritative=G.QuestJourney(2);has(authoritative.detail,'실제 로그 목표');notHas(authoritative.detail,'참고 공략 첫 단계')
G.specialQuestMeta={[1]={directTurnin=true}}
local direct=G.QuestJourney(1);has(direct.nextText,'보고할 대상');notHas(direct.nextText,'목표 수행')
print('PASS JourneyState lazy summaries and curated fallback: '..n..' total assertions')

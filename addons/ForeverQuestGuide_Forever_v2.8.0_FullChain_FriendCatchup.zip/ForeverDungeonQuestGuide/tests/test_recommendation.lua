local root=arg[1] or './'
local G={db={deferredQuests={[80]=true}},player={level=46}}
local codes={[10]="active",[11]="turnin",[12]="ready",[13]="locked",[14]="blocked",[80]="ready",[20]="ready",[21]="ready",[22]="done"}
local inLog={[10]=true,[11]=true}
local completed={[22]=true}
local points={
 [10]={map=1428,x=.1,y=.1},[11]={map=1428,x=.9,y=.9},
 [12]={map=1428,x=.49,y=.49},[20]={map=1428,x=.49,y=.49},
 [21]={map=1428,x=.8,y=.8},[80]={map=1428,x=.49,y=.49}}
local zones={[10]=1,[11]=1,[12]=2,[13]=2,[14]=2,[20]=2,[21]=2,[22]=3,[80]=2}
function G.RouteAssessment(id)return '상태',codes[id] or 'unknown'end
function G.QuestJourney(id)
 if codes[id]=='locked' then return{actionQuestId=12,canGuide=true,prerequisite=true}end
 if codes[id]=='blocked' then return {actionQuestId=id,canGuide=false} end
 return {actionQuestId=id,canGuide=true}
end
function G.GetQuestZone(id)return zones[id]end
function G.QuestPoint(id)return points[id]end
function G.IsInLog(id)return inLog[id] or false end
function G.IsCompleted(id)return completed[id] or false end
function G.GetQuestLevel(id)return id==21 and 60 or 46 end
function G.PlayerLocation()return {map=1428,x=.5,y=.5}end
assert(loadfile(root..'QuestRecommendation.lua'))('ForeverDungeonQuestGuide',G)
local base=G.RecommendNextQuest({12,10,11,13,14,20,21,22,80})
assert(base and base.questId==11 and base.phaseLabel=='보고','live turn-in wins regardless of distance')
assert(base.reason:find('직선 근접도',1,true),'location caveat absent')
assert(G.RecommendNextQuest({12,10,21}).questId==10,'accepted quest wins over unaccepted')
assert(G.RecommendNextQuest({12,20,21}).questId==12,'same-position, id tie deterministic')
assert(G.RecommendNextQuest({21,20}).questId==20,'nearby and level relevance')
assert(G.RecommendNextQuest({80,14,22})==nil,'deferred/blocked/completed must not be recommended')
local pre=G.RecommendNextQuest({13,14});assert(pre and pre.questId==13 and pre.actionQuestId==12,'safe prerequisite guided')
assert(G.RecommendNextQuest({13,13,80}).evaluated==1,'ids deduplicated, deferred excluded')
assert(G.RecommendNextQuest({})==nil,'empty list')
G.PlayerLocation=function()return {map=1428,approx=true}end
local fallback=G.RecommendNextQuest({12,20,21})
assert(fallback and fallback.hasComparablePosition==false,'map-only position must not claim distance')
assert(not fallback.reason:find('직선 근접도',1,true),'approx coords described as real')
G.PlayerLocation=function()return {map=1455,x=.5,y=.5}end
fallback=G.RecommendNextQuest({12,20})
assert(fallback and not fallback.hasComparablePosition,'cross-map distances are incomparable')
G.PlayerLocation=function()return {map=1428,x=.5,y=.5}end
points[20]={map=1428,x=.5,y=.5,approx=true}
assert(G.RecommendNextQuest({20,21}).questId==21,'approx target must not get fabricated proximity')
assert(G.db.deferredQuests[80]==true and G.player.level==46,'read only DB/player state')
print('PASS Phase3 recommendation: status priority, live log, blocker/defer, level, same-map geometry, uncertainty and deterministic selection')

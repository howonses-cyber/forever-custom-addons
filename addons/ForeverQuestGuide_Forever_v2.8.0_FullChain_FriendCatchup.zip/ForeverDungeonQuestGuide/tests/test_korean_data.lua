-- Data-only load test; no WoW client APIs or runtime database are provided.
local base=arg[1] or './'
local sentinel={existing='preserve'};local G={koQuestNames=sentinel}
local before=collectgarbage('count')
assert(loadfile(base..'KoreanGameData.lua'))('ForeverDungeonQuestGuide',G)
collectgarbage('collect')
local count=0
local function eq(a,b,msg)count=count+1;assert(a==b,(msg or 'mismatch')..': '..tostring(a)..' vs '..tostring(b))end
local function hasKorean(s)
 if type(s)~='string'then return false end
 -- The checked Hangul ranges are three-byte UTF-8 code points. Decode those
 -- locally so this test runs on the actual Lua 5.1 client language.
 for a,b,c in s:gmatch('([\224-\239])([\128-\191])([\128-\191])')do
  local cp=(a:byte()-224)*4096+(b:byte()-128)*64+c:byte()-128
  if(cp>=0xAC00 and cp<=0xD7A3)or(cp>=0x1100 and cp<=0x11FF)then return true end
 end
 return false
end
local expected={quest=5752,npc=10737,object=1896,item=18325}
for kind,n in pairs(expected)do
 local seen=0
 for id,ko in pairs(G.koGameNames[kind])do
  assert(type(id)=='number' and id>0 and id%1==0)
  assert(hasKorean(ko),'not Korean '..kind..':'..id)
  assert(type(G.enGameNames[kind][id])=='string' and G.enGameNames[kind][id]~='','missing English match guard')
  seen=seen+1
 end
 local english=0;for id in pairs(G.enGameNames[kind])do english=english+1;assert(G.koGameNames[kind][id],'unpaired English key')end
 eq(seen,n,kind..' count');eq(english,n,kind..' paired keys');eq(G.koGameDataSource.counts[kind],n)
end
eq(G.koQuestNames,sentinel,'verified overrides must be preserved')
eq(G.koGameNames.quest[3801],'검은무쇠 유물');eq(G.koGameNames.quest[3802],'검은무쇠 유물')
eq(G.koGameNames.quest[4126],'헐레이 블랙브레스');eq(G.koGameNames.quest[4136],'리블리 스크류스피곳')
eq(G.enGameNames.quest[3801],'Dark Iron Legacy')
eq(G.koGameNames.npc[9623],'에이미 01');eq(G.enGameNames.npc[9623],'A-Me 01')
eq(G.koGameNames.npc[9500],'지배인 나그마라','trace must override older base lookup')
eq(G.koGameNames.npc[13716],'회복된 셀레브라스')
eq(G.koGameNames.item[10999],'무쇠지옥');eq(G.enGameNames.item[10999],'Ironfel')
eq(G.koGameNames.item[10662],'충만한 학카르의 알')
eq(G.koGameNames.item[3825],'하급 인내의 비약');eq(G.koGameNames.item[3830],'조제법: 하급 인내의 비약')
eq(G.koGameNames.quest[99670],'제레만에게 돌아가기','Forever trace-added ID coverage')
eq(G.enGameNames.quest[99670],'Return to Jereman')
eq(G.koGameNames.quest[999999999],nil,'unknown custom ID must remain unknown')
local function nums(lines)local a={};for _,s in ipairs(lines)do for n in s:gmatch('%d+')do a[#a+1]=tonumber(n)end end;table.sort(a);return table.concat(a,',')end
local objectiveCount=0
for id,ko in pairs(G.koQuestObjectives)do
 assert(G.koGameNames.quest[id] and G.enQuestObjectives[id],'objective without name/text match guards')
 assert(type(ko)=='table' and #ko>0)
 assert(nums(ko)==nums(G.enQuestObjectives[id]),'numeric mismatch was not withheld '..id)
 assert(not G.koQuestObjectiveWarnings[id],'a withheld objective was shipped')
 objectiveCount=objectiveCount+1
end
eq(objectiveCount,4788)
local warningCount=0;for id in pairs(G.koQuestObjectiveWarnings)do warningCount=warningCount+1;assert(not G.koQuestObjectives[id])end
eq(warningCount,204)
for _,id in ipairs({216,303,484,679})do eq(G.koQuestObjectives[id],nil,'known number disagreement');assert(G.koQuestObjectiveWarnings[id])end
assert(G.koQuestObjectives[3802] and G.enQuestObjectives[3802])
eq(G.koGameDataSource.commit,'4377c981ac368d1593ec92788218e0a689a6a02b')
eq(G.koGameDataSource.flavor,'Forever')
print('PASS KoreanGameData: '..count..' focused checks; all36710 name pairs and4788 objective pairs structurally validated;204 disagreements withheld')

-- Execute the real Forever chat parser/hash importer with small widget/C-API
-- doubles. This is stronger than calling SlashCmdList directly, but is not a
-- live-client taint/keyboard test.
-- Sources: Gethe/wow-ui-source 9dc84f0d3bbae1768ac3405b3716000bd93eda06
-- (1.60.1.70862); all three parser/registry files are byte-identical at
-- c01a87b549bbc19e0f284c1616d18654c91297de (1.60.1.71091).
local native=arg[2] or 'research213/blizzard/'
local current=arg[1] or './'
local baseline=arg[3]
local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,(label or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b))end
local function ok(v,label)checks=checks+1;assert(v,label)end
strsub=string.sub;strfind=string.find;strmatch=string.match;strlen=string.len;strupper=string.upper;strlower=string.lower
strtrim=function(s)return s:match('^%s*(.-)%s*$')end
table.wipe=function(t)for k in pairs(t)do t[k]=nil end;return t end
securecallfunction=function(fn,...)return fn(...)end
secureexecuterange=function(list,fn,...)for k,v in pairs(list)do fn(k,v,...)end end
CreateFromMixins=function(...)
 local result={}
 for i=1,select('#',...)do for k,v in pairs(select(i,...))do result[k]=v end end
 return result
end
ChatFrameConstants={MaxRememberedWhisperTargets=10}
ChatTypeInfo={SYSTEM={r=1,g=1,b=1,id=1},SAY={sticky=1}}
AUTOCOMPLETE_LIST={};MAXEMOTEINDEX=0;ChatTypeGroup={};HELP_TEXT_SIMPLE='unknown slash command'
AutoCompleteEditBox_SetAutoCompleteSource=function()end
DevTools_AddMessageHandler=function()end
ChatFrame1={messages={}};function ChatFrame1:AddMessage(s)self.messages[#self.messages+1]=s end
local nativeNamespace={}
for _,name in ipairs({'SlashCommandsRegistry.lua','ChatFrameUtil.lua','ChatFrameEditBox.lua','ChatFrameSetup.lua'})do
 assert(loadfile(native..name))('Blizzard_ChatFrameBase',nativeNamespace)
end
local controller={}
function controller:SetScript()end
function controller:RegisterEvent()end
CreateFrame=function()return controller end
local function edit(text)
 local e={text=text,shown=true,history={},attributes={chatType='SAY',stickyType='SAY'},chatFrame=ChatFrame1}
 function e:GetText()return self.text end
 function e:SetText(t)self.text=t end
 function e:GetAttribute(k)return self.attributes[k]end
 function e:SetAttribute(k,v)self.attributes[k]=v end
 function e:Hide()self.shown=false end
 function e:AddHistoryLine(line)self.history[#self.history+1]=line end
 return setmetatable(e,{__index=ChatFrameEditBoxBaseMixin})
end
local function submit(text)
 local e=edit(text)
 local success,why=pcall(e.ParseText,e,1)
 return e,success,why
end

-- Reproduce the published failure: UI.lua does not compile in Lua5.1 when
-- buildUI exceeds 60 upvalues, so Events.lua registers a callback whose
-- G.ToggleUI target is nil. Here only that consequence is injected; the
-- separate native5.1 compile test proves the underlying source defect.
local G={}
local baselineMode
if baseline and baseline~='' then
 assert(loadfile(baseline..'Events.lua'))('ForeverDungeonQuestGuide',G)
 baselineMode='archived Events.lua'
else
 -- Compact fixture of our own published blank-command path. This keeps the
 -- released test suite usable without requiring the entire old addon ZIP.
 -- The current production dispatcher below is always loaded and tested.
 SLASH_FOREVERDUNGEONQUESTGUIDE1='/fqg';SLASH_FOREVERDUNGEONQUESTGUIDE2='/퀘스트가이드'
 SLASH_FOREVERDUNGEONQUESTGUIDE3='/fdq';SLASH_FOREVERDUNGEONQUESTGUIDE4='/던전퀘'
 SlashCmdList.FOREVERDUNGEONQUESTGUIDE=function(msg)
  msg=tostring(msg or ''):gsub('^%s+',''):gsub('%s+$','')
  if msg=='' then G.ToggleUI();return end
 end
 baselineMode='compact published nil-UI fixture'
end
local originalHandler=SlashCmdList.FOREVERDUNGEONQUESTGUIDE
eq(type(originalHandler),'function','published Events registers a function')
for _,alias in ipairs({'/fqg','/퀘스트가이드','/fdq','/던전퀘'})do
 local e,success,why=submit(alias)
 eq(success,false,'missing UI callback fails through native parser: '..alias)
 ok(type(why)=='string' and why:find('ToggleUI',1,true),'native error identifies missing UI target: '..alias)
 eq(e.text,alias,'exception leaves original slash text in chat: '..alias)
 eq(e.shown,true,'exception prevents native ClearChat/Hide: '..alias)
 eq(#e.history,0,'exception occurs before native history append: '..alias)
 eq(hash_SlashCmdList[alias:upper()],originalHandler,'native cache contains correct alias: '..alias)
end
eq(rawget(SlashCmdList,'FOREVERDUNGEONQUESTGUIDE'),nil,'native importer wipes raw registry entries')
eq(SlashCmdList.FOREVERDUNGEONQUESTGUIDE,originalHandler,'proxy preserves handler after import')
local unknown,unknownOK=submit('/not_a_registered_test_command')
eq(unknownOK,true,'an unknown command does not throw')
eq(unknown.text,'','unknown command clears native edit text')
eq(unknown.shown,false,'unknown command hides native edit box')
eq(ChatFrame1.messages[#ChatFrame1.messages],HELP_TEXT_SIMPLE,'unknown command prints native help')

-- Show why an own-handler guard is sufficient to let Blizzard finish its
-- existing lifecycle. No editbox hooks, forced ClearChat, table replacements,
-- or blanket hash resets are used.
local reports={}
local function guarded(msg,box)
 local success,why=xpcall(function()return originalHandler(msg,box)end,function(err)return tostring(err)end)
 if not success then reports[#reports+1]=why end
end
SlashCmdList.FOREVERDUNGEONQUESTGUIDE=guarded
for _,alias in ipairs({'/fqg','/퀘스트가이드'})do
 local e,success=submit(alias)
 eq(success,true,'guarded callback returns to native parser: '..alias)
 eq(e.text,'','native ClearChat runs after guarded error: '..alias)
 eq(e.shown,false,'native lifecycle hides input after guarded error: '..alias)
 eq(e.history[1],alias,'native history records guarded command: '..alias)
 eq(hash_SlashCmdList[alias:upper()],guarded,'late own-key registration refreshes native hash: '..alias)
end
eq(#reports,2,'guard exposes both command errors')

-- Restore a working UI target and retain the same actual Events command
-- parser. Both writing systems and uppercase ASCII dispatch normally.
local opened=0
G.ToggleUI=function()opened=opened+1 end
for _,alias in ipairs({'/fqg','/FQG','/퀘스트가이드','/fdq','/던전퀘'})do
 local e,success=submit(alias)
 eq(success,true,'working UI callback: '..alias)
 eq(e.text,'','working command clears input: '..alias)
 eq(e.history[1],alias,'working command native history: '..alias)
end
eq(opened,5,'all aliases execute the UI action exactly once')
eq(#reports,2,'successful opens do not manufacture diagnostics')

-- A different addon command remains registered through all imports/updates.
SLASH_CHATDISPATCHOTHER1='/chatdispatchother'
local other=0;SlashCmdList.CHATDISPATCHOTHER=function()other=other+1 end
local unrelated,otherOK=submit('/chatdispatchother')
eq(otherOK,true,'unrelated command remains executable');eq(other,1,'unrelated handler executed once');eq(unrelated.text,'','unrelated command keeps native cleanup')

-- Verify the actual replacement, not only the minimal guard demonstration.
-- Core/Events are the production modules; action/UI widgets are controlled
-- here so the native parser is exercised on success and every error path.
local live={}
assert(loadfile(current..'Core.lua'))('ForeverDungeonQuestGuide',live)
local reported,displayed={},{ }
live.Print=function(s)displayed[#displayed+1]=s end
debugstack=function()return'fixture command stack'end
geterrorhandler=function()return function(s)reported[#reported+1]=s end end
assert(loadfile(current..'Events.lua'))('ForeverDungeonQuestGuide',live)
eq(SlashCmdList.FOREVERDUNGEONQUESTGUIDE,live.HandleSlashCommand,'actual production handler registered')
local progress={selectedQuests={[3802]=true},deferredQuests={[4126]=true},manualProgress={keep=true}}
live.db=progress
for _,alias in ipairs({'/fqg','/퀘스트가이드','/fdq','/던전퀘'})do
 local e,success=submit(alias)
 eq(success,true,'actual guard catches missing ToggleUI: '..alias)
 eq(e.text,'','actual guard leaves cleanup to native parser: '..alias)
 eq(e.history[1],alias,'actual guard preserves native history: '..alias)
 eq(e.shown,false,'actual guarded failure hides native input: '..alias)
 eq(live.lastCommandError.version,live.version,'diagnostic records actual version')
 ok(live.lastCommandError.message:find('ToggleUI',1,true),'diagnostic records concrete missing callback')
 eq(live.lastCommandError.stack,'fixture command stack','diagnostic preserves available stack')
 eq(hash_SlashCmdList[alias:upper()],live.HandleSlashCommand,'native import updates actual alias handler')
end
eq(#displayed,4,'all actual failures report in chat');eq(#reported,4,'all actual failures reach error handler')
eq(live.db,progress,'diagnostics retain progress table identity')
eq(progress.selectedQuests[3802],true,'diagnostics retain checked quest')
eq(progress.deferredQuests[4126],true,'diagnostics retain deferred quest')
eq(progress.manualProgress.keep,true,'diagnostics retain saved progress')
eq(progress.lastCommandError,nil,'diagnostic remains session-only')

-- Even broken third-party chat/error presentation must not re-break Enter.
live.Print=function()error('chat presentation failed')end
geterrorhandler=function()return function()error('error presentation failed')end end
local reporterFailure,reporterOK=submit('/fqg')
eq(reporterOK,true,'failing chat and error reporters are contained');eq(reporterFailure.text,'','native cleanup survives reporter failures')
geterrorhandler=function()error('error handler lookup failed')end
local lookupFailure,lookupOK=submit('/퀘스트가이드')
eq(lookupOK,true,'failing geterrorhandler lookup is contained');eq(lookupFailure.text,'','native cleanup survives reporter lookup failure')
debugstack=function()error('stack unavailable')end
local stackFailure,stackOK=submit('/fqg')
eq(stackOK,true,'missing debug stack is contained');eq(stackFailure.text,'','native cleanup survives debug stack failure');eq(live.lastCommandError.stack,nil,'failed stack collection is not fabricated')

local actualOpened=0
live.ToggleUI=function()actualOpened=actualOpened+1 end
local priorError=live.lastCommandError
for _,alias in ipairs({'/fqg','/FQG','/퀘스트가이드','/fdq','/던전퀘'})do
 local e,success=submit(alias)
 eq(success,true,'actual production success: '..alias)
 eq(e.text,'','actual successful command clears input: '..alias)
 eq(e.history[1],alias,'actual successful command records history: '..alias)
end
eq(actualOpened,5,'actual production opens action exactly once for each alias')
eq(live.lastCommandError,priorError,'successful dispatch preserves the last real diagnostic')
local finalOther,finalOtherOK=submit('/chatdispatchother')
eq(finalOtherOK,true,'actual guard preserves unrelated command dispatch');eq(other,2,'unrelated handler still executes once');eq(finalOther.text,'','unrelated command still has native cleanup')

-- Combined original regression: load the actual complete addon using the
-- stricter widget contracts, then send both commands through the real native
-- parser into the real UI implementation. G.ToggleUI is never stubbed here.
local Mock=assert(loadfile(current..'tests/mock_wow.lua'))().install()
assert(loadfile(current..'tests/strict_api.lua'))()(Mock)
GetTime=function()return 100 end
GetLocale=function()return'koKR'end
UnitRace=function()return'드워프','Dwarf',3 end
Minimap=CreateFrame('Frame','Minimap',UIParent);Minimap:SetSize(140,140)
QuestDB=nil;ForeverDungeonQuestGuideDB=nil
ChatTypeInfo={SYSTEM={r=1,g=1,b=1,id=1},SAY={sticky=1}}
ChatFrame1={messages={}};function ChatFrame1:AddMessage(s)self.messages[#self.messages+1]=s end
local fullNative={}
for _,name in ipairs({'SlashCommandsRegistry.lua','ChatFrameUtil.lua','ChatFrameEditBox.lua','ChatFrameSetup.lua'})do
 assert(loadfile(native..name))('Blizzard_ChatFrameBase',fullNative)
end
local clientErrors={}
debugstack=function()return'full addon native dispatch stack'end
geterrorhandler=function()return function(message)clientErrors[#clientErrors+1]=message end end
local actual={};local loaded=0
for line in io.lines(current..'ForeverDungeonQuestGuide.toc')do
 local name=line:match('^([^#].-%.lua)%s*$')
 if name then
  local chunk,why=loadfile(current..name);assert(chunk,why)
  local success,message=pcall(chunk,'ForeverDungeonQuestGuide',actual)
  ok(success,'full TOC module '..name..': '..tostring(message));loaded=loaded+1
 end
end
local eventController=assert(Mock.find(function(o)return o.scripts.OnEvent and o.scripts.OnUpdate end),'actual event controller missing')
eventController.scripts.OnEvent(eventController,'ADDON_LOADED','ForeverDungeonQuestGuide')
eventController.scripts.OnEvent(eventController,'PLAYER_LOGIN')
eventController.scripts.OnUpdate(eventController,.51)
eq(actual.IsUIShown(),false,'full addon starts with main UI closed')
eq(type(actual.ToggleUI),'function','native engine compiled actual UI implementation')
eq(actual.UIJourneyWidgets,nil,'first native command must build the untouched UI')
for _,alias in ipairs({'/퀘스트가이드','/fqg'})do
 if actual.IsUIShown() then actual.ShowUI(false)end
 for _,visible in ipairs({true,false,true})do
  local e,success,why=submit(alias)
  ok(success,'full addon native command '..alias..': '..tostring(why))
  eq(actual.IsUIShown(),visible,'actual UI first-open/close/reopen: '..alias)
  eq(e.text,'','full addon native command clears edit text: '..alias)
  eq(e.history[1],alias,'full addon native command records history: '..alias)
  eq(e.shown,false,'full addon native command closes chat input: '..alias)
  eq(actual.lastCommandError,nil,'successful actual UI command produces no guarded error')
 end
end
eq(#clientErrors,0,'full TOC and actual UI dispatch produce no error reports')
print('PASS actual Forever native slash parser: '..checks..' checks; '..loaded..' real addon modules, actual Korean/English UI open-close-reopen, guarded native cleanup, proxy/hash import; baseline='..baselineMode..' (mock widget/C APIs only)')

#!/usr/bin/env python3
"""Fetch pinned Blizzard UI test inputs; never include these in the addon ZIP.

The publisher mirrors extracted client UI sources. Git blob hashes come from
that exact commit's GitHub tree. Only these four public source files are read;
the fetcher does not run downloaded code or install anything into the game.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from pathlib import Path
import urllib.request

COMMIT = '9dc84f0d3bbae1768ac3405b3716000bd93eda06'
PREFIX = 'Interface/AddOns/Blizzard_ChatFrameBase/Shared/'
FILES = {
    'SlashCommandsRegistry.lua': '91e5db054db955f8dc57c917b3e5eb85929c71b3',
    'ChatFrameUtil.lua': '89f17b78581dbf30fd3241136e4969dc4f89c9a6',
    'ChatFrameEditBox.lua': '0fd0fa7a878578b9a2f31f66159c6de357ef9c5e',
    'ChatFrameSetup.lua': 'af6a133f320ad7550c15bbcd986fd6c5af7398a3',
}


def read_one(name):
    url = f'https://raw.githubusercontent.com/Gethe/wow-ui-source/{COMMIT}/{PREFIX}{name}'
    with urllib.request.urlopen(url, timeout=30) as response:
        data = response.read()
    sha = hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()
    if sha != FILES[name]:
        raise ValueError(f'{name}: expected Git blob {FILES[name]}, received {sha}')
    return name, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True, help='External test-cache directory; not the addon folder')
    args = parser.parse_args()
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(read_one, FILES))
    args.destination.mkdir(parents=True, exist_ok=True)
    for name, data in results:
        (args.destination / name).write_bytes(data)
        print(f'VERIFIED {name}: {len(data)} bytes, Git blob {FILES[name]}')
    print(f'Forever 1.60.1.70862 native chat fixtures: {args.destination.resolve()}')


if __name__ == '__main__':
    main()

-- Phase4: synthetic quest records only; no invented Forever quest claims.
local root=arg[1] or './'
local Mock=assert(loadfile(root..'tests/mock_wow.lua'))().install()
local G={}
local function load(name) assert(loadfile(root..name))('ForeverDungeonQuestGuide',G) end
local function eq(actual,expected,why) assert(actual==expected,(why or 'mismatch')..': '..tostring(actual)..' != '..tostring(expected)) end
UnitRace=function() return '드워프','Dwarf',3 end
load('Core.lua');load('Data.lua');load('VerifiedRoutes.lua');load('QuestData.lua');load('FactionFilter.lua');load('QuestSearch.lua');load('QuestDiagnostics.lua');load('QuestStatus.lua')
G.PlayerRefresh();G.StartSaved()
local unavailable=G.QuestDataDiagnostics()
eq(unavailable.code,'NO_GET','DB getter missing')
assert(unavailable.help:find('QuestieDB',1,true),'no-action diagnostics')
local records,ids={},{}
for id=1,830 do
 records[id]={name='모의 검색 퀘스트 '..id,questLevel=50+id%3,zoneOrSort=46,requiredLevel=45}
 ids[#ids+1]=id
end
records[900]={name='호드 수락 퀘스트',zoneOrSort=46,requiredRaces=2,requiredLevel=61,requiredClasses=1}
records[901]={name='전사 전용',zoneOrSort=46,requiredClasses=1,requiredLevel=40}
records[902]={name='레벨 제한 퀘스트',zoneOrSort=46,requiredLevel=60}
QuestDB={Get=function(id,field)return records[id] and records[id][field]end,GetAllIds=function()return ids end}
G.RestartQuestIndex();G.TickQuestIndex(1000)
assert(G.questIndex.ready,'index must finish')
local ready=G.QuestDataDiagnostics()
eq(ready.code,'READY','DB getter and IDs ready');assert(ready.details[#ready.details]:find('조치:',1,true))
local first,n,building=G.SearchQuestIds('all','모의 검색',{limit=180,offset=0,sortMode='id'})
eq(n,830,'total beyond previous 600');eq(#first,180);eq(first[1],1);eq(first[#first],180)
local seen={}
for page=0,4 do
 local batch,total=G.SearchQuestIds('all','모의 검색',{limit=180,offset=page*180,sortMode='id'})
 eq(total,830)
 for _,id in ipairs(batch)do assert(not seen[id],'overlapping page '..id);seen[id]=true end
end
local nSeen=0;for _ in pairs(seen)do nSeen=nSeen+1 end;eq(nSeen,830,'no skipped records')
local beyond,allCount=G.SearchQuestIds('all','모의 검색',{limit=180,offset=720})
eq(allCount,830);eq(#beyond,110,'last partial page');eq(beyond[1],721);eq(beyond[#beyond],830)
local ranked=G.SearchQuestIds('all','모의 검색',{limit=180,sortMode='level'})
for _,id in ipairs(ranked)do eq(records[id].questLevel,50,'level sorting applies before paging')end
local near=G.SearchQuestIds('all','모의 검색',{limit=180,levelFilter='near'})
eq(#near,180,'near-level browsing remains paged')
-- The filter is browsing-only. A genuine active log wins despite stale race,
-- class and minimum-level DB masks.
assert(not G.IsEligibleQuest(900),'opposite faction not eligible while unaccepted')
eq(G.QuestFaction(900),'Horde','race mask to faction')
assert(not G.IsEligibleQuest(901),'class mismatch blocks unaccepted')
local low=G.RouteHardBlock(902)
assert(type(low)=='string' and low:find('레벨 부족',1,true),'minimum acceptance level gate')
G.activeQuests[900]={title='호드 수락 퀘스트',complete=false}
assert(G.IsEligibleQuest(900),'actual accepted log must override stale masks')
assert(G.QuestMatchesFactionFilter(900),'actual accepted quest remains visible for own faction')
local fact=G.QuestEligibilityFacts(900)
assert(fact.accepted and fact.minimum==61 and fact.faction=='Horde','facts separate log from DB mask')
G.activeQuests[900]=nil
-- A missing completion API cannot be interpreted as a negative completed flag.
C_QuestLog=nil;IsQuestFlaggedCompleted=nil
local unknown=G.QuestListStatus(1)
eq(unknown.key,'unknown','missing reward API unknown')
eq(unknown.historyReason,'no_history_api','explicit missing API cause')
assert(unknown.detail:find('미수락과 완료를 구분',1,true),'no unsupported conclusion')
C_QuestLog={IsQuestFlaggedCompleted=function()return false end}
eq(G.QuestListStatus(1).key,'unaccepted','verified negative completed record')
C_QuestLog.IsQuestFlaggedCompleted=function()error('test only')end
local failed=G.QuestListStatus(1)
eq(failed.key,'unknown','broken completed flag is not negative')
eq(failed.historyReason,'history_api_error','API error category')
-- Hard failures and browsing did not delete the character settings.
assert(type(G.db.selectedQuests)=='table' and type(G.db.deferredQuests)=='table','saved state preserved')
print('PASS Phase4: indexed full-set paging and sorting, diagnostic API states, evidence-only unknown reasons, real log precedence, race/class/level limits')

-- V2.8.0 graph + catch-up + opt-in private protocol. No live character/WTF.
local root=arg[1] or './'
local Mock=assert(loadfile(root..'tests/mock_wow.lua'))().install()
local G={db={groupChains=true,chainCollapsed={},selectedQuests={[4024]=true},deferredQuests={[91]=true},manualProgress={[55]=true},guide={steps={{quest=4024}}},catchupShareEnabled=false},
 activeQuests={},sessionTurnins={},selection={quest=4024},player={faction='Alliance',level=54},API={}}
local function load(file) assert(loadfile(root..file))('ForeverDungeonQuestGuide',G) end
local N={ [3441]='성스러운 복수',[3442]='완전무결한 불꽃',[3443]='횃불 자루 만들기',[3452]='불꽃의 테두리',
 [3453]='응보의 횃불 1',[3454]='응보의 횃불 2',[3462]='견습기사 몰트레이크',[3463]='불 공격!',[3481]='만물 상자...',
 [4022]='화염의 맛 (허물)',[4023]='화염의 맛 (다른 경로)',[4024]='화염의 맛 (나락)',[4128]='라그나르 썬더브루',[4126]='헐레이 블랙브레스' }
local DB={ [4024]={preQuestSingle={4022,4023}},[4022]={preQuestGroup={3481}},[4128]={breadcrumbForQuestId=4126} }
QuestDB={Get=function(id,field) return DB[id] and DB[id][field] or (field=='name' and N[id] or nil) end}
local states={[3441]='D',[3442]='D',[3443]='A',[4128]='D',[4024]='A'}
G.Ready=function()return true end
G.DBGet=function(_,id,field) return QuestDB.Get(id,field) end
G.QuestPrerequisite=function(id)
 local d=DB[id] or {};return d.preQuestGroup or {},d.preQuestSingle or {}
end
G.GetQuestName=function(id) return N[id] or ('퀘스트 # '..id) end
G.IsQuestBrowseVisible=function()return true end
G.QuestListMeta=function()return {level=55} end
G.RouteAssessment=function(id)return states[id] or 'ready',states[id] or 'ready' end
G.IsCompleted=function(id)return states[id]=='D' end
G.IsRouteSatisfied=function(id)return states[id]=='D' end
G.IsInLog=function(id)return states[id]=='A' or states[id]=='T' end
G.IsReadyToTurnIn=function(id)return states[id]=='T' end
G.QuestPoint=function(id,stage)
 if id==3441 then return {map=1427,x=.3906,y=.3899} end
 if id==4126 then return {map=1426,x=.468,y=.524} end
 return nil
end
G.MapDisplayName=function(id)return id==1427 and '이글거리는 협곡' or id==1426 and '던 모로' or ('지도 '..id)end
G.QuestRegionHint=function()return '자료 미확인 지역' end
G.QuestObjectiveText=function(id)return id==4024 and '밸가르 처치 후 허물 사용' or '퀘스트 목표 확인' end
G.QuestContactName=function(id,stage)return id==3441 and '칼라란 윈드블레이드' or id==4126 and '라그나르 썬더브루' or nil end
G.UIButton=function(parent,title,w,h,click)
 local b=CreateFrame('Button',nil,parent);b:SetSize(w,h);b:SetText(title);b:SetScript('OnClick',click);return b
end
G.Print=function()end
G.questIndex={available=true,ready=true}
load('QuestChainGraph.lua')
load('QuestChains.lua')
load('CatchupGuide.lua')
local n=0
local function check(value,message) assert(value,message);n=n+1 end
local function row(...) local t={};for _,id in ipairs({...})do t[#t+1]={kind='quest',id=id}end;return t end
local function familyHas(f,id) for _,q in ipairs(f.ids)do if q==id then return true end end end
local rng=G.QuestNarrativeFamily(4126)
check(#rng.ids==2 and familyHas(rng,4128) and familyHas(rng,4126),'referral + dungeon quest in same family')
check(G.NarrativeEdgeKind(4128,4126)=='breadcrumb','optional referral never mandatory')
local grouped=G.QuestChainRows(row(4128,4126),'dungeon',true)
check(grouped[1].kind=='chain' and grouped[1].count==2,'BRD visually grouped')
check(grouped[1].done==1 and not grouped[1].linear,'optional chain not hard linear')
local flame=G.QuestNarrativeFamily(4024)
check(#flame.ids==12 and familyHas(flame,3441) and familyHas(flame,3481) and familyHas(flame,4022) and familyHas(flame,4023),'full 12-node story')
check(flame.branch and flame.optional and not flame.linear,'OR path flagged as branch')
check(G.NarrativeEdgeKind(4022,4024)=='alternative' and G.NarrativeEdgeKind(4023,4024)=='alternative','molt alternatives')
local tiny=G.QuestChainRows(row(4024),'dungeon',true)
check(tiny[1].kind=='chain' and tiny[1].count==12,'dungeon-only root expands into outdoor story context')
-- In-game completion false is known 'N'; lack of API is never falsely 'done'.
local flags={[3441]=true,[3442]=true,[4128]=true}
C_QuestLog={IsQuestFlaggedCompleted=function(id)return flags[id]==true end}
check(G.CatchupSelfState(3441)=='D' and G.CatchupSelfState(3443)=='A' and G.CatchupSelfState(4024)=='A','self statuses')
local friendStates={}
for _,id in ipairs(flame.ids) do friendStates[id]='N' end
friendStates[3441]='D';friendStates[3442]='D';friendStates[3443]='A'
G.CatchupPeerSnapshot=function(peer,id)
 return peer=='동료' and id==4024 and {quests=friendStates} or nil,'미공유'
end
local saved={selected=G.db.selectedQuests,deferred=G.db.deferredQuests,manual=G.db.manualProgress,guide=G.db.guide}
local report,data=G.CatchupReport(4024,'동료')
local combined=table.concat(report,'\n')
check(data.peerKnown and data.counts.friend==2 and data.counts.activeFriend==3443,'friend progress evidenced')
check(combined:find('3443',1,true) and combined:find('4128',1,true)==nil,'only correct family summarized')
check(combined:find('택일',1,true) and combined:find('진행 기록과 맞는 연계 경로',1,true),'friend route proposal preserves alternatives')
check(G.CatchupStageLocation(3441,'accept'):find('칼라란 윈드블레이드',1,true),'receives real starting NPC')
local story=data.storyPath
check(story and #story.steps==11 and story.remaining>0,'friend observed 3443 progress yields one story path, not both exclusive paths')
local storyIds={}
for _,entry in ipairs(story.steps) do storyIds[entry.id]=true end
check(storyIds[3441] and storyIds[3443] and storyIds[3452] and storyIds[4022] and storyIds[4024] and not storyIds[4023],'catch-up path explicitly chooses evidenced 4022 branch')
local words=table.concat(select(1,G.CatchupChatLines(4024,'동료')),' ')
check(words:find('3443',1,true) and words:find('3452',1,true),'friend-facing instructions include middle story stages, not just hard prerequisites')
local guessed=G.CatchupStoryPath(4024,{},G.CatchupRequiredTrace(4024,{}))
check(guessed and #guessed.branches==1 and #guessed.branches[1].options==2,'unknown friend status retains both possible branches')
local realPrereq=G.QuestPrerequisite
G.QuestPrerequisite=function()return {},{}end
local fallback=G.CatchupRequiredTrace(4024,{})
check(#fallback.alternatives==1 and #fallback.alternatives[1].ids==2,'verified one-of alternative is retained when optional DB does not provide prerequisites')
G.QuestPrerequisite=realPrereq
local jumped=G.CatchupStoryPath(4024,{[4024]='A',[3441]='N'})
check(jumped.remaining==1 and jumped.nextIndex==#jumped.steps,'later accepted quest never forces old unknown chapters to be redone')
local reached=G.CatchupStoryPath(4024,{[4024]='D'})
check(reached.remaining==0 and reached.goalReached,'reported meet-up goal never claims preceding chapters still need completion')
local referral=G.CatchupStoryPath(4126,{[4128]='D',[4126]='N'})
check(referral and #referral.steps==2 and referral.steps[1].optional,'Ragnar is an optional breadcrumb, not a mandatory dungeon predecessor')
local req=data.required
check(#req.alternatives==1 and req.alternatives[1].recommended==4022,'friend mid long route selects evidence-backed alternative')
local missingPlan=G.CatchupRequiredTrace(4024,{})
check(missingPlan.alternatives[1].recommended==nil and missingPlan.uncertain,'unknown friend never picks arbitrary branch')
check(G.db.selectedQuests==saved.selected and G.db.deferredQuests==saved.deferred and G.db.guide==saved.guide,'read only no state mutation')
-- Other party side receives only on explicit opt-in; every request is private.
local now=0
GetTime=function()return now end
local outgoing={};local chat={};local roster={'동료'}
UnitName=function(unit)
 if unit=='player' then return '나' end
 local index=tonumber(tostring(unit):match('^party(%d+)$'))
 return index and roster[index] or nil
end
GetNumPartyMembers=function()return #roster end
IsInRaid=function()return false end
C_ChatInfo={RegisterAddonMessagePrefix=function(prefix)check(prefix=='FQGuideCatch8','separate prefix');return 0 end,
 SendAddonMessage=function(prefix,text,channel,receiver)
  outgoing[#outgoing+1]={prefix,text,channel,receiver}
  return 0
 end}
SendChatMessage=function(text,channel,language,target)chat[#chat+1]={text,channel,target}end
load('CatchupSync.lua')
check(not G.CatchupShareReceive('FQGuideCatch8','8|Q|2|4126','WHISPER','동료'),'opt-out input blocked')
check(#outgoing==0,'opt-out no output')
G.CatchupShareSetEnabled(true)
check(not G.CatchupShareReceive('FQGuideCatch8','8|Q|2|4126','WHISPER','외부인'),'outsider blocked')
check(not G.CatchupShareReceive('FQGuideCatch8','8|Q|2|4126','PARTY','동료'),'only targeted whisper')
check(G.CatchupShareReceive('FQGuideCatch8','8|Q|2|4126','WHISPER','동료'),'valid opt-in query accepted')
now=2;G.CatchupShareTick(2)
check(#outgoing==1 and outgoing[1][3]=='WHISPER' and outgoing[1][4]=='동료','private reply delivery')
check(outgoing[1][2]:find('4128=D',1,true) and outgoing[1][2]:find('4126=N',1,true),'queried chain status only')
check(not outgoing[1][2]:find('3441',1,true),'no unrelated completed history exported')
now=20
local ok,why=G.CatchupRequest(4024,'동료')
check(ok and outgoing[#outgoing][2]:find('^8|Q|'),'explicit friend query')
local query=outgoing[#outgoing][2]
local nonce,quest=query:match('^8|Q|(%d+)|(%d+)$')
check(nonce and tonumber(quest)==4024,'query uses requested quest only')
local tokens={}
for _,id in ipairs(flame.ids)do tokens[#tokens+1]=id..'='..friendStates[id] end
local chunks,current={},''
for _,token in ipairs(tokens)do if #current>0 and #current+#token+1>125 then chunks[#chunks+1]=current;current='' end
 current=current=='' and token or current..','..token
end
if current~='' then chunks[#chunks+1]=current end
check(not G.CatchupShareReceive('FQGuideCatch8','8|S|999|4024|1|1|4024=D','WHISPER','동료'),'unsolicited or mismatched nonce rejected')
for i,chunk in ipairs(chunks)do
 check(G.CatchupShareReceive('FQGuideCatch8','8|S|'..nonce..'|4024|'..i..'|'..#chunks..'|'..chunk,'WHISPER','동료'),'valid response chunk')
end
local fresh=G.CatchupPeerSnapshot('동료',4024)
check(fresh and fresh.quests[3443]=='A' and fresh.quests[4024]=='N','friend real response in RAM only')
check(G.db.catchupShareEnabled and not G.db.partyShareEnabled,'different opt-in flag from old status share')
load('CatchupUI.lua')
check(G.ShowCatchupUI(4024),'main catch-up window creates and opens')
local popup=Mock.names.ForeverDungeonQuestGuideCatchup
check(popup and popup:IsShown() and Mock.visibleText(popup):find('3443',1,true),'popup shows detailed quest progress from selected chain')
check(Mock.button('친구에게 따라잡기 안내 보내기')~=nil,'manual private-share action in popup')
popup:Hide()
check(G.ShowCatchupUI(4024) and popup:IsShown(),'catch-up reopens without creating duplicate UI')
local sent,reason=G.CatchupShareSendChat(4024,'동료')
check(sent,'manual catch-up chat after query')
now=22;G.CatchupShareTick(2)
check(#chat>=1 and chat[1][2]=='WHISPER' and chat[1][3]=='동료','explicit private chat queued')
roster={'새동료'};G.CatchupShareRosterChanged()
check(G.CatchupPeerSnapshot('동료',4024)==nil,'roster exit expires snapshots')
G.CatchupShareSetEnabled(false)
check(G.CatchupPeerSnapshot('새동료',4024)==nil,'opt-out cannot read')
check(G.db.selectedQuests==saved.selected and G.db.deferredQuests==saved.deferred and G.db.manualProgress==saved.manual,'no WTF state touched')
print('PASS V2.8.0: '..n..' story graph, branch, party consent, privacy, resume regression assertions')

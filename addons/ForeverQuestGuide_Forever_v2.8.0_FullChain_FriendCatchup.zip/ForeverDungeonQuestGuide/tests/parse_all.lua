local root=arg[1] or './'
local count=0
for l in io.lines(root..'ForeverDungeonQuestGuide.toc') do
 local file=l:match('^([^#].-%.lua)%s*$')
 if file then local ok,err=loadfile(root..file);assert(ok,err);count=count+1 end
end
print('PASS: '..count..' source Lua modules parsed by supplemental Lua 5.4 (NOT Lua 5.1 CI)')

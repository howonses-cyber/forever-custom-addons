-- Diagnostic contracts, intentionally separate from production. These check
-- widget types and argument shapes, not native rendering or a whole client.
return function(Mock)
 local Widget=getmetatable(UIParent).__index
 assert(type(Widget)=='table','strict adapter expects shared mock method table')
 local unpackValues=table.unpack or unpack
 function Widget:GetNumPoints()return #self.points end
 function Widget:GetObjectType()return self.kind end
 function Widget:GetName()return self.name end
 function Widget:GetChildren()
  local children={};for _,child in ipairs(self.children)do
   if child.kind~='Texture' and child.kind~='FontString' then children[#children+1]=child end
  end
  return unpackValues(children)
 end
 function Widget:SetMaxLetters(n)assert(type(n)=='number');self.maxLetters=n end
 local function set(words) local t={};for k in words:gmatch('%S+') do t[k]=true end;return t end
 local region=set('SetSize SetWidth SetHeight GetWidth GetHeight SetPoint GetPoint GetNumPoints ClearAllPoints SetAllPoints Show Hide SetShown IsShown IsVisible SetAlpha SetScale GetScale GetEffectiveScale GetCenter SetParent GetParent GetObjectType GetName')
 local frame=set('CreateTexture CreateFontString SetScript GetScript HookScript GetChildren SetClampedToScreen SetMovable EnableMouse EnableMouseWheel RegisterForDrag SetFrameStrata GetFrameLevel SetFrameLevel SetToplevel StartMoving StopMovingOrSizing SetHitRectInsets RegisterEvent UnregisterEvent UnregisterAllEvents SetBackdrop SetBackdropColor SetBackdropBorderColor SetResizable SetResizeBounds SetMinResize SetMaxResize SetUserPlaced SetClipsChildren Click Wheel')
 local text=set('SetText GetText SetFont GetFont SetTextColor SetFontObject SetSpacing SetWordWrap SetMaxLines SetJustifyH SetJustifyV GetStringHeight GetStringWidth')
 local texture=set('SetTexture SetTexCoord SetColorTexture SetVertexColor SetDrawLayer')
 local button=set('Enable Disable SetEnabled IsEnabled SetFontString GetFontString SetNormalTexture SetPushedTexture SetHighlightTexture SetDisabledTexture SetNormalFontObject SetHighlightFontObject SetDisabledFontObject SetText GetText RegisterForClicks')
 local check=set('SetChecked GetChecked')
 local slider=set('SetMinMaxValues GetMinMaxValues SetValue GetValue SetThumbTexture GetThumbTexture SetOrientation SetValueStep SetObeyStepOnDrag Enable Disable SetEnabled IsEnabled')
 local edit=set('SetAutoFocus SetFocus ClearFocus HasFocus SetTextInsets SetMaxLetters')
 local scroll=set('SetScrollChild GetScrollChild SetVerticalScroll GetVerticalScroll')
 local tooltip=set('SetOwner AddLine AddDoubleLine ClearLines SetText GetText')
 function Mock.methodAllowed(kind,key)
  if region[key] then return true end
  if kind=='FontString' then return text[key] or key=='SetDrawLayer' end
  if kind=='Texture' then return texture[key] end
  if frame[key] then return true end
  if kind=='Button' or kind=='CheckButton' then return button[key] or (kind=='CheckButton' and check[key]) end
  if kind=='Slider' then return slider[key] end
  if kind=='EditBox' then return text[key] or edit[key] end
  if kind=='ScrollFrame' then return scroll[key] end
  if kind=='GameTooltip' then return tooltip[key] end
  return false
 end
 local function wrap(name,check)
  local old=assert(Widget[name],name)
  Widget[name]=function(self,...) check(self,...);return old(self,...) end
 end
 local function number(v,label)
  assert(type(v)=='number' and v==v and v~=math.huge and v~=-math.huge,(label or 'value')..' must be finite number: '..tostring(v))
 end
 wrap('SetSize',function(_,w,h)number(w,'width');number(h,'height')end)
 for _,name in ipairs({'SetWidth','SetHeight','SetScale','SetAlpha','SetValue','SetValueStep','SetVerticalScroll','SetSpacing','SetFrameLevel'}) do
  wrap(name,function(_,v)number(v,name)end)
 end
 wrap('SetMinMaxValues',function(_,a,b)number(a);number(b);assert(a<=b,'invalid slider range')end)
 local anchors=set('TOPLEFT TOP TOPRIGHT LEFT CENTER RIGHT BOTTOMLEFT BOTTOM BOTTOMRIGHT')
 wrap('SetPoint',function(self,a,b,c,d,e)
  assert(anchors[a],'invalid anchor '..tostring(a))
  if type(b)=='number' then number(c,'y offset');assert(d==nil and e==nil,'invalid anchor overload')
  else
   assert(b==nil or type(b)=='string' or (type(b)=='table' and b.kind),'invalid relative region')
   if c then assert(anchors[c],'invalid relative anchor '..tostring(c))end
   if d then number(d,'x offset')end;if e then number(e,'y offset')end
  end
 end)
 wrap('SetAllPoints',function(_,target)assert(target==nil or type(target)=='string' or (type(target)=='table' and target.kind),'invalid target region')end)
 wrap('SetFontString',function(_,font)assert(font and font.kind=='FontString','Button font must be FontString')end)
 wrap('SetText',function(self,value)
  assert(value==nil or type(value)=='string' or type(value)=='number','invalid text value '..type(value))
 end)
 for _,name in ipairs({'SetColorTexture','SetTextColor','SetVertexColor'}) do
  wrap(name,function(_,r,g,b,a)number(r);number(g);number(b);if a~=nil then number(a)end end)
 end
 wrap('SetScript',function(_,event,fn)assert(type(event)=='string' and (type(fn)=='function' or fn==nil),'invalid script callback')end)
 wrap('RegisterEvent',function(_,event)
  assert(type(event)=='string','event must be string')
 end)
 -- Install class-specific method exposure on existing and future objects.
 -- There is no catch-all no-op for unknown or wrong-widget methods.
 local function decorate(widget)
  return setmetatable(widget,{__index=function(self,key)
   local value=Widget[key]
   if value and not Mock.methodAllowed(self.kind,key)then return nil end
   return value
  end})
 end
 local createFrame=CreateFrame
 CreateFrame=function(...)return decorate(createFrame(...))end
 for _,name in ipairs({'CreateTexture','CreateFontString'})do
  local method=Widget[name];Widget[name]=function(self,...)return decorate(method(self,...))end
 end
 local setThumb=Widget.SetThumbTexture
 Widget.SetThumbTexture=function(self,...)setThumb(self,...);decorate(self.thumb)end
 for _,object in ipairs(Mock.objects)do decorate(object)end
 return Mock
end

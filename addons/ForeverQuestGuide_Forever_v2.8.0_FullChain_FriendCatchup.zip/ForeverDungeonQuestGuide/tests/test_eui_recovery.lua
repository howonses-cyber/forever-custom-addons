-- EUI integration regression: both native quest detail and custom tracker
-- launch paths, plus the EUI minimap collection lifecycle.
-- This is a mock test, not a claim of testing the player's UI installation.
local root=arg[1] or './'
local Mock=assert(loadfile(root..'tests/mock_wow.lua'))().install()
local G={displayName='포에버 퀘스트 가이드'}
local function load(name) assert(loadfile(root..name))('ForeverDungeonQuestGuide',G) end
local function eq(x,y,message) assert(x==y,(message or 'mismatch')..': '..tostring(x)..' vs '..tostring(y)) end
G.Print=function() end
G.IsReadyToTurnIn=function()return false end
local opened=0
G.ToggleUI=function()opened=opened+1 end
local idOpened=nil
G.StartQuickGuide=function(id)idOpened=id;return true end
local mini=CreateFrame('Frame','Minimap',UIParent);mini:SetSize(140,140)
load('UITheme.lua')
load('MinimapButton.lua')
load('EUIQuestBridge.lua')
-- Module not loaded yet: no exception; independent addon button still exists.
assert(not G.InstallEUIQuestBridge(),'no EUI addon loaded')
local small=assert(G.CreateMinimapButton(),'direct minimap access exists')
eq(small:GetParent(),mini,'direct minimap parent')
local last=opened;small:Click('LeftButton');eq(opened,last+1,'direct minimap opens guide')
-- EUI has collected and hidden the button. Reentering the world must not
-- re-show it on the map, stealing ownership from the EUI flyout.
_EBS_CachedAddonButtons={small};small:Hide()
G.CreateMinimapButton();assert(not small:IsShown(),'EUI flyout hidden state respected')
-- Separate direct launcher even when no details popup was opened.
local trackerFrame=CreateFrame('Frame','EUI_CustomQuestTracker',UIParent)
trackerFrame:SetSize(260,400)
assert(G.RefreshEUITrackerLauncher(),'custom tracker launcher ready')
local launcher=assert(Mock.find(function(o)return o.kind=='Button' and o.parent==trackerFrame and o:GetText()=='가이드' end))
last=opened;launcher:Click();eq(opened,last+1,'custom tracker launches full guide')
for _=1,4 do G.RefreshEUITrackerLauncher() end
eq(#Mock.all(function(o)return o.kind=='Button' and o.parent==trackerFrame end),1,'no duplicate EUI tracker launcher')
-- Public native EUI ShowQuestDetails(id) method and its known footer geometry.
local win=CreateFrame('Frame','EUI_QuestDetails',UIParent);win:SetSize(360,480);win:Hide()
win.focus={};win.untrack={};win.share={};win.abandon={}
local scroll=CreateFrame('ScrollFrame',nil,win)
scroll:SetPoint('TOPLEFT',win,'TOPLEFT',14,-64)
scroll:SetPoint('BOTTOMRIGHT',win,'BOTTOMRIGHT',-14,58)
EllesmereUIQuestTracker={ShowQuestDetails=function(id)win:Show() end}
local hookCount=0
hooksecurefunc=function(owner,name,fn)
 hookCount=hookCount+1
 local native=owner[name]
 owner[name]=function(...)local result=native(...);fn(...);return result end
end
assert(G.InstallEUIQuestBridge(),'posthook EUI detail callback')
assert(G.InstallEUIQuestBridge(),'idempotent install')
eq(hookCount,1,'no duplicate EUI posthook')
EllesmereUIQuestTracker.ShowQuestDetails(111)
local detailButton=assert(Mock.find(function(o)return o.kind=='Button' and o.parent==win and o:IsShown() and o:GetText()==G.displayName end))
eq(select(5,scroll:GetPoint(2)),88,'recognized EUI detail footer reserves row')
detailButton:Click();eq(idOpened,111,'selected EUI quest ID forwarded')
assert(not win:IsShown(),'successful action closes EUI details')
eq(select(5,scroll:GetPoint(2)),58,'native EUI scroll geometry restored')
-- Different EUI layout must not make the action disappear or touch native rows.
scroll:ClearAllPoints()
scroll:SetPoint('TOPLEFT',win,'TOPLEFT',12,-52)
scroll:SetPoint('BOTTOMRIGHT',win,'BOTTOMRIGHT',-14,24)
EllesmereUIQuestTracker.ShowQuestDetails(222)
assert(detailButton:IsShown(),'EUI action remains available in fallback mode')
eq(select(5,scroll:GetPoint(2)),24,'unknown EUI geometry untouched')
detailButton:Click();eq(idOpened,222,'fallback EUI action uses quest ID')
eq(#Mock.all(function(o)return o.kind=='Button' and o.parent==win end),1,'EUI detail button reused')
assert(G.EUIBridgeStatus():find('등록 확인',1,true),'EUI collection present in diagnostics')
print('PASS EUI restore: direct tracker launcher, detail callback, external fallback, no duplicate, EUI flyout ownership')

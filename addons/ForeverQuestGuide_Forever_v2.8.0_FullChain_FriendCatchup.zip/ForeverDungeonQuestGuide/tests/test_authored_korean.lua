-- Regression checks of authored Korean text. No game client is used.
local scriptDir=(arg[0] or ''):match('^(.*[/\\])') or './'
local function directory(path)return path:match('[/\\]$') and path or path..'/'end
local base=directory(arg[1] or './')
local count=0
local function check(ok,msg) count=count+1;assert(ok,msg or 'failed') end
local function eq(a,b,msg)check(a==b,(msg or 'mismatch')..': '..tostring(a)..' vs '..tostring(b))end
local modules={'Data.lua','VerifiedRoutes.lua','Walkthrough.lua','DungeonWalkthrough.lua'}
local function loadAuthored(path)
 local G={}
 G.GetDungeon=function(id)return G.dungeonById[id]end
 G.SafeCall=function(fn,...)if type(fn)=='function'then return fn(...)end end
 G.IsInLog=function()return false end
 G.DBGet=function()return nil end
 for _,file in ipairs(modules)do assert(loadfile(path..file))('ForeverDungeonQuestGuide',G)end
 return G
end
-- The package contains a data-only baseline, so the original release source
-- is unnecessary. An optional second argument permits comparison to a full
-- old source directory during development.
local old=arg[2] and loadAuthored(directory(arg[2])) or assert(loadfile(scriptDir..'fixtures/authored_v2.1.0.lua'))()
local G=loadAuthored(base)

-- Check numeric quest/item IDs, quantities, coordinates, boolean flags and
-- technical enum/URL/search strings against the exact previous module set.
local function compare(a,b,path)
 eq(type(a),type(b),path..' type')
 if type(a)=='table'then
  for key,value in pairs(a)do check(b[key]~=nil,path..' missing '..tostring(key));compare(value,b[key],path..'.'..tostring(key))end
  for key in pairs(b)do check(a[key]~=nil,path..' added '..tostring(key))end
 elseif type(a)=='number'or type(a)=='boolean'then eq(a,b,path)
 elseif type(a)=='string'and not a:find('[\128-\255]')and not b:find('[\128-\255]')then eq(a,b,path)end
end
for _,key in ipairs({'dungeons','pickupOverrides','turninOverrides','specialQuestMeta','verifiedObjectives','verifiedItemRequirements','walkthroughRecords','verifiedRouteSources','regionInstanceAreas','regionInstanceKeys'})do
 compare(old[key],G[key],key)
end

assert(loadfile(base..'KoreanGameData.lua'))('ForeverDungeonQuestGuide',G)
assert(loadfile(base..'KoreanPlaces.lua'))('ForeverDungeonQuestGuide',G)
assert(loadfile(base..'QuestLocalization.lua'))('ForeverDungeonQuestGuide',G)
eq(G.koTextReplacements['The Lyceum'],'훈련강당')
eq(G.koTextReplacements["Zaetar's Grave"],'재타르의 무덤')
eq(G.koTextReplacements['The Black Vault'],'검은 금고')
eq(G.koTextReplacements['The Grim Guzzler'],'험상궂은 주정뱅이 선술집')
eq(G.koTextReplacements['Gordok Commons'],'고르독 광장')
eq(G.koreanPlacesSource.foreverNames,1133)
local fallbacks=0
for raw in pairs(G.koPlaceFallbacks)do
 fallbacks=fallbacks+1
 check(G.koTextReplacements[raw]:find('명칭 확인 필요',1,true),'fallback must not pretend canonical')
 check(not G.koTextReplacements[raw]:find('%a'),'fallback display contains English')
end
eq(fallbacks,9)

local rendered=0
for id,record in pairs(G.walkthroughRecords)do
 local text=G.WalkthroughDetails(id)
 check(type(text)=='string'and #text>0,'missing walkthrough '..id)
 text=text:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r','')
 check(not text:find('%a'),'authored walkthrough still contains English '..id..': '..text)
 check(not text:find('https?://'),'source URLs should remain metadata')
 check(type(record.urls)=='table'and #record.urls>0,'source URLs lost')
 rendered=rendered+1
end
check(G.WalkthroughDetails(4243):find('에이미 01',1,true),'A-Me name not canonical')
check(G.WalkthroughDetails(3802):find('장인의 전당',1,true),'Fineous landmark not canonical')
check(G.WalkthroughDetails(3802):find('무쇠지옥',1,true),'Ironfel item not canonical')
eq(G.walkthroughRecords[7044].items[1][1],17703)
eq(G.walkthroughRecords[7044].items[1][3],'셀레브리안 다이아몬드')
eq(G.walkthroughRecords[7044].items[2][1],17702)
eq(G.walkthroughRecords[7044].items[2][3],'셀레브리안 마법봉')
eq(G.walkthroughRecords[4282].items[1][3],'윈저의 잃어버린 두번째 단서')
eq(G.walkthroughRecords[4282].items[2][3],'윈저의 잃어버린 첫번째 단서')
eq(G.verifiedObjectives[4083][1].id,7910,'existing corrected material ID preserved')

local function inspect(value,path)
 if type(value)=='table'then for key,v in pairs(value)do inspect(v,path..'.'..tostring(key))end
 elseif type(value)=='string'and value:find('[\128-\255]')then
  check(not value:find('%a'),'English inside authored label '..path..': '..value)
 end
end
for _,key in ipairs({'pickupOverrides','turninOverrides','specialQuestMeta','verifiedObjectives'})do inspect(G[key],key)end

-- Client names and maps: a map ID must not be passed through the AreaTable ID
-- namespace. Exact English lookup and known Korean fallback work independently.
C_Map={GetMapInfo=function()return{name='The Black Vault'}end}
eq(G.MapDisplayName(990001),'검은 금고')
C_Map.GetMapInfo=function()return{name='실제 클라이언트 지역'}end
eq(G.MapDisplayName(1449),'실제 클라이언트 지역')
C_Map.GetMapInfo=function()return{name='Unknown English Map'}end
eq(G.MapDisplayName(1449),'운고로 분화구')

-- Exact live quest objective text is translated through the paired runtime API.
G.IsInLog=function(id)return id==3802 end
C_QuestLog={GetLogIndexForQuestID=function(id)return id==3802 and 7 or 0 end,GetInfo=function()return{questID=3802}end}
GetQuestLogQuestText=function(index)eq(index,7);return '한국어 설명',table.concat(G.enQuestObjectives[3802],' / ')end
local narrative=G.LiveQuestNarrative(3802)
eq(narrative.objective,table.concat(G.koQuestObjectives[3802],' / '))
eq(narrative.description,'한국어 설명')

-- A missing runtime item name still has the old safe Korean item-number label.
G.DBGet=function(db,id,field)if id==99999998 and field=='sourceItemId'then return 99999997 end end
G.IsInLog=function()return false end
local rows=G.StepWalkthrough({quest=99999998,kind='accept'},false,true)
check(table.concat(rows,'\n'):find('아이템 #99999997',1,true),'missing item fallback must not crash')
print('PASS authored Korean: '..count..' assertions; '..rendered..' rendered walkthroughs; IDs, quantities, coordinates, flags, aliases and source URLs preserved (mock only)')

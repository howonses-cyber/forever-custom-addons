-- Native Lua 5.1 compatible command/UI wiring checks with stricter widget types.
-- No native frame renderer or physical keyboard is simulated.
local Mock=assert(loadfile('tests/mock_wow.lua'))().install()
assert(loadfile('tests/strict_api.lua'))()(Mock)
local base=arg[1] or './'
local G={}
local prints={}
DEFAULT_CHAT_FRAME.AddMessage=function(_,text)prints[#prints+1]=text end
GetTime=function()return 100 end
GetLocale=function()return 'koKR' end
UnitRace=function()return '드워프','Dwarf',3 end
Minimap=CreateFrame('Frame','Minimap',UIParent);Minimap:SetSize(140,140)
local failed
for line in io.lines(base..'ForeverDungeonQuestGuide.toc') do
 local name=line:match('^([^#].-%.lua)%s*$')
 if name then
  local chunk,err=loadfile(base..name);assert(chunk,err)
  local ok,why=xpcall(function()chunk('ForeverDungeonQuestGuide',G)end,debug.traceback)
  if not ok then failed=why;print('LOAD FAILURE '..name..': '..why) end
 end
end
assert(not failed,failed)
local controller=assert(Mock.find(function(o)return o.scripts.OnEvent and o.scripts.OnUpdate end))
controller.scripts.OnEvent(controller,'ADDON_LOADED','ForeverDungeonQuestGuide')
controller.scripts.OnEvent(controller,'PLAYER_LOGIN')
controller.scripts.OnUpdate(controller,.51)
local slash=assert(SlashCmdList.FOREVERDUNGEONQUESTGUIDE)
local scenarios=0
local function run(label,fn)
 local ok,err=xpcall(fn,debug.traceback)
 assert(ok,label..': '..tostring(err));assert(not G.lastCommandError,label..': guarded command failed');scenarios=scenarios+1;print('PASS '..label)
end
run('blank slash opens main UI from untouched initial state',function()
 assert(not G.IsUIShown());slash('');assert(G.IsUIShown())
end)
run('blank slash closes/reopens and whitespace-only input works',function()
 slash('');assert(not G.IsUIShown());slash('  ');assert(G.IsUIShown())
end)
run('Korean and English alias globals point to same command key',function()
 assert(SLASH_FOREVERDUNGEONQUESTGUIDE1=='/fqg');assert(SLASH_FOREVERDUNGEONQUESTGUIDE2=='/퀘스트가이드')
end)
run('blank entry after stale English saved route text',function()
 G.db.guide={steps={{quest=91001,kind='accept',title='Talk to Grark Lorkrub',note='Burning Steppes'}},index=1,mode='selected'}
 G.ShowUI(false);slash('');assert(G.IsUIShown());G.db.guide=nil
end)
run('HUD and settings/plan commands under per-type API constraints',function()
 slash('표시');slash('설정');slash('동선')
end)
run('minimap click shares successful ToggleUI path',function()
 G.ShowUI(false);local b=G.CreateMinimapButton();b:Click('LeftButton');assert(G.IsUIShown())
 b.scripts.OnEnter(b)
end)
run('version subcommand still prints loaded runtime version',function()
 slash('버전');assert(prints[#prints]:find(G.version,1,true))
end)
run('EUI detail hook attaches and opens the quick guide callback',function()
 local win=CreateFrame('Frame','EUI_QuestDetails',UIParent);win:SetSize(500,700)
 win.focus={};win.untrack={};win.share={};win.abandon={}
 local scroll=CreateFrame('ScrollFrame',nil,win)
 scroll:SetPoint('TOPLEFT',win,'TOPLEFT',0,-30)
 scroll:SetPoint('BOTTOMRIGHT',win,'BOTTOMRIGHT',-12,60)
 EllesmereUIQuestTracker={ShowQuestDetails=function()win:Show()end}
 hooksecurefunc=function(owner,key,after)
  local old=owner[key];owner[key]=function(...)local result=old(...);after(...);return result end
 end
 local oldIsInLog=G.IsInLog;G.IsInLog=function()return true end
 assert(G.InstallEUIQuestBridge());EllesmereUIQuestTracker.ShowQuestDetails(91001)
 local b=Mock.find(function(o)return o.kind=='Button' and o.parent==win and o:GetText()==G.displayName end)
 assert(b,'EUI bridge button did not attach');b.scripts.OnEnter(b)
 local called=false;local oldStart=G.StartQuickGuide;G.StartQuickGuide=function(id)assert(id==91001);called=true;return true end
 b:Click();assert(called);assert(not win:IsShown());G.StartQuickGuide=oldStart;G.IsInLog=oldIsInLog
end)
print('PASS strict command/UI widget API contracts: '..scenarios..' scenarios (mock frames; no native rendering)')

-- Phase5 mocked behavioral checks: anchors, map pin ownership, character
-- settings, opt-in addon communication. No live WoW or actual FPS data.
local root=arg[1] or './'
local Mock=assert(loadfile(root..'tests/mock_wow.lua'))().install()
local G={}
local function load(name) assert(loadfile(root..name))('ForeverDungeonQuestGuide',G) end
local function eq(a,b,why) assert(a==b,(why or 'equal')..': '..tostring(a)..' vs '..tostring(b)) end
local now=0
GetTime=function()return now end
load('Core.lua')
local saved={selectedQuests={[101]=true},deferredQuests={[102]={reason='user'}},manualProgress={[99]=true},
 guide={index=1,steps={{kind='accept',title='퀘스트 101',quest=101,point={map=42,x=.25,y=.45}}}},
 position={x=17,y=-25},hudSize={width=492,height=471},factionFilter='Alliance',mapPinMode='auto'}
ForeverDungeonQuestGuideDB=saved
G.StartSaved()
eq(G.db,saved);eq(G.db.selectedQuests,saved.selectedQuests);eq(G.db.deferredQuests,saved.deferredQuests)
eq(G.db.manualProgress,saved.manualProgress);eq(G.db.position,saved.position);eq(G.db.partyShareEnabled,false,'new opt-in default')
G.StartSaved();eq(G.db,saved,'repeated saved initialization does not reset progress')
local existing={guide=saved.guide,selected=saved.selectedQuests,deferred=saved.deferredQuests,manual=saved.manualProgress,position=saved.position}
-- Stable map must not hide/reposition same pin each half second.
local world=CreateFrame('Frame','WorldMapFrame',UIParent)
local canvas=CreateFrame('Frame',nil,world);canvas:SetSize(900,600)
world.ScrollContainer={Child=canvas};world.mapID=42;world.GetMapID=function(self)return self.mapID end
G.StepIsDone=function()return false end
G.CurrentAcceptanceBlock=function()return nil end
local pointReads=0
G.GuideStepNavPoint=function(step)pointReads=pointReads+1;return step.point end
G.GuideStepNavTitle=function()return '현재 목적지' end
G.IsGuideJourneyActive=function()return false end
load('MapPins.lua')
G.RefreshMapPins()
local own=Mock.find(function(o)return o.kind=='Button' and o.parent==canvas and o.point end)
assert(own and own:IsShown(),'map marker was not drawn')
local originalCount=#own.points
for i=1,15 do G.RefreshMapPins() end
eq(pointReads,1,'unchanged map must not resolve point again')
eq(#own.points,originalCount,'unchanged map must not reposition pin')
local other=CreateFrame('Button',nil,canvas);other:Show()
G.IsGuideJourneyActive=function()return true end;G.RefreshMapPins()
assert(not own:IsShown() and other:IsShown(),'external-path pins must not be affected')
G.IsGuideJourneyActive=function()return false end;G.RefreshMapPins();assert(own:IsShown())
world:Hide();G.RefreshMapPins();assert(not own:IsShown() and other:IsShown(),'map close must clear only own markers')
world:Show();G.db.mapPinMode='next';G.RefreshMapPins();assert(own:IsShown())
local before=pointReads;G.db.guide.steps[1].point.x=.4;G.InvalidateMapPins();G.RefreshMapPins()
assert(pointReads>before and #own.points==1,'route mutation invalidated map pin once')
-- EUI detail frame should restore its native viewport anchors and never stack
-- buttons, even across opening/closing and switch to unknown layout.
G.IsInLog=function(id)return id==101 end
G.IsReadyToTurnIn=function()return false end
G.StartQuickGuide=function()return true end
G.UIButton=function(parent,title,w,h,callback)
 local b=CreateFrame('Button',nil,parent);b:SetSize(w,h);b:SetText(title);b:SetScript('OnClick',callback);return b
end
local eui=CreateFrame('Frame','EUI_QuestDetails',UIParent);eui:SetSize(430,540)
eui.focus={};eui.untrack={};eui.share={};eui.abandon={}
local viewport=CreateFrame('ScrollFrame',nil,eui)
viewport:SetPoint('TOPLEFT',eui,'TOPLEFT',10,-30)
viewport:SetPoint('BOTTOMRIGHT',eui,'BOTTOMRIGHT',-12,60)
EllesmereUIQuestTracker={ShowQuestDetails=function()eui:Show()end}
hooksecurefunc=function(tbl,name,hook)
 local previous=tbl[name]
 tbl[name]=function(...)local result=previous(...);hook(...);return result end
end
load('EUIQuestBridge.lua')
assert(G.InstallEUIQuestBridge(),'EUI post-hook should install')
EllesmereUIQuestTracker.ShowQuestDetails(101)
local _,_,_,x,y=viewport:GetPoint(2)
eq(x,-12);eq(y,90,'viewport reserved only for visible detail')
local bridgeCount=#Mock.all(function(o)return o.kind=='Button' and o.parent==eui end)
eq(bridgeCount,1,'one bridge button')
eui:Hide();eq(select(5,viewport:GetPoint(2)),60,'viewport restored on hide')
EllesmereUIQuestTracker.ShowQuestDetails(101)
eq(select(5,viewport:GetPoint(2)),90,'viewport reserved on reopen')
eq(#Mock.all(function(o)return o.kind=='Button' and o.parent==eui end),1,'no duplicate EUI button')
G.RefreshEUIQuestBridge();eq(select(5,viewport:GetPoint(2)),90,'refresh must not shift anchor again')
eui:Hide();viewport:ClearAllPoints();viewport:SetPoint('BOTTOMRIGHT',eui,'BOTTOMRIGHT',-12,25)
EllesmereUIQuestTracker.ShowQuestDetails(101)
eq(select(5,viewport:GetPoint(1)),25,'unknown EUI layout stays native')
-- Consent and inbound/outbound sanitization, stale peers, roster leave.
local messages={};local roster={'동료A'};local calls=0
UnitName=function(unit)
 if unit=='player' then return '자신' end
 local index=tonumber(unit:match('^party(%d+)$'))
 if index then return roster[index] end
 return nil
end
GetNumPartyMembers=function()return #roster end
IsInRaid=function()return false end
C_ChatInfo={RegisterAddonMessagePrefix=function(prefix)eq(prefix,'FQGuideParty5');return 0 end,
 SendAddonMessage=function(prefix,text,channel)
  calls=calls+1;messages[#messages+1]={prefix,text,channel};return 0
 end}
G.activeQuests={[101]={title='101',complete=false},[102]={title='102',complete=true}}
G.IsReadyToTurnIn=function(id)return id==102 end
load('PartySync.lua')
G.PartyShareLogin();G.PartyShareTick(10);eq(calls,0,'opt-out sends zero messages')
assert(not G.PartyShareReceive('FQGuideParty5','5|H','PARTY','동료A'),'opt-out ignores inbound')
G.PartyShareSetEnabled(true);G.PartyShareTick(1)
eq(messages[1][2],'5|H','initial announcement contains no quest data')
eq(messages[1][3],'PARTY','group scoped delivery')
for i=1,10 do G.PartyShareTick(1)end
eq(calls,1,'idle sharing must not spam or leak quest IDs before a peer opts in')
assert(not G.PartyShareReceive('FQGuideParty5','5|H','GUILD','동료A'),'guild message rejected')
assert(not G.PartyShareReceive('FQGuideParty5','5|H','PARTY','외부인'),'non-member ignored')
assert(G.PartyShareReceive('FQGuideParty5','5|H','PARTY','동료A'),'peer opt-in handshake')
now=3;G.PartyShareTick(1)
assert(#messages==2 and messages[2][2]:find('^5|S|'),'peer opt-in permits limited status snapshot')
local body=messages[2][2]
assert(body:find('101=A',1,true) and body:find('102=R',1,true))
assert(not body:find('saved',1,true),'no saved variable data on wire')
assert(not G.PartyShareReceive('FQGuideParty5',string.rep('A',300),'PARTY','동료A'),'oversized payload blocked')
assert(G.PartyShareReceive('FQGuideParty5','5|S|9|1|1|1|101=R','PARTY','동료A'))
assert(G.PartyQuestSummary(101):find('보고 가능',1,true),'peer reportable is visible')
assert(G.PartyQuestSummary(111):find('완료 여부 미확인',1,true),'missing peer acceptance is not completion')
roster={'동료B'};G.PartyShareRosterChanged();assert(not G.PartyQuestSummary(101):find('동료A',1,true),'leaving member invalidated')
assert(not G.PartyShareReceive('FQGuideParty5','5|S|9|1|1|1|101=R','PARTY','동료A'),'former member cannot send stale snapshot')
G.PartyShareSetEnabled(false);now=60;G.PartyShareTick(1);local beforeCalls=calls
G.PartyShareTick(2);eq(calls,beforeCalls,'opt-out stops all sending')
eq(G.db.guide,existing.guide);eq(G.db.selectedQuests,existing.selected)
eq(G.db.deferredQuests,existing.deferred);eq(G.db.manualProgress,existing.manual)
eq(G.db.position,existing.position);eq(G.db.partyShareEnabled,false)
print('PASS Phase5: map owner + invalidation, EUI anchor restoration without duplicate, stable SavedVariables, opt-in party-only bounded comms')

local addon,G=...
G.diagnosticsVersion="2.6.0"
-- Read-only; never load/enable/disable or rewrite another addon.
local function safe(fn,...)
 if type(fn)~="function" then return nil,false end
 local ok,a=pcall(fn,...)
 return ok and a or nil,ok
end
local function addonState(name)
 local loaded,checked=safe((C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded,name)
 local listed,listChecked=safe((C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo,name)
 local enabled,enableChecked=safe((C_AddOns and C_AddOns.GetAddOnEnableState) or GetAddOnEnableState,
  (UnitName and UnitName("player")) or "player",name)
 if loaded==true or loaded==1 then return "로드됨" end
 if listChecked and (listed==nil or listed==false) then return "설치 목록에서 찾지 못함" end
 if enableChecked and type(enabled)=="number" and enabled==0 then return "비활성화됨" end
 if checked then return "설치 또는 로드 상태 확인 필요" end
 return "클라이언트 조회 API 없음 · 상태 미확인"
end
local function add(lines,title,value)
 lines[#lines+1]=title..": "..value
end
function G.QuestDataDiagnostics()
 local lines={}
 add(lines,"QuestieDB 애드온",addonState("QuestieDB"))
 add(lines,"Questie 애드온",addonState("Questie"))
 local db=type(QuestDB)=="table" and type(QuestDB.Get)=="function"
 local ids,idsState=nil,"전체 ID 목록 API 없음"
 if db then
  if G.questIndex and G.questIndex.available then
   ids=G.questIndex.ids
   idsState="사용 가능 ("..tostring(G.questIndex.total).."개 ID)"
  elseif type(QuestDB.GetAllIds)=="function" then
   local ok,result=pcall(QuestDB.GetAllIds)
   if ok and type(result)=="table" then
    ids=result
    idsState="사용 가능 ("..tostring(#result).."개 ID)"
   elseif ok then idsState="API 결과 형식 확인 필요"
   else idsState="API 실행 오류" end
  elseif type(QuestieDB)=="table" and type(QuestieDB.QuestPointers)=="table" then
   idsState="구형 QuestPointers 대체 경로 사용 가능"
  end
 end
 add(lines,"퀘스트 데이터 Get API",db and "호출 경로 확인" or "없음 또는 호환 불가")
 add(lines,"전체 퀘스트 ID API",idsState)
 local index=G.questIndex
 if index and index.available then
  add(lines,"색인 진행",tostring(index.loaded or 0).."/"..tostring(index.total or 0)..(index.ready and " · 완료" or " · 처리 중"))
 else add(lines,"색인 진행","시작되지 않았거나 전체 ID 조회 불가") end
 local code,summary,help
 if not db then
  code="NO_GET";summary="퀘스트 DB 연결 필요"
  help="캐릭터 선택 화면의 애드온 목록에서 QuestieDB가 설치·활성화되었는지 확인하세요. 게임 완전 종료 후 재실행해도 안 되면 QuestieDB/Questie 버전 호환성을 확인하세요."
 elseif not ids and (not index or not index.available) then
  code="NO_IDS";summary="검색용 전체 ID 목록 확인 필요"
  help="QuestDB.GetAllIds 또는 QuestieDB.QuestPointers 제공 여부를 확인하세요. 현재 수락 중인 퀘스트의 게임 로그는 계속 사용할 수 있습니다."
 elseif index and index.available and not index.ready then
  code="INDEXING";summary="퀘스트 목록 준비 중"
  help="색인 숫자가 늘어나는지 확인하세요. 다른 애드온을 삭제하거나 WTF를 수정하지 마세요."
 else code="READY";summary="퀘스트 자료 연결됨";help="퀘스트마다 좌표·선행·완료 이력은 별도로 미확인일 수 있습니다." end
 lines[#lines+1]="조치: "..help
 return {code=code,ok=code=="READY",summary=summary,details=lines,help=help}
end

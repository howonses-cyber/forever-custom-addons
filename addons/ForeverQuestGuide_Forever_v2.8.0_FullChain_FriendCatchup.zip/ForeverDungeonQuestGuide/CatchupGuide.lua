local addon,G=...
G.catchupVersion="2.8.0"
-- All functions in this module are read-only. Peer snapshots never overwrite
-- Blizzard/Questie quest flags, route planner state, selections or WTF data.
local function valid(id)
 id=tonumber(id)
 return id and id>0 and id<100000000 and id%1==0 and id or nil
end
local function call(fn,...)
 if type(fn)~="function" then return nil end
 local ok,result=pcall(fn,...)
 if ok then return result end
 return nil
end
function G.CatchupSelfState(id)
 id=valid(id);if not id then return "U" end
 if G.IsInLog and G.IsInLog(id) then
  return G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) and "T" or "A"
 end
 if G.sessionTurnins and G.sessionTurnins[id] then return "D" end
 for _,fn in ipairs({C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted or false, IsQuestFlaggedCompleted or false}) do
  if type(fn)=="function" then
   local success,result=pcall(fn,id)
   if success and result~=nil then return (result==true or result==1) and "D" or "N" end
  end
 end
 local char=Questie and Questie.db and Questie.db.char
 if char and type(char.complete)=="table" and char.complete[id]==true then return "D" end
 return "U"
end
local stateLabels={D="보고 완료",T="보고 가능",A="수행 중",N="미완료 · 수락 여부 확인",U="미확인"}
local function relationText(parent,child)
 local kind=G.NarrativeEdgeKind and G.NarrativeEdgeKind(parent,child)
 return ({required="필수 선행",alternative="대체 경로 · 택일",followup="후속 연계 · 필수 여부 별도 확인",breadcrumb="선택 안내 연계"})[kind] or "연계 참고"
end
local function formatPoint(point)
 if type(point)~="table" then return nil end
 if type(point.map)~="number" or type(point.x)~="number" or type(point.y)~="number" then return nil end
 if point.x<0 or point.x>1 or point.y<0 or point.y>1 then return nil end
 local map=(G.MapDisplayName and G.MapDisplayName(point.map)) or ("지도 #"..point.map)
 return map..string.format(" (%.1f, %.1f)",point.x*100,point.y*100)..(point.approx and " · 참고 위치" or "")
end
function G.CatchupStageLocation(id,phase)
 id=valid(id);if not id then return "위치 미확인" end
 local stage=phase=="report" and "turnin" or phase=="goal" and "objective" or "accept"
 local target=call(G.QuestContactName,id,stage)
 local point=call(G.QuestPoint,id,stage)
 local spot=formatPoint(point)
 local lm=call(G.QuestStageLandmark,id,stage) or call(G.QuestContactLandmark,id,stage)
 if not spot and type(lm)=="table" then spot=(lm.zone or "장소 미확인")..(lm.site and (" · "..lm.site) or "") end
 if not spot then spot=call(G.QuestRegionHint,id) or "위치 미확인 · 실제 게임 퀘스트 창 확인" end
 return (type(target)=="string" and target~="" and (target.." · ") or "")..spot
end
-- Determine prerequisite obligations without confusing one-of alternatives
-- with all-of requirements. A forward-link never becomes a hard prerequisite.
function G.CatchupRequiredTrace(root,states)
 root=valid(root);if not root then return nil end
 states=states or {}
 local result={ids={},alternatives={},blocked={},uncertain=false,cyclic=false}
 local visited,visiting={},{}
 local function state(id) return states[id] or "U" end
 local function walk(id,depth)
  if depth>32 or visiting[id] then result.cyclic=true;return end
  if visited[id] then return end
  visiting[id]=true
  local all,one={},{}
  if G.QuestPrerequisite then all,one=G.QuestPrerequisite(id) end
  all=type(all)=="table" and all or {};one=type(one)=="table" and one or {}
  -- Verified fallback for the two real A Taste of Flame branches if the
  -- optional database cannot supply their direct prerequisite records.
  -- This is NOT a blanket requirement for the earlier narrative chapters.
  if #all==0 and #one==0 then
   if id==4024 then one={4022,4023}
   elseif id==4022 then all={3481} end
  end
  if state(id)~="D" and state(id)~="A" and state(id)~="T" then
   for _,raw in ipairs(all) do
    local p=valid(raw)
    if p then walk(p,depth+1) else result.uncertain=true end
   end
   if #one==1 then
    local p=valid(one[1]);if p then walk(p,depth+1) else result.uncertain=true end
   elseif #one>1 then
    local candidates={};local satisfied=false
    for _,raw in ipairs(one) do
     local p=valid(raw)
     if p then
      candidates[#candidates+1]=p
      if state(p)=="D" or state(p)=="A" or state(p)=="T" then satisfied=true end
     else result.uncertain=true end
    end
    table.sort(candidates)
    local group={forQuest=id,ids=candidates,satisfied=satisfied,options={}}
    -- For each alternative, show its own actual prerequisite path without
    -- treating ALL alternative paths as simultaneously required.
    for _,candidate in ipairs(candidates) do
     local opts={};local used={}
     local function trace(q,depth2)
      if used[q] or depth2>24 then return end
      used[q]=true
      local st=state(q)
      if st~="D" and st~="A" and st~="T" and G.QuestPrerequisite then
       local req,choices=G.QuestPrerequisite(q)
       for _,parent in ipairs(type(req)=="table" and req or {}) do
        parent=valid(parent);if parent then trace(parent,depth2+1)end
       end
       if type(choices)=="table" and #choices==1 then
        local parent=valid(choices[1]);if parent then trace(parent,depth2+1)end
       end
      end
      opts[#opts+1]=q
     end
     trace(candidate,0)
     local score=0
     for _,q in ipairs(opts) do if state(q)=="D" then score=score+2
      elseif state(q)=="A" or state(q)=="T" then score=score+4 end end
     -- Narrative follow-ups help find where a friend left off, but never
     -- become mandatory acceptance conditions just because they connect.
     local story,storySeen={},{}
     local function storyWalk(q,d)
      if storySeen[q] or d>32 then return end
      storySeen[q]=true
      if G.NarrativeParents then
       for _,p in ipairs(G.NarrativeParents(q)) do
        storyWalk(p,d+1)
       end
      end
      story[#story+1]=q
     end
     storyWalk(candidate,0)
     local storyScore=0
     for _,q in ipairs(story) do
      if state(q)=="D" then storyScore=storyScore+2
      elseif state(q)=="A" or state(q)=="T" then storyScore=storyScore+4 end
     end
     group.options[#group.options+1]={id=candidate,ids=opts,narrativeIds=story,evidenceScore=storyScore}
    end
    table.sort(group.options,function(a,b)
     if a.evidenceScore~=b.evidenceScore then return a.evidenceScore>b.evidenceScore end
     return a.id<b.id
    end)
    if #group.options>1 and group.options[1].evidenceScore>0 and
       group.options[1].evidenceScore>group.options[2].evidenceScore then
     group.recommended=group.options[1].id
     walk(group.recommended,depth+1)
    elseif #group.options==1 then
     walk(group.options[1].id,depth+1)
    end
    result.alternatives[#result.alternatives+1]=group
    if not satisfied then result.uncertain=true end
   end
  end
  visiting[id]=nil;visited[id]=true
  result.ids[#result.ids+1]=id
 end
 walk(root,0)
 return result
end
-- Forward story route to the selected meet-up quest. This is an EXPLANATORY
-- route, not a quest-completion or must-do assertion. It deliberately does not
-- blindly traverse both sides of a one-of fork.
function G.CatchupStoryPath(root,states,required)
 root=valid(root);if not root then return nil end
 states=states or {};required=required or G.CatchupRequiredTrace(root,states)
 local chosen={};for _,choice in ipairs(required and required.alternatives or {}) do
  if choice.recommended then chosen[choice.forQuest]=choice.recommended end
 end
 local entries,branches,seen,visiting={},{},{},{}
 local overflow=false
 local function walk(id,kind,depth)
  if depth>42 or #entries>=42 then overflow=true;return end
  if seen[id] then return end
  if visiting[id] then overflow=true;return end
  visiting[id]=true
  local normal,alternatives={},{}
  for _,q in ipairs(G.NarrativeParents and G.NarrativeParents(id) or {}) do
   local edge=G.NarrativeEdgeKind and G.NarrativeEdgeKind(q,id) or 'followup'
   if edge=='alternative' then alternatives[#alternatives+1]=q
   else normal[#normal+1]={id=q,kind=edge} end
  end
  table.sort(normal,function(a,b)return a.id<b.id end)
  for _,parent in ipairs(normal) do walk(parent.id,parent.kind,depth+1) end
  if #alternatives==1 then
   walk(alternatives[1],'alternative',depth+1)
  elseif #alternatives>1 then
   table.sort(alternatives)
   local preferred=chosen[id]
   if not preferred then
    -- A reported or active quest on exactly one branch is evidence for
    -- that path; otherwise do not silently force a route on the friend.
    local matches={}
    for _,candidate in ipairs(alternatives) do
     local st=states[candidate]
     if st=='D' or st=='A' or st=='T' then matches[#matches+1]=candidate end
    end
    if #matches==1 then preferred=matches[1] end
   end
   if preferred then walk(preferred,'alternative',depth+1)
   else branches[#branches+1]={forQuest=id,options=alternatives} end
  end
  visiting[id]=nil;seen[id]=true
  entries[#entries+1]={id=id,kind=kind or 'goal',state=states[id] or 'U',
   optional=kind=='breadcrumb',confirmed=(states[id] or 'U')~='U'}
 end
 walk(root,'goal',0)
 local remaining=0;local unverified=0;local optional=0
 local nextIndex=1
 local goalReached=states[root]=='D'
 -- If the friend already accepted a later chapter, never tell them to
 -- re-do an older chapter just because the API cannot prove its history.
 for ix,entry in ipairs(entries) do
  if entry.state=='A' or entry.state=='T' then nextIndex=ix end
 end
 for ix,entry in ipairs(entries) do
  if entry.optional then optional=optional+1
  elseif not goalReached and ix>=nextIndex and entry.state~='D' then
   remaining=remaining+1
   if entry.state=='U' then unverified=unverified+1 end
  end
 end
 return {steps=entries,branches=branches,remaining=remaining,unknown=unverified,optional=optional,
  nextIndex=nextIndex,goalReached=goalReached,truncated=overflow,root=root}
end
local function peerSnapshot(peer,root)
 if not peer or peer=="" then return nil,"비교할 파티원을 선택하세요." end
 if type(G.CatchupPeerSnapshot)~="function" then return nil,"동행 통신 모듈 미연결" end
 return G.CatchupPeerSnapshot(peer,root)
end
function G.CatchupBuild(root,peer)
 root=valid(root);if not root then return nil,"퀘스트를 먼저 선택하세요." end
 local family=G.QuestNarrativeFamily and G.QuestNarrativeFamily(root)
 if not family then return nil,"연계 자료를 확인할 수 없습니다." end
 local peerData,why=peerSnapshot(peer,root)
 local my,friend={},{}
 local yours=peerData and peerData.quests or {}
 local counts={me=0,friend=0,unknown=0,activeMe=nil,activeFriend=nil}
 local steps={}
 for index,id in ipairs(family.ids) do
  local selfStatus=G.CatchupSelfState(id)
  local theirStatus=yours[id] or "U"
  my[id],friend[id]=selfStatus,theirStatus
  if selfStatus=="D" then counts.me=counts.me+1
  elseif selfStatus=="A" or selfStatus=="T" then counts.activeMe=id end
  if theirStatus=="D" then counts.friend=counts.friend+1
  elseif theirStatus=="A" or theirStatus=="T" then counts.activeFriend=id end
  if theirStatus=="U" then counts.unknown=counts.unknown+1 end
  local links={}
  if G.NarrativeParents then
   for _,p in ipairs(G.NarrativeParents(id)) do if family.member[p] then links[#links+1]=relationText(p,id) end end
  end
  table.sort(links)
  local relation=#links>0 and table.concat(links," / ") or "연계 시작 또는 별도 분기"
  local phase=theirStatus=="T" and "report" or theirStatus=="A" and "goal" or "accept"
  local where=G.CatchupStageLocation(id,phase)
  local goal=(G.QuestObjectiveText and call(G.QuestObjectiveText,id)) or nil
  steps[#steps+1]={id=id,index=index,name=G.GetQuestName and G.GetQuestName(id) or ("퀘스트 #"..id),mine=selfStatus,
   theirs=theirStatus,relation=relation,where=where,goal=goal,phase=phase}
 end
 local required=G.CatchupRequiredTrace(root,friend)
 local storyPath=G.CatchupStoryPath(root,friend,required)
 return {root=root,peer=peer,peerKnown=peerData~=nil,peerReason=why,family=family,steps=steps,
  counts=counts,required=required,storyPath=storyPath,friendStates=friend,selfStates=my}
end
local function short(s,max)
 s=tostring(s or ""):gsub("[\r\n]+"," ")
 if #s>max then
  local cut=max-3
  while cut>0 do
   local b=s:byte(cut+1)
   if b and b>=128 and b<192 then cut=cut-1 else break end
  end
  return s:sub(1,cut).."..."
 end
 return s
end
local function howto(step)
 if step.theirs=="D" then return "완료 확인" end
 if step.theirs=="T" then return "완료 보고: "..step.where end
 if step.theirs=="A" then return "목표 수행: "..step.where end
 if step.theirs=="N" then return "수락 → 목표 수행 → 보고 · 시작: "..step.where end
 return "상태 확인 후 수락/수행/보고 · 시작 후보: "..step.where
end
function G.CatchupReport(root,peer)
 local data,reason=G.CatchupBuild(root,peer)
 if not data then return {reason},nil end
 local lines={"|cffffdd8b"..data.family.title.."|r · 연결 "..#data.steps.."개 (선택 경로 포함)",
  "내 완료 확인 "..data.counts.me.."개 · "..(data.counts.activeMe and ("진행 퀘스트 #"..data.counts.activeMe) or "진행 상태 별도 확인"),
  data.peerKnown and ("친구 "..peer.." · 완료 확인 "..data.counts.friend.."개 · 미확인 "..data.counts.unknown.."개")
   or ("친구 진행도 미확인: "..(data.peerReason or "동행 공유 동의/조회 필요"))}
 if data.family.indexing then lines[#lines+1]="전체 퀘스트 색인 준비 중 · 후속 연계가 더 나타날 수 있습니다." end
 if data.family.truncated then lines[#lines+1]="연계가 길어 최대 범위까지만 표시했습니다. 나머지 연결은 확인 필요." end
 if data.family.cycle then lines[#lines+1]="원본 연계 데이터 순환 발견 · 번호는 반드시 수행 순서를 뜻하지 않습니다." end
 if data.family.optional or data.family.branch then lines[#lines+1]="선택 안내와 택일 분기 포함 · 모든 단계를 필수로 진행할 필요는 없습니다." end
 lines[#lines+1]="|cff92dfeb친구가 합류할 때까지의 이야기 순서|r"
 local story=data.storyPath
 if story then
  lines[#lines+1]=string.format("합류 목표까지 연결 %d단계 · 완료 미확인 %d단계%s",#story.steps,story.remaining,
   data.peerKnown and "" or " (친구 정보 미공유 · 단계수는 임시 안내)")
  if story.goalReached then lines[#lines+1]="친구가 합류 목표를 보고 완료했습니다. 과거 미확인 단계는 다시 수행하도록 안내하지 않습니다." end
  for ix,entry in ipairs(story.steps) do
   local st=entry.state
   local role=entry.optional and "[선택 안내]" or entry.kind=='alternative' and "[택일 분기]" or "[연계 단계]"
   lines[#lines+1]=string.format(" %d/%d %s %s (#%d) · 친구 %s",ix,#story.steps,role,
    G.GetQuestName and G.GetQuestName(entry.id) or ("퀘스트 #"..entry.id),entry.id,stateLabels[st] or "미확인")
   if st~="D" then
    if story.goalReached or ix<story.nextIndex then
     lines[#lines+1]="   이전 단계 기록 미확인 · 이미 도달한 구간이므로 재수행 지시 없음"
    else
     local phase=st=="T" and "report" or st=="A" and "goal" or "accept"
     lines[#lines+1]="   다음 안내: "..short(G.CatchupStageLocation(entry.id,phase),156)
    end
   end
  end
  for _,branch in ipairs(story.branches) do
   local names={};for _,id in ipairs(branch.options) do names[#names+1]=(G.GetQuestName and G.GetQuestName(id) or ("#"..id)).." (#"..id..")" end
   lines[#lines+1]="갈림길: "..table.concat(names," 또는 ").." · 어느 길을 이미 시작했는지 확인한 뒤 진행"
  end
  if story.truncated then lines[#lines+1]="표시 한도 도달 · 추가 연계는 직접 확인하세요." end
 end
 lines[#lines+1]="|cff92dfeb전체 연계와 친구의 현재 위치|r"
 for _,step in ipairs(data.steps) do
  local me=stateLabels[step.mine] or "미확인"
  local them=data.peerKnown and (stateLabels[step.theirs] or "미확인") or "미공유"
  lines[#lines+1]=string.format("%d. %s (#%d) · 나 %s / 친구 %s",step.index,step.name,step.id,me,them)
  lines[#lines+1]="   "..step.relation.." · "..short(howto(step),156)
 end
 lines[#lines+1]="|cffffd78a합류 목표에 필요한 필수 선행|r"
 local required=data.required
 if required and #required.ids>0 then
  for _,id in ipairs(required.ids) do
   local st=data.friendStates[id] or "U"
   lines[#lines+1]="• "..(G.GetQuestName and G.GetQuestName(id) or ("퀘스트 #"..id)).." (#"..id..") · "..(stateLabels[st] or "미확인")
   if st~="D" then
    lines[#lines+1]="  "..short(G.CatchupStageLocation(id,st=="T" and "report" or st=="A" and "goal" or "accept"),156)
   end
  end
 end
 for _,choice in ipairs(required and required.alternatives or {}) do
  local names={};for _,id in ipairs(choice.ids) do names[#names+1]=(G.GetQuestName and G.GetQuestName(id) or tostring(id)).." (#"..id..")" end
  lines[#lines+1]="택일 선행 → "..table.concat(names," 또는 ")..(choice.satisfied and " · 진행 기록 있음" or " · 실제 수락 가능 여부 확인")
  for _,path in ipairs(choice.options or {}) do
   local parts={}
   for _,id in ipairs(path.narrativeIds or path.ids) do parts[#parts+1]=(G.GetQuestName and G.GetQuestName(id) or tostring(id)).." (#"..id..")" end
   lines[#lines+1]="  "..(choice.recommended==path.id and "진행 기록과 맞는 연계 경로: " or "선택 가능한 연계 경로 후보: ")..table.concat(parts," → ")
   if choice.recommended==path.id then
    for _,id in ipairs(path.narrativeIds or path.ids) do
     local st=data.friendStates[id] or "U"
     if st~="D" then lines[#lines+1]="    다음 확인: "..(G.GetQuestName and G.GetQuestName(id) or tostring(id)).." · "..short(G.CatchupStageLocation(id,st=="T" and "report" or st=="A" and "goal" or "accept"),120);break end
    end
   end
  end
 end
 if required and required.uncertain then lines[#lines+1]="선행 갈림길의 실제 수락 가능 여부는 친구 캐릭터에서 확인해야 합니다." end
 if required and required.cyclic then lines[#lines+1]="선행 자료에 순환이 있어 자동 합류 판단을 중단했습니다." end
 lines[#lines+1]="|cff9aa8bc친구의 실제 레벨·직업·진영과 NPC 수락 가능 여부는 친구 캐릭터에서 확인하세요.|r"
 lines[#lines+1]="|cff9aa8bc완료는 보고·보상 수령 기록만 인정. 타인의 정보는 동의 후 받은 실시간 응답이며 WTF에는 저장하지 않습니다.|r"
 return lines,data
end
function G.CatchupChatLines(root,peer)
 local data,why=G.CatchupBuild(root,peer)
 if not data then return nil,why end
 if not data.peerKnown then return nil,"친구의 진행도 응답을 먼저 받아야 개인별 따라잡기 안내를 보낼 수 있습니다." end
 local path=data.storyPath
 if not path or path.truncated then return nil,"전체 연계 범위가 불완전해 전송을 중단했습니다. 화면에서 확인하세요." end
 local lines={"[포에버 동행] "..short(data.family.title,50).." · 합류 목표 #"..root.." · 친구 기록 기준"}
 lines[#lines+1]=string.format("연계 %d단계, 친구 완료 미확인 %d단계%s",#path.steps,path.remaining,
  path.unknown>0 and " (일부 상태 미확인)" or "")
 local pending={}
 for ix,entry in ipairs(path.steps) do
  if not path.goalReached and ix>=path.nextIndex and entry.state~="D" then
   local marker=entry.optional and "선택" or entry.kind=="alternative" and "택일" or "연계"
   local action=entry.state=="T" and "보고" or entry.state=="A" and "수행" or "수락/확인"
   pending[#pending+1]=string.format("%d/%d #%d %s %s · %s",ix,#path.steps,entry.id,
     short(G.GetQuestName and G.GetQuestName(entry.id) or "",24),marker,action)
  end
 end
 if #pending==0 then lines[#lines+1]="연결 단계는 완료로 확인됐습니다. 목표 퀘스트 수락/보고 상태를 다시 확인하세요."
 else
  local first
  for ix,entry in ipairs(path.steps) do
   if ix>=path.nextIndex and entry.state~="D" then first=entry;break end
  end
  if first then
   local phase=first.state=="T" and "report" or first.state=="A" and "goal" or "accept"
   lines[#lines+1]="첫 목적지: #"..first.id.." "..short(G.CatchupStageLocation(first.id,phase),130)
  end
  -- Group multiple story stages into a bounded number of private messages.
  -- The full step-by-step NPC/coordinates remain visible inside the addon.
  local message=""
  for _,step in ipairs(pending) do
   if #message>0 and #message+#step+3>205 then
    lines[#lines+1]=message;message=""
   end
   message=message=="" and step or message.." → "..step
  end
  if message~="" then lines[#lines+1]=message end
 end
 for _,fork in ipairs(path.branches) do
  local ids={};for _,id in ipairs(fork.options) do ids[#ids+1]="#"..id end
  lines[#lines+1]="택일 경로: "..table.concat(ids," 또는 ").." · 친구 NPC 수락 조건 확인"
 end
 -- Caller sends at most nine lines per explicit click; if a chain is longer
 -- than will fit, do not silently drop the missing tail and call it complete.
 if #lines>9 then
  local extra=#lines-8
  while #lines>8 do table.remove(lines) end
  lines[#lines+1]="안내가 길어 상세 "..extra.."개 메시지는 생략됐습니다. 애드온 '연계 전체·동행 안내'에서 모든 단계 확인."
 end
 return lines,data
end
G.API.Catchup=function(id,peer)return G.CatchupReport(id,peer)end

local addon,G=...
-- Separate, non-invasive guide panel. It does not move the EUI quest tracker,
-- rewrite quest state, or modify the user's current route/selection.
local frame,root,peer,scroll,body,heading,sharing,partner,note
local function button(parent,label,x,y,w,fn)
 local b
 if type(G.UIButton)=="function" then b=G.UIButton(parent,label,w,28,fn)
 else
  b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetSize(w,28);b:SetText(label);b:SetScript("OnClick",fn)
 end
 b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 return b
end
local function label(parent,value,x,y,w,h,font)
 local text=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
 text:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 text:SetSize(w,h);text:SetJustifyH("LEFT");text:SetJustifyV("TOP")
 if value then text:SetText(value) end
 return text
end
local function choosePeer(nextOne)
 local list=G.CatchupPeerNames and G.CatchupPeerNames() or {}
 if #list==0 then peer=nil;return nil end
 if not nextOne then
  for _,value in ipairs(list) do if value==peer then return peer end end
  peer=list[1];return peer
 end
 local index=0
 for i,value in ipairs(list) do if value==peer then index=i;break end end
 peer=list[(index%#list)+1]
 return peer
end
local function refresh()
 if not frame then return end
 choosePeer(false)
 sharing:SetText((G.CatchupShareEnabled and G.CatchupShareEnabled()) and "동행 공유 끄기" or "동행 공유 켜기")
 partner:SetText(peer and ("비교 대상: "..peer.." · 변경") or "파티원 없음 · 변경")
 heading:SetText("연계 전체 · "..(root and G.GetQuestName(root) or "퀘스트 선택 필요")..(root and (" (#"..root..")") or ""))
 local lines=G.CatchupReport and G.CatchupReport(root,peer) or {"연계 안내를 불러오지 못했습니다."}
 -- The text may contain long chains; keep it inside its own scrollable
 -- viewport, independent of the native EUI details scroll frame.
 body:SetText(table.concat(lines,"\n"))
 local h=body.GetStringHeight and body:GetStringHeight() or (#lines*19)
 if not h or h<=0 then h=#lines*19 end
 body:SetHeight(math.max(1,h+30))
 scroll:GetScrollChild():SetHeight(math.max(1,h+30))
 local current=scroll:GetVerticalScroll()
 local max=math.max(0,scroll:GetScrollChild():GetHeight()-scroll:GetHeight())
 scroll:SetVerticalScroll(math.min(current,max))
end
function G.CatchupUIRefresh() if frame and frame:IsShown() then refresh() end end
local function build()
 if frame or not UIParent then return end
 frame=CreateFrame("Frame","ForeverDungeonQuestGuideCatchup",UIParent)
 frame:SetSize(740,690)
 frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
 frame:SetFrameStrata("DIALOG")
 frame:SetClampedToScreen(true)
 frame:SetMovable(true)
 frame:EnableMouse(true)
 frame:RegisterForDrag("LeftButton")
 frame:SetScript("OnDragStart",function(self)
  if not(InCombatLockdown and InCombatLockdown())then self:StartMoving()end
 end)
 frame:SetScript("OnDragStop",function(self) self:StopMovingOrSizing()end)
 local bg=frame:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.055,.075,.095,.97)
 local accent=frame:CreateTexture(nil,"BORDER");accent:SetPoint("TOPLEFT",0,-1);accent:SetPoint("TOPRIGHT",0,-1)
 accent:SetHeight(2);accent:SetColorTexture(.90,.67,.30,.95)
 heading=label(frame,"연계 전체",18,-16,635,32,"GameFontNormalLarge")
 button(frame,"×",690,-12,32,function()frame:Hide()end)
 note=label(frame,"선택 안내와 택일 경로는 필수 선행이 아닙니다. 친구 완료 기록은 양쪽 동의 후 요청한 연계만 조회합니다.",18,-56,702,36,"GameFontHighlightSmall")
 partner=button(frame,"파티원 선택",18,-100,232,function()choosePeer(true);scroll:SetVerticalScroll(0);refresh()end)
 sharing=button(frame,"동행 공유 켜기",260,-100,154,function()
  if G.CatchupShareSetEnabled then
   local enabled=G.CatchupShareSetEnabled(not G.CatchupShareEnabled())
   G.Print("동행 진행도 공유 "..(enabled and "켜짐 · 친구도 켜야 상태를 조회할 수 있습니다." or "꺼짐"))
  end
  refresh()
 end)
 button(frame,"친구 정보 요청",424,-100,140,function()
  local ok,message=G.CatchupRequest and G.CatchupRequest(root,peer)
  G.Print(message or "친구 진행도 조회 모듈을 확인하세요.")
  refresh()
 end)
 button(frame,"새로고침",578,-100,144,function()refresh()end)
 scroll=CreateFrame("ScrollFrame",nil,frame)
 scroll:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-149)
 scroll:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-18,94)
 scroll:EnableMouseWheel(true)
 scroll:SetScript("OnMouseWheel",function(self,delta)
  local child=self:GetScrollChild();local max=math.max(0,(child and child:GetHeight() or 0)-self:GetHeight())
  self:SetVerticalScroll(math.max(0,math.min(max,self:GetVerticalScroll()-delta*43)))
 end)
 local child=CreateFrame("Frame",nil,scroll);child:SetSize(690,1)
 scroll:SetScrollChild(child)
 body=child:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 body:SetPoint("TOPLEFT",child,"TOPLEFT",4,-4)
 body:SetWidth(676)
 body:SetJustifyH("LEFT");body:SetJustifyV("TOP")
 if body.SetWordWrap then body:SetWordWrap(true) end
 body:SetText("")
 button(frame,"친구에게 따라잡기 안내 보내기",18,-625,317,function()
  local ok,message=G.CatchupShareSendChat and G.CatchupShareSendChat(root,peer)
  G.Print(message or "친구에게 전송하지 못했습니다.")
 end)
 button(frame,"내 가이드로 시작",346,-625,178,function()
  if root and G.StartQuickGuide then G.StartQuickGuide(root) end
 end)
 button(frame,"선택 퀘스트로 이동",535,-625,187,function()
  if root then G.SetQuest(root);G.ShowUI(true) end
 end)
 -- No auto-send, no auto-open on login; all disclosure requires explicit click.
 frame:Hide()
end
function G.ShowCatchupUI(id)
 build();if not frame then return false end
 root=tonumber(id) or (G.selection and tonumber(G.selection.quest))
 if not root or root<=0 then G.Print("동행 안내를 볼 퀘스트를 먼저 선택하세요.");return false end
 choosePeer(false)
 scroll:SetVerticalScroll(0)
 frame:Show();refresh()
 return true
end
G.API.ShowCatchup=function(id)return G.ShowCatchupUI(id)end

local addon,G=...
-- QuestieDB provides the complete quest-ID set. Build a name index incrementally so
-- opening the guide never freezes the game while thousands of names are decoded.
local index={ids={},names={},normalized={},cursor=1,loaded=0,total=0,ready=false,available=false,zones={},zoneByQuest={}}
local function getZone(id)
 return G.QuestCategoryInfo(G.DBGet(QuestDB,id,"zoneOrSort"))
end
function G.ZoneLabel(key)
 local z=index.zones[key]
 return z and z.name or G.MapDisplayName(key) or "지역명 미확인"
end
G.questIndex=index
local DEFAULT_PAGE_SIZE=600
local MAX_PAGE_SIZE=600
local nextRetryAt=0
local function queryIds()
 if type(QuestDB)~="table" then return nil end
 if type(QuestDB.GetAllIds)=="function" then
  local ok,result=pcall(QuestDB.GetAllIds)
  if ok and type(result)=="table" then return result end
 end
 -- Legacy Questie installations expose the same composed ID map via QuestPointers.
 local ptr=QuestieDB and QuestieDB.QuestPointers
 if type(ptr)=="table" then
  local ids={}
  for id,present in pairs(ptr) do
   if present and type(id)=="number" and id>0 then ids[#ids+1]=id end
  end
  table.sort(ids)
  return ids
 end
 return nil
end
function G.RestartQuestIndex()
 if G.InvalidateQuestBrowseCache then G.InvalidateQuestBrowseCache() end
 if G.ResetRouteDependencyIndex then G.ResetRouteDependencyIndex() end
 if G.ResetNarrativeIndex then G.ResetNarrativeIndex() end
 index.ids={};index.names={};index.normalized={};index.zones={};index.zoneByQuest={}
 index.cursor=1;index.loaded=0;index.total=0;index.ready=false;index.available=false
 local ids=queryIds()
 if not ids then return false end
 -- GetAllIds is shared read-only. Never mutate it.
 index.ids=ids
 index.total=#ids
 index.available=true
 index.ready=(index.total==0)
 return true
end
function G.TickQuestIndex(budget)
 if not G.Ready() then return end
 if not index.available then
  local now=GetTime and GetTime() or 0
  if now<nextRetryAt then return end
  if not G.RestartQuestIndex() then nextRetryAt=now+3;return end
 end
 if index.ready then return end
 local count=0
 while index.cursor<=index.total and count<(budget or 150) do
  local id=index.ids[index.cursor]
  if type(id)=="number" and id>0 then
   local name=G.GetQuestName(id)
   if G.IndexRouteDependencies then G.IndexRouteDependencies(id) end
   if G.IndexNarrativeQuest then G.IndexNarrativeQuest(id) end
   index.names[id]=name
   index.normalized[id]=G.Clean(name).." "..G.Clean((G.DBRawGet or G.DBGet)(QuestDB,id,"name"))
   local key,name,kind,map,aliases=getZone(id)
   if key then
    local zone=index.zones[key]
    if not zone then
     zone={key=key,map=map,name=name,kind=kind,aliases=aliases,ids={},count=0,factionCounts={Alliance=0,Horde=0,Any=0,Both=0,Unknown=0}}
     index.zones[key]=zone
    end
    zone.ids[#zone.ids+1]=id
    zone.count=zone.count+1
    local faction=G.QuestFaction(id)
    zone.factionCounts[faction]=(zone.factionCounts[faction] or 0)+1
    index.zoneByQuest[id]=key
   end
  end
  index.cursor=index.cursor+1;count=count+1
 end
 index.loaded=index.cursor-1
 index.ready=index.cursor>index.total
 if G.InvalidateQuestBrowseCache then G.InvalidateQuestBrowseCache() end
 if index.ready and G.RefreshRouteEvidence then
  G.RefreshRouteEvidence()
  if G.db and G.db.guide and G.db.guide.steps then
   if G.db.guide.mode=="selected" and G.ReplanSelectedGuide then G.ReplanSelectedGuide("연계 정보 준비")
   elseif G.ReconcileGuide then G.ReconcileGuide() end
  end
 end
 -- Refresh periodically while the user is actively searching.
 if (index.ready or (math.floor(index.loaded/600)~=math.floor((index.loaded-count)/600)))
     and G.IsUIShown and G.IsUIShown() and G.UIRefresh then
  G.UIRefresh()
 end
end
function G.QuestIndexStatus()
 if not index.available then return "퀘스트 자료의 전체 목록 연결 확인 필요" end
 if not index.ready then return string.format("검색 목록 준비 %d/%d",index.loaded,index.total) end
 return string.format("전체 %d개 검색 가능",index.total)
end
local function matches(id,needle)
 if needle=="" then return true end
 if tostring(id)==needle then return true end
 local name=index.normalized[id]
 if not name then
  name=G.Clean(G.GetQuestName(id)).." "..G.Clean((G.DBRawGet or G.DBGet)(QuestDB,id,"name"))
  -- On-demand cache for accepted/dungeon quests while indexing is in progress.
  index.normalized[id]=name
 end
 return string.find(name,needle,1,true)~=nil
end
function G.GetQuestZone(id)
 id=tonumber(id)
 if not id then return nil end
 local key=index.zoneByQuest[id]
 local z=key and index.zones[key]
 if z then return key,z.name,z.kind end
 return getZone(id)
end
function G.ZoneFactionCount(z)
 if not z then return 0 end
 local mode=G.FactionFilterMode()
 if mode=="all" then return z.count end
 local counts=z.factionCounts or {}
 return (counts.Any or 0)+(counts.Both or 0)+(counts[mode] or 0)
end
function G.SearchQuestZones(query)
 local needle=G.Clean(query)
 local zones={}
 for _,z in pairs(index.zones) do
  if G.ZoneFactionCount(z)>0 and (needle=="" or string.find(G.Clean(z.name),needle,1,true) or string.find(G.Clean(z.aliases),needle,1,true) or tostring(z.key)==needle) then
   zones[#zones+1]=z
  end
 end
 local order={zone=1,dungeon=2,raid=3,pvp=4,unknown=5}
 table.sort(zones,function(a,b)
  local oa,ob=order[a.kind] or 9,order[b.kind] or 9
  if oa~=ob then return oa<ob end
  return a.name==b.name and a.key<b.key or a.name<b.name
 end)
 return zones
end
local function inResult(list,id,seen)
 id=tonumber(id)
 if id and id>0 and not seen[id] then list[#list+1]=id;seen[id]=true end
end
-- Returns {ids, matchCount, stillIndexing}. A blank global query starts with
-- LIVE quests only; past checked/completed quests are never mistaken for active.
-- Zone mode searches the indexed QuestieDB zoneOrSort assignment, not a
-- guessed nearest NPC. This is a content catalog, not a terrain route.
-- The caller can reach every match through offset+limit. All counts are
-- complete for the currently indexed records (never pretend a partial index
-- is finished). Sorting is performed over the full matching scope, not only
-- over an arbitrary 600-row prefix.
local browseCache={key=nil,ids=nil}
function G.InvalidateQuestBrowseCache() browseCache.key=nil;browseCache.ids=nil end
function G.QuestBrowseMatchesLevel(id,filter)
 if not filter or filter=="all" then return true end
 local level=tonumber(G.GetQuestLevel and G.GetQuestLevel(id)) or 0
 local player=tonumber(G.player and G.player.level) or 0
 local min=tonumber(G.GetQuestMinLevel and G.GetQuestMinLevel(id)) or 0
 if filter=="near" then return level>0 and player>0 and math.abs(level-player)<=5 end
 if filter=="available" then
  return (G.IsInLog and G.IsInLog(id)) or (min>0 and min<=player and G.IsEligibleQuest(id))
 end
 if filter=="above" then return min>player and player>0 end
 return true
end
local function sortResults(ids,mode)
 if mode=="id" then table.sort(ids);return end
 local metrics={}
 local here=mode=="distance" and G.PlayerLocation and G.PlayerLocation() or nil
 local stageMap=here and type(here.map)=="number" and not here.approx and here.map or nil
 for _,id in ipairs(ids) do
  local score
  if mode=="level" then
   score=tonumber(G.GetQuestLevel and G.GetQuestLevel(id)) or 0
   if score<=0 then score=math.huge end
  elseif mode=="status" then
   -- Verified live-log facts first; avoid expensive route graph walks for
   -- thousands of historical IDs merely because the sort button was clicked.
   if G.IsInLog and G.IsInLog(id) then score=G.IsReadyToTurnIn and G.IsReadyToTurnIn(id) and 0 or 1
   elseif G.IsCompleted and G.IsCompleted(id) then score=3
   else score=2 end
  elseif mode=="distance" then
   score=math.huge
   if stageMap and G.QuestPoint then
    local p=G.QuestPoint(id,"accept")
    if type(p)=="table" and p.map==stageMap and not p.approx and
     type(p.x)=="number" and type(p.y)=="number" and p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1 then
      score=(here.x-p.x)^2+(here.y-p.y)^2
    end
   end
  else score=id end
  metrics[id]=score
 end
 table.sort(ids,function(a,b)
  local av,bv=metrics[a],metrics[b]
  if av~=bv then return av<bv end
  return a<b
 end)
end
G.SortBrowseResults=sortResults
function G.SearchQuestIds(mode,query,options)
 options=type(options)=="table" and options or {}
 local text=G.Clean(query)
 local offset=math.max(0,math.floor(tonumber(options.offset) or 0))
 local limit=math.max(1,math.min(MAX_PAGE_SIZE,math.floor(tonumber(options.limit) or DEFAULT_PAGE_SIZE)))
 local sort=options.sortMode or "id"
 local filter=options.levelFilter or "all"
 if not ({id=true,level=true,status=true,distance=true})[sort] then sort="id" end
 local indexed=mode=="zone" or (mode=="all" and text~="")
 if indexed and not index.available and G.Ready() then G.RestartQuestIndex() end
 -- Current-log/check/deferred lists can change without the DB index moving.
 local stable=indexed and index.ready
 local map=G.selection.zone or (G.db and G.db.selectedZone)
 local faction=G.FactionFilterMode and G.FactionFilterMode() or "all"
 local position=sort=="distance" and G.PlayerLocation and G.PlayerLocation() or nil
 local positionKey=position and (tostring(position.map)..":"..tostring(math.floor((position.x or 0)*100))..":"..tostring(math.floor((position.y or 0)*100))) or "none"
 local key=table.concat({mode,text,tostring(map),tostring(index.loaded),tostring(index.total),tostring(faction),sort,filter,tostring(G.player and G.player.level),positionKey,tostring(options.ignoreStateFilters),tostring(G.db and G.db.hideUnavailable),tostring(G.db and G.db.onlyIncomplete)},"|")
 local matchesAll=stable and browseCache.key==key and browseCache.ids or nil
 if not matchesAll then
  matchesAll={}
  local seen={}
  local function add(id,matchRequired)
   id=tonumber(id)
   if not id or id<=0 or id%1~=0 or seen[id] then return end
   if matchRequired and not matches(id,text) then return end
   if not G.QuestBrowseMatchesLevel(id,filter) then return end
   if not (G.IsQuestBrowseVisible and G.IsQuestBrowseVisible(id,options)) then return end
   seen[id]=true;matchesAll[#matchesAll+1]=id
  end
  if mode=="active" or mode=="turnin" or mode=="selected" or mode=="deferred" or (mode=="all" and text=="") then
   local ids={}
   if mode=="active" or mode=="turnin" or (mode=="all" and text=="") then
    for id in pairs(G.activeQuests or {}) do
     if mode~="turnin" or G.IsReadyToTurnIn(id) then ids[#ids+1]=id end
    end
   elseif mode=="selected" then
    for id,v in pairs((G.db and G.db.selectedQuests) or {}) do if v then ids[#ids+1]=id end end
   elseif mode=="deferred" then
    for id,v in pairs((G.db and G.db.deferredQuests) or {}) do if v then ids[#ids+1]=id end end
   end
   for _,id in ipairs(ids) do add(id,true) end
  elseif mode=="zone" then
   local chosen=tonumber(G.selection.zone or (G.db and G.db.selectedZone))
   local zones=G.SearchQuestZones(query)
   local relevant={}
   if text~="" and #zones>0 then relevant=zones
   elseif chosen and index.zones[chosen] then relevant={index.zones[chosen]}
   elseif #zones>0 then
    local current=G.SafeCall(C_Map and C_Map.GetBestMapForUnit,"player")
    local first=current and index.zones[current] or zones[1]
    G.selection.zone=first.key
    if G.db then G.db.selectedZone=first.key end
    relevant={first}
   end
   for _,zone in ipairs(relevant) do
    for _,id in ipairs(zone.ids) do add(id,text=="" or #zones==0) end
   end
  elseif mode=="all" then
   local zoneKeys={}
   if text~="" then for _,z in ipairs(G.SearchQuestZones(query)) do zoneKeys[z.key]=true end end
   local exact=tonumber(text)
   if exact and G.DBGet(QuestDB,exact,"name") then add(exact,false) end
   for i=1,index.loaded do
    local id=index.ids[i]
    if id and index.normalized[id] and (matches(id,text) or zoneKeys[index.zoneByQuest[id]]) then add(id,false) end
   end
  end
  sortResults(matchesAll,sort)
  if stable then browseCache={key=key,ids=matchesAll} end
 end
 local total=#matchesAll
 local out={}
 for i=offset+1,math.min(offset+limit,total) do out[#out+1]=matchesAll[i] end
 return out,total,indexed and not index.ready
end
function G.SelectedCount()
 local n=0
 for _,enabled in pairs(G.db.selectedQuests or {}) do if enabled then n=n+1 end end
 return n
end
function G.SelectedQuestIds()
 local ids={}
 for id,enabled in pairs(G.db.selectedQuests or {}) do
  if enabled then ids[#ids+1]=tonumber(id) end
 end
 table.sort(ids)
 return ids
end
function G.ToggleQuestChecked(id,enabled)
 id=tonumber(id)
 if not id or id<=0 then return false end
 G.db.selectedQuests=G.db.selectedQuests or {}
 if enabled==nil then enabled=not G.db.selectedQuests[id] end
 local hard=enabled and G.RouteHardBlock(id)
 if enabled and hard and not G.db.selectedQuests[id] then
  G.Print("동선 체크 불가: "..G.GetQuestName(id).." · "..hard)
  if G.UIRefresh then G.UIRefresh() end
  return false
 end
 if enabled and not G.db.selectedQuests[id] and not G.IsInLog(id) and not G.IsRouteSatisfied(id) then
  local graph,why=G.ResolveRouteRequirements(id,{})
  if not graph then
   G.Print("동선 체크 불가: "..G.GetQuestName(id).." · "..(why or "선행 조건 확인 필요"))
   if G.UIRefresh then G.UIRefresh() end
   return false
  end
 end
 if enabled and not G.IsInLog(id) and not G.IsEligibleQuest(id) then
  G.db.selectedQuests[id]=nil
  G.Print("다른 진영/종족/직업 퀘스트는 현재 캐릭터의 동선에 추가할 수 없습니다: "..G.GetQuestName(id))
  if G.UIRefresh then G.UIRefresh() end
  return false
 end
 if enabled and G.RouteExclusionReason and G.RouteExclusionReason(id) then
  G.Print("동선 제외: "..G.GetQuestName(id).." · "..G.RouteExclusionReason(id))
  if G.UIRefresh then G.UIRefresh() end
  return false
 end
 if enabled and G.IsCompleted(id) then
  G.db.selectedQuests[id]=nil
  G.Print("이미 완료한 퀘스트는 동선 대상에서 제외됩니다: "..G.GetQuestName(id))
  if G.UIRefresh then G.UIRefresh() end
  return false
 end
 if enabled then
  G.db.selectedQuests[id]=true
 else
  G.db.selectedQuests[id]=nil
 end
 if G.db.guide and G.db.guide.mode=="selected" and (G.db.guide.scope or "checked")=="checked" and G.ReplanSelectedGuide then
  G.ReplanSelectedGuide("체크 목록 변경")
 end
 if G.UIRefresh then G.UIRefresh() end
 return true
end
function G.ClearCheckedQuests()
 G.db.selectedQuests={}
 if G.db.guide and G.db.guide.mode=="selected" and (G.db.guide.scope or "checked")=="checked" then G.StopGuide() end
 if G.UIRefresh then G.UIRefresh() end
end

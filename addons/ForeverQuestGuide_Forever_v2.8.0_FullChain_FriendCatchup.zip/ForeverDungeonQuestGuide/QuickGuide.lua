local addon,G=...
-- One temporary focus route per character. Preserve the earlier route and
-- its manual progress without affecting actual quest flags or checkbox sets.
function G.HasSuspendedGuide()
 local s=G.db and G.db.suspendedGuide
 return type(s)=="table" and type(s.guide)=="table" and type(s.guide.steps)=="table" and type(s.manualProgress)=="table"
end
local function inCombat() return InCombatLockdown and InCombatLockdown() end
function G.StartQuickGuide(id)
 id=tonumber(id)
 if not id or id<=0 or id~=math.floor(id) then G.Print("퀘스트 번호를 확인하세요.");return false end
 if inCombat() then G.Print("전투가 끝난 뒤 퀘스트 가이드를 시작하세요.");return false end
 if not G.db or not G.db.deferredQuests then return false end
 G.PlayerRefresh();G.RefreshQuestLog()
 if G.IsCompleted(id) then G.Print("이미 보고한 퀘스트입니다: "..G.GetQuestName(id));return false end
 if not G.IsInLog(id) and (not G.Ready() or not G.DBGet(QuestDB,id,"name")) then G.Print("이미 받은 퀘스트 또는 연결된 자료에서 확인된 퀘스트를 선택하세요.");return false end
 local old=G.db.guide
 local wasDeferred=G.db.deferredQuests[id]
 -- Choosing a quest directly is an explicit request to resume it. Only that
 -- quest is resumed, and only after a successful preflight.
 G.db.deferredQuests[id]=nil
 local ok,nextGuide,err,meta=pcall(G.BuildSelectedGuide,false,{scope="quest",focus=id})
 if not ok or not nextGuide then
  G.db.deferredQuests[id]=wasDeferred
  local detail=ok and err or "동선 계산 실패"
  local reason=meta and meta.excluded and meta.excluded[1] and meta.excluded[1].reason
  G.Print((reason or detail or "동선 생성 실패").." · 기존 동선 유지")
  return false,reason or detail
 end
 if not G.HasSuspendedGuide() and old and old.steps and #old.steps>=(old.index or 1) and not (old.scope=="quest" and old.focus==id) then
  G.db.suspendedGuide={guide=old,manualProgress=G.db.manualProgress or {}}
 end
 if G.ClearWaypoint then G.ClearWaypoint() end
 G.db.guide=nextGuide;G.db.manualProgress={};G.guideFeedback=nil
 G.db.hudHidden=false;G.db.hudCollapsed=false
 G.ReconcileGuide()
 if G.CurrentStep() then G.ActivateGuideStep(false) end
 if G.IsUIShown and G.IsUIShown() and G.ShowUI then G.ShowUI(false) end
 G.NotifyDataChange()
 G.Print("단일 퀘스트 가이드: "..G.GetQuestName(id)..(G.HasSuspendedGuide() and " · 기존 동선 보관 중" or ""))
 return true
end
function G.ResumeSuspendedGuide()
 if inCombat() then G.Print("전투 종료 후 기존 동선에 복귀하세요.");return false end
 if not G.HasSuspendedGuide() then G.Print("보관된 기존 동선이 없습니다.");return false end
 local saved=G.db.suspendedGuide
 if G.ClearWaypoint then G.ClearWaypoint() end
 G.db.suspendedGuide=nil
 G.db.guide=saved.guide;G.db.manualProgress=saved.manualProgress
 G.db.hudHidden=false;G.db.hudCollapsed=false;G.guideFeedback=nil
 G.PlayerRefresh();G.RefreshQuestLog()
 if G.HydrateGuideLocations then G.HydrateGuideLocations() end
 if saved.guide.mode=="selected" then G.ReplanSelectedGuide("기존 동선 복귀") else G.ReconcileGuide() end
 if G.CurrentStep() then G.ActivateGuideStep(false) end
 G.NotifyDataChange();G.Print("기존 동선 복귀 · 현재 캐릭터의 실제 퀘스트 상태 반영")
 return true
end
function G.StartActiveGuide(turninOnly)
 if inCombat() then G.Print("전투가 끝난 뒤 동선을 시작하세요.");return false end
 return G.StartSelectedGuide(turninOnly==true,{scope="active"})
end
G.API.StartQuest=function(id) return G.StartQuickGuide(id) end
G.API.ResumeRoute=function() return G.ResumeSuspendedGuide() end

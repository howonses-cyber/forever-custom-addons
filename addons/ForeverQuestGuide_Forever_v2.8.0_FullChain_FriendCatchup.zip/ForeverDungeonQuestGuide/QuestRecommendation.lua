local addon,G=...
G.recommendationVersion="2.6.0"
-- Read-only shortlisting. This does not accept, abandon, turn in, or navigate.
-- Distances are comparable only when BOTH positions use one real UI-map ID.
local baseRank={turnin=10000,active=6000,ready=3000,locked=500}
local phaseTitle={turnin="보고",active="수행",ready="수락",locked="선행"}
local function invoke(name,...)
 local fn=G[name]
 if type(fn)~="function" then return nil end
 local ok,a,b,c=pcall(fn,...)
 if ok then return a,b,c end
end
local function pointOk(p)
 return type(p)=="table" and not p.approx and type(p.map)=="number" and
  type(p.x)=="number" and type(p.y)=="number" and
  p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function proximity(here,point)
 if not pointOk(here) or not pointOk(point) or here.map~=point.map then return nil end
 local dx,dy=here.x-point.x,here.y-point.y
 return math.sqrt(dx*dx+dy*dy)
end
local function candidateStage(code)
 return code=="turnin" and "turnin" or code=="ready" and "accept" or "objective"
end
function G.RecommendNextQuest(ids,journeyCache,stateCache)
 if type(ids)~="table" then return nil end
 journeyCache=type(journeyCache)=="table" and journeyCache or {}
 stateCache=type(stateCache)=="table" and stateCache or {}
 local here=invoke("PlayerLocation")
 local groups,seen,density={},{},{}
 -- Grouping is an *observed list density*, never estimated XP/hour.
 for _,raw in ipairs(ids) do
  local id=tonumber(raw)
  if id and id>0 and id%1==0 and not seen[id] then
   seen[id]=true
   local state=stateCache[id]
   local code=type(state)=="table" and state.code or nil
   if not code then local _,assessed=invoke("RouteAssessment",id);code=assessed end
   if baseRank[code] and not (G.db and G.db.deferredQuests and G.db.deferredQuests[id]) then
    -- The current accepted quest log is authoritative even when the DB is stale.
    local inLog=invoke("IsInLog",id)
    if (inLog or code~="active" and code~="turnin") and
       (inLog or not invoke("IsCompleted",id)) then
     local zone=invoke("GetQuestZone",id)
     local entry={id=id,code=code,zone=zone}
     groups[#groups+1]=entry
     if zone~=nil then density[zone]=(density[zone] or 0)+1 end
    end
   end
  end
 end
 local candidates={}
 for _,entry in ipairs(groups) do
  local id,code=entry.id,entry.code
  local phase=candidateStage(code)
  local point=invoke("QuestPoint",id,phase)
  local distance=proximity(here,point)
  local cluster=entry.zone and density[entry.zone] or 0
  local level=tonumber(G.player and G.player.level)
  local target=invoke("GetQuestLevel",id)
  local nearLevel=level and type(target)=="number" and target>0
   and math.max(0,24-5*math.abs(target-level)) or 0
  local closeness=distance and math.max(0,260-440*distance) or 0
  entry.distance=distance;entry.cluster=cluster
  entry.score=baseRank[code]+closeness+math.min(36,cluster*4)+nearLevel
  candidates[#candidates+1]=entry
 end
 table.sort(candidates,function(a,b)
  if a.score~=b.score then return a.score>b.score end
  -- Deterministic fallback; uncertain coordinates never become a fake tie-break.
  return a.id<b.id
 end)
 for _,entry in ipairs(candidates) do
  -- The existing route solver is the final safety gate, including prerequisites,
  -- deferred chains and faction/level/profession restrictions.
  local journey=journeyCache[entry.id]
  if not journey then journey=invoke("QuestJourney",entry.id,stateCache);journeyCache[entry.id]=journey end
  if journey and journey.canGuide and journey.actionQuestId then
   local basis=phaseTitle[entry.code] or "진행"
   local reason=(entry.code=="turnin" and "게임에서 보고 가능한 퀘스트를 우선합니다." or
    entry.code=="active" and "이미 받은 퀘스트를 먼저 진행합니다." or
    entry.code=="ready" and "현재 수락 조건을 통과한 퀘스트입니다." or
    "실행 가능한 선행 퀘스트부터 안내합니다.")
   if entry.distance then
    reason=reason.." 현재 지도에서 확인된 좌표의 직선 근접도만 참고했습니다."
   elseif entry.cluster>1 then
    reason=reason.." 현재 목록의 같은 지역 퀘스트 "..entry.cluster.."개를 함께 참고했습니다."
   end
   reason=reason.." 경험치·실제 이동 시간·지형 최단 경로의 보증은 아닙니다."
   return {questId=entry.id,actionQuestId=journey.actionQuestId,journey=journey,
    phase=entry.code,phaseLabel=basis,reason=reason,score=entry.score,
    hasComparablePosition=entry.distance~=nil,cluster=entry.cluster,
    evaluated=#candidates}
  end
 end
 return nil
end

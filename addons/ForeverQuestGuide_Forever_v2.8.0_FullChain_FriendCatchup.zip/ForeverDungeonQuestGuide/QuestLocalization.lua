local addon,G=...
-- Exact source-title correspondence, not an assertion of current Forever availability.
-- Wowhead Classic (English/Korean) Nightmare Incursions Overview.
-- https://www.wowhead.com/classic/guide/season-of-discovery/nightmare-incursions-overview
-- https://www.wowhead.com/classic-ptr/ko/guide/season-of-discovery/nightmare-incursions-overview
local aliases={
 ["Hinterlands Mission I: Defeat Moonkin"]="동부 내륙지 임무 I: 달빛야수 처치",
 ["Hinterlands Mission II: Defeat Giant Turtles"]="동부 내륙지 임무 II: 거대 거북이 처치",
 ["Hinterlands Mission III: Defeat Dragonkin"]="동부 내륙지 임무 III: 용족 처치",
 ["Hinterlands Mission IV: Dragon Intelligence"]="동부 내륙지 임무 IV: 용 첩보",
 ["Hinterlands Mission V: Turtle Intelligence"]="동부 내륙지 임무 V: 거북이 첩보",
 ["Hinterlands Mission VI: Moonkin Intelligence"]="동부 내륙지 임무 VI: 달빛야수 첩보",
 ["Hinterlands Mission VII: Recover Star-Touched Dragonegg"]="동부 내륙지 임무 VII: 별에 물든 용의 알 회수",
 ["Hinterlands Mission VIII: Recover Elunar Relic"]="동부 내륙지 임무 VIII: 엘루나르 유물 회수",
 ["Hinterlands Mission IX: Recover Dreampearl"]="동부 내륙지 임무 IX: 꿈진주 회수",
 ["Hinterlands Mission X: Star Lotus"]="동부 내륙지 임무 X: 별빛연꽃",
 ["Hinterlands Mission XI: Starsilver Ore"]="동부 내륙지 임무 XI: 별빛은 광석",
 ["Hinterlands Mission XII: Starshells"]="동부 내륙지 임무 XII: 별빛껍질",
 ["Hinterlands Mission XIII: Defeat Florius"]="동부 내륙지 임무 XIII: 플로리우스 처치",
 ["Hinterlands Mission XIV: Defeat Doomkin"]="동부 내륙지 임무 XIV: 파멸의 자손 처치",
 ["Hinterlands Mission XV: Defeat Ghamoo-Raja"]="동부 내륙지 임무 XV: 가무라자 처치",
 ["Hinterlands Mission XVI: Rescue Elianar Shadowdrinker"]="동부 내륙지 임무 XVI: 엘리아나르 섀도드링커 구출",
 ["Hinterlands Mission XVII: Rescue Serlina Starbright"]="동부 내륙지 임무 XVII: 세를리나 스타브라이트 구출",
 ["Hinterlands Mission XVIII: Rescue Veanna Cloudsleeper"]="동부 내륙지 임무 XVIII: 베아나 클라우드슬리퍼 구출",
 ["Feralas Mission I: Defeat Children of Cenarius"]="페랄라스 임무 I: 세나리우스의 자손 처치",
 ["Feralas Mission II: Defeat Harpies"]="페랄라스 임무 II: 하피 처치",
 ["Feralas Mission III: Defeat Dragonkin"]="페랄라스 임무 III: 용족 처치",
 ["Feralas Mission IV: Dragon Intelligence"]="페랄라스 임무 IV: 용 첩보",
 ["Feralas Mission V: Cenarion Intelligence"]="페랄라스 임무 V: 세나리온 첩보",
 ["Feralas Mission VI: Harpy Intelligence"]="페랄라스 임무 VI: 하피 첩보",
 ["Feralas Mission VII: Recover Moonglow Dragonegg"]="페랄라스 임무 VII: 달빛너울 용의 알 회수",
 ["Feralas Mission VIII: Recover Keeper's Notes"]="페랄라스 임무 VIII: 수호자의 기록 회수",
 ["Feralas Mission IX: Recover Harpy Screed"]="페랄라스 임무 IX: 하피의 장광설 회수",
 ["Feralas Mission X: Moonroot"]="페랄라스 임무 X: 달뿌리",
 ["Feralas Mission XI: Greater Moonstone"]="페랄라스 임무 XI: 상급 월장석",
 ["Feralas Mission XII: Greater Moondragon Scales"]="페랄라스 임무 XII: 상급 달의 용비늘",
 ["Feralas Mission XIII: Defeat Tyrannikus"]="페랄라스 임무 XIII: 티라니쿠스 처치",
 ["Feralas Mission XIV: Defeat Alondrius"]="페랄라스 임무 XIV: 알론드리우스 처치",
 ["Feralas Mission XV: Defeat Slirena"]="페랄라스 임무 XV: 슬리레나 처치",
 ["Feralas Mission XVI: Rescue Mellias Earthtender"]="페랄라스 임무 XVI: 멜리아스 어스텐더 구출",
 ["Feralas Mission XVII: Rescue Nerene Brooksinger"]="페랄라스 임무 XVII: 네렌 브룩싱어 구출",
 ["Feralas Mission XVIII: Rescue Jamniss Treemender"]="페랄라스 임무 XVIII: 잼니스 트리멘더 구출",
}
function G.ExternalKoreanQuestName(raw)
 return aliases[raw]
end
function G.ExternalQuestNameNote(id,raw)
 if not aliases[raw] then return nil end
 if tonumber(id)==81833 and raw=="Hinterlands Mission X: Star Lotus" then
  return "클래식 한국어 명칭 대조 · 포에버 공개 자료에 현재 수락 불가로 표시됨. 게임에서 수락 여부 확인 필요."
 end
 return "클래식 한국어 명칭 대조 · 포에버 실제 수락 가능 여부는 별도 확인 필요."
end

-- Display localization is independent of route/quest identity. Never replace
-- an installed database's name merely because a different dataset reused its ID.
local function normalized(s)
 if type(s)~="string" then return nil end
 return s:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):lower():gsub("[%s%p%c]","")
end
function G.HasKoreanText(s)
 if type(s)~="string" then return false end
 for i=1,#s-2 do
  local a,b,c=s:byte(i,i+2)
  if a and a>=224 and a<=239 and b and b>=128 and b<=191 and c and c>=128 and c<=191 then
   local cp=(a-224)*4096+(b-128)*64+c-128
   if (cp>=44032 and cp<=55203) or (cp>=4352 and cp<=4607) or (cp>=12592 and cp<=12687) then return true end
  end
 end
 return false
end
local reverseNames={}
local function exactName(kind,raw)
 if type(raw)~="string" or raw=="" then return nil end
 local paired=G.enGameNames and G.enGameNames[kind]
 local translated=G.koGameNames and G.koGameNames[kind]
 if not paired or not translated then return nil end
 local reverse=reverseNames[kind]
 if not reverse then
  reverse={}
  for id,en in pairs(paired) do
   local ko=translated[id]
   if type(en)=="string" and type(ko)=="string" and G.HasKoreanText(ko) then
    local key=normalized(en)
    if reverse[key]~=nil and reverse[key]~=ko then reverse[key]=false else reverse[key]=ko end
   end
  end
  reverseNames[kind]=reverse
 end
 return reverse[normalized(raw)] or nil
end
local function phrase(raw)
 if type(raw)~="string" or not raw:find("%a") then return nil end
 local explicit=G.koTextReplacements and G.koTextReplacements[raw]
 if explicit then return explicit end
 for _,kind in ipairs({"zone","item","npc","object","quest"}) do
  local value=exactName(kind,raw)
  if value then return value end
 end
 return aliases[raw]
end
function G.KoreanText(value)
 if type(value)~="string" or value=="" or not value:find("%a") then return value end
 local direct
 if not value:find("|",1,true) and not value:find("https?://") then
  direct=(G.koTextReplacements and G.koTextReplacements[value]) or (not G.HasKoreanText(value) and phrase(value))
 end
 if direct then return direct end
 local saved={}
 local function protect(text)
  saved[#saved+1]=text;return "\001"..#saved.."\002"
 end
 local working=value:gsub("|T.-|t",protect):gsub("|A.-|a",protect):gsub("|H.-|h",protect)
 working=working:gsub("|c%x%x%x%x%x%x%x%x",protect):gsub("|r",protect):gsub("https?://%S+",protect)
 -- Only whole English name spans with an exact verified correspondence are
 -- replaced. Unknown prose, hyperlink payloads, texture paths and IDs survive.
 local out=working:gsub("([A-Za-z][A-Za-z0-9 '%-:]*)",function(span)
  local body,spaces=span:match("^(.-)(%s*)$")
  return (phrase(body) or body)..spaces
 end)
 -- A known bilingual label should not repeat the same Korean name twice.
 out=out:gsub("([^()\n]+)%(([^()\n]+)%)",function(before,inside)
  local trimmed=before:gsub("%s+$","")
  local inner=inside:gsub("^%s+",""):gsub("%s+$","")
  if G.HasKoreanText(inner) and trimmed:sub(-#inner)==inner then return trimmed end
  return before.."("..inside..")"
 end)
 local restored=out:gsub("\001(%d+)\002",function(index)return saved[tonumber(index)] end)
 return restored
end
function G.KoreanName(kind,id,raw,fallback)
 if type(raw)=="string" and G.HasKoreanText(raw) then return G.KoreanText(raw) end
 local place=kind=="zone" and G.koTextReplacements and G.koTextReplacements[raw]
 if place then return place end
 id=tonumber(id)
 local ko=G.koGameNames and G.koGameNames[kind] and G.koGameNames[kind][id]
 local en=G.enGameNames and G.enGameNames[kind] and G.enGameNames[kind][id]
 if ko and (not raw or raw=="" or normalized(raw)==normalized(en) or normalized(raw)==normalized(ko)) then return ko end
 local byName=kind=="quest" and aliases[raw] or nil
 byName=byName or exactName(kind,raw)
 if byName then return byName end
 if type(fallback)=="string" and G.HasKoreanText(fallback) then return G.KoreanText(fallback) end
 if type(raw)=="string" and raw~="" then
  if raw:find("한글 명칭 미확인",1,true) then return raw end
  return "한글 명칭 미확인 ("..raw..")"
 end
 return fallback
end
function G.KoreanQuestObjectives(id,value)
 local ko=G.koQuestObjectives and G.koQuestObjectives[tonumber(id)]
 local en=G.enQuestObjectives and G.enQuestObjectives[tonumber(id)]
 local function objectiveKey(s)
  if type(s)~="string" then return nil end
  -- Punctuation can change counts (1.0 / 10, 2/3 / 23). Only whitespace,
  -- case and color wrappers are irrelevant to this exact-source comparison.
  return s:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):lower():gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")
 end
 local function one(raw,index)
  if type(raw)~="string" then return raw end
  if G.HasKoreanText(raw) then return G.KoreanText(raw) end
  if type(ko)=="table" and type(en)=="table" then
   if index and ko[index] and objectiveKey(raw)==objectiveKey(en[index]) then return ko[index] end
   for i,source in ipairs(en) do if ko[i] and objectiveKey(raw)==objectiveKey(source) then return ko[i] end end
   if objectiveKey(raw)==objectiveKey(table.concat(en," / ")) then return table.concat(ko," / ") end
  end
  return G.KoreanText(raw)
 end
 if type(value)=="table" then local result={};for k,v in pairs(value) do result[k]=one(v,k) end;return result end
 return one(value)
end

local addon,G=...
G.narrativeVersion="2.8.0"
-- Read-only narrative connections, deliberately distinct from acceptance rules.
-- Forward/breadcrumb links are evidence of a story connection, NOT a requirement.
local edges,forward,backward,seen={}, {}, {}, {}
local curated={
 -- Ragnar's optional referral: the in-dungeon recipe quest can be obtained
 -- directly from Ragnar without completing the referral.
 {4128,4126,"breadcrumb"},
 -- Forever quest-record and community-confirmed Torch of Retribution series.
 {3441,3442,"followup"},{3442,3443,"followup"},{3443,3452,"followup"},
 {3452,3453,"followup"},{3453,3454,"followup"},{3454,3462,"followup"},
 {3462,3463,"followup"},{3463,3481,"followup"},
 {3481,4022,"followup"},
 -- Cyrus offers two mutually exclusive molt presentations, not two required stages.
 {4022,4024,"alternative"},{4023,4024,"alternative"},
}
local titleById={[4128]="라그나르·헐레이 연계",[4126]="라그나르·헐레이 연계"}
for _,id in ipairs({3441,3442,3443,3452,3453,3454,3462,3463,3481,4022,4023,4024}) do
 titleById[id]="화염의 맛 전체 연계"
end
local priority={required=4,alternative=3,followup=2,breadcrumb=1}
-- Pinned, manually verified exceptions must not be accidentally promoted to
-- mandatory when a different quest database uses an imprecise chain field.
local confirmedKinds={["4128:4126"]="breadcrumb",["4022:4024"]="alternative",["4023:4024"]="alternative"}
local function valid(id)
 id=tonumber(id)
 return id and id>0 and id<100000000 and id%1==0 and id or nil
end
local function attach(source,target,kind)
 source,target=valid(source),valid(target)
 if not source or not target or source==target then return end
 local key=source..":"..target
 kind=confirmedKinds[key] or kind
 if not edges[key] or priority[kind]>priority[edges[key]] then edges[key]=kind end
 forward[source]=forward[source] or {};forward[source][target]=true
 backward[target]=backward[target] or {};backward[target][source]=true
end
local function reset()
 edges,forward,backward,seen={}, {}, {}, {}
 for _,edge in ipairs(curated) do attach(edge[1],edge[2],edge[3]) end
end
reset()
function G.ResetNarrativeIndex() reset() end
function G.IndexNarrativeQuest(id)
 id=valid(id)
 if not id or seen[id] or not G.Ready or not G.Ready() or not G.DBGet then return end
 seen[id]=true
 local function linkList(field,kind)
  local list=G.DBGet(QuestDB,id,field)
  if type(list)~="table" then return end
  for _,raw in ipairs(list) do
   local q=valid(raw)
   if q then attach(q,id,kind) end
  end
 end
 -- These fields have distinct semantics: all-of vs one-of alternatives.
 linkList("preQuestGroup","required")
 local one=G.DBGet(QuestDB,id,"preQuestSingle")
 if type(one)=="table" then
  for _,value in ipairs(one) do
   local q=valid(value)
   if q then attach(q,id,#one==1 and "required" or "alternative") end
  end
 end
 local nextId=valid(G.DBGet(QuestDB,id,"nextQuestInChain"))
 if nextId then attach(id,nextId,"followup") end
 local breadcrumb=valid(G.DBGet(QuestDB,id,"breadcrumbForQuestId"))
 if breadcrumb then attach(id,breadcrumb,"breadcrumb") end
end
local function ids(t)
 local result={}
 for n in pairs(t or {}) do result[#result+1]=n end
 table.sort(result)
 return result
end
local function ensure(id)
 G.IndexNarrativeQuest(id)
 for _,q in ipairs(ids(backward[id])) do G.IndexNarrativeQuest(q) end
 for _,q in ipairs(ids(forward[id])) do G.IndexNarrativeQuest(q) end
end
function G.NarrativeEdgeKind(a,b) return edges[tostring(a)..":"..tostring(b)] end
function G.NarrativeParents(id)
 id=valid(id);if not id then return {} end
 ensure(id)
 return ids(backward[id])
end
function G.NarrativeChildren(id)
 id=valid(id);if not id then return {} end
 ensure(id)
 return ids(forward[id])
end
function G.NarrativeTitle(id) return titleById[tonumber(id)] end
-- The entire connected, bounded component. Its order is a topological DISPLAY
-- order only. Never infer that a branch or optional breadcrumb is mandatory.
function G.QuestNarrativeFamily(root,limit)
 root=valid(root);if not root then return nil end
 local cap=math.max(2,math.min(64,math.floor(tonumber(limit) or 42)))
 local queue={root};local member={[root]=true};local cursor=1;local truncated=false
 while cursor<=#queue do
  local id=queue[cursor];cursor=cursor+1;ensure(id)
  local connected=ids(forward[id])
  for _,parent in ipairs(ids(backward[id])) do connected[#connected+1]=parent end
  table.sort(connected)
  for _,other in ipairs(connected) do
   if not member[other] then
    if #queue<cap then member[other]=true;queue[#queue+1]=other
    else truncated=true end
   end
  end
 end
 local indegree,children,kinds={}, {}, {}
 local optional=false;local branched=false
 for id in pairs(member) do indegree[id]=0;children[id]={} end
 for id in pairs(member) do
  for _,nextId in ipairs(ids(forward[id])) do if member[nextId] then
   local kind=G.NarrativeEdgeKind(id,nextId)
   children[id][#children[id]+1]=nextId
   indegree[nextId]=indegree[nextId]+1
   kinds[id..":"..nextId]=kind
   if kind~="required" then optional=true end
  end end
 end
 local ready={};for id in pairs(member) do if indegree[id]==0 then ready[#ready+1]=id end end
 table.sort(ready)
 local ordered={}
 while #ready>0 do
  local q=table.remove(ready,1);ordered[#ordered+1]=q
  if #children[q]>1 then branched=true end
  for _,other in ipairs(children[q]) do
   indegree[other]=indegree[other]-1
   if indegree[other]==0 then ready[#ready+1]=other;table.sort(ready) end
  end
 end
 local cycle=#ordered~=#queue
 if cycle then
  for _,id in ipairs(ids(member)) do
   local present=false;for _,q in ipairs(ordered) do if q==id then present=true;break end end
   if not present then ordered[#ordered+1]=id end
  end
 end
 for id in pairs(member) do
  if #ids(backward[id])>1 then branched=true end
 end
 local name=titleById[root]
 if not name then
  for _,id in ipairs(ordered) do if titleById[id] then name=titleById[id];break end end
 end
 local incomplete=G.questIndex and G.questIndex.available and not G.questIndex.ready or false
 return {root=root,ids=ordered,member=member,edges=kinds,title=name or (G.GetQuestName and G.GetQuestName(ordered[1]) or "연계 퀘스트"),
  branch=branched,optional=optional,cycle=cycle,truncated=truncated,indexing=incomplete,
  linear=not branched and not cycle and not truncated and not optional}
end

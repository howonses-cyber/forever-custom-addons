Forever BiS Audit v0.4.0 (2026-11-24)

[설치]
ZIP 안의 ForeverBiSAudit 폴더를 Interface/AddOns 아래에 설치하거나 Forever Addon Manager 온라인 카탈로그로 설치.
기존 애드온/설정/WTF를 수정하지 않습니다.

[열기]
엘스미어UI 애드온 버튼 모음집의 황금색 장비 아이콘 클릭, 또는 /fbis
직업·특성 버튼을 누를 때마다 선택이 바뀝니다. 9개 직업 28개 역할 조합 탐색 지원.

[획득처 / 비스 데이터 범위]
선별된 초기 참고 데이터 74개, 7개 특성(고술, 무기/방어 전사, 사격 냥꾼, 전투 도적, 암사, 냉법)에 한해 등록.
7개도 슬롯별 완성형 검증 BiS는 아닙니다. 다른 21개 특성은 아직 수집 중이며 UI에 수록 목록이 없다고 표시합니다.
모든 '가이드 후보'는 외부 가이드의 후보, 실제 Forever 서버에서 드롭 확인됨을 뜻하지 않습니다.
'확인 필요'는 실제 획득처/진영/시기 미확인, '미개방'은 알방 등 현재 열리지 않은 콘텐츠.
현재 파밍 화면은 기본적으로 미개방을 숨깁니다. 필요 시 [미개방 포함]을 켜서 미래 장비를 참고하세요.
실시간 서버/웹 요청은 WoW 애드온에서 불가능하므로 최신 소스는 관리툴로 배포 업데이트.
검토일 2026-11-24. 실제 인게임 획득처, 직업별 레벨 제한/진영 가능 여부는 검증 필요.
공개된 Wowhead Forever 작성 가이드와 2026-11-23 ForeverWoW.gg 장비 순위 참고.

[비교 퍼센트 주의]
가방/착용 장비에 마우스를 올리면 현재 직업 3~4특성별 스탯 가중 점수(EP)가 표시됩니다.
'% EP' = (새 장비의 적용된 스탯 가중치 합 - 비교 슬롯 착용 장비 점수) / 착용 장비 점수 x 100.
이것은 시뮬레이션으로 측정한 실제 DPS/HPS/생존율 상승 퍼센트가 아닙니다.
무기 DPS, 공속, 효과 발동, 사용 효과, 세트 보너스, 타겟 종족/지역, 명중률 상한, 마법/특성 상호작용,
보석/마법부여, 탄약 및 토템/유물 특수효과를 정확히 반영하지 못합니다.
아이템 데이터가 게임 캐시에 없거나 0점/불일치 슬롯이면 비교 수치를 표시하지 않습니다.
각 특성의 사전 정의 가중치는 추정치이며, 고술/사격/냉법/신사는 출처가 있는 참고 가중치를 씁니다.
스탯 가중치가 1일 때 '+5% EP'가 '+5% DPS'를 뜻하지 않습니다. 절대로 그렇게 읽지 마세요.

[명령어]
/fbis                  창 열기/닫기
/fbis help             명령어 안내
/fbis weight str 1.5   현재 선택 특성 힘 가중치 설정
/fbis reset            현재 특성 가중치 초기화
/fbis tooltip off      가방/장착 장비 툴팁 비교 끄기
/fbis tooltip on       툴팁 비교 켜기
/fbis locked on        미개방 후보 표시
/fbis locked off       미개방 후보 숨김

[출처]
https://www.wowhead.com/forever/guide/classes/shaman/enhancement/bis-gear (updated Nov 20, 2026)
https://www.wowhead.com/forever/guide/classes/warrior/arms/bis-gear (updated Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/warrior/protection/bis-gear (Nov 2026)
https://www.wowhead.com/forever/guide/classes/hunter/marksmanship/bis-gear (Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/rogue/combat/bis-gear (Nov 22, 2026)
https://www.wowhead.com/forever/guide/classes/priest/shadow/bis-gear (Nov 17, 2026)
https://foreverwow.gg/shaman/enhancement/pre-raid/ (Nov 23, 2026)
https://foreverwow.gg/mage/frost/pre-raid/ (Nov 23, 2026)
https://www.wowhead.com/forever/gear-planner/warrior (Classic Era weights disclosed)
서버별 드롭 검증이 없는 경우 '검증'으로 표기하지 않습니다.

[참고] QuestieDB ItemDB.GetAllIds가 사용 가능하면 74개 후보의 아이템 ID를 읽기 전용으로 순차 탐색합니다.
이 과정에서 확인된 ID로 인게임 한글명/툴팁을 표시할 수 있으나 데이터 미발견 또는 미캐시 때는 보류합니다.

[BiS data automatic update]
External web access is not available to the WoW Lua runtime. A scheduled GitHub Action checks independent public pre-raid rankings. Only unambiguous matching items with a legitimate slot and source can enter the automatically compiled archive. Pending discrepancies remain unchanged, including PvP/raid/locked items. The installed addon never downloads external code. Forever Addon Manager shows the new ZIP when a verified data change is published, and updates only after the user presses Install. The current 74 curated candidates are NOT declared official in-game BiS. Personal Library mirrors the version at last assistant-run and is not directly writable from GitHub Actions.
/fbis data: print the installed data version and evidence policy.

[V0.3.0 - 착용 장비를 기준으로 비교]
- WoW Forever 1.60.1: 기존 제거된 GetItemStats / GetItemInfoInstant / OnTooltipSetItem 사용 대신 C_Item.GetItemStats / C_Item.GetItemInfoInstant / TooltipDataProcessor를 우선 사용합니다.
- 가방 아이템에 마우스를 올리면 실제 GetInventoryItemLink('player', slot)의 착용 장비 이름, 장착 슬롯 및 교체 전후 기본 스탯 EP 차이를 계산합니다.
- 반지/장신구: 같은 아이템을 착용했을 때는 해당 슬롯(0%); 다른 아이템은 비어 있는 슬롯 우선, 둘 다 차 있으면 낮은 EP 슬롯을 교체 후보로 표시합니다.
- 양손무기: 현재 주무기와 보조장비를 합친 EP와 비교합니다. 한손무기와 양손무기 직접 비교처럼 다른 무기 구성이 필요한 경우에는 %를 보류합니다.
- 해당 부위에 장비가 없거나 착용 장비의 EP가 계산되지 않으면 %를 만들어내지 않습니다. 원인과 후보 EP만 표시합니다.
- 이 계산은 기본 스탯의 정적 가중치 비교이며 실제 피해량/치유량/탱킹 성능 %, 무기 DPS, 공속, 발동 효과, 마법부여, 세트 효과를 포괄하지 않습니다.
- 프로그램 버전 0.4.0, 수록 BiS 데이터 버전은 0.2.0 유지. BiS 자동 수집/갱신 배포와 독립입니다.

[V0.4.0 - 고술 무기 공격력·속도 모델 및 특성별 무기 비교]
- 기존 V0.3.0은 GetItemStats 기본 능력치에 무기 최소/최대 피해·공격속도·기본 초당 공격력이 포함되지 않아, 스탯 옵션이 없는 양손 무기는 "측정 가능한 스탯 없음"으로 비교를 중단했습니다.
- 포에버 1.60.1에서 제공하는 C_TooltipInfo.GetHyperlink의 읽기 전용 좌/우 툴팁 문구를 이용하여 한글/영문 무기의 기본 최소·최대 피해와 공격속도를 추출합니다. API 부재 시에는 화면에 나타나지 않는 전용 숨김 툴팁으로 대체를 시도합니다.
- 고양 주술사의 양손 무기 비교: 평균 피해/공속으로 기본 무기 DPS를 구하고, 현재 캐릭터 공격력(AP)에 장비 교체로 직접 변경된 힘 및 전투력(조회 가능할 때만)을 더해 자동공격 기여량을 계산합니다.
- 질풍의 무기 모델은 발동률 20%, 추가 2회(재발동·내부쿨·전투 조건 무시)를 가정합니다. 폭풍의 일격은 최신 2026-11-20 패치 기준 100% 정규화 무기 피해, 재사용 대기 8초를 가정합니다.
- 출력 수치 "무기 물리 모델"은 (기본자동공격+질풍 기대 추가타+폭풍의 일격 빈도)의 단순 합이며, 실제 전투 전체 DPS, 파티 버프 또는 레이드 시뮬레이션이 아닙니다. 보스 방어도/적중/치명/질풍 토템/소용돌이치는 무기/마법 피해/마법부여/특수 발동 확률·쿨은 계산에서 제외합니다. 발동 효과가 있는 무기는 UI에 미반영 경고를 표시합니다.
- 정기와 복원 주술사는 무기의 물리 피해를 주문 DPS·치유 HPS로 환산하지 않습니다. 장착 무기(필요 시 보조장비까지 합산) 대비 주문력·치유 보너스·지능·치명/가속 점수·MP5 및 기본 EP의 변화만 표시합니다. 주문 계수, 회전, 대상, 실제 전투 로그가 없으면 정확한 주문 DPS/HPS 변화율을 제시하지 않습니다.
- 무기 정보 API 호출 실패 시 원인 표시 후 평가 보류, 조회에 성공하지 못한 캐릭터 AP 또는 현재 무기 스탯은 반영하지 않고 명확한 경고를 출력합니다.
- 관련 유틸/계산 소스: Weapon.lua. 기존 BiS 데이터/자동 검사 워크플로와 구버전 설정 저장 데이터는 그대로 유지했습니다.
- 검증: Lua 문법 검사와 별도 Lua 5.3 실행 환경에서 한국어/영문 무기 피해 추출, 질풍+폭격 물리 모델, 동일 장착 아이템, 정기·복원 스탯 분기, 한손+보조장비, 누락된 데이터 보호, 현대 툴팁 중복 방지 시나리오. 실제 포에버 클라이언트 수치 검증·아이템별 발동률·실전 DPS는 미검증.

[모델 근거]
- https://www.icy-veins.com/wow-forever/enhancement-shaman-melee-dps-pve-stat-priority
- https://www.wowhead.com/ptr-2/news/enhancement-shaman-class-changes-now-live-383858
- https://warcraft.wiki.gg/wiki/API_C_TooltipInfo.GetHyperlink
- https://www.wowhead.com/forever/guide/classes/shaman/restoration/stat-priority-pve-healer

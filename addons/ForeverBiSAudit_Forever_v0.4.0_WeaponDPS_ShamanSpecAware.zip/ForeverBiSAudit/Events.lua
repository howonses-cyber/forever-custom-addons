local _,B=...
if not CreateFrame then return end
local frame=CreateFrame('Frame')
frame:RegisterEvent('PLAYER_LOGIN')
frame:RegisterEvent('PLAYER_ENTERING_WORLD')
frame:RegisterEvent('PLAYER_EQUIPMENT_CHANGED')
frame:RegisterEvent('PLAYER_TALENT_UPDATE')
frame:SetScript('OnEvent',function(_,event)
 if event=='PLAYER_LOGIN' or event=='PLAYER_ENTERING_WORLD' then
  if not B.db then B:Initialize() end
  if B.CreateMinimapButton and not B.minimapButtonFrame then
   B.minimapButtonFrame=B:CreateMinimapButton()
  end
 elseif B.db and B.frame and B.frame:IsShown() then
  -- No hard dependency on manual spec auto-detection: chosen spec is user controlled.
  if B.RefreshUI then B:RefreshUI() end
 end
end)

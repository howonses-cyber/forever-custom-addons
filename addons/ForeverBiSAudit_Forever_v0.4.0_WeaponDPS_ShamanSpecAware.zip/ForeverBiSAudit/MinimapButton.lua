local _, B=...
local button
local function collected()
 local cache=_G._EBS_CachedAddonButtons
 if type(cache)~='table' or not button then return false end
 for _,value in ipairs(cache) do if value==button then return true end end
 return false
end
local function place()
 local map=_G.Minimap
 if not button or not map or button:GetParent()~=map or collected() then return end
 local radius=(map.GetWidth and map:GetWidth() or 140)/2+12
 local angle=math.rad(B.db and B.db.minimapAngle or 195)
 button:ClearAllPoints();button:SetPoint('CENTER',map,'CENTER',math.cos(angle)*radius,math.sin(angle)*radius)
end
function B:CreateMinimapButton()
 if button then place();button:Show();return button end
 if not UIParent or not CreateFrame then return end
 local p=_G.Minimap or UIParent
 button=CreateFrame('Button','ForeverBiSAuditMinimapButton',p)
 button:SetSize(32,32);button:SetFrameStrata('HIGH');button:SetFrameLevel(8)
 button:EnableMouse(true);button:RegisterForClicks('LeftButtonUp');button:RegisterForDrag('LeftButton')
 local bg=button:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.06,.075,.09,.95)
 local icon=button:CreateTexture(nil,'ARTWORK');icon:SetTexture('Interface\\Icons\\INV_Misc_ArmorKit_17')
 icon:SetTexCoord(.08,.92,.08,.92);icon:SetPoint('TOPLEFT',button,'TOPLEFT',3,-3);icon:SetPoint('BOTTOMRIGHT',button,'BOTTOMRIGHT',-3,3)
 button.icon=icon
 for i=1,4 do
  local t=button:CreateTexture(nil,'OVERLAY');t:SetColorTexture(1,.75,.24,1)
  if i==1 then t:SetHeight(2);t:SetPoint('TOPLEFT');t:SetPoint('TOPRIGHT')
  elseif i==2 then t:SetHeight(2);t:SetPoint('BOTTOMLEFT');t:SetPoint('BOTTOMRIGHT')
  elseif i==3 then t:SetWidth(2);t:SetPoint('TOPLEFT');t:SetPoint('BOTTOMLEFT')
  else t:SetWidth(2);t:SetPoint('TOPRIGHT');t:SetPoint('BOTTOMRIGHT') end
 end
 local highlight=button:CreateTexture(nil,'HIGHLIGHT');highlight:SetAllPoints(icon);highlight:SetColorTexture(.88,.69,.35,.2)
 button:SetScript('OnClick',function()B:Toggle()end)
 button:SetScript('OnEnter',function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,'ANCHOR_LEFT')
  GameTooltip:AddLine('Forever BiS Audit',1,.82,.4)
  GameTooltip:AddLine('클릭: 직업·특성별 장비 및 획득처',.85,.94,1)
  GameTooltip:AddLine('%는 스탯 점수 비교로 DPS %가 아닙니다.',1,.65,.55)
  if collected() then GameTooltip:AddLine('엘스미어UI 버튼 모음집에 통합',.7,.78,.9) end
  GameTooltip:Show()
 end)
 button:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
 button:SetScript('OnDragStart',function(self)
  if collected() or self:GetParent()~=_G.Minimap then return end
  if InCombatLockdown and InCombatLockdown() then return end
  self:SetScript('OnUpdate',function()
   if collected() or not GetCursorPosition then return end
   local cx,cy=GetCursorPosition()
   local mx,my=_G.Minimap:GetCenter()
   local scale=_G.Minimap.GetEffectiveScale and _G.Minimap:GetEffectiveScale() or 1
   if not mx or not my or not scale or scale<=0 then return end
   local dx,dy=cx/scale-mx,cy/scale-my
   if dx*dx+dy*dy<9 then return end
   local angle
   if math.atan2 then angle=math.deg(math.atan2(dy,dx))
   elseif dx==0 then angle=dy>=0 and 90 or -90
   else angle=math.deg(math.atan(dy/dx));if dx<0 then angle=angle+180 end end
   B.db.minimapAngle=angle;place()
  end)
 end)
 button:SetScript('OnDragStop',function(self)self:SetScript('OnUpdate',nil)end)
 if _G.Minimap then place() else button:SetPoint('TOPRIGHT',UIParent,'TOPRIGHT',-175,-91) end
 button:Show();return button
end

local _, B = ...
-- WoW Forever weapon comparison. This is an intentionally limited weapon-
-- contribution MODEL, never a combat simulation or a prediction of total DPS.
-- The player equipment remains the baseline for every comparison.
local function isNumber(v)
 return type(v)=='number' and v==v and v<100000000 and v>-100000000
end
local function round(v) return string.format('%.1f',v or 0) end
local function stripColor(s)
 if type(s)~='string' then return '' end
 return s:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r',''):gsub(',','')
end
local function scanLine(text,record)
 local t=stripColor(text)
 if #t>220 then return end
 if not record.min then
  local a,b=t:match('공격력%s*(%d+)%s*%-%s*(%d+)')
  if not a then a,b=t:match('^(%d+)%s*%-%s*(%d+)%s*[Dd]amage') end
  if not a then a,b=t:match('^(%d+)%s*%-%s*(%d+)%s*공격력') end
  if a and b and tonumber(a) and tonumber(b) and tonumber(a)<=tonumber(b) then
   record.min=tonumber(a);record.max=tonumber(b)
  end
 end
 if not record.speed then
  local n=t:match('속도%s*([%d%.]+)') or t:match('[Ss]peed%s*([%d%.]+)')
  if n and tonumber(n) and tonumber(n)>.5 and tonumber(n)<8 then record.speed=tonumber(n) end
 end
 if not record.tooltipDPS then
  local n=t:match('초당%s*공격력%s*([%d%.]+)') or t:match('([%d%.]+)%s*[Dd]amage [Pp]er [Ss]econd')
  if n then record.tooltipDPS=tonumber(n) end
 end
 if t:find('공격 시',1,true) or t:find('일정 확률',1,true) or
    t:find('착용 효과',1,true) or t:find('Chance on hit',1,true) or
    t:find('chance on hit',1,true) or t:find('Equip:',1,true) or
    t:find('Use:',1,true) or t:find('사용 효과',1,true) then
  record.special=true
 end
end
local function collectLines(link)
 local lines={}
 if C_TooltipInfo and type(C_TooltipInfo.GetHyperlink)=='function' then
  local ok,t=pcall(C_TooltipInfo.GetHyperlink,link)
  if ok and type(t)=='table' and type(t.lines)=='table' then
   for _,v in ipairs(t.lines) do
    if v.leftText then lines[#lines+1]=v.leftText end
    if v.rightText then lines[#lines+1]=v.rightText end
   end
  end
 end
 if #lines>0 then return lines end
 -- Explicit fallback for clients without C_TooltipInfo. The hidden tooltip
 -- never modifies the GameTooltip and is never visible on screen.
 if type(CreateFrame)~='function' or not UIParent then return lines end
 if not B._fbisScanner then
  local ok,t=pcall(CreateFrame,'GameTooltip','ForeverBiSAuditWeaponScanner',UIParent,'GameTooltipTemplate')
  if not ok or not t then return lines end
  B._fbisScanner=t
 end
 local scanner=B._fbisScanner
 if not scanner or type(scanner.SetHyperlink)~='function' then return lines end
 pcall(function()
  scanner:SetOwner(UIParent,'ANCHOR_NONE')
  scanner:SetHyperlink(link)
  local n=math.min(35,scanner:NumLines() or 0)
  for i=1,n do
   local left=_G[scanner:GetName()..'TextLeft'..i]
   local right=_G[scanner:GetName()..'TextRight'..i]
   if left and left.GetText and left:GetText() then lines[#lines+1]=left:GetText() end
   if right and right.GetText and right:GetText() then lines[#lines+1]=right:GetText() end
  end
  scanner:Hide()
 end)
 return lines
end
function B:ReadWeapon(link)
 if not link then return nil,'무기 링크 없음' end
 local record={}
 local texts=collectLines(link)
 for i,line in ipairs(texts) do
  -- Physical damage and attack speed are in the header; avoid mistaking a
  -- long proc description for the weapon's base damage range.
  if i<=12 then scanLine(line,record)
  else
   local t=stripColor(line)
   if t:find('공격 시',1,true) or t:find('일정 확률',1,true) or t:find('착용 효과',1,true) or
      t:find('Chance on hit',1,true) or t:find('Equip:',1,true) then record.special=true end
  end
 end
 if not record.min or not record.max or not record.speed then
  return nil,'무기 공격력·공격속도 조회 실패 (아이템 정보 또는 툴팁 API 확인)'
 end
 record.baseAverage=(record.min+record.max)/2
 record.dps=record.baseAverage/record.speed
 return record,nil
end
local function rawStats(link)
 if not link then return {},false end
 local getter=(C_Item and type(C_Item.GetItemStats)=='function') and C_Item.GetItemStats or GetItemStats
 if type(getter)~='function' then return {},false end
 local ok,stats=pcall(getter,link)
 if ok and type(stats)=='table' then return stats,true end
 return {},false
end
local function addStats(to,source,sign)
 for k,v in pairs(source) do
  if type(k)=='string' and isNumber(v) then to[k]=(to[k] or 0)+v*(sign or 1) end
 end
end
local function getCurrent(slot)
 if type(GetInventoryItemLink)~='function' then return nil end
 local ok,v=pcall(GetInventoryItemLink,'player',slot)
 return ok and type(v)=='string' and v or nil
end
local function itemIdent(link)
 return link and type(link)=='string' and link:match('item:(%d+)') or nil
end
local function equalItem(a,b)
 if not a or not b then return false end
 return a==b or (itemIdent(a) and itemIdent(a)==itemIdent(b))
end
local function getAP()
 if type(UnitAttackPower)~='function' then return nil end
 local ok,a,b,c=pcall(UnitAttackPower,'player')
 if not ok or not isNumber(a) then return nil end
 return math.max(0,a+(isNumber(b) and b or 0)+(isNumber(c) and c or 0))
end
local function statNumber(s,k)
 local v=s[k]
 return isNumber(v) and v or 0
end
local function meleeAPDelta(new,old,class)
 local str=statNumber(new,'ITEM_MOD_STRENGTH_SHORT')-statNumber(old,'ITEM_MOD_STRENGTH_SHORT')
 local ap=statNumber(new,'ITEM_MOD_ATTACK_POWER_SHORT')-statNumber(old,'ITEM_MOD_ATTACK_POWER_SHORT')
 -- In WoW Forever, Shaman melee AP receives 2 AP per Strength; this is the
 -- direct item contribution only. Mental Dexterity talent conversion, set
 -- effects, temporary buffs and other stats are intentionally not guessed.
 return ap+((class=='SHAMAN' or class=='WARRIOR' or class=='PALADIN') and 2*str or 0)
end
local function simpleWeaponModel(weapon,attackPower,isTwoHand,isEnhancement)
 local ap=attackPower or 0
 local normal=isTwoHand and 3.3 or 2.4
 local direct=weapon.dps+ap/14
 local normalHit=weapon.baseAverage+ap*normal/14
 local swing=weapon.baseAverage+ap*weapon.speed/14
 -- Melee model: one auto-attack per weapon speed, Windfury Weapon's 20%
 -- chance of two extra swings (no chaining or ICD), and one 100% normalized
 -- Stormstrike per 8 sec. This is an upper-level baseline, not total DPS.
 return {auto=direct,windfury=isEnhancement and direct*.4 or 0,
         stormstrike=isEnhancement and normalHit/8 or 0,
         total=isEnhancement and (direct*1.4+normalHit/8) or direct,normalHit=normalHit,swing=swing,
         ap=ap}
end
local function weighted(stats,weights,statByAPI)
 local total,seen=0,0
 for k,v in pairs(stats) do
  local key=statByAPI[k]
  local factor=key and weights[key]
  if isNumber(v) and isNumber(factor) and factor~=0 then
   total=total+v*factor;seen=seen+1
  end
 end
 return total,seen
end
local function spellDeltas(new,old)
 local function d(key) return statNumber(new,key)-statNumber(old,key) end
 return {
  sp=d('ITEM_MOD_SPELL_POWER_SHORT')+d('ITEM_MOD_SPELL_DAMAGE_DONE_SHORT'),
  heal=d('ITEM_MOD_SPELL_HEALING_DONE_SHORT')+d('ITEM_MOD_HEALING_DONE_SHORT'),
  intel=d('ITEM_MOD_INTELLECT_SHORT'),mp5=d('ITEM_MOD_MANA_REGENERATION_SHORT'),
  crit=d('ITEM_MOD_CRIT_RATING_SHORT')+d('ITEM_MOD_SPELL_CRIT_RATING_SHORT'),
  haste=d('ITEM_MOD_HASTE_RATING_SHORT')+d('ITEM_MOD_SPELL_HASTE_RATING_SHORT'),
  nature=d('ITEM_MOD_NATURE_DAMAGE_SHORT'),
 }
end
local weaponLoc={INVTYPE_2HWEAPON=true,INVTYPE_WEAPON=true,
 INVTYPE_WEAPONMAINHAND=true,INVTYPE_WEAPONOFFHAND=true,
 INVTYPE_SHIELD=true,INVTYPE_HOLDABLE=true}
function B:IsWeaponLike(loc,slot)
 return weaponLoc[loc] or slot=='TwoHand' or slot=='MainHand' or slot=='OffHand'
end
function B:CompareWeapon(link,class,spec,slot,loc)
 local main=getCurrent(16)
 if not main then return nil,'현재 주무기 미착용 (교체 기준 없음)' end
 local hand=loc or self:ResolveEquipLocation(link)
 local targetTwoHand=hand=='INVTYPE_2HWEAPON' or slot=='TwoHand'
 local currentLoc=self:ResolveEquipLocation(main)
 local currentTwoHand=currentLoc=='INVTYPE_2HWEAPON'
 if not targetTwoHand and currentTwoHand then
  return nil,'양손 무기 착용 중: 한손+보조장비 조합을 먼저 지정해야 비교 가능'
 end
 local off=getCurrent(17)
 local targetOff=(hand=='INVTYPE_SHIELD' or hand=='INVTYPE_HOLDABLE' or
                  hand=='INVTYPE_WEAPONOFFHAND' or slot=='OffHand')
 local currentLink=targetOff and off or main
 local baselineParts={}
 if currentLink then baselineParts[#baselineParts+1]=currentLink end
 if targetTwoHand and off and not currentTwoHand then baselineParts[#baselineParts+1]=off end
 local cStats,goodC=rawStats(link)
 local bStats,goodB={},true
 for _,v in ipairs(baselineParts) do
  local stats,known=rawStats(v)
  addStats(bStats,stats)
  goodB=goodB and known
 end
 local scoreC,knownC=weighted(cStats,self:GetWeights(class,spec),self.statByAPI)
 local scoreB,knownB=weighted(bStats,self:GetWeights(class,spec),self.statByAPI)
 local comparedName=self.GetEquippedName and self.GetEquippedName(currentLink) or '현재 장비'
 if targetTwoHand and off and not currentTwoHand then
  comparedName=comparedName..' + '..(self.GetEquippedName and self.GetEquippedName(off) or '보조장비')
 end
 local diff=spellDeltas(cStats,bStats)
 local result={mode='weapon',class=class,spec=spec,compared=currentLink,
   comparedName=comparedName,equippedSlot=targetOff and 17 or 16,
   statsAvailable=goodC and goodB,statCandidate=scoreC,statEquipped=scoreB,
   statDelta=scoreC-scoreB,statKnown=knownC+knownB,
   spellDiff=diff,offhand=targetOff}
 if scoreB>0 and knownC+knownB>0 and result.statsAvailable then
  result.statChange=(scoreC-scoreB)/scoreB*100
 end
 if equalItem(link,currentLink) and not (targetTwoHand and off) then
  result.same=true;result.statChange=0;result.statDelta=0
 end
 -- For Elemental and Restoration the weapon DPS itself does not represent
 -- spell/healing throughput. Return the raw spell-related deltas separately.
 if class=='SHAMAN' and (spec=='elemental' or spec=='restoration') then
  result.mode='spellWeapon'
  return result,nil
 end
 if targetOff then
  result.mode='offhand';return result,'보조장비는 별도의 직접 근접 DPS 모델 대상이 아닙니다'
 end
 local weapon,why=self:ReadWeapon(link)
 if not weapon then return result,why end
 result.weaponCandidate=weapon
 local equipped,whyOld=self:ReadWeapon(main)
 if not equipped then return result,'현재 착용 무기: '..tostring(whyOld) end
 result.weaponEquipped=equipped
 local ap=getAP()
 local newAP=ap and math.max(0,ap+((goodC and goodB) and meleeAPDelta(cStats,bStats,class) or 0)) or nil
 local isEnh=(class=='SHAMAN' and spec=='enhancement')
 local mine=simpleWeaponModel(equipped,ap,currentTwoHand,isEnh)
 local theirs=simpleWeaponModel(weapon,newAP,targetTwoHand,isEnh)
 result.modelBase=mine.total;result.modelCandidate=theirs.total
 result.modelDelta=theirs.total-mine.total
 result.modelPct=mine.total>0 and (theirs.total-mine.total)/mine.total*100 or nil
 result.modelAPKnown=ap~=nil and goodC and goodB
 result.modelDetail={old=mine,new=theirs,weaponDelta=weapon.dps-equipped.dps,
    averageDelta=weapon.baseAverage-equipped.baseAverage}
 result.procWarning=weapon.special or equipped.special
 result.mode=isEnh and 'enhWeapon' or 'meleeWeapon'
 if result.same then result.modelDelta=0;result.modelPct=0 end
 return result,nil
end
B.WeaponModel=simpleWeaponModel

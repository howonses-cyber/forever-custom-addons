local _, B = ...
-- Comparison engine for the Forever (modern) client. All percentages below
-- compare weighted *recognized item stats* against the player's CURRENT gear.
-- They are not simulated DPS, healing, mitigation, or full item values.
local statByAPI = {
 ITEM_MOD_STRENGTH_SHORT='str', ITEM_MOD_AGILITY_SHORT='agi',
 ITEM_MOD_STAMINA_SHORT='sta', ITEM_MOD_INTELLECT_SHORT='int',
 ITEM_MOD_SPIRIT_SHORT='spi', ITEM_MOD_ATTACK_POWER_SHORT='ap',
 ITEM_MOD_RANGED_ATTACK_POWER_SHORT='rap',
 ITEM_MOD_SPELL_POWER_SHORT='sp', ITEM_MOD_SPELL_DAMAGE_DONE_SHORT='sp',
 ITEM_MOD_SPELL_HEALING_DONE_SHORT='heal', ITEM_MOD_HEALING_DONE_SHORT='heal',
 ITEM_MOD_HIT_RATING_SHORT='hit', ITEM_MOD_HIT_PERCENT_SHORT='hit',
 ITEM_MOD_CRIT_RATING_SHORT='crit', ITEM_MOD_CRIT_PERCENT_SHORT='crit',
 ITEM_MOD_SPELL_HIT_RATING_SHORT='spellhit', ITEM_MOD_SPELL_HIT_PERCENT_SHORT='spellhit',
 ITEM_MOD_SPELL_CRIT_RATING_SHORT='spellcrit', ITEM_MOD_SPELL_CRIT_PERCENT_SHORT='spellcrit',
 ITEM_MOD_HASTE_RATING_SHORT='haste', ITEM_MOD_SPELL_HASTE_RATING_SHORT='haste',
 ITEM_MOD_EXPERTISE_RATING_SHORT='expertise', ITEM_MOD_DEFENSE_SKILL_RATING_SHORT='def',
 ITEM_MOD_DODGE_RATING_SHORT='dodge', ITEM_MOD_PARRY_RATING_SHORT='parry',
 ITEM_MOD_BLOCK_RATING_SHORT='block', ITEM_MOD_ARMOR_SHORT='armor',
 RESISTANCE0_NAME='armor', ITEM_MOD_MANA_REGENERATION_SHORT='mp5',
 ITEM_MOD_FROST_DAMAGE_SHORT='frost', ITEM_MOD_FIRE_DAMAGE_SHORT='fire',
 ITEM_MOD_SHADOW_DAMAGE_SHORT='shadow', ITEM_MOD_NATURE_DAMAGE_SHORT='nature'
}
B.statByAPI = statByAPI
local function validNumber(v)
 return type(v)=='number' and v==v and v<100000000 and v>-100000000
end
local function loadInfo(link)
 if C_Item and type(C_Item.GetItemInfo)=='function' then return C_Item.GetItemInfo(link) end
 if type(GetItemInfo)=='function' then return GetItemInfo(link) end
end
local function getName(link)
 if not link then return '미착용' end
 local ok,name=pcall(loadInfo,link)
 if ok and type(name)=='string' and name~='' then return name end
 return type(link)=='string' and (link:match('|h%[(.-)%]|h') or link:match('item:(%d+)')) or '장비'
end
B.GetEquippedName = getName
function B:WeightedStats(stats,class,spec)
 if type(stats)~='table' then return nil,'아이템 스탯 정보 없음' end
 local weights=self:GetWeights(class,spec)
 local points,recognized,scored,unmapped=0,0,0,0
 local excluded={}
 for raw,val in pairs(stats) do
  if validNumber(val) then
   local key=statByAPI[raw]
   if key then
    recognized=recognized+1
    local weight=weights[key]
    if validNumber(weight) and weight~=0 then
     scored=scored+1
     points=points+val*weight
    else excluded[#excluded+1]=raw end
   else
    unmapped=unmapped+1
   end
  end
 end
 if scored==0 then
  if recognized>0 then return nil,'특성 가중치에 해당하는 스탯 없음' end
  return nil,'측정 가능한 스탯 없음'
 end
 return points,nil,{scored=scored,recognized=recognized,unmapped=unmapped,excluded=excluded}
end
function B:ScoreItem(link,class,spec)
 if not link then return nil,'아이템 링크 없음' end
 -- GetItemStats was removed from Forever's retail-derived UI API.
 local getter=(C_Item and type(C_Item.GetItemStats)=='function') and C_Item.GetItemStats or GetItemStats
 if type(getter)~='function' then return nil,'C_Item.GetItemStats API 없음' end
 local ok,stats=pcall(getter,link)
 if not ok or type(stats)~='table' then
  local id=type(link)=='string' and tonumber(link:match('item:(%d+)')) or nil
  if id and C_Item and C_Item.RequestLoadItemDataByID then
   pcall(C_Item.RequestLoadItemDataByID,id)
  end
  return nil,'아이템 스탯 조회 대기'
 end
 return self:WeightedStats(stats,class,spec)
end
local slotToEquip={Head=1,Neck=2,Shoulder=3,Back=15,Chest=5,Wrist=9,
 Hands=10,Waist=6,Legs=7,Feet=8,Finger=11,Trinket=13,
 MainHand=16,OffHand=17,TwoHand=16,Ranged=18,Relic=18}
B.slotToEquip=slotToEquip
local locations={
 INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},
 INVTYPE_CLOAK={15},INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WRIST={9},
 INVTYPE_HAND={10},INVTYPE_WAIST={6},INVTYPE_LEGS={7},INVTYPE_FEET={8},
 INVTYPE_FINGER={11,12},INVTYPE_TRINKET={13,14},
 INVTYPE_RANGED={18},INVTYPE_RANGEDRIGHT={18},INVTYPE_THROWN={18},INVTYPE_RELIC={18},
 INVTYPE_WEAPONMAINHAND={16},INVTYPE_WEAPONOFFHAND={17},INVTYPE_SHIELD={17},
 INVTYPE_HOLDABLE={17},INVTYPE_2HWEAPON={16,17},INVTYPE_WEAPON={16,17}
}
function B:ResolveEquipLocation(link)
 if not link then return nil end
 local getter=(C_Item and type(C_Item.GetItemInfoInstant)=='function') and C_Item.GetItemInfoInstant or GetItemInfoInstant
 if type(getter)=='function' then
  local ok,_,_,_,loc=pcall(getter,link)
  if ok and type(loc)=='string' and loc~='' then return loc end
 end
 local info=(C_Item and type(C_Item.GetItemInfo)=='function') and C_Item.GetItemInfo or GetItemInfo
 if type(info)=='function' then
  local ok,a,b,c,d,e,f,g,h,loc=pcall(info,link)
  if ok and type(loc)=='string' and loc~='' then return loc end
 end
 return nil
end
local function equippedAt(slot)
 if type(GetInventoryItemLink)~='function' then return nil end
 local ok,link=pcall(GetInventoryItemLink,'player',slot)
 if ok and type(link)=='string' and link~='' then return link end
end
local function sameItem(a,b)
 if not a or not b then return false end
 if a==b then return true end
 local ia,ib=a:match('item:(%d+)'),b:match('item:(%d+)')
 return ia and ib and ia==ib
end
local function slotLabel(id)
 local names={
 [1]='머리',[2]='목',[3]='어깨',[5]='가슴',[6]='허리',[7]='다리',[8]='발',
 [9]='손목',[10]='손',[11]='반지 1',[12]='반지 2',[13]='장신구 1',
 [14]='장신구 2',[15]='망토',[16]='주무기',[17]='보조장비',[18]='원거리/성물'}
 return names[id] or '장비'
end
B.EquipSlotLabel=slotLabel
local function playerHandType(self)
 local main=equippedAt(16)
 return main and self:ResolveEquipLocation(main) or nil
end
function B:ChooseEquipped(slot,link,class,spec)
 if type(GetInventoryItemLink)~='function' then return nil,'현재 착용 장비 조회 API 없음' end
 local loc=self:ResolveEquipLocation(link)
 local ids=locations[loc]
 if not ids then
  if slot and slotToEquip[slot] then ids={slotToEquip[slot]} end
 end
 if not ids or not ids[1] then return nil,'장착할 슬롯을 확인할 수 없음' end
 -- A 2H weapon replaces the combined main-hand and off-hand setup.
 if loc=='INVTYPE_2HWEAPON' or slot=='TwoHand' then
  local main=equippedAt(16);local off=equippedAt(17)
  if not main then return nil,'주무기 미착용',0,16 end
  local m,why=self:ScoreItem(main,class,spec)
  if m==nil then return nil,'현재 주무기: '..(why or '스탯 조회 실패') end
  local total=m
  if off then
   local o,reason=self:ScoreItem(off,class,spec)
   if o==nil then return nil,'현재 보조장비: '..(reason or '스탯 조회 실패') end
   total=total+o
  end
  return main,nil,total,16,(off and getName(main)..' + '..getName(off) or getName(main))
 end
 local currentHand=playerHandType(self)
 if (loc=='INVTYPE_WEAPON' or loc=='INVTYPE_WEAPONMAINHAND' or loc=='INVTYPE_WEAPONOFFHAND'
  or loc=='INVTYPE_SHIELD' or loc=='INVTYPE_HOLDABLE' or slot=='MainHand' or slot=='OffHand')
  and currentHand=='INVTYPE_2HWEAPON' then
  return nil,'양손 무기 착용 중: 한손 무기는 단독 교체 %를 계산하지 않음'
 end
 if loc=='INVTYPE_WEAPON' then
  if slot=='OffHand' then ids={17} else ids={16} end
 elseif slot=='OffHand' and loc~='INVTYPE_2HWEAPON' then ids={17} end
 -- First prefer the *same equipped item* so hovering an equipped ring shows 0%.
 -- Otherwise choose the lowest EP occupied socket, which makes it explicit which
 -- ring/trinket is the replacement candidate. Empty slots are shown separately.
 local options,empty,errors={},nil,{}
 for _,id in ipairs(ids) do
  local current=equippedAt(id)
  if not current then
   if not empty then empty=id end
  else
   local score,why=self:ScoreItem(current,class,spec)
   if score==nil then errors[#errors+1]=slotLabel(id)..' '..(why or '측정 실패')
   else
    options[#options+1]={link=current,score=score,id=id,name=getName(current),match=sameItem(link,current)}
   end
  end
 end
 if #errors>0 then return nil,table.concat(errors,'; ') end
 for _,p in ipairs(options) do
  if p.match then return p.link,nil,p.score,p.id,p.name end
 end
 -- For two equip slots, fill empty before replacing an already-equipped item.
 if empty then return nil,slotLabel(empty)..' 미착용',0,empty end
 table.sort(options,function(a,b)
  if a.score==b.score then return a.id<b.id end
  return a.score<b.score
 end)
 local best=options[1]
 if best then return best.link,nil,best.score,best.id,best.name end
 return nil,'해당 부위 미착용',0,ids[1]
end
function B:Compare(link,class,spec,slot)
 local loc=self:ResolveEquipLocation(link)
 if self.IsWeaponLike and self:IsWeaponLike(loc,slot) then
  return self:CompareWeapon(link,class,spec,slot,loc)
 end
 local candidate,why,details=self:ScoreItem(link,class,spec)
 if candidate==nil then return nil,why end
 local current,reason,base,equippedSlot,equippedName=self:ChooseEquipped(slot,link,class,spec)
 local out={candidate=candidate,equipped=base,compared=current,comparedName=equippedName,
            equippedSlot=equippedSlot,details=details,
            limited=(self:ResolveEquipLocation(link)=='INVTYPE_2HWEAPON' or
                     self:ResolveEquipLocation(link)=='INVTYPE_WEAPON' or
                     self:ResolveEquipLocation(link)=='INVTYPE_WEAPONMAINHAND' or
                     self:ResolveEquipLocation(link)=='INVTYPE_WEAPONOFFHAND' or
                     self:ResolveEquipLocation(link)=='INVTYPE_TRINKET' or
                     slot=='Trinket' or slot=='TwoHand')}
 if base==nil then return out,reason end
 out.delta=candidate-base
 if not current or base<=0 then
  out.noBaseline=true
  return out,reason or '현재 착용 장비의 점수가 0 이하입니다'
 end
 local pct=(candidate-base)/base*100
 if not validNumber(pct) or pct>9999 or pct < -1000 then return out,'점수 차이 이상치' end
 out.change=pct
 return out,nil
end
function B:FindLocalItem(name)
 if type(name)~='string' then return nil end
 local get=(C_Item and type(C_Item.GetItemInfo)=='function') and C_Item.GetItemInfo or GetItemInfo
 if type(get)~='function' then return nil end
 local function attempt(info)
  local ok,n,link=pcall(get,info)
  if ok and n and type(link)=='string' and link:find('item:',1,true) then return link end
 end
 local found=attempt(name)
 if found then return found end
 local id=self.ResolveItemID and self:ResolveItemID(name) or nil
 if id and id>0 then
  local link=attempt('item:'..tostring(id))
  if link then return link end
  if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID,id) end
 end
 return nil
end

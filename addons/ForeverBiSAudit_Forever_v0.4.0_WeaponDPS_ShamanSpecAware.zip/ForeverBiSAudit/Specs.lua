local _, B = ...
B.classOrder={'WARRIOR','PALADIN','HUNTER','ROGUE','PRIEST','SHAMAN','MAGE','WARLOCK','DRUID'}
B.classNames={WARRIOR='전사',PALADIN='성기사',HUNTER='사냥꾼',ROGUE='도적',PRIEST='사제',SHAMAN='주술사',MAGE='마법사',WARLOCK='흑마법사',DRUID='드루이드'}
B.specs={
 WARRIOR={{key='arms',label='무기 DPS'},{key='fury',label='분노 DPS'},{key='protection',label='방어 탱커'}},
 PALADIN={{key='holy',label='신성 힐러'},{key='protection',label='보호 탱커'},{key='retribution',label='징벌 DPS'}},
 HUNTER={{key='beast-mastery',label='야수 DPS'},{key='marksmanship',label='사격 DPS'},{key='survival',label='생존 DPS'}},
 ROGUE={{key='assassination',label='암살 DPS'},{key='combat',label='전투 DPS'},{key='subtlety',label='잠행 DPS'}},
 PRIEST={{key='discipline',label='수양 힐러'},{key='holy',label='신성 힐러'},{key='shadow',label='암흑 DPS'}},
 SHAMAN={{key='elemental',label='정기 DPS'},{key='enhancement',label='고양 DPS'},{key='restoration',label='복원 힐러'}},
 MAGE={{key='arcane',label='비전 DPS'},{key='fire',label='화염 DPS'},{key='frost',label='냉기 DPS'}},
 WARLOCK={{key='affliction',label='고통 DPS'},{key='demonology',label='악마 DPS'},{key='destruction',label='파괴 DPS'}},
 DRUID={{key='balance',label='조화 DPS'},{key='feral-cat',label='야성 표범 DPS'},{key='feral-bear',label='야성 곰 탱커'},{key='restoration',label='회복 힐러'}},
}
B.defaultSpec={WARRIOR='arms',PALADIN='retribution',HUNTER='marksmanship',ROGUE='combat',PRIEST='shadow',SHAMAN='enhancement',MAGE='frost',WARLOCK='destruction',DRUID='feral-cat'}
B.slotOrder={'Head','Neck','Shoulder','Back','Chest','Wrist','Hands','Waist','Legs','Feet','Finger','Trinket','MainHand','OffHand','TwoHand','Ranged','Relic'}
B.slotNames={Head='머리',Neck='목',Shoulder='어깨',Back='망토',Chest='가슴',Wrist='손목',Hands='손',Waist='허리',Legs='다리',Feet='발',Finger='반지',Trinket='장신구',MainHand='주장비',OffHand='보조장비',TwoHand='양손 무기',Ranged='원거리',Relic='성물'}
B.statNames={str='힘',agi='민첩',sta='체력',int='지능',spi='정신력',ap='전투력',rap='원거리 전투력',sp='주문력',heal='치유량',hit='적중',crit='치명타',spellhit='주문 적중',spellcrit='주문 치명타',haste='가속',expertise='숙련',def='방어 숙련',dodge='회피',parry='무기 막기',block='방패 막기',armor='방어도',mp5='5초당 마나',frost='냉기 주문력',fire='화염 주문력',shadow='암흑 주문력',nature='자연 주문력'}
-- Source weights are estimates; NOT measured DPS/throughput.
-- Enhancement approximate starting weights based on 2026-11-23 ForeverWoW.gg pre-raid stat-priority page;
-- other scales are conservative generic priors for a fully functional comparison interface.
local w=B
local melee={str=1,agi=.7,ap=.45,hit=1.05,crit=.82,haste=.8,expertise=1.4,sta=.10}
local rogue={agi=1,str=.7,ap=.5,hit=1.2,crit=.85,haste=.9,expertise=1.35,sta=.08}
local hunter={agi=1,int=.5,rap=.3,ap=.15,hit=1.1,crit=.8,haste=.55,sta=.08}
local caster={sp=1,int=.3,spi=.10,spellhit=1.25,hit=1,spellcrit=.65,crit=.65,haste=.8,mp5=.2,sta=.10}
local healer={heal=1,sp=.75,int=.7,spi=.5,mp5=1.6,spellcrit=.55,crit=.55,haste=.6,sta=.12}
local tank={str=.65,sta=1,agi=.35,def=1.25,dodge=1.1,parry=1,block=.8,armor=.08,hit=.7,expertise=.7,ap=.15}
local function copy(t) local o={}for k,v in pairs(t)do o[k]=v end return o end
B.scales={default=melee}
for cls,list in pairs(B.specs) do
 for _,s in ipairs(list) do
  local key=cls..':'..s.key
  local wt
  if s.key=='restoration' or s.key=='holy' or s.key=='discipline' then wt=healer
  elseif s.key=='protection' or s.key=='feral-bear' then wt=tank
  elseif cls=='MAGE' or cls=='WARLOCK' or s.key=='elemental' or s.key=='balance' or s.key=='shadow' then wt=caster
  elseif cls=='ROGUE' or s.key=='feral-cat' then wt=rogue
  elseif cls=='HUNTER' then wt=hunter
  else wt=melee end
  B.scales[key]=copy(wt)
 end
end
B.scales['SHAMAN:enhancement']={str=1,agi=.65,int=.89,sta=.1,ap=.45,sp=.62,hit=.95,spellhit=.95,crit=.84,haste=.98,expertise=1.85,mp5=.3,nature=.29,fire=.10}
B.scales['HUNTER:marksmanship']={agi=1,int=.58,sta=.1,ap=.10,rap=.30,hit=1.11,crit=.84,haste=.38,expertise=.31,mp5=.21}
B.scales['MAGE:frost']={sp=1,frost=.85,hit=1.64,spellhit=1.64,haste=1.09,crit=.65,spellcrit=.65,int=.18,sta=.15,mp5=.1,spi=.05}
B.scales['PRIEST:holy']={heal=1,sp=1,spi=.7,int=.7,mp5=1.8,haste=.6,crit=.5,spellcrit=.5,sta=.10}
B.weightOrigin={['SHAMAN:enhancement']='ForeverWoW.gg(2026-11-23) 참고치', ['HUNTER:marksmanship']='ForeverWoW.gg(2026-11-23) 참고치',['MAGE:frost']='ForeverWoW.gg(2026-11-23) 참고치',['PRIEST:holy']='ForeverWoW.gg(2026-11-23) 참고치'}

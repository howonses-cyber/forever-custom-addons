local _, B = ...
-- Modern Forever tooltips are dispatched through TooltipDataProcessor;
-- OnTooltipSetItem was removed from the retail-derived UI API.
local initialized=false
local supported={
 INVTYPE_HEAD=true,INVTYPE_NECK=true,INVTYPE_SHOULDER=true,INVTYPE_CLOAK=true,
 INVTYPE_CHEST=true,INVTYPE_ROBE=true,INVTYPE_WRIST=true,INVTYPE_HAND=true,
 INVTYPE_WAIST=true,INVTYPE_LEGS=true,INVTYPE_FEET=true,
 INVTYPE_FINGER=true,INVTYPE_TRINKET=true,INVTYPE_WEAPON=true,
 INVTYPE_WEAPONMAINHAND=true,INVTYPE_WEAPONOFFHAND=true,
 INVTYPE_2HWEAPON=true,INVTYPE_SHIELD=true,INVTYPE_HOLDABLE=true,
 INVTYPE_RANGED=true,INVTYPE_RANGEDRIGHT=true,INVTYPE_THROWN=true,INVTYPE_RELIC=true
}
local slots={INVTYPE_FINGER='Finger',INVTYPE_TRINKET='Trinket',
 INVTYPE_2HWEAPON='TwoHand',INVTYPE_WEAPON='MainHand',
 INVTYPE_WEAPONMAINHAND='MainHand',INVTYPE_WEAPONOFFHAND='OffHand',
 INVTYPE_HOLDABLE='OffHand',INVTYPE_SHIELD='OffHand',
 INVTYPE_RANGED='Ranged',INVTYPE_RANGEDRIGHT='Ranged',
 INVTYPE_RELIC='Relic'}
local function formatPoints(p)
 return type(p)=='number' and string.format('%.1f',p) or '확인 불가'
end
local function equipSignature()
 if type(GetInventoryItemLink)~='function' then return 'no-api' end
 local a={}
 for _,id in ipairs({1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18}) do
  a[#a+1]=tostring(GetInventoryItemLink('player',id) or '')
 end
 return table.concat(a,';')
end
local function AddInfo(tooltip,data)
 if not B.db or not B.db.showTooltip or not tooltip then return end
 if tooltip~=GameTooltip and tooltip~=ItemRefTooltip then return end
 if tooltip._fbisBusy then return end
 local link=nil
 if tooltip.GetItem then
  local ok,_,itemLink=pcall(tooltip.GetItem,tooltip)
  if ok and type(itemLink)=='string' then link=itemLink end
 end
 if not link and data then
  if type(data.hyperlink)=='string' then link=data.hyperlink
  elseif type(data.id)=='number' and data.id>0 then link='item:'..tostring(data.id) end
 end
 if type(link)~='string' or not link:find('item:',1,true) then return end
 local loc=B:ResolveEquipLocation(link)
 if not supported[loc] then return end
 local cl=UnitClass and select(2,UnitClass('player')) or B.db.class
 if not B.specs[cl] then return end
 local sig=link..'|'..tostring(cl)..'|'..equipSignature()
 if tooltip._fbisSignature==sig then return end
 tooltip._fbisSignature=sig
 tooltip._fbisBusy=true
 local ok,err=pcall(function()
  tooltip:AddLine('Forever BiS |cffb9e4ff현재 착용 장비 대비 EP|r',1,.77,.28)
  local printed=0
  local ordered={}
  if B.db.class==cl then
   for _,sp in ipairs(B.specs[cl]) do
    if sp.key==B.db.spec then ordered[#ordered+1]=sp end
   end
  end
  for _,sp in ipairs(B.specs[cl]) do
   if not (B.db.class==cl and sp.key==B.db.spec) then ordered[#ordered+1]=sp end
  end
  for _,sp in ipairs(ordered) do
   local c,reason=B:Compare(link,cl,sp.key,slots[loc])
   if c and (c.mode=='enhWeapon' or c.mode=='meleeWeapon') then
    if c.modelPct~=nil then
     local d=c.modelPct
     tooltip:AddDoubleLine(sp.label,'무기 물리 모델 '..(d>=0 and '+' or '')..string.format('%.1f%%',d),
       1,1,1,d>=0 and .39 or 1,d>=0 and 1 or .47,.60)
     tooltip:AddLine('  장착 기준: '..tostring(c.comparedName or '-')..' / 모델 '..formatPoints(c.modelBase)..' > '..formatPoints(c.modelCandidate),.66,.81,.95,true)
     local old,new=c.weaponEquipped,c.weaponCandidate
     tooltip:AddLine('  기본 무기 DPS '..formatPoints(old.dps)..' > '..formatPoints(new.dps)..' / 공속 '..string.format('%.2f',old.speed)..' > '..string.format('%.2f',new.speed),.70,.80,.94,true)
     if sp.key=='enhancement' and cl=='SHAMAN' then
      tooltip:AddLine('  질풍 20% x 추가 2회 + 폭풍의 일격 8초/100% 가정',.73,.86,.68,true)
     end
     if not c.modelAPKnown then tooltip:AddLine('  AP/장비 스탯 일부 미확인: 무기 물리 수치 기반 추정',1,.69,.43,true) end
     if c.procWarning then tooltip:AddLine('  발동 효과 있는 무기: 발동 피해/확률/내부 쿨 미반영',1,.64,.37,true) end
     printed=printed+1
    else
     tooltip:AddDoubleLine(sp.label,'무기 피해/공속 조회 보류',1,1,1,1,.66,.42)
     tooltip:AddLine('  '..tostring(reason or '무기 툴팁 데이터 없음'),.76,.76,.80,true)
    end
   elseif c and (c.mode=='spellWeapon' or c.mode=='offhand') then
    local d=c.spellDiff or {}
    local tag=(sp.key=='restoration' or sp.key=='holy') and '치유 관련 스탯' or '주문 관련 스탯'
    tooltip:AddDoubleLine(sp.label,tag..' 비교 (물리 DPS 제외)',1,1,1,.70,.88,1)
    tooltip:AddLine('  착용 기준: '..tostring(c.comparedName or '-'),.68,.80,.91,true)
    if not c.statsAvailable then
     tooltip:AddLine('  스탯 API 응답 부족: 주문/치유 성능 변화 판정 보류',1,.65,.42,true)
    else
     tooltip:AddLine('  주문력 '..string.format('%+d',d.sp or 0)..' / 치유량 '..string.format('%+d',d.heal or 0)..' / 지능 '..string.format('%+d',d.intel or 0),.67,.86,.75,true)
     tooltip:AddLine('  치명점수 '..string.format('%+d',d.crit or 0)..' / 가속점수 '..string.format('%+d',d.haste or 0)..' / MP5 '..string.format('%+d',d.mp5 or 0),.73,.79,.88,true)
     if c.statKnown>0 then
      tooltip:AddLine('  스탯 EP '..formatPoints(c.statEquipped)..' > '..formatPoints(c.statCandidate)..' ('..string.format('%+.1f',c.statDelta)..') - DPS/HPS 아님',.72,.76,.81,true)
     else
      tooltip:AddLine('  스탯 EP: 유효 주문/치유 옵션 없음 (효과/무기 발동 미산정)',.96,.74,.45,true)
     end
    end
    printed=printed+1
   elseif c and c.change~=nil then
    local direction=c.change>=0 and '+' or ''
    tooltip:AddDoubleLine(sp.label,direction..string.format('%.1f',c.change)..'% 스탯 EP ('..formatPoints(c.equipped)..' > '..formatPoints(c.candidate)..')',
      1,1,1,c.change>=0 and .4 or 1,c.change>=0 and 1 or .44,.6)
    tooltip:AddLine('  착용 기준: '..tostring(c.comparedName or '-')..' / '..(B.EquipSlotLabel and B.EquipSlotLabel(c.equippedSlot) or ''),.64,.79,.92,true)
    printed=printed+1
   elseif c and c.noBaseline then
    tooltip:AddDoubleLine(sp.label,'비교 슬롯 비어 있음 / '..formatPoints(c.candidate)..' EP',1,1,1,.9,.79,.42)
    tooltip:AddLine('  '..tostring(reason or '착용 장비 기준 % 계산 불가'),.7,.7,.72,true)
    printed=printed+1
   else
    tooltip:AddDoubleLine(sp.label,'비교 보류: '..tostring(reason or '스탯 정보 불충분'),1,1,1,.74,.68,.61)
   end
  end
  if printed==0 then tooltip:AddLine('현재 장착 무기/장비의 비교 근거를 확인하지 못했습니다.',.82,.66,.52) end
  if B.IsWeaponLike and B:IsWeaponLike(loc,slots[loc]) then
   tooltip:AddLine('※ 무기 물리 모델은 장비 교체 시 일부 물리 기여량 추정. 실전 전체 DPS가 아닙니다.',1,.55,.43,true)
   tooltip:AddLine('정기/복원: 주문력·치유 보너스 비교만 지원. 주문 DPS·실제 HPS 미계산.',.76,.76,.83,true)
  else
   tooltip:AddLine('※ % = 장착템 대비 수치 스탯 EP 변화. 실제 DPS/치유량 증가율 아님.',1,.55,.43,true)
  end
 end)
 tooltip._fbisBusy=false
 if not ok and B.Print then B.Print('툴팁 계산 오류: '..tostring(err)) end
end
function B:SetupTooltips()
 if initialized then return end
 initialized=true
 local modern=TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall)=='function'
  and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item~=nil
 if modern then
  local ok=pcall(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,function(tip,data)
   AddInfo(tip,data)
  end)
  if ok then
   for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
    if tip and tip.HookScript then
     pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)
      self._fbisSignature=nil
     end)
    end
   end
   return
  end
 end
 -- Fallback for clients still exposing the old tooltip event.
 for _,tip in ipairs({GameTooltip,ItemRefTooltip}) do
  if tip and tip.HookScript then
   pcall(tip.HookScript,tip,'OnTooltipCleared',function(self)self._fbisSignature=nil end)
   pcall(tip.HookScript,tip,'OnTooltipSetItem',function(self)AddInfo(self)end)
  end
 end
end

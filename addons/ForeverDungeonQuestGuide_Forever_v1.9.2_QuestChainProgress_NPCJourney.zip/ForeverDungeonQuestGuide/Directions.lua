local addon,G = ...
-- Basic, source-grounded written directions. We never infer road, ship or portal
-- connections from point proximity; the existing live navigation stays separate.
local fallbackContinents = {}
for map=1411,1413 do fallbackContinents[map]=1414 end
for map=1416,1437 do fallbackContinents[map]=1415 end
for map=1438,1452 do fallbackContinents[map]=1414 end
fallbackContinents[1453]=1415
fallbackContinents[1454]=1414
fallbackContinents[1455]=1415
fallbackContinents[1456]=1414
fallbackContinents[1457]=1414
fallbackContinents[1458]=1415
local phases={accept="수락",objective="수행",turnin="보고",entrance="입구",inside="던전"}
local function goodPoint(p)
 return type(p)=="table" and type(p.map)=="number" and
  type(p.x)=="number" and type(p.y)=="number" and
  p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
end
local function mapInfo(id)
 return G.SafeCall(C_Map and C_Map.GetMapInfo,id)
end
function G.StepPlace(p)
 if not goodPoint(p) then return nil end
 local info=mapInfo(p.map)
 local zone=(info and type(info.name)=="string" and info.name~="" and info.name) or
  ("지역 미확인 (#"..tostring(p.map)..")")
 local continent=nil
 local visited={}
 local id=p.map
 for _=1,12 do
  if not id or visited[id] then break end
  visited[id]=true
  local i=mapInfo(id)
  if not i then break end
  if i.mapType==2 or id==1414 or id==1415 then
   continent=i.name
   break
  end
  local parent=tonumber(i.parentMapID)
  if not parent or parent<=0 or parent==id then break end
  id=parent
 end
 if not continent then
  local continentId=fallbackContinents[p.map]
  if continentId==1414 then continent="칼림도어" end
  if continentId==1415 then continent="동부 왕국" end
 end
 if continent==zone then continent=nil end
 return {map=p.map,continent=continent,zone=zone,x=p.x,y=p.y,name=p.name}
end
local function stageTitle(step)
 local label=phases[step.kind] or "이동"
 local qname=step.questName
 if type(qname)~="string" or qname=="" then
  qname=step.title or "퀘스트명 미확인"
  local suffix=" - "..label
  if qname:sub(-#suffix)==suffix then qname=qname:sub(1,-#suffix-1) end
 end
 return "["..label.."] "..qname
end
local function actionMessage(step)
 if step.kind=="turnin" then return "NPC에게 말을 걸어 퀘스트를 보고하고 보상을 받으세요." end
 if step.kind=="accept" then return "NPC에게 말을 걸어 퀘스트를 수락하세요." end
 if step.kind=="objective" then return "퀘스트 목표를 수행하세요. 표시 위치는 후보이며 실제 위치가 다를 수 있습니다." end
 if step.kind=="entrance" then return "던전 입구에 도착한 뒤 내부 이동 경로를 확인하세요." end
 if step.kind=="inside" then return "던전 내부의 목표를 수행하세요. 내부 위치는 별도 확인이 필요합니다." end
 return step.note or "퀘스트 로그에서 단계 완료 여부를 확인하세요."
end
function G.BuildStepDirections(step,playerPosition)
 if type(step)~="table" then return nil end
 local title=stageTitle(step)
 local p=step.point
 local area=G.StepPlace(p)
 local indoor=step.indoor or (step.quest and G.QuestInsideInfo and G.QuestInsideInfo(step.quest,step.kind))
 local lines={}
 if indoor then
  lines[#lines+1]="2. "..indoor.dungeon.." 던전에 파티로 입장하세요. 야외 이동은 오른쪽 여정을 확인하세요."
  lines[#lines+1]="3. 내부 "..indoor.room.."에서 NPC "..indoor.npcName.."을(를) 찾으세요. 실내 좌표는 확인되지 않았습니다."
  lines[#lines+1]="4. "..actionMessage(step)
  if indoor.followup then
   lines[#lines+1]="5. 완료 후 연계 퀘스트 "..G.GetQuestName(indoor.followup).."을(를) 확인하세요."
  end
 elseif area then
  if area.continent then
   lines[#lines+1]="2. "..area.continent.." → "..area.zone.." 지역으로 이동하세요."
  else
   lines[#lines+1]="2. "..area.zone.."으로 이동하세요."
  end
  local coord=string.format("%.1f, %.1f",area.x*100,area.y*100)
  local subject=type(p.name)=="string" and p.name~="" and p.name or nil
  if subject then
   local who=(step.kind=="accept" or step.kind=="turnin") and "NPC " or "목표 "
   local suffix=(step.kind=="accept" or step.kind=="turnin") and
    "에게 이동하세요." or " 위치로 이동하세요."
   lines[#lines+1]="3. "..who..subject.." ("..coord..")"..suffix
  else
   lines[#lines+1]="3. "..coord.." 좌표 지점으로 이동하세요."
  end
 elseif step.landmark then
  local landmark=step.landmark
  local region=(landmark.continent and (landmark.continent.." → ") or "")..(landmark.zone or "확인된 장소")
  lines[#lines+1]="2. "..region.."으로 이동하세요."
  lines[#lines+1]="3. 목표 장소: "..(landmark.site or "퀘스트 안내 장소")..". "..(landmark.instruction or "현장에서 목표를 확인하세요.")
  if landmark.note and landmark.note~="" then lines[#lines+1]="참고: "..landmark.note end
 elseif step.regionHint then
  lines[#lines+1]="2. 퀘스트 DB 분류 지역: "..step.regionHint.." (목표의 정확한 출현 지점은 아닙니다)."
  local target=step.objectiveTitle or step.contactName or step.questName or "퀘스트 목표"
  lines[#lines+1]="3. 확인 대상: "..target..". 정확한 출현 좌표가 제공되지 않아 Questie 지도에서 목표를 확인해야 합니다."
 else
  if step.contactName then
   lines[#lines+1]="2. 확인된 NPC: "..step.contactName..". 지역/대륙 좌표는 현재 데이터에 없습니다."
  else
   lines[#lines+1]="2. 지역/대륙 정보가 없어 정확한 이동 안내를 만들 수 없습니다."
  end
  lines[#lines+1]="3. 위치 좌표 미확인: 퀘스트 로그와 지도에서 확인하세요."
 end
 if not indoor and not step.landmark then lines[#lines+1]="4. "..actionMessage(step) end
 if area and not indoor then
  if goodPoint(playerPosition) and playerPosition.map==area.map then
   local label,dir
   if G.RouteDistanceLabel then label,dir=G.RouteDistanceLabel(playerPosition,p) end
   lines[#lines+1]="같은 지도: "..(dir and dir~="" and dir.." 방향 | " or "")..(label or "현재 위치 정보 미확인")
  elseif goodPoint(playerPosition) and playerPosition.map~=area.map then
   lines[#lines+1]="다른 지역입니다. 이동 수단·지형은 오른쪽 실시간 길찾기를 확인하세요."
  end
 end
 lines[#lines+1]="실시간 지형 경로는 오른쪽 애드온이 별도로 표시합니다."
 return {title=title,lines=lines,area=area,indoor=indoor,hasCoordinates=area~=nil}
end

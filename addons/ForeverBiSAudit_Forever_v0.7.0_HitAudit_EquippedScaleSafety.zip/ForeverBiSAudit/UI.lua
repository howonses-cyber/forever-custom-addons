local _,B=...
local frame, scroll, child, detail, selected
local classBtn,specBtn,lockedBtn,unknownBtn,tooltipBtn,counts
local itemRows={}
local function text(parent,size,r,g,b)
 local fs=parent:CreateFontString(nil,'OVERLAY','GameFontNormal')
 fs:SetFont('Fonts\\2002.TTF',size or 12,'OUTLINE')
 fs:SetTextColor(r or .92,g or .94,b or .98)
 fs:SetJustifyH('LEFT');fs:SetJustifyV('MIDDLE')
 return fs
end
local function style(box,bg)
 local t=box:CreateTexture(nil,'BACKGROUND')
 t:SetAllPoints();t:SetColorTexture(bg or .06,.075,.10,.97)
 local corners={}
 for i=1,4 do
  local edge=box:CreateTexture(nil,'BORDER');edge:SetColorTexture(.58,.46,.21,.94)
  if i==1 then edge:SetHeight(1);edge:SetPoint('TOPLEFT');edge:SetPoint('TOPRIGHT')
  elseif i==2 then edge:SetHeight(1);edge:SetPoint('BOTTOMLEFT');edge:SetPoint('BOTTOMRIGHT')
  elseif i==3 then edge:SetWidth(1);edge:SetPoint('TOPLEFT');edge:SetPoint('BOTTOMLEFT')
  else edge:SetWidth(1);edge:SetPoint('TOPRIGHT');edge:SetPoint('BOTTOMRIGHT') end
  corners[#corners+1]=edge
 end
end
local function button(parent,title,width,height,fn)
 local b=CreateFrame('Button',nil,parent)
 b:SetSize(width or 104,height or 27)
 local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.12,.16,.22,.96)
 local line=b:CreateTexture(nil,'BORDER');line:SetHeight(1);line:SetPoint('BOTTOMLEFT');line:SetPoint('BOTTOMRIGHT');line:SetColorTexture(.65,.52,.24,.95)
 local label=text(b,12,.96,.83,.54);label:SetAllPoints();label:SetJustifyH('CENTER');label:SetText(title)
 b.label=label
 b:SetScript('OnClick',function() if fn then fn(b) end end)
 b:SetScript('OnEnter',function()bg:SetColorTexture(.18,.25,.32,1)end)
 b:SetScript('OnLeave',function()bg:SetColorTexture(.12,.16,.22,.96)end)
 return b
end
local function nextClass()
 local idx=1 for i,c in ipairs(B.classOrder) do if c==B.db.class then idx=i;break end end
 B:SetClass(B.classOrder[idx%#B.classOrder+1])
end
local function nextSpec()
 local list=B.specs[B.db.class]
 local idx=1 for i,s in ipairs(list) do if s.key==B.db.spec then idx=i;break end end
 B:SetSpec(list[idx%#list+1].key)
end
local function currentSpecLabel()
 for _,s in ipairs(B.specs[B.db.class]) do if s.key==B.db.spec then return s.label end end
 return B.db.spec
end
local function statOrigin()
 return B.weightOrigin[B.db.class..':'..B.db.spec] or '검증 전 일반 참고 가중치'
end
local function statusLabel(s)
 if s=='locked' then return '미개방',1,.49,.39 end
 if s=='unknown' then return '확인 필요',.94,.77,.43 end
 return '가이드 후보',.55,.86,.71
end
local function showTooltip(row,item)
 if not GameTooltip then return end
 GameTooltip:SetOwner(row,'ANCHOR_RIGHT')
 local link=B:FindLocalItem(item.name)
 if link and GameTooltip.SetHyperlink then GameTooltip:SetHyperlink(link)
 else GameTooltip:AddLine(item.name,.98,.88,.58) end
 GameTooltip:AddLine('출처: '..item.source,.7,.9,1,true)
 GameTooltip:AddLine('분류: '..statusLabel(item.status),1,.8,.46)
 GameTooltip:AddLine('Forever 실제 획득처는 별도 게임 확인 필요',1,.65,.55,true)
 GameTooltip:Show()
end
local function updateDetail(item)
 selected=item
 if not detail then return end
 if not item then
  detail.title:SetText('추천 장비 없음')
  detail.desc:SetText('이 특성의 슬롯별 BiS 자료는 아직 검증되지 않았습니다.\n\n임의의 아이템을 최고 장비로 만들어 표시하지 않습니다.\n\n가방·착용 장비 스탯 비교는 현재 직업 특성별로 사용할 수 있습니다.')
  detail.source:SetText('기본 데이터 / WoW Forever · 자동 감시: /fbis data')
  detail.compare:SetText('현재 장비 대비: 검증할 아이템 없음')
  detail.url:SetText(B.guideURLs[B.db.class..':'..B.db.spec] or '')
  return
 end
 detail.title:SetText(item.name)
 local status=statusLabel(item.status)
 detail.desc:SetText('추천 구분: '..status..'\n'..'슬롯: '..(B.slotNames[item.slot] or item.slot)..'\n'..'획득: '..item.source..'\n\n'..(item.note or ''))
 detail.source:SetText('참고 출처: '..(item.url or '-')..'\n검토 기준일: '..(item.checked or '?')..(item.autoEvidence and '\n독립 출처 일치(획득 검증 아님)' or ''))
 detail.url:SetText(item.url or '')
 local link=B:FindLocalItem(item.name)
 if link then
  local loc=B:ResolveEquipLocation(link)
  local c,why=B:VerifiedEquipPercent(link,B.db.class,B.db.spec,loc)
  if not c then
   detail.compare:SetText('Pawn 평가 불가: '..tostring(why or '아이템 확인 필요')..'\n공식 Pawn과 Pawn Forever 설치 여부를 확인하세요.')
  elseif c.pct==nil then
   detail.compare:SetText('현재 착용: '..tostring(c.comparedName or '-')..'\nPawn 스탯 점수 기준값 0: %는 수학적으로 계산 불가.\n실제 DPS/HPS 상승률을 임의로 만들지 않습니다.')
  else
   local pct=c.pct
   local pretty=(pct>0 and '+' or '')..string.format('%.1f%%',pct)
   detail.compare:SetText('착용: '..tostring(c.comparedName or '-')..'\n'..tostring(c.source)..' 스탯 업그레이드 점수: '..pretty..'\n'..
    ((c.proc or c.hasSet) and '세트/발동 효과 제외: 실제 DPS/HPS 아님' or '실전 DPS/HPS 증가율이 아닌 Pawn Forever 가중치 점수'))
  end

 else
  detail.compare:SetText('스탯 비교 보류: 게임 캐시에 해당 아이템 정보가 없음.\n가방에 있는 아이템은 마우스를 올려 비교하세요.')
 end
end
local function makeRow()
 local row=CreateFrame('Button',nil,child); row:SetHeight(43);row:SetWidth(466)
 local bg=row:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.065,.085,.12,.66)
 local n=text(row,12,.95,.93,.9);n:SetPoint('TOPLEFT',row,'TOPLEFT',10,-6);n:SetWidth(353);n:SetHeight(17)
 local s=text(row,10,.63,.73,.8);s:SetPoint('TOPLEFT',row,'TOPLEFT',10,-23);s:SetWidth(353);s:SetHeight(13)
 local a=text(row,11,.57,.86,.71);a:SetPoint('RIGHT',row,'RIGHT',-7,0);a:SetWidth(90);a:SetJustifyH('RIGHT')
 row.name=n;row.sub=s;row.status=a
 row:SetScript('OnClick',function(self) if self.item then updateDetail(self.item) end end)
 row:SetScript('OnEnter',function(self) bg:SetColorTexture(.15,.20,.26,1);if self.item then showTooltip(self,self.item) end end)
 row:SetScript('OnLeave',function(self) bg:SetColorTexture(.065,.085,.12,.66);if GameTooltip then GameTooltip:Hide() end end)
 return row
end
local function makeSection()
 local row=CreateFrame('Frame',nil,child);row:SetHeight(27);row:SetWidth(466)
 local t=text(row,12,1,.79,.4);t:SetPoint('LEFT',row,'LEFT',8,0)
 row.name=t
 local bar=row:CreateTexture(nil,'BACKGROUND');bar:SetAllPoints();bar:SetColorTexture(.12,.13,.16,.80)
 return row
end
local sections={}
local function refreshList()
 if not child then return end
 for _,row in ipairs(itemRows) do row:Hide() end
 for _,s in ipairs(sections) do s:Hide() end
 local class,spec=B.db.class,B.db.spec
 local y,n,visible=0,0,0
 for _,slot in ipairs(B.slotOrder) do
  local entries=B:GetEntries(class,spec,slot)
  if #entries>0 then
   n=n+1
   if not sections[n] then sections[n]=makeSection() end
   local section=sections[n];section.name:SetText((B.slotNames[slot] or slot)..'  ('..#entries..')')
   section:ClearAllPoints();section:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);section:Show();y=y+28
   for _,item in ipairs(entries) do
    visible=visible+1
    if not itemRows[visible] then itemRows[visible]=makeRow() end
    local row=itemRows[visible];row.item=item
    local localizedItemName=item.name
    local resolvedLink=B:FindLocalItem(item.name)
    local getInfo=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    if resolvedLink and type(getInfo)=='function' then
     local ok,ln=pcall(getInfo,resolvedLink)
     if ok and type(ln)=='string' then localizedItemName=ln end
    end
    row.name:SetText((item.priority<=1 and '|cffffe39d' or '')..localizedItemName..(item.priority<=1 and '|r' or ''))
    row.sub:SetText(item.source)
    local label,r,g,b=statusLabel(item.status);row.status:SetText(label);row.status:SetTextColor(r,g,b)
    row:ClearAllPoints();row:SetPoint('TOPLEFT',child,'TOPLEFT',0,-y);row:Show();y=y+45
   end
  end
 end
 if y==0 then y=50 end
 child:SetHeight(math.max(y+12,350));child:SetWidth(466)
 if scroll and scroll.SetVerticalScroll then scroll:SetVerticalScroll(0) end
 counts:SetText('검토 목록 '..visible..'개 / 미검증 특성·슬롯은 공란 · 자동 자료는 2개 독립 출처 일치만 반영')
 local found=false
 if selected then for _,item in ipairs(B:GetEntries(class,spec)) do if selected==item then found=true;break end end end
 if not found then selected=nil end
 if not selected then
  for _,slot in ipairs(B.slotOrder) do local entries=B:GetEntries(class,spec,slot);if entries[1] then selected=entries[1];break end end
 end
 updateDetail(selected)
end
function B:RefreshUI()
 if not frame or not B.db then return end
 classBtn.label:SetText('직업: '..(B.classNames[B.db.class] or B.db.class)..' ▶')
 specBtn.label:SetText('특성: '..currentSpecLabel()..' ▶')
 lockedBtn.label:SetText('미개방 '..(B.db.showLocked and '포함' or '제외'))
 unknownBtn.label:SetText('확인 필요 '..(B.db.showUnknown and '표시' or '제외'))
 tooltipBtn.label:SetText('가방 툴팁 '..(B.db.showTooltip and '켜짐' or '꺼짐'))
 frame.weightText:SetText('데이터 '..tostring(B.dataVersion)..' · 출처 교차확인 '..tostring(B.autoMeta and B.autoMeta.count or 0)..'개 · Pawn/Pawn Forever 스탯 점수 연동 (발동 피해·실전 DPS는 별도)')
 refreshList()
end
function B:BuildUI()
 if frame or not CreateFrame or not UIParent then return end
 frame=CreateFrame('Frame','ForeverBiSAuditMainFrame',UIParent)
 frame:SetSize(948,642);frame:SetFrameStrata('HIGH');frame:SetToplevel(true)
 frame:EnableMouse(true);frame:SetMovable(true);frame:RegisterForDrag('LeftButton')
 frame:SetClampedToScreen(true)
 frame:SetScript('OnDragStart',function(self)self:StartMoving()end)
 frame:SetScript('OnDragStop',function(self)self:StopMovingOrSizing();local _,_,_,x,y=self:GetPoint();B.db.ui.x=x or 0;B.db.ui.y=y or 0 end)
 frame:SetPoint('CENTER',UIParent,'CENTER',B.db.ui.x or 0,B.db.ui.y or 0)
 style(frame)
 local header=text(frame,18,1,.85,.5);header:SetPoint('TOPLEFT',frame,'TOPLEFT',18,-12);header:SetText('FOREVER BiS AUDIT   |cffffffffV'..tostring(B.version)..'|r')
 local close=button(frame,'X',32,25,function()frame:Hide()end);close:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-12,-11)
 classBtn=button(frame,'직업',160,29,nextClass);classBtn:SetPoint('TOPLEFT',frame,'TOPLEFT',20,-55)
 specBtn=button(frame,'특성',177,29,nextSpec);specBtn:SetPoint('LEFT',classBtn,'RIGHT',6,0)
 lockedBtn=button(frame,'미개방 제외',112,29,function()B.db.showLocked=not B.db.showLocked;B:RefreshUI()end);lockedBtn:SetPoint('LEFT',specBtn,'RIGHT',6,0)
 unknownBtn=button(frame,'확인 필요 표시',135,29,function()B.db.showUnknown=not B.db.showUnknown;B:RefreshUI()end);unknownBtn:SetPoint('LEFT',lockedBtn,'RIGHT',6,0)
 tooltipBtn=button(frame,'가방 툴팁 켜짐',135,29,function()B.db.showTooltip=not B.db.showTooltip;B:RefreshUI()end);tooltipBtn:SetPoint('LEFT',unknownBtn,'RIGHT',6,0)
 frame.weightText=text(frame,11,.78,.82,.89);frame.weightText:SetPoint('TOPLEFT',frame,'TOPLEFT',20,-92);frame.weightText:SetSize(906,18)
 local left=CreateFrame('Frame',nil,frame);left:SetSize(491,449);left:SetPoint('TOPLEFT',frame,'TOPLEFT',20,-124);style(left)
 scroll=CreateFrame('ScrollFrame','ForeverBiSAuditItemScroll',left,'UIPanelScrollFrameTemplate')
 scroll:SetPoint('TOPLEFT',left,'TOPLEFT',7,-7);scroll:SetPoint('BOTTOMRIGHT',left,'BOTTOMRIGHT',-27,7)
 child=CreateFrame('Frame',nil,scroll);child:SetSize(466,400);scroll:SetScrollChild(child)
 local right=CreateFrame('Frame',nil,frame);right:SetSize(403,449);right:SetPoint('TOPLEFT',left,'TOPRIGHT',8,0);style(right)
 detail={}
 detail.title=text(right,16,1,.83,.45);detail.title:SetPoint('TOPLEFT',right,'TOPLEFT',15,-14);detail.title:SetSize(374,46)
 detail.desc=text(right,12,.90,.92,.95);detail.desc:SetPoint('TOPLEFT',right,'TOPLEFT',15,-72);detail.desc:SetSize(370,153);detail.desc:SetJustifyV('TOP')
 local separator=right:CreateTexture(nil,'ARTWORK');separator:SetColorTexture(.32,.34,.38,.9);separator:SetHeight(1);separator:SetPoint('TOPLEFT',right,'TOPLEFT',12,-235);separator:SetPoint('TOPRIGHT',right,'TOPRIGHT',-12,-235)
 detail.compare=text(right,12,.49,.95,.7);detail.compare:SetPoint('TOPLEFT',right,'TOPLEFT',15,-248);detail.compare:SetSize(369,93);detail.compare:SetJustifyV('TOP')
 local copyLabel=text(right,11,1,.79,.43);copyLabel:SetPoint('TOPLEFT',right,'TOPLEFT',15,-346);copyLabel:SetText('원문 주소 (클릭 후 Ctrl+C로 복사)')
 local edit=CreateFrame('EditBox',nil,right,'InputBoxTemplate');edit:SetAutoFocus(false);edit:SetSize(335,24);edit:SetPoint('TOPLEFT',right,'TOPLEFT',26,-368)
 edit:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
 edit:SetScript('OnEditFocusGained',function(self)self:HighlightText()end)
 detail.url=edit
 detail.source=text(right,10,.64,.72,.82);detail.source:SetPoint('TOPLEFT',right,'TOPLEFT',15,-413);detail.source:SetSize(368,35)
 detail.source:SetJustifyV('TOP')
 counts=text(frame,11,.68,.84,.92);counts:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',22,45)
 local foot=text(frame,11,1,.58,.46);foot:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT',22,17);foot:SetSize(906,20)
 foot:SetText('Pawn/Pawn Forever 설치 시 특성별 업그레이드 점수 표시. 발동 효과는 DPS 계산에 포함되지 않습니다.')
 B.frame=frame;B.detail=detail
 frame:Hide()
 self:RefreshUI()
end
